export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  password?: string;
  status: 'pending_otp' | 'pending_kyc' | 'kyc_submitted' | 'active' | 'suspended';
  otp: string;
  otpVerified: boolean;
  kycStatus: 'not_submitted' | 'pending' | 'approved' | 'rejected';
  kycDetails?: {
    documentType: string;
    documentNumber: string;
    fileUrl: string;
    submittedAt: string;
    remarks?: string;
  };
  walletBalance: number;
  provideWallet?: number;
  getWallet?: number;
  directWallet?: number;
  levelWallet?: number;
  totalContributed: number;
  totalReceived: number;
  referralCode: string;
  directId?: string;
  directReferralId?: string;
  referredBy?: string;
  sponsorId?: string;
  directSponsorId?: string;
  registeredAt: string;
  role: 'user' | 'admin';
  registrationPin?: string;
  upiId?: string;
  bankName?: string;
  accountNumber?: string;
  ifscCode?: string;
  secondaryUpiId?: string;
  secondaryBankName?: string;
  secondaryAccountNumber?: string;
  secondaryIfscCode?: string;
  levelCommissionDistributed?: boolean;
  activatedWithPin?: boolean;
  currentPlanStep?: 'pending_pin' | 'giver_40' | 'taker_50_1' | 'taker_50_2' | 'taker_25_1' | 'taker_25_2' | 'taker_25_3' | 'completed';
  deviceId?: string;
  deviceInfo?: string;
  isBlocked?: boolean;
  blockedReason?: string;
  _updatedAt?: number;
}

export interface Contribution {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  paymentProof?: string;
  status: 'pending_dispatch' | 'pending_proof' | 'pending_verification' | 'approved' | 'rejected';
  createdAt: string;
  verifiedAt?: string;
  remarks?: string;
  txLink?: string;
}

export interface HelpRequest {
  id: string;
  userId: string;
  userName: string;
  title: string;
  description: string;
  amountRequested: number;
  amountReceived: number;
  documentUrl?: string;
  status: 'pending_review' | 'approved' | 'rejected' | 'completed';
  createdAt: string;
  reviewedAt?: string;
  remarks?: string;
  txLink?: string;
}

export interface Transaction {
  id: string;
  userId: string;
  userName: string;
  type: 'deposit' | 'withdrawal' | 'contribution' | 'payout' | 'referral_bonus' | 'upgrade' | 'growth_bonus' | 'interest' | 'matching_bonus';
  amount: number;
  status: 'pending' | 'completed' | 'rejected';
  description: string;
  createdAt: string;
  paymentMethod?: string;
  walletSource?: 'provide' | 'get' | 'direct' | 'level' | 'main';
  txLink?: string;
}

export interface SpecialOffer {
  id: string;
  title: string;
  description: string;
  badge?: string;
  discountPercent?: number;
  pinPriceOffer?: number;
  bannerUrl?: string;
  isActive: boolean;
  createdAt: string;
}

export interface SystemSettings {
  minContribution: number;
  maxContribution: number;
  minWithdrawal: number;
  referralCommissionPercent: number;
  helpPledgeMatchingPercent: number;
  isRegistrationOpen: boolean;
  maintenanceMode: boolean;
  systemWalletAddress: string;
  systemQRUrl: string;
  autoMatchingEnabled: boolean;
  homeBgImageUrl?: string;
  homeLogoUrl?: string;
  adminHolderName?: string;
  adminBankName?: string;
  adminAccountNumber?: string;
  adminIfscCode?: string;
  whatsappSupportNumber?: string;
  whatsappAutoReplyEnabled?: boolean;
  whatsappAutoReplyMessage?: string;
  websiteButtonEnabled?: boolean;
  websiteButtonText?: string;
  websiteButtonUrl?: string;
  levelAmounts?: number[];
  activationPinPrice?: number;
  giverPaymentAmount?: number;
  dispatchLinksEnabled?: boolean;
  offers?: SpecialOffer[];
}

export interface IssuedPin {
  id: string;
  pinCode: string;
  userId: string;
  userName: string;
  amount: number;
  isUsed: boolean;
  createdAt: string;
  usedAt?: string;
  usedForContributionId?: string;
}

export interface P2PMatch {
  id: string;
  giverId: string; // Contribution ID
  giverUserId: string; // Giver User ID
  giverName: string;
  giverPhone?: string;
  giverEmail?: string;
  takerId: string; // HelpRequest ID
  takerUserId: string; // Taker User ID
  takerName: string;
  takerPhone?: string;
  takerEmail?: string;
  amount: number;
  status: 'pending' | 'pending_verification' | 'completed' | 'rejected';
  createdAt: string;
  pinUsed?: string;
  paymentDetails?: string;
  takerType?: 'withdrawal' | 'get_help';
  matchMethod?: 'auto' | 'manual';
  screenshotUrl?: string;
  paymentSlipUrl?: string;
  submittedAt?: string;
  phLink?: string;
  ghLink?: string;
  adminLink?: string;
  isPhLinkSent?: boolean;
  isGhLinkSent?: boolean;
}

export interface Notification {
  id: string;
  userId: string; // 'all' or specific userId
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  subject: string;
  message: string;
  status: 'open' | 'resolved';
  createdAt: string;
  reply?: string;
  repliedAt?: string;
}

export interface EmailLog {
  id: string;
  recipientEmail: string;
  recipientName: string;
  subject: string;
  body: string;
  sentAt: string;
  status: 'sent' | 'failed';
  type: 'welcome' | 'forgot_password';
}

