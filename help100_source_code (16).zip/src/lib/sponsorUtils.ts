import { User } from '../types';

/**
 * Finds the matching sponsor user from a list of users given any referral input string.
 * Supports:
 * - Direct ID / Referral Code (e.g., ASHU100, DIR-ASHU100)
 * - User ID (e.g., user-ashu, USR-1234)
 * - Email address (e.g., ashuk2968@gmail.com)
 * - Mobile phone number (e.g., 9876543210, +91 9876543210)
 * - Name / First Name (e.g., Ashu Kumar, Ashu)
 * - Full referral URL (e.g. https://domain.com/?ref=ASHU100, ?ref=ASHU100)
 * - Prefix-stripped variants (e.g. ref:ASHU100, code:ASHU100, id:user-ashu, DIR-ASHU100)
 */
export function findSponsorInList(refInput: string | undefined | null, usersList: User[]): User | null {
  if (!refInput) return null;
  const raw = refInput.trim();
  if (!raw) return null;

  // Clean URL params if pasted e.g. https://domain.com/?ref=ASHU100 or ?ref=ASHU100
  let clean = raw;
  if (clean.includes('ref=')) {
    clean = clean.split('ref=')[1].split('&')[0].split('#')[0];
  } else if (clean.includes('/')) {
    const parts = clean.split('/').filter(Boolean);
    const lastPart = parts[parts.length - 1].split('?')[0].split('#')[0];
    if (lastPart && lastPart.length >= 3) {
      clean = lastPart;
    }
  }
  clean = clean.trim();
  if (!clean) return null;

  // Strip common prefixes
  const stripped = clean.replace(/^(id:|code:|ref:|sponsor:|dir-|link:)\s*/i, '').trim();
  const cleanUpper = clean.toUpperCase();
  const cleanLower = clean.toLowerCase();
  const cleanNorm = clean.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
  const strippedUpper = stripped.toUpperCase();
  const strippedNorm = stripped.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
  const phoneDigits = clean.replace(/\D/g, '');

  for (const u of usersList) {
    if (!u) continue;

    const candidates = [
      u.referralCode,
      u.id,
      u.directId,
      u.directReferralId,
      u.email,
      u.phone,
      u.name
    ].filter(Boolean) as string[];

    for (const cand of candidates) {
      const candRaw = cand.trim();
      const candUpper = candRaw.toUpperCase();
      const candLower = candRaw.toLowerCase();
      const candNorm = candRaw.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
      const candDigits = candRaw.replace(/\D/g, '');

      if (
        candUpper === cleanUpper ||
        candLower === cleanLower ||
        candNorm === cleanNorm ||
        candUpper === strippedUpper ||
        candNorm === strippedNorm ||
        (candDigits && phoneDigits && candDigits.length >= 10 && phoneDigits.length >= 10 && candDigits.slice(-10) === phoneDigits.slice(-10))
      ) {
        return u;
      }
    }

    // Also check first name if sponsor name has multiple words (e.g. "Ashu Kumar" -> "ashu")
    if (u.name) {
      const firstName = u.name.trim().split(' ')[0].toLowerCase();
      if (firstName.length >= 3 && (cleanLower === firstName || stripped.toLowerCase() === firstName)) {
        return u;
      }
    }
  }

  return null;
}

/**
 * Returns all direct recruits for a target user.
 */
export function getDirectChildren(targetUser: User, usersList: User[]): User[] {
  if (!targetUser) return [];

  const targetIdentifiers = new Set<string>();
  const addTarget = (val?: string) => {
    if (!val) return;
    const clean = val.trim().toLowerCase();
    if (clean) {
      targetIdentifiers.add(clean);
      targetIdentifiers.add(clean.replace(/[^a-z0-9]/g, ''));
      const noPrefix = clean.replace(/^(id:|code:|ref:|sponsor:|dir-|link:)\s*/i, '').trim();
      if (noPrefix) {
        targetIdentifiers.add(noPrefix);
        targetIdentifiers.add(noPrefix.replace(/[^a-z0-9]/g, ''));
      }
    }
  };

  addTarget(targetUser.id);
  addTarget(targetUser.referralCode);
  addTarget(targetUser.directId);
  addTarget(targetUser.directReferralId);
  addTarget(targetUser.email);
  if (targetUser.referralCode) {
    addTarget(`dir-${targetUser.referralCode.toLowerCase()}`);
  }
  if (targetUser.id) {
    addTarget(`dir-${targetUser.id.toLowerCase()}`);
  }
  if (targetUser.phone) {
    const digits = targetUser.phone.replace(/\D/g, '');
    if (digits) {
      addTarget(digits);
      if (digits.length >= 10) addTarget(digits.slice(-10));
    }
  }
  if (targetUser.name && targetUser.name.length >= 2) {
    addTarget(targetUser.name);
    const firstName = targetUser.name.trim().split(' ')[0];
    if (firstName.length >= 2) addTarget(firstName);
  }

  return usersList.filter(u => {
    if (!u || u.id === targetUser.id) return false;

    // Check if child explicitly references targetUser in sponsor fields
    const childSponsorRefs = [
      u.sponsorId,
      u.directSponsorId,
      u.referredBy
    ].filter(Boolean) as string[];

    for (const ref of childSponsorRefs) {
      const cleanRef = ref.trim().toLowerCase();
      if (!cleanRef) continue;
      const cleanRefNorm = cleanRef.replace(/[^a-z0-9]/g, '');
      const refCleanPrefixRemoved = cleanRef.replace(/^(id:|code:|ref:|sponsor:|dir-|link:)\s*/i, '').trim();
      const refPrefixNorm = refCleanPrefixRemoved.replace(/[^a-z0-9]/g, '');

      if (
        targetIdentifiers.has(cleanRef) ||
        targetIdentifiers.has(cleanRefNorm) ||
        targetIdentifiers.has(refCleanPrefixRemoved) ||
        targetIdentifiers.has(refPrefixNorm)
      ) {
        return true;
      }

      const refDigits = cleanRef.replace(/\D/g, '');
      if (refDigits && refDigits.length >= 10 && targetIdentifiers.has(refDigits.slice(-10))) {
        return true;
      }
    }

    // Resolve child's sponsorId or referredBy directly against all users
    const matchedSponsor = findSponsorInList(u.sponsorId || u.directSponsorId || u.referredBy, usersList);
    if (matchedSponsor) {
      if (
        matchedSponsor.id === targetUser.id ||
        (targetUser.email && matchedSponsor.email && matchedSponsor.email.trim().toLowerCase() === targetUser.email.trim().toLowerCase()) ||
        (targetUser.phone && matchedSponsor.phone && targetUser.phone.replace(/\D/g, '') === matchedSponsor.phone.replace(/\D/g, '') && targetUser.phone.replace(/\D/g, '').length >= 10)
      ) {
        return true;
      }
    }

    return false;
  });
}

/**
 * Returns the direct sponsor User object for a given child user.
 */
export function getSponsorOfUser(childUser: User | null, usersList: User[]): User | null {
  if (!childUser) return null;

  const childSponsorRefs = [
    childUser.sponsorId,
    childUser.directSponsorId,
    childUser.referredBy
  ].filter(Boolean) as string[];

  for (const ref of childSponsorRefs) {
    const matched = findSponsorInList(ref, usersList);
    if (matched && matched.id !== childUser.id) {
      return matched;
    }
  }

  return null;
}
