import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getFirestore, 
  initializeFirestore,
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  getDocs, 
  writeBatch,
  onSnapshot
} from 'firebase/firestore';
import { 
  User, 
  Contribution, 
  HelpRequest, 
  Transaction, 
  SystemSettings, 
  Notification, 
  SupportTicket, 
  IssuedPin, 
  P2PMatch,
  EmailLog
} from '../types';

const metaEnv = (import.meta as any).env || {};

// Only consider Firebase configured if actual environment variables are supplied
const firebaseConfig = {
  apiKey: metaEnv.VITE_FIREBASE_API_KEY || "AIzaSyDAHYiOa1yN5lWE595Nsn412MAy0m43xVU",
  authDomain: metaEnv.VITE_FIREBASE_AUTH_DOMAIN || "help2-dcc45.firebaseapp.com",
  projectId: metaEnv.VITE_FIREBASE_PROJECT_ID || "help2-dcc45",
  storageBucket: metaEnv.VITE_FIREBASE_STORAGE_BUCKET || "help2-dcc45.firebasestorage.app",
  messagingSenderId: metaEnv.VITE_FIREBASE_MESSAGING_SENDER_ID || "639512354686",
  appId: metaEnv.VITE_FIREBASE_APP_ID || "1:639512354686:web:73f4080d0654c84671dd2f",
};

const isConfigured = !!(
  firebaseConfig.apiKey &&
  firebaseConfig.projectId &&
  firebaseConfig.appId
);

let app;
let db: any = null;
let cloudConnectionFailed = false;

if (isConfigured) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    try {
      db = initializeFirestore(app, {
        experimentalAutoDetectLongPolling: true
      });
    } catch {
      db = getFirestore(app);
    }
    console.log('Firebase successfully initialized with environment credentials.');
  } catch (error) {
    console.error('Error initializing Firebase:', error);
    cloudConnectionFailed = true;
  }
} else {
  console.log('Firebase env credentials not present. Running seamlessly in local & server API mode.');
}

// Helper to race an async operation against a timeout to prevent hanging on poor/blocked connection
function withTimeout<T>(promise: Promise<T>, ms = 12000): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error('Firebase operation timeout'));
    }, ms);
    promise.then(
      (res) => {
        clearTimeout(timer);
        resolve(res);
      },
      (err) => {
        clearTimeout(timer);
        reject(err);
      }
    );
  });
}

export { db };

export function isFirebaseEnabled(): boolean {
  return !!db && !cloudConnectionFailed;
}

export function isFirebaseConfigured(): boolean {
  return isConfigured;
}

export function isCloudConnectionFailed(): boolean {
  return cloudConnectionFailed;
}

export function resetCloudConnection() {
  cloudConnectionFailed = false;
  console.log('Firebase cloud connection status reset manually.');
}

function handleFirebaseError(error: any, context: string) {
  const msg = error?.message || String(error);
  console.warn(`Firebase notice [${context}]:`, msg);
  // Only mark connection as permanently failed for catastrophic auth or configuration errors
  if (
    msg.includes('invalid-api-key') || 
    msg.includes('project-not-found')
  ) {
    cloudConnectionFailed = true;
  }
}

// Save a single document safely
async function saveDoc(collectionName: string, docId: string, data: any) {
  if (!db) return;
  try {
    const payload = {
      ...JSON.parse(JSON.stringify(data)),
      _updatedAt: data._updatedAt || Date.now()
    };
    await setDoc(doc(db, collectionName, docId), payload);
  } catch (error: any) {
    handleFirebaseError(error, `saveDoc ${collectionName}/${docId}`);
  }
}

// Bulk save a collection
async function saveCollection(collectionName: string, items: any[]) {
  if (!db) return;
  try {
    const batch = writeBatch(db);
    // Firestore batch limits to 500 operations
    const limitedItems = items.slice(0, 450); 
    for (const item of limitedItems) {
      if (item && item.id) {
        const docRef = doc(db, collectionName, item.id);
        const payload = {
          ...JSON.parse(JSON.stringify(item)),
          _updatedAt: item._updatedAt || Date.now()
        };
        batch.set(docRef, payload);
      }
    }
    await withTimeout(batch.commit(), 10000);
  } catch (error: any) {
    handleFirebaseError(error, `saveCollection ${collectionName}`);
  }
}

// Fetch all items from a collection
async function fetchCollection(collectionName: string): Promise<any[]> {
  if (!db) return [];
  try {
    const querySnapshot = await withTimeout(getDocs(collection(db, collectionName)), 10000);
    const items: any[] = [];
    querySnapshot.forEach((docSnap) => {
      items.push(docSnap.data());
    });
    return items;
  } catch (error: any) {
    handleFirebaseError(error, `fetchCollection ${collectionName}`);
    return [];
  }
}

// Synchronizers for specific data models
export async function saveUserToCloud(user: User) {
  await saveDoc('users', user.id, user);
}

export async function saveUsersToCloud(users: User[]) {
  await saveCollection('users', users);
}

export async function fetchUsersFromCloud(): Promise<User[]> {
  return await fetchCollection('users') as User[];
}

export async function saveContributionToCloud(contribution: Contribution) {
  await saveDoc('contributions', contribution.id, contribution);
}

export async function saveContributionsToCloud(contributions: Contribution[]) {
  await saveCollection('contributions', contributions);
}

export async function fetchContributionsFromCloud(): Promise<Contribution[]> {
  return await fetchCollection('contributions') as Contribution[];
}

export async function saveHelpRequestToCloud(helpRequest: HelpRequest) {
  await saveDoc('helpRequests', helpRequest.id, helpRequest);
}

export async function saveHelpRequestsToCloud(helpRequests: HelpRequest[]) {
  await saveCollection('helpRequests', helpRequests);
}

export async function fetchHelpRequestsFromCloud(): Promise<HelpRequest[]> {
  return await fetchCollection('helpRequests') as HelpRequest[];
}

export async function saveTransactionToCloud(transaction: Transaction) {
  await saveDoc('transactions', transaction.id, transaction);
}

export async function saveTransactionsToCloud(transactions: Transaction[]) {
  await saveCollection('transactions', transactions);
}

export async function fetchTransactionsFromCloud(): Promise<Transaction[]> {
  return await fetchCollection('transactions') as Transaction[];
}

export async function saveSettingsToCloud(settings: SystemSettings) {
  if (!db) return;
  await saveDoc('config', 'systemSettings', settings);
}

export async function fetchSettingsFromCloud(): Promise<SystemSettings | null> {
  if (!db || cloudConnectionFailed) return null;
  try {
    const docSnap = await withTimeout(getDoc(doc(db, 'config', 'systemSettings')), 2500);
    if (docSnap.exists()) {
      return docSnap.data() as SystemSettings;
    }
  } catch (error: any) {
    console.warn('Firebase settings fetch warning (offline/fallback):', error.message || error);
    if (
      error.message?.includes('offline') || 
      error.message?.includes('timeout') ||
      error.message?.includes('permission') || 
      error.message?.includes('unreachable') ||
      error.code?.includes('unavailable') ||
      error.code?.includes('permission-denied')
    ) {
      cloudConnectionFailed = true;
    }
  }
  return null;
}

export async function saveNotificationToCloud(notification: Notification) {
  await saveDoc('notifications', notification.id, notification);
}

export async function saveNotificationsToCloud(notifications: Notification[]) {
  await saveCollection('notifications', notifications);
}

export async function fetchNotificationsFromCloud(): Promise<Notification[]> {
  return await fetchCollection('notifications') as Notification[];
}

export async function saveTicketToCloud(ticket: SupportTicket) {
  await saveDoc('tickets', ticket.id, ticket);
}

export async function saveTicketsToCloud(tickets: SupportTicket[]) {
  await saveCollection('tickets', tickets);
}

export async function fetchTicketsFromCloud(): Promise<SupportTicket[]> {
  return await fetchCollection('tickets') as SupportTicket[];
}

export async function saveIssuedPinToCloud(issuedPin: IssuedPin) {
  await saveDoc('issuedPins', issuedPin.id, issuedPin);
}

export async function saveIssuedPinsToCloud(issuedPins: IssuedPin[]) {
  await saveCollection('issuedPins', issuedPins);
}

export async function fetchIssuedPinsFromCloud(): Promise<IssuedPin[]> {
  return await fetchCollection('issuedPins') as IssuedPin[];
}

export async function saveP2PMatchToCloud(p2pMatch: P2PMatch) {
  await saveDoc('p2pMatches', p2pMatch.id, p2pMatch);
}

export async function saveP2PMatchesToCloud(p2pMatches: P2PMatch[]) {
  await saveCollection('p2pMatches', p2pMatches);
}

export async function fetchP2PMatchesFromCloud(): Promise<P2PMatch[]> {
  return await fetchCollection('p2pMatches') as P2PMatch[];
}

export async function saveCommunityReservesToCloud(reserves: number) {
  if (!db) return;
  await saveDoc('config', 'communityReserves', { value: reserves });
}

export async function fetchCommunityReservesFromCloud(): Promise<number | null> {
  if (!db) return null;
  try {
    const docSnap = await withTimeout(getDoc(doc(db, 'config', 'communityReserves')), 10000);
    if (docSnap.exists()) {
      return docSnap.data().value as number;
    }
  } catch (error: any) {
    console.warn('Firebase reserves fetch notice:', error.message || error);
  }
  return null;
}

export async function saveEmailLogsToCloud(emailLogs: EmailLog[]) {
  await saveCollection('emailLogs', emailLogs);
}

export async function fetchEmailLogsFromCloud(): Promise<EmailLog[]> {
  return await fetchCollection('emailLogs') as EmailLog[];
}

// Subscribe to a real-time Firestore collection stream across all devices
export function subscribeToCollection(collectionName: string, callback: (items: any[]) => void): () => void {
  if (!db) return () => {};
  try {
    const unsub = onSnapshot(
      collection(db, collectionName),
      (querySnapshot) => {
        const items: any[] = [];
        querySnapshot.forEach((docSnap) => {
          items.push(docSnap.data());
        });
        callback(items);
      },
      (error) => {
        handleFirebaseError(error, `onSnapshot ${collectionName}`);
      }
    );
    return unsub;
  } catch (err) {
    handleFirebaseError(err, `subscribeToCollection ${collectionName}`);
    return () => {};
  }
}

export function subscribeUsers(callback: (users: User[]) => void) {
  return subscribeToCollection('users', callback);
}

export function subscribeContributions(callback: (contribs: Contribution[]) => void) {
  return subscribeToCollection('contributions', callback);
}

export function subscribeHelpRequests(callback: (reqs: HelpRequest[]) => void) {
  return subscribeToCollection('helpRequests', callback);
}

export function subscribeTransactions(callback: (txs: Transaction[]) => void) {
  return subscribeToCollection('transactions', callback);
}

export function subscribeNotifications(callback: (notifs: Notification[]) => void) {
  return subscribeToCollection('notifications', callback);
}

export function subscribeTickets(callback: (tickets: SupportTicket[]) => void) {
  return subscribeToCollection('tickets', callback);
}

export function subscribeIssuedPins(callback: (pins: IssuedPin[]) => void) {
  return subscribeToCollection('issuedPins', callback);
}

export function subscribeP2PMatches(callback: (matches: P2PMatch[]) => void) {
  return subscribeToCollection('p2pMatches', callback);
}

export function subscribeEmailLogs(callback: (logs: EmailLog[]) => void) {
  return subscribeToCollection('emailLogs', callback);
}

