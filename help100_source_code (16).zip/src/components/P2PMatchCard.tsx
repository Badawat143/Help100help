import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Clock, Copy, Eye, Activity, User as UserIcon } from 'lucide-react';
import { User, SystemSettings, P2PMatch } from '../types';

interface P2PMatchCardProps {
  key?: React.Key;
  match: P2PMatch;
  currentUser: User;
  users: User[];
  systemSettings: SystemSettings;
  onUpdateP2PMatch: (matchId: string, updates: Partial<P2PMatch>) => void;
  onApproveP2PMatch?: (matchId: string) => boolean;
  onRejectP2PMatch?: (matchId: string) => boolean;
  demoRole: 'giver' | 'taker';
  setDemoRole: (role: 'giver' | 'taker') => void;
  setMatchStatus: (status: string) => void;
  setMatchSlipUrl: (url: string) => void;
  setMatchSlipName: (name: string) => void;
  expandedMatchId: string | null;
  setExpandedMatchId: (id: string | null) => void;
  uploadMatchId: string | null;
  setUploadMatchId: (id: string | null) => void;
  matchUploads: { [key: string]: string };
  setMatchUploads: React.Dispatch<React.SetStateAction<{ [key: string]: string }>>;
  matchPreviewUrls: { [key: string]: string };
  setMatchPreviewUrls: React.Dispatch<React.SetStateAction<{ [key: string]: string }>>;
  viewedSlips: { [key: string]: boolean };
  setViewedSlips: React.Dispatch<React.SetStateAction<{ [key: string]: boolean }>>;
  setActiveSlipPreview: (match: any) => void;
}

export function isUserMatch(user?: User | null, targetIdOrCode?: string): boolean {
  if (!user || !targetIdOrCode) return false;
  const rawTarget = targetIdOrCode.trim();
  if (!rawTarget) return false;

  const target = rawTarget.toLowerCase();
  const cleanTarget = target.replace(/[^a-z0-9]/g, '');

  const uid = (user.id || '').trim().toLowerCase();
  const ucode = (user.referralCode || '').trim().toLowerCase();
  const udid = (user.directId || '').trim().toLowerCase();
  const uphone = (user.phone || '').trim().toLowerCase();
  const uemail = (user.email || '').trim().toLowerCase();
  const uname = (user.name || '').trim().toLowerCase();
  const uusername = ((user as any).username || '').trim().toLowerCase();

  const cleanUid = uid.replace(/[^a-z0-9]/g, '');
  const cleanUcode = ucode.replace(/[^a-z0-9]/g, '');
  const cleanUdid = udid.replace(/[^a-z0-9]/g, '');
  const cleanUphone = uphone.replace(/[^a-z0-9]/g, '');
  const cleanUemail = uemail.replace(/[^a-z0-9]/g, '');
  const cleanUname = uname.replace(/[^a-z0-9]/g, '');
  const cleanUusername = uusername.replace(/[^a-z0-9]/g, '');

  if (cleanTarget === '' && target === '') return false;

  return (
    (uid !== '' && (uid === target || (cleanUid !== '' && cleanUid === cleanTarget))) ||
    (ucode !== '' && (ucode === target || (cleanUcode !== '' && cleanUcode === cleanTarget))) ||
    (udid !== '' && (udid === target || (cleanUdid !== '' && cleanUdid === cleanTarget))) ||
    (uphone !== '' && (uphone === target || (cleanUphone !== '' && (cleanUphone === cleanTarget || target.includes(cleanUphone) || cleanTarget.includes(cleanUphone))))) ||
    (uemail !== '' && (uemail === target || (cleanUemail !== '' && cleanUemail === cleanTarget))) ||
    (uname !== '' && (uname === target || (cleanUname !== '' && cleanUname === cleanTarget) || (cleanUname.length > 2 && cleanTarget.includes(cleanUname)))) ||
    (uusername !== '' && (uusername === target || (cleanUusername !== '' && cleanUusername === cleanTarget)))
  );
}

function CardInlineTimer({ createdAt, status }: { createdAt: string; status: string }) {
  const [timeLeft, setTimeLeft] = useState<number>(0);

  React.useEffect(() => {
    const calculateTimeLeft = () => {
      const createdTime = new Date(createdAt).getTime();
      const expiryTime = createdTime + 24 * 60 * 60 * 1000;
      const diff = Math.max(0, Math.floor((expiryTime - Date.now()) / 1000));
      return diff;
    };

    setTimeLeft(calculateTimeLeft());

    const interval = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(interval);
  }, [createdAt]);

  if (status === 'completed') {
    return <span>00:00:00</span>;
  }
  if (timeLeft <= 0) {
    return <span>00:00:00</span>;
  }

  const h = Math.floor(timeLeft / 3600).toString().padStart(2, '0');
  const m = Math.floor((timeLeft % 3600) / 60).toString().padStart(2, '0');
  const s = (timeLeft % 60).toString().padStart(2, '0');

  return <span>{h}:{m}:{s}</span>;
}

export function P2PMatchCard({
  match,
  currentUser,
  users,
  systemSettings,
  onUpdateP2PMatch,
  onApproveP2PMatch,
  onRejectP2PMatch,
  demoRole,
  setDemoRole,
  setMatchStatus,
  setMatchSlipUrl,
  setMatchSlipName,
  expandedMatchId,
  setExpandedMatchId,
  uploadMatchId,
  setUploadMatchId,
  matchUploads,
  setMatchUploads,
  matchPreviewUrls,
  setMatchPreviewUrls,
  viewedSlips,
  setViewedSlips,
  setActiveSlipPreview,
}: P2PMatchCardProps) {
  const isManuallyDispatched = !!(
    match.id ||
    match.phLink || 
    match.adminLink || 
    match.ghLink || 
    match.isPhLinkSent || 
    match.isGhLinkSent ||
    (match as any).txLink ||
    match.status === 'pending' ||
    match.status === 'pending_verification' ||
    match.paymentSlipUrl ||
    match.screenshotUrl ||
    match.status === 'completed'
  );

  if (systemSettings && systemSettings.dispatchLinksEnabled === false && !isManuallyDispatched) {
    return (
      <div className="bg-amber-500/10 border-2 border-amber-500/40 p-5 rounded-2xl space-y-2 text-center animate-fade-in shadow-md">
        <div className="text-2xl">📢</div>
        <h4 className="font-extrabold text-amber-300 text-sm">
          प्रमोशन पीरियड ऑन (Promotional Phase Active)
        </h4>
        <p className="text-[11px] text-amber-200/90 leading-relaxed max-w-md mx-auto">
          एडमिन द्वारा प्रमोशन पीरियड रखा गया है। एडमिन द्वारा <strong>Link Dispatch ON</strong> करते ही आपका PH / GH पेमेंट लिंक बॉक्स दोनों यूजर्स (Giver & Taker) के डिवाइस में तुरंत दिखने लगेगा।
        </p>
        <p className="text-[10px] text-emerald-300 font-bold bg-emerald-950/60 p-2 rounded-xl border border-emerald-500/30">
          💡 नोट: एडमिन चाहें तो बिना ग्लोबल बटन ON किए भी आपको सीधे मेन्युअली लिंक बॉक्स भेज सकते हैं।
        </p>
        <div className="inline-block bg-amber-500/20 px-3.5 py-1 rounded-full text-[10px] font-bold text-amber-300 border border-amber-500/30 font-mono">
          ⏳ Pending Link Dispatch
        </div>
      </div>
    );
  }

  const isDemoMatch = match.id === 'demo-p2p-match-id';
  const isCurrentUserGiver = isDemoMatch
    ? (demoRole === 'giver')
    : (
        isUserMatch(currentUser, match.giverUserId) ||
        isUserMatch(currentUser, match.giverId) ||
        isUserMatch(currentUser, match.giverName) ||
        (match.giverPhone && currentUser.phone && match.giverPhone.trim() === currentUser.phone.trim()) ||
        (match.giverName && currentUser.name && match.giverName.trim().toLowerCase() === currentUser.name.trim().toLowerCase())
      );

  // Giver & Taker detail lookups
  const isWithdrawalTaker = match.takerType === 'withdrawal';
  const typeLabel = isWithdrawalTaker ? 'P2P Withdrawal' : 'Peer Get Help';

  // Find Giver details (if current user is Taker)
  const giverUser = users.find(u => isUserMatch(u, match.giverUserId) || isUserMatch(u, match.giverName) || isUserMatch(u, match.giverId));
  const cleanGiverName = giverUser ? giverUser.name.toLowerCase().replace(/[^a-z0-9]/g, '') : 'peer';

  const isGiverRoutedToAdmin = !!match.adminLink || match.paymentDetails === 'admin_upi' || match.giverUserId === 'admin' || match.giverName.toLowerCase().includes('admin');
  const giverUpi = isGiverRoutedToAdmin
    ? (systemSettings.systemWalletAddress || 'help100admin@sbin')
    : (giverUser?.upiId || `${cleanGiverName}@okaxis`);

  const senderName = isGiverRoutedToAdmin
    ? (systemSettings.adminHolderName || 'Platform Administrator (Escrow / System ID)')
    : (giverUser?.name || match.giverName);

  const giverBank = isGiverRoutedToAdmin
    ? (systemSettings.adminBankName || 'Admin Settlement Bank')
    : (giverUser?.bankName || 'SBI');

  const giverAccount = isGiverRoutedToAdmin
    ? (systemSettings.adminAccountNumber || 'System Central Account')
    : (giverUser?.accountNumber || 'XXXXX1234');

  const giverIfsc = isGiverRoutedToAdmin
    ? (systemSettings.adminIfscCode || 'SYSTEM_CENTRAL_IFSC')
    : (giverUser?.ifscCode || 'SBIN0001234');

  // Find Taker details (if current user is Giver)
  const isTakerRoutedToAdmin = !!match.adminLink || match.paymentDetails === 'admin_upi' || match.takerUserId === 'admin' || match.takerName.toLowerCase().includes('admin');
  const takerUser = users.find(u => isUserMatch(u, match.takerUserId) || isUserMatch(u, match.takerName) || isUserMatch(u, match.takerId));
  const cleanTakerName = takerUser ? takerUser.name.toLowerCase().replace(/[^a-z0-9]/g, '') : 'peer';

  const takerUpi = isTakerRoutedToAdmin
    ? (systemSettings.systemWalletAddress || 'help100admin@sbin')
    : (takerUser?.upiId || `${cleanTakerName}@okaxis`);

  const recipientName = isTakerRoutedToAdmin
    ? (systemSettings.adminHolderName || 'Platform Administrator (Escrow / System ID)')
    : (takerUser?.name || match.takerName);

  const takerBank = isTakerRoutedToAdmin
    ? (systemSettings.adminBankName || 'Admin Settlement Bank')
    : (takerUser?.bankName || 'HDFC Bank');

  const takerAccount = isTakerRoutedToAdmin
    ? (systemSettings.adminAccountNumber || 'System Central Node Account')
    : (takerUser?.accountNumber || '5010098273615');

  const takerIfsc = isTakerRoutedToAdmin
    ? (systemSettings.adminIfscCode || 'SYSTEM_CENTRAL_IFSC')
    : (takerUser?.ifscCode || 'HDFC0000120');

  const upiPayLink = `upi://pay?pa=${takerUpi}&pn=${encodeURIComponent(recipientName)}&am=${match.amount}&cu=INR`;
  const qrUrl = isTakerRoutedToAdmin && systemSettings.systemQRUrl
    ? systemSettings.systemQRUrl
    : `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(upiPayLink)}`;

  return (
    <div className="flex flex-col items-center justify-center p-2 sm:p-4 bg-slate-900/40 border border-slate-800/60 rounded-3xl space-y-4 max-w-full overflow-hidden shadow-xl">
      
      {/* Demo perspective switcher remains active inside sandbox simulation */}
      {isDemoMatch && (
        <div className="w-full bg-indigo-950 border-b border-indigo-900 px-5 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl">
          <div className="flex items-center gap-1.5 text-indigo-200 text-[11px] font-black uppercase tracking-wider">
            <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
            <span>Sandbox Simulation Controls</span>
          </div>
          <div className="flex items-center gap-1 bg-black/25 p-1 rounded-xl border border-indigo-900/50">
            <button
              type="button"
              onClick={() => setDemoRole('giver')}
              className={`px-3.5 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                demoRole === 'giver'
                  ? 'bg-emerald-500 text-white shadow-md'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              Act as Giver (Sunil)
            </button>
            <button
              type="button"
              onClick={() => setDemoRole('taker')}
              className={`px-3.5 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                demoRole === 'taker'
                  ? 'bg-gradient-to-r from-[#0D6EFD] to-[#00BFFF] text-white shadow-md shadow-[#0D6EFD]/20'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              Act as Taker (Sarah)
            </button>
          </div>
        </div>
      )}

      {isCurrentUserGiver ? (
        /* CARD 1: GIVER'S VIEW MATCH CARD - SPECIFIED DIMENSIONS (420px width, 220px height) */
        <div id={`match-giver-card-${match.id}`} className="w-full sm:w-[420px] max-w-[340px] sm:max-w-[420px] h-auto sm:h-[220px] rounded-2xl p-[20px] bg-gradient-to-br from-purple-950 via-fuchsia-950 to-slate-950 border-2 border-fuchsia-400 text-slate-100 flex flex-col justify-between shadow-2xl relative text-left transition-all hover:border-fuchsia-300">
          <div>
            <div className="text-[14px] font-black tracking-wider uppercase pb-2.5 border-b border-fuchsia-300/30 flex justify-between items-center bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 -mx-[20px] -mt-[20px] p-[12px] mb-3 rounded-t-2xl text-white shadow-md">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-lime-300 animate-pulse shrink-0" />
                <span className="font-extrabold text-xs uppercase tracking-wider text-lime-300">PH LINK</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[9px] font-mono bg-black/30 text-white px-2 py-0.5 rounded border border-white/20">
                  #{match.id.substring(0, 8).toUpperCase()}
                </span>
                <UserIcon className="w-5 h-5 text-white/80 shrink-0" />
              </div>
            </div>

            <div className="mt-3.5 space-y-1.5 text-[12px] font-medium text-slate-300">
              <div className="flex justify-between items-center">
                <span>Amount :</span>
                <span className="font-extrabold text-[#00BFFF]">₹{match.amount}</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Status :</span>
                <span className={`font-black uppercase text-[10px] ${
                  match.status === 'completed' ? 'text-emerald-400' :
                  match.status === 'pending_verification' ? 'text-indigo-400 animate-pulse' :
                  match.status === 'rejected' ? 'text-rose-400' : 'text-amber-400 animate-pulse'
                }`}>
                  {match.status === 'pending' ? 'Pending' :
                    match.status === 'pending_verification' ? 'Pending Verification' :
                    match.status === 'completed' ? 'Completed' : 'Rejected'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span>Timer :</span>
                <span className="font-mono font-bold text-rose-400">
                  <CardInlineTimer createdAt={match.createdAt} status={match.status} />
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span>User Name :</span>
                <span className="font-bold text-white truncate max-w-[180px]">{match.takerName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Mobile :</span>
                <span className="font-mono text-slate-300">{match.takerPhone || '98XXXXXXXX'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span>UPI ID :</span>
                <span className="font-mono font-black text-indigo-300 select-all">{takerUpi}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 mt-4 border-t border-white/5 pt-3">
            <button
              id={`btn-match-view-details-${match.id}`}
              type="button"
              onClick={() => {
                setExpandedMatchId(expandedMatchId === match.id ? null : match.id);
                setUploadMatchId(null);
              }}
              className={`flex-1 py-1.5 text-center text-[11px] font-black uppercase tracking-wider rounded-lg border transition-all active:scale-95 cursor-pointer ${
                expandedMatchId === match.id
                  ? 'bg-slate-800 text-white border-white/35 shadow-inner'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300 border-white/10'
              }`}
            >
              [ View Details ]
            </button>
            <button
              id={`btn-match-payment-done-${match.id}`}
              type="button"
              onClick={() => {
                setUploadMatchId(uploadMatchId === match.id ? null : match.id);
                setExpandedMatchId(null);
              }}
              className={`flex-1 py-1.5 text-center text-[11px] font-black uppercase tracking-wider rounded-lg border transition-all active:scale-95 cursor-pointer ${
                uploadMatchId === match.id
                  ? 'bg-indigo-700 text-white border-indigo-500'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white border-indigo-400/20 shadow-md shadow-indigo-950/50'
              }`}
            >
              [ Payment Done ]
            </button>
          </div>
        </div>
      ) : (
        /* CARD 2: TAKER'S VIEW MATCH CARD - COMPACT STREAMLINED DIMENSIONS (380px max width) */
        <div id={`match-taker-card-${match.id}`} className="w-full sm:w-[380px] max-w-[320px] sm:max-w-[380px] h-auto rounded-2xl p-3.5 bg-gradient-to-br from-emerald-400 via-green-400 to-lime-300 border-2 border-emerald-600 text-slate-950 flex flex-col justify-between shadow-2xl relative text-left transition-all overflow-hidden space-y-2.5">
          <div>
            <div className="text-[13px] font-black tracking-wider uppercase pb-2 border-b border-black/20 flex justify-between items-center bg-slate-950 -mx-3.5 -mt-3.5 p-2.5 mb-2 rounded-t-2xl text-white shadow-md">
              <div className="flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-lime-400 animate-pulse shrink-0" />
                <span className="font-extrabold text-[11px] uppercase tracking-wider text-lime-300 font-mono bg-black/60 px-1.5 py-0.5 rounded border border-lime-400/40">GH LINK</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[8.5px] font-mono bg-lime-400 text-slate-950 px-1.5 py-0.5 rounded font-black border border-lime-300">
                  ACTIVE MATCH
                </span>
                <UserIcon className="w-4 h-4 text-lime-300 shrink-0" />
              </div>
            </div>

            <div className="mt-2 space-y-1.5 text-[11px] font-extrabold text-slate-950">
              <div className="flex justify-between items-center border-b border-black/15 pb-1">
                <span className="flex items-center gap-1 text-slate-900 font-extrabold">🆔 PH Link ID :</span>
                <span className="font-mono text-black font-black select-all bg-emerald-300/80 px-1.5 py-0.5 rounded border border-emerald-600/30 text-[10px]">
                  {match.id}
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-black/15 pb-1">
                <span className="flex items-center gap-1 text-slate-900 font-extrabold">👤 PH User का नाम :</span>
                <span className="font-black text-black truncate max-w-[170px]">{match.giverName}</span>
              </div>
              <div className="flex justify-between items-center border-b border-black/15 pb-1">
                <span className="flex items-center gap-1 text-slate-900 font-extrabold">💰 Amount :</span>
                <span className="font-black text-slate-950 text-sm bg-lime-200 px-1.5 py-0.5 rounded border border-emerald-700/40 shadow-xs">₹{match.amount}</span>
              </div>
              <div className="flex justify-between items-center border-b border-black/15 pb-1">
                <span className="flex items-center gap-1 text-slate-900 font-extrabold">📅 Link समय :</span>
                <span className="font-black text-slate-950 text-[10px]">
                  {match.createdAt ? new Date(match.createdAt).toLocaleString() : new Date().toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-black/15 pb-1">
                <span className="flex items-center gap-1 text-slate-900 font-extrabold">⏳ Payment Timer :</span>
                <span className="font-mono font-black text-black bg-lime-200 px-1.5 py-0.5 rounded shadow-sm border border-emerald-600/40 text-[10.5px]">
                  <CardInlineTimer createdAt={match.createdAt} status={match.status} />
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-black/15 pb-1">
                <span className="flex items-center gap-1 text-slate-900 font-extrabold">🏦 User Name :</span>
                <span className="font-black text-black truncate max-w-[170px]">{giverUser?.name || match.giverName}</span>
              </div>
              <div className="flex justify-between items-center border-b border-black/15 pb-1">
                <span className="flex items-center gap-1 text-slate-900 font-extrabold">📱 User ID :</span>
                <span className="font-mono text-black font-black bg-emerald-300/80 px-1.5 py-0.5 rounded select-all border border-emerald-600/30 text-[10px]">
                  {match.giverUserId}
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-black/15 pb-1">
                <span className="flex items-center gap-1 text-slate-900 font-extrabold">📞 Mobile Number :</span>
                <span className="font-mono text-black font-black select-all bg-emerald-300/50 px-1.5 py-0.5 rounded text-[10.5px]">
                  {giverUser?.phone || match.giverPhone || '+91 94827 50132'}
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-black/15 pb-1">
                <span className="flex items-center gap-1 text-slate-900 font-extrabold">🔍 View Uploaded Slip :</span>
                <span>
                  {(match.paymentSlipUrl || match.screenshotUrl) ? (
                    <button
                      type="button"
                      onClick={() => {
                        setViewedSlips(prev => ({ ...prev, [match.id]: true }));
                        setActiveSlipPreview({ ...match, paymentSlipUrl: match.paymentSlipUrl || '', screenshotUrl: match.screenshotUrl || '' });
                      }}
                      className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-950 hover:bg-black text-white text-[9.5px] font-black uppercase rounded shadow-sm hover:scale-105 active:scale-95 transition-all cursor-pointer border border-black"
                    >
                      View Slip
                    </button>
                  ) : (
                    <span className="text-[9px] text-slate-950 font-bold bg-emerald-300/80 px-1.5 py-0.5 rounded border border-emerald-600/40">Pending Upload</span>
                  )}
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-black/15 pb-1">
                <span className="flex items-center gap-1 text-slate-900 font-extrabold">📌 Payment Status :</span>
                <span className={`px-1.5 py-0.5 rounded text-[9.5px] font-black uppercase ${
                  match.status === 'completed' ? 'bg-emerald-900 text-lime-300 border border-emerald-700' :
                  match.status === 'pending_verification' ? 'bg-slate-900 text-lime-300 border border-slate-700 animate-pulse' :
                  match.status === 'rejected' ? 'bg-rose-950 text-rose-200 border border-rose-700' : 'bg-slate-950 text-lime-300 border border-black animate-pulse'
                }`}>
                  {match.status === 'pending' ? 'Pending' :
                   match.status === 'pending_verification' ? 'Slip Uploaded' :
                   match.status === 'completed' ? 'Verified' : 'Rejected'}
                </span>
              </div>
              {(match.ghLink || match.phLink || match.adminLink) && (
                <div className="flex justify-between items-center border-b border-black/15 pb-1 bg-black/20 p-2 rounded-lg mt-1">
                  <span className="flex items-center gap-1 text-slate-950 font-black text-[10px]">🔗 Dispatched Gateway Link:</span>
                  <a
                    href={(match.ghLink || match.phLink || match.adminLink)!.startsWith('http') ? (match.ghLink || match.phLink || match.adminLink)! : `https://${match.ghLink || match.phLink || match.adminLink}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-950 hover:bg-black text-lime-300 font-black uppercase text-[9px] rounded shadow transition-all border border-black cursor-pointer animate-pulse"
                  >
                    Open Link ↗
                  </a>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 mt-3 border-t border-amber-200/60 pt-2.5">
            <button
              id={`btn-match-reject-${match.id}`}
              type="button"
              onClick={() => {
                if ((match.paymentSlipUrl || match.screenshotUrl) && !viewedSlips[match.id]) {
                  alert("Please click 'View Details/Proofs' first to inspect the payment proofs before rejecting.");
                  setViewedSlips(prev => ({ ...prev, [match.id]: true }));
                  setActiveSlipPreview(match);
                  return;
                }
                const reason = prompt('Please enter a brief rejection reason (e.g. Payment not received / Invalid proof):');
                if (reason === null) return;
                if (onRejectP2PMatch) {
                  onRejectP2PMatch(match.id);
                  if (match.id === 'demo-p2p-match-id') { setMatchStatus('rejected'); }
                  alert('Rejection recorded!');
                } else {
                  onUpdateP2PMatch(match.id, { status: 'rejected' });
                  alert('Rejection recorded!');
                }
              }}
              className="flex-1 py-1.5 text-center text-[11px] font-black uppercase tracking-wider bg-rose-600 hover:bg-rose-700 active:scale-95 transition-all text-white rounded-lg border border-rose-600/10 shadow-sm cursor-pointer shadow-rose-600/15"
            >
              [Reject]
            </button>
            <button
              id={`btn-match-accept-${match.id}`}
              type="button"
              onClick={() => {
                if ((match.paymentSlipUrl || match.screenshotUrl) && !viewedSlips[match.id]) {
                  alert("Please click 'View Details/Proofs' first to inspect the payment proofs before accepting.");
                  setViewedSlips(prev => ({ ...prev, [match.id]: true }));
                  setActiveSlipPreview(match);
                  return;
                }
                if (confirm("Are you absolutely sure you have received the payment of ₹" + match.amount + " in your bank account? This is irreversible.")) {
                  if (onApproveP2PMatch) {
                    onApproveP2PMatch(match.id);
                    if (match.id === 'demo-p2p-match-id') { setMatchStatus('approved'); }
                    alert('Success! Payout match approved and finalized.');
                  } else {
                    onUpdateP2PMatch(match.id, { status: 'completed' });
                    alert('Success! Confirmed.');
                  }
                }
              }}
              className="flex-1 py-1.5 text-center text-[11px] font-black uppercase tracking-wider bg-gradient-to-r from-emerald-500 to-teal-500 hover:opacity-95 active:scale-95 transition-all text-white rounded-lg border border-emerald-500/25 shadow-md cursor-pointer shadow-emerald-500/10"
            >
              [Accept]
            </button>
          </div>
        </div>
      )}

      {/* COLLAPSIBLE 1: GIVER VIEW PAYMENT RECIPIENT DETAILS */}
      {isCurrentUserGiver && expandedMatchId === match.id && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full sm:w-[420px] max-w-[340px] sm:max-w-[420px] bg-slate-900 border border-indigo-500/30 p-4 rounded-xl space-y-3 text-[11px] text-left text-slate-200"
        >
          <div className="flex justify-between items-center border-b border-white/10 pb-1.5">
            <span className="font-bold text-indigo-400 uppercase text-[9px] tracking-wider">⚡ Bank & UPI Routing</span>
            <span className="bg-indigo-500/20 text-indigo-300 font-bold px-2 py-0.5 rounded text-[8.5px]">Pay ₹{match.amount}</span>
          </div>

          <div className="flex gap-3 items-center bg-black/40 p-2.5 rounded-lg border border-white/5">
            <div className="shrink-0 bg-white p-0.5 rounded shadow-sm">
              <img
                src={qrUrl}
                alt="Scan to Pay Taker"
                className="w-16 h-16 object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="flex-1 min-w-0 space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">UPI VPA:</span>
                <div className="flex items-center gap-1">
                  <span className="font-mono font-black text-white select-all truncate max-w-[130px]">{takerUpi}</span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(takerUpi);
                      alert('UPI ID copied to clipboard!');
                    }}
                    className="text-indigo-400 hover:text-white p-0.5 cursor-pointer shrink-0"
                  >
                    <Copy className="w-3 h-3" />
                  </button>
                </div>
              </div>
              <div>
                <span className="text-slate-400 block text-[9.5px]">Recipient:</span>
                <span className="font-bold text-white truncate block max-w-[170px]" title={recipientName}>{recipientName}</span>
              </div>
            </div>
          </div>

          <div className="bg-black/30 p-2.5 rounded-lg border border-white/5 space-y-1">
            <div className="flex justify-between"><span className="text-slate-400">Bank Name:</span><span className="font-bold text-white">{takerBank}</span></div>
            <div className="flex justify-between"><span className="text-slate-400">Account No:</span><span className="font-mono text-white select-all">{takerAccount}</span></div>
            <div className="flex justify-between"><span className="text-slate-400">IFSC Code:</span><span className="font-mono text-white select-all">{takerIfsc}</span></div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <a
              href={upiPayLink}
              className="inline-flex items-center justify-center gap-1 py-1.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-black uppercase text-[9px] tracking-wider rounded-lg shadow transition-all cursor-pointer text-center"
            >
              💳 Open UPI App ↗
            </a>
            {(match.phLink || match.adminLink || match.ghLink) && (
              <a
                href={(match.phLink || match.adminLink || match.ghLink)!.startsWith('http') ? (match.phLink || match.adminLink || match.ghLink)! : `https://${match.phLink || match.adminLink || match.ghLink}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-1 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black uppercase text-[9px] tracking-wider rounded-lg shadow transition-all cursor-pointer text-center animate-pulse"
              >
                🔗 Secure Gateway ↗
              </a>
            )}
          </div>
        </motion.div>
      )}

      {/* COLLAPSIBLE 2: GIVER VIEW PAYMENT PROOF UPLOAD */}
      {isCurrentUserGiver && uploadMatchId === match.id && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full sm:w-[420px] max-w-[340px] sm:max-w-[420px] bg-slate-900 border border-emerald-500/30 p-4 rounded-xl space-y-3 text-[11px] text-left text-slate-200"
        >
          <div className="flex justify-between items-center border-b border-white/10 pb-1.5">
            <span className="font-bold text-emerald-400 uppercase text-[9px] tracking-wider">📤 Upload Transfer Proof</span>
            <span className="text-[8px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded">Required for Audit</span>
          </div>

          <div className="space-y-2">
            <span className="text-[9.5px] font-bold text-slate-300 uppercase tracking-wider block">📄 Payment Slip Receipt</span>
            <div className="relative">
              <input
                id={"p2p-file-input-tracker-slip-" + match.id}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const objectUrl = URL.createObjectURL(file);
                    setMatchUploads(prev => ({ ...prev, [match.id + '-slip']: file.name }));
                    setMatchPreviewUrls(prev => ({ ...prev, [match.id + '-slip']: objectUrl }));
                  }
                }}
              />
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  document.getElementById("p2p-file-input-tracker-slip-" + match.id)?.click();
                }}
                onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
                onDrop={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  const file = e.dataTransfer.files?.[0];
                  if (file) {
                    const objectUrl = URL.createObjectURL(file);
                    setMatchUploads(prev => ({ ...prev, [match.id + '-slip']: file.name }));
                    setMatchPreviewUrls(prev => ({ ...prev, [match.id + '-slip']: objectUrl }));
                  }
                }}
                className="border border-dashed border-white/20 hover:border-white/50 rounded-xl p-3 text-center bg-black/20 hover:bg-black/35 transition-colors cursor-pointer text-white min-h-[50px] flex flex-col justify-center items-center"
              >
                {matchUploads[match.id + '-slip'] ? (
                  <div className="flex items-center gap-1.5 w-full justify-center">
                    {matchPreviewUrls[match.id + '-slip'] ? (
                      <img src={matchPreviewUrls[match.id + '-slip']} className="w-8 h-8 object-cover rounded border border-white/20" alt="Slip" />
                    ) : (
                      <span className="text-emerald-300">📄</span>
                    )}
                    <span className="text-[9.5px] font-bold block truncate">{matchUploads[match.id + '-slip']}</span>
                  </div>
                ) : (
                  <span className="text-[10px] font-bold block text-slate-300">Click or Drag & Drop Slip Receipt</span>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-[9.5px] uppercase font-black text-slate-300 tracking-wider">
              12-Digit UPI Ref No. / UTR Reference
            </label>
            <input
              id={"p2p-utr-input-" + match.id}
              type="text"
              maxLength={12}
              placeholder="e.g. 207569973264"
              className="w-full bg-black/35 border border-white/15 text-white rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:border-indigo-400 transition-colors placeholder:text-slate-600"
            />
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              const slipName = matchUploads[match.id + '-slip']?.trim();
              const utrInput = document.getElementById("p2p-utr-input-" + match.id) as HTMLInputElement;
              const utrValue = utrInput?.value?.trim() || '';

              if (!slipName) {
                alert("Please select/upload a Payment Slip first.");
                return;
              }
              if (!utrValue || utrValue.length < 8) {
                alert("Please enter a valid Transaction ID or UTR Reference number.");
                return;
              }

              const finalSlip = slipName || 'payment_slip.png';
              onUpdateP2PMatch(match.id, {
                status: 'pending_verification',
                paymentSlipUrl: finalSlip,
                screenshotUrl: finalSlip,
                submittedAt: new Date().toISOString()
              });
              if (match.id === 'demo-p2p-match-id') {
                setMatchStatus('submitted');
                setMatchSlipUrl(finalSlip);
                setMatchSlipName(finalSlip);
              }
              alert("Success! Your transaction proof has been submitted.");
              setUploadMatchId(null);
            }}
            className="w-full py-2 bg-white text-slate-900 hover:bg-slate-100 active:scale-95 transition-all text-[11px] font-black uppercase rounded-lg shadow cursor-pointer"
          >
            Submit Proof
          </button>
        </motion.div>
      )}

      {/* COLLAPSIBLE 3: TAKER VIEW PROOF INSPECTION */}
      {!isCurrentUserGiver && match.status === 'pending_verification' && (match.paymentSlipUrl || match.screenshotUrl) && (
        <div className="w-full sm:w-[420px] max-w-[340px] sm:max-w-[420px] bg-slate-900/60 border border-slate-800 p-3 rounded-xl flex items-center justify-between text-[11px] text-slate-300 text-left">
          <span className="truncate max-w-[180px] font-mono text-[9.5px]">📄 Slip: {match.paymentSlipUrl || match.screenshotUrl}</span>
          <button
            type="button"
            onClick={() => {
              setViewedSlips(prev => ({ ...prev, [match.id]: true }));
              setActiveSlipPreview({ ...match, paymentSlipUrl: match.paymentSlipUrl || '', screenshotUrl: match.screenshotUrl || '' });
            }}
            className="px-2.5 py-1 bg-gradient-to-r from-[#0D6EFD] to-[#00BFFF] hover:opacity-95 text-white text-[9.5px] font-black uppercase rounded shadow flex items-center gap-1 cursor-pointer transition-all animate-pulse shadow-blue-500/10"
          >
            <Eye className="w-2.5 h-2.5" /> View Slip
          </button>
        </div>
      )}

    </div>
  );
}
