import React, { useState, useMemo, useRef } from 'react';
import { User, Transaction } from '../types';
import { 
  TrendingUp, 
  HeartHandshake, 
  Activity, 
  Calendar, 
  ArrowUpRight, 
  ArrowDownLeft,
  Info,
  ChevronRight,
  Filter
} from 'lucide-react';

interface FinancialOverviewProps {
  currentUser: User;
  transactions: Transaction[];
}

export default function FinancialOverview({ currentUser, transactions }: FinancialOverviewProps) {
  const [timeFilter, setTimeFilter] = useState<'all' | '30days' | '6months'>('all');
  const [hoveredPointIndex, setHoveredPointIndex] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);

  // Parse and build cumulative data points
  const allPoints = useMemo(() => {
    // 1. Start on user registration date
    const regDate = new Date(currentUser.registeredAt);
    
    // 2. Fetch completed contribution/payout transactions for current user
    const myTx = transactions
      .filter(t => t.userId === currentUser.id && t.status === 'completed' && (t.type === 'contribution' || t.type === 'payout'))
      .map(t => ({
        id: t.id,
        date: new Date(t.createdAt),
        type: t.type,
        amount: t.amount,
        description: t.description
      }))
      // Sort chronologically (oldest first)
      .sort((a, b) => a.date.getTime() - b.date.getTime());

    // 3. Build running cumulative values
    let currentContributed = 0;
    let currentReceived = 0;

    const points = [
      {
        id: 'reg',
        date: regDate,
        contributed: 0,
        received: 0,
        label: 'Registration',
        description: 'Joined Help 100 Mutual Aid Community'
      }
    ];

    for (const tx of myTx) {
      if (tx.type === 'contribution') {
        currentContributed += tx.amount;
      } else if (tx.type === 'payout') {
        currentReceived += tx.amount;
      }

      points.push({
        id: tx.id,
        date: tx.date,
        contributed: currentContributed,
        received: currentReceived,
        label: tx.type === 'contribution' ? 'Contributed Pledge' : 'Help Received',
        description: tx.description
      });
    }

    // 5. Always ensure we have a final data point representing the current status right now
    const now = new Date();
    // Only add if last point is at least a minute older than now
    if (points[points.length - 1].date.getTime() < now.getTime() - 60 * 1000) {
      points.push({
        id: 'now',
        date: now,
        contributed: currentUser.totalContributed,
        received: currentUser.totalReceived,
        label: 'Current Status',
        description: 'Cumulative ledger total'
      });
    }

    return points;
  }, [currentUser, transactions]);

  // Filter points based on selected time filter
  const filteredPoints = useMemo(() => {
    if (timeFilter === 'all') {
      return allPoints;
    }

    const now = new Date();
    const cutoffDate = new Date();
    if (timeFilter === '30days') {
      cutoffDate.setDate(now.getDate() - 30);
    } else if (timeFilter === '6months') {
      cutoffDate.setMonth(now.getMonth() - 6);
    }

    const cutoffTime = cutoffDate.getTime();
    
    // Find any points before cutoff to use as base cumulative values
    let initialContributed = 0;
    let initialReceived = 0;
    
    const visiblePoints = [];

    for (const pt of allPoints) {
      if (pt.date.getTime() < cutoffTime) {
        initialContributed = pt.contributed;
        initialReceived = pt.received;
      } else {
        visiblePoints.push(pt);
      }
    }

    // Prepend a base point at the cutoff line to draw complete paths
    const basePoint = {
      id: 'cutoff-base',
      date: cutoffDate,
      contributed: initialContributed,
      received: initialReceived,
      label: 'Base Period',
      description: 'Starting balance for selected range'
    };

    return [basePoint, ...visiblePoints];
  }, [allPoints, timeFilter]);

  // Dimensions & Grid Configuration for SVG
  const width = 600;
  const height = 260;
  const paddingLeft = 60;
  const paddingRight = 20;
  const paddingTop = 25;
  const paddingBottom = 40;

  const plotW = width - paddingLeft - paddingRight;
  const plotH = height - paddingTop - paddingBottom;

  // Compute Scales
  const scales = useMemo(() => {
    if (filteredPoints.length === 0) return null;

    const times = filteredPoints.map(pt => pt.date.getTime());
    const minX = Math.min(...times);
    const maxX = Math.max(...times);

    const values = filteredPoints.flatMap(pt => [pt.contributed, pt.received]);
    const minY = 0;
    const maxY = Math.max(100, ...values) * 1.15; // 15% head padding

    return { minX, maxX, minY, maxY, spanX: maxX - minX || 1, spanY: maxY - minY };
  }, [filteredPoints]);

  // Map coordinate helpers
  const getX = (date: Date) => {
    if (!scales) return paddingLeft;
    return paddingLeft + ((date.getTime() - scales.minX) / scales.spanX) * plotW;
  };

  const getY = (value: number) => {
    if (!scales) return paddingTop + plotH;
    return paddingTop + plotH - (value / scales.maxY) * plotH;
  };

  // Convert points to SVG drawing coordinates
  const svgPoints = useMemo(() => {
    return filteredPoints.map((pt, idx) => ({
      ...pt,
      x: getX(pt.date),
      yCont: getY(pt.contributed),
      yRec: getY(pt.received),
      index: idx
    }));
  }, [filteredPoints, scales]);

  // SVG Path Builders
  const paths = useMemo(() => {
    if (svgPoints.length === 0) return { contribPath: '', recPath: '', contribArea: '', recArea: '' };

    let contribPath = '';
    let recPath = '';

    // Generate straight / step / curve lines
    svgPoints.forEach((pt, i) => {
      const command = i === 0 ? 'M' : 'L';
      contribPath += `${command} ${pt.x.toFixed(1)} ${pt.yCont.toFixed(1)} `;
      recPath += `${command} ${pt.x.toFixed(1)} ${pt.yRec.toFixed(1)} `;
    });

    // Close areas at the bottom of the plot area (y = paddingTop + plotH)
    const bottomY = paddingTop + plotH;
    const firstX = svgPoints[0].x.toFixed(1);
    const lastX = svgPoints[svgPoints.length - 1].x.toFixed(1);

    const contribArea = `${contribPath} L ${lastX} ${bottomY} L ${firstX} ${bottomY} Z`;
    const recArea = `${recPath} L ${lastX} ${bottomY} L ${firstX} ${bottomY} Z`;

    return { contribPath, recPath, contribArea, recArea };
  }, [svgPoints, plotH]);

  // Compute Axis Ticks
  const yTicks = useMemo(() => {
    if (!scales) return [];
    const ticks = [];
    for (let i = 0; i <= 4; i++) {
      ticks.push((scales.maxY * i) / 4);
    }
    return ticks;
  }, [scales]);

  const xTicks = useMemo(() => {
    if (filteredPoints.length < 2) return [];
    
    // Choose 3 dates: start, middle, end
    const start = filteredPoints[0].date;
    const end = filteredPoints[filteredPoints.length - 1].date;
    const midTime = start.getTime() + (end.getTime() - start.getTime()) / 2;
    const mid = new Date(midTime);

    return [
      { date: start, label: start.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) },
      { date: mid, label: mid.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) },
      { date: end, label: end.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) }
    ];
  }, [filteredPoints]);

  // Interactive mouse events to find closest index
  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current || svgPoints.length === 0) return;
    const rect = svgRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;

    let closestIdx = 0;
    let minDistance = Infinity;

    svgPoints.forEach((pt, idx) => {
      const distance = Math.abs(pt.x - mouseX);
      if (distance < minDistance) {
        minDistance = distance;
        closestIdx = idx;
      }
    });

    setHoveredPointIndex(closestIdx);
  };

  const handleMouseLeave = () => {
    setHoveredPointIndex(null);
  };

  const currentHoveredPoint = hoveredPointIndex !== null ? svgPoints[hoveredPointIndex] : null;

  // Currency Formatter Helper
  const formatINR = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  // Percentage calculations
  const totalContributed = currentUser.totalContributed;
  const totalReceived = currentUser.totalReceived;
  const balanceNet = totalContributed - totalReceived;

  return (
    <div id="financial-overview-card" className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden mb-8">
      {/* Visual Header */}
      <div className="p-5 sm:p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-50/50">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-600 flex items-center gap-1.5 mb-1">
            <Activity className="w-3 h-3 text-emerald-500" /> Platform Financial Overview
          </span>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight">Aid Giving vs Receiving Over Time</h2>
          <p className="text-slate-500 text-xs">Visualize your community contributions versus the total help payouts you have received.</p>
        </div>

        {/* Time Filter Controls */}
        <div className="flex bg-slate-200/60 p-1 rounded-lg text-xs font-semibold text-slate-600 gap-1 self-start sm:self-auto shrink-0">
          <button 
            onClick={() => setTimeFilter('all')}
            className={`px-3 py-1 rounded-md transition-all cursor-pointer ${timeFilter === 'all' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'hover:text-slate-900'}`}
          >
            All Time
          </button>
          <button 
            onClick={() => setTimeFilter('6months')}
            className={`px-3 py-1 rounded-md transition-all cursor-pointer ${timeFilter === '6months' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'hover:text-slate-900'}`}
          >
            6 Months
          </button>
          <button 
            onClick={() => setTimeFilter('30days')}
            className={`px-3 py-1 rounded-md transition-all cursor-pointer ${timeFilter === '30days' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'hover:text-slate-900'}`}
          >
            30 Days
          </button>
        </div>
      </div>

      {/* Mini Financial Summary Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 border-b border-slate-100">
        <div className="p-4 sm:p-5 border-r border-slate-100 flex flex-col justify-between">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Pledges Paid</span>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-xl sm:text-2xl font-black text-emerald-600">{formatINR(totalContributed)}</span>
            <span className="text-[10px] text-emerald-600/80 font-bold bg-emerald-50 px-1 rounded flex items-center gap-0.5">
              <ArrowUpRight className="w-2.5 h-2.5" /> Giver
            </span>
          </div>
        </div>

        <div className="p-4 sm:p-5 border-r border-slate-100 sm:border-r flex flex-col justify-between">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Help Received</span>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className="text-xl sm:text-2xl font-black text-indigo-600">{formatINR(totalReceived)}</span>
            <span className="text-[10px] text-indigo-600/80 font-bold bg-indigo-50 px-1 rounded flex items-center gap-0.5">
              <ArrowDownLeft className="w-2.5 h-2.5" /> Taker
            </span>
          </div>
        </div>

        <div className="p-4 sm:p-5 border-r border-slate-100 flex flex-col justify-between col-span-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Net Support Balance</span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className={`text-xl sm:text-2xl font-black ${balanceNet >= 0 ? 'text-slate-800' : 'text-rose-600'}`}>
              {balanceNet >= 0 ? '+' : ''}{formatINR(balanceNet)}
            </span>
          </div>
        </div>

        <div className="p-4 sm:p-5 flex flex-col justify-between col-span-1 bg-slate-50/30">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Help Ratio</span>
          <div className="mt-1 flex items-center gap-1.5">
            <span className="text-xl sm:text-2xl font-black text-slate-800">
              {totalContributed > 0 ? `${Math.round((totalReceived / totalContributed) * 100)}%` : '0%'}
            </span>
            <span className="text-[9px] text-slate-400 font-medium">Reciprocated</span>
          </div>
        </div>
      </div>

      {/* Main Chart Section */}
      <div className="p-5 sm:p-6 bg-slate-50/20 relative">
        {filteredPoints.length <= 1 ? (
          /* Empty Sandbox State placeholder */
          <div className="h-60 flex flex-col items-center justify-center text-center p-6 bg-white rounded-xl border border-dashed border-slate-200">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3">
              <Activity className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-slate-800 text-sm">No Active Ledger Timeline Yet</h4>
            <p className="text-slate-500 text-xs mt-1 max-w-sm leading-relaxed">
              Your registered account has not participated in completed transfers. Raising a contribution pledge or a help payout will populate this graph.
            </p>
          </div>
        ) : (
          <div className="relative">
            {/* SVG Interactive Area */}
            <svg
              id="financial-overview-svg"
              ref={svgRef}
              width="100%"
              height={height}
              viewBox={`0 0 ${width} ${height}`}
              className="overflow-visible select-none cursor-crosshair"
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
            >
              {/* Definitions for gorgeous area gradients */}
              <defs>
                <linearGradient id="gradient-contrib" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.22" />
                  <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                </linearGradient>
                <linearGradient id="gradient-received" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity="0.22" />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Y Gridlines and Labels */}
              {yTicks.map((tick, i) => {
                const y = getY(tick);
                return (
                  <g key={`y-${i}`} className="opacity-75">
                    <line
                      x1={paddingLeft}
                      y1={y}
                      x2={width - paddingRight}
                      y2={y}
                      stroke="#f1f5f9"
                      strokeWidth={1}
                      strokeDasharray="3,3"
                    />
                    <text
                      x={paddingLeft - 8}
                      y={y + 4}
                      className="font-mono text-[9px] fill-slate-400 font-bold"
                      textAnchor="end"
                    >
                      ₹{tick >= 1000 ? `${(tick / 1000).toFixed(1)}k` : tick}
                    </text>
                  </g>
                );
              })}

              {/* X Gridlines and Labels */}
              {xTicks.map((tick, i) => {
                const x = getX(tick.date);
                return (
                  <g key={`x-${i}`}>
                    <line
                      x1={x}
                      y1={paddingTop}
                      x2={x}
                      y2={paddingTop + plotH}
                      stroke="#f1f5f9"
                      strokeWidth={1}
                    />
                    <text
                      x={x}
                      y={paddingTop + plotH + 16}
                      className="font-sans text-[10px] fill-slate-400 font-semibold"
                      textAnchor="middle"
                    >
                      {tick.label}
                    </text>
                  </g>
                );
              })}

              {/* Area Underlay Fill */}
              <path d={paths.contribArea} fill="url(#gradient-contrib)" className="transition-all duration-300" />
              <path d={paths.recArea} fill="url(#gradient-received)" className="transition-all duration-300" />

              {/* Main Line Curves */}
              <path
                d={paths.contribPath}
                fill="none"
                stroke="#10b981"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="transition-all duration-300"
              />
              <path
                d={paths.recPath}
                fill="none"
                stroke="#6366f1"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="transition-all duration-300"
              />

              {/* Highlight Hover Dots & Intersection Line */}
              {currentHoveredPoint && (
                <g>
                  {/* Vertical Hover Intercept Line */}
                  <line
                    x1={currentHoveredPoint.x}
                    y1={paddingTop}
                    x2={currentHoveredPoint.x}
                    y2={paddingTop + plotH}
                    stroke="#94a3b8"
                    strokeWidth="1.5"
                    strokeDasharray="2,2"
                  />

                  {/* Contributed Highlight Circle */}
                  <circle
                    cx={currentHoveredPoint.x}
                    cy={currentHoveredPoint.yCont}
                    r="5"
                    fill="#10b981"
                    stroke="#ffffff"
                    strokeWidth="2"
                    className="shadow-sm"
                  />

                  {/* Received Highlight Circle */}
                  <circle
                    cx={currentHoveredPoint.x}
                    cy={currentHoveredPoint.yRec}
                    r="5"
                    fill="#6366f1"
                    stroke="#ffffff"
                    strokeWidth="2"
                    className="shadow-sm"
                  />
                </g>
              )}
            </svg>

            {/* Interactive Tooltip Card */}
            {currentHoveredPoint ? (
              <div 
                className="absolute bg-slate-900/95 backdrop-blur-xs text-white border border-slate-700 p-3 rounded-xl shadow-lg text-xs space-y-2 pointer-events-none transition-all duration-150 z-20"
                style={{
                  left: `${Math.min(plotW - 10, Math.max(10, currentHoveredPoint.x - 90))}px`,
                  top: `${Math.min(plotH - 50, Math.max(5, Math.min(currentHoveredPoint.yCont, currentHoveredPoint.yRec) - 110))}px`
                }}
              >
                <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-1.5">
                  <span className="font-mono text-[10px] text-slate-300 font-semibold flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-slate-400" />
                    {currentHoveredPoint.date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                  </span>
                  <span className="bg-white/10 text-[9px] text-slate-200 font-bold uppercase tracking-wider px-1.5 py-0.5 rounded">
                    {currentHoveredPoint.label}
                  </span>
                </div>
                
                <div className="space-y-1">
                  <div className="flex items-center justify-between gap-6">
                    <span className="text-slate-400 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Contributed:
                    </span>
                    <strong className="text-emerald-400 font-black font-mono">{formatINR(currentHoveredPoint.contributed)}</strong>
                  </div>
                  <div className="flex items-center justify-between gap-6">
                    <span className="text-slate-400 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span> Received Help:
                    </span>
                    <strong className="text-indigo-400 font-black font-mono">{formatINR(currentHoveredPoint.received)}</strong>
                  </div>
                </div>

                <p className="text-[10px] text-slate-300 italic border-t border-white/10 pt-1 leading-relaxed max-w-[190px] truncate-3-lines">
                  💡 {currentHoveredPoint.description}
                </p>
              </div>
            ) : (
              /* Hint label when no hover */
              <div className="absolute top-2 right-4 flex items-center gap-1 text-[10px] text-slate-400 font-medium">
                <Info className="w-3.5 h-3.5 text-slate-300 shrink-0" />
                Hover line points to view timeline events
              </div>
            )}
          </div>
        )}
      </div>

      {/* Visual Chart Legend */}
      <div className="p-4 bg-slate-50 border-t border-slate-100 flex flex-wrap gap-x-6 gap-y-2 items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
            <span className="w-3 h-1.5 rounded bg-emerald-500 inline-block"></span>
            <span>Cumulative Contributed (₹)</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
            <span className="w-3 h-1.5 rounded bg-indigo-500 inline-block"></span>
            <span>Cumulative Help Received (₹)</span>
          </div>
        </div>

        <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
          <span>Active Ledger Audit</span> <ChevronRight className="w-3 h-3" />
        </div>
      </div>
    </div>
  );
}
