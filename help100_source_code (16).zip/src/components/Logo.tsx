import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
}

export default function Logo({ className = '', size = 120, showText = true }: LogoProps) {
  return (
    <div className={`flex flex-col items-center justify-center ${className}`} style={{ width: size, height: showText ? 'auto' : size }}>
      <svg
        viewBox="0 0 500 500"
        width="100%"
        height="100%"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full select-none"
      >
        {/* Definition of Gradients for Premium Finish */}
        <defs>
          <linearGradient id="blueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#0B429A" />
            <stop offset="100%" stopColor="#0E62E1" />
          </linearGradient>
          <linearGradient id="greenGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1E9E1E" />
            <stop offset="100%" stopColor="#3CD03C" />
          </linearGradient>
          <linearGradient id="navyTextGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#082F6B" />
            <stop offset="100%" stopColor="#0F4BA3" />
          </linearGradient>
        </defs>

        {/* --- OUTER CIRCLE SWOOSHES --- */}
        {/* Top-Left Blue Arch */}
        <path
          d="M 250,20 C 120,20 30,110 30,240 C 30,285 42,325 63,360 C 50,320 45,280 45,240 C 45,125 135,35 250,35 C 285,35 315,42 345,55 C 315,32 285,20 250,20 Z"
          fill="url(#blueGrad)"
        />
        
        {/* Top-Right Green Arch */}
        <path
          d="M 250,40 C 310,40 370,65 410,115 C 445,160 455,215 455,270 C 455,325 435,380 400,420 C 440,360 470,300 470,230 C 470,120 380,40 270,40 C 263,40 257,40 250,40 Z"
          fill="url(#greenGrad)"
        />

        {/* --- BOTTOM SUPPORT HANDS --- */}
        {/* Left Blue Hand (Cupping the bottom left) */}
        <path
          d="M 75,335 C 95,370 120,400 155,425 C 190,445 220,455 250,455 C 220,455 185,445 155,425 C 115,395 90,355 75,310 C 73,300 71,290 70,280 C 72,295 78,315 85,330 C 95,350 115,370 145,390 C 185,415 220,425 240,425 C 205,425 170,410 140,390 C 110,370 90,345 75,310 C 76,320 100,380 150,415 C 200,450 245,450 248,450 C 210,448 160,430 120,395 C 100,375 85,350 75,315 Z"
          fill="url(#blueGrad)"
          opacity="0.95"
        />
        {/* Solid beautiful abstract hand shapes instead of micro lines for vector clarity */}
        {/* Blue Left Hand */}
        <path
          d="M 76,335 C 100,390 160,450 252,450 C 255,450 240,440 230,430 C 185,420 140,395 110,360 C 90,335 80,305 76,280 C 78,300 90,330 115,355 C 145,385 190,410 238,420 C 242,421 210,405 180,385 C 150,365 125,335 115,305 C 122,315 140,335 170,355 C 200,375 230,385 242,388 C 215,380 185,360 160,335 C 145,320 135,300 130,285 C 135,295 150,310 175,325 C 205,340 235,350 248,352 C 220,345 195,330 175,310 C 165,300 158,285 155,275 C 160,285 175,298 198,310 C 220,320 245,328 258,330 Z"
          fill="url(#blueGrad)"
        />

        {/* Right Green Hand */}
        <path
          d="M 424,335 C 400,390 340,450 248,450 C 245,450 260,440 270,430 C 315,420 360,395 390,360 C 410,335 420,305 424,280 C 422,300 410,330 385,355 C 355,385 310,410 262,420 C 258,421 290,405 320,385 C 350,365 375,335 385,305 C 378,315 360,335 330,355 C 300,375 270,385 258,388 C 285,380 315,360 340,335 C 355,320 365,300 370,285 C 365,295 350,310 325,325 C 295,340 265,350 252,352 C 280,345 305,330 325,310 C 335,300 342,285 345,275 C 340,285 325,298 302,310 C 280,320 255,328 242,330 Z"
          fill="url(#greenGrad)"
        />

        {/* --- HELPING FIGURES (TOP) --- */}
        {/* Curved Bridge/Hill that they stand on */}
        <path
          d="M 180,215 C 220,190 280,180 360,210 C 380,218 400,225 410,230 C 370,200 310,185 250,185 C 200,185 170,195 150,205 L 180,215 Z"
          fill="url(#blueGrad)"
        />
        <path
          d="M 160,210 C 220,180 300,178 385,215 C 395,220 405,225 410,228 C 360,190 280,175 220,185 C 195,190 175,198 160,210 Z"
          fill="url(#greenGrad)"
        />

        {/* Left Climbing Figure (Blue) */}
        {/* Head */}
        <circle cx="205" cy="128" r="14" fill="url(#blueGrad)" />
        {/* Body & Arm reaching up-right, climbing legs */}
        <path
          d="M 205,142 C 185,152 170,162 155,182 L 152,192 C 160,185 172,175 185,180 C 190,182 195,185 200,192 L 210,210 L 225,200 L 215,180 L 220,165 C 230,160 240,150 250,140 C 245,138 238,140 232,143 C 222,148 215,152 208,144 L 205,142 Z"
          fill="url(#blueGrad)"
        />
        {/* Refined clean arm reach */}
        <path
          d="M 206,145 C 220,145 235,140 252,130 C 255,128 256,132 254,135 C 240,145 225,152 210,152 L 206,145 Z"
          fill="url(#blueGrad)"
        />

        {/* Right Tall Reaching Figure (Green) */}
        {/* Head */}
        <circle cx="275" cy="78" r="15" fill="url(#greenGrad)" />
        {/* Torso, legs standing and leaning left, arm reaching down to join hands */}
        <path
          d="M 275,93 C 295,95 320,110 345,145 C 350,152 355,160 365,185 C 350,170 338,160 325,155 C 315,150 305,155 295,165 C 285,175 280,180 282,195 L 298,190 C 298,175 305,165 315,155 C 322,150 335,145 348,175 C 355,190 365,202 368,205 C 350,185 330,168 310,158 C 300,153 290,142 285,125 L 275,93 Z"
          fill="url(#greenGrad)"
        />
        {/* Green Arm reaching down to connect */}
        <path
          d="M 275,98 C 265,105 255,115 248,131 C 246,135 249,136 251,133 C 258,118 268,108 276,102 L 275,98 Z"
          fill="url(#greenGrad)"
        />

        {/* Sparkle of touch at connection point */}
        <circle cx="250" cy="132" r="5" fill="#3CD03C" />
        <circle cx="250" cy="132" r="2" fill="#FFFFFF" />

        {/* --- CENTRAL TYPOGRAPHY --- */}
        {/* Large "HELP" text, bold italic sans-serif */}
        <g transform="translate(0, 4)">
          <text
            x="248"
            y="285"
            textAnchor="middle"
            fontFamily="system-ui, -apple-system, 'SF Pro Display', sans-serif"
            fontWeight="900"
            fontStyle="italic"
            fontSize="84"
            fill="url(#navyTextGrad)"
            letterSpacing="-2"
          >
            HELP
          </text>

          {/* Large "100" text, vibrant green italic sans-serif */}
          <text
            x="250"
            y="355"
            textAnchor="middle"
            fontFamily="system-ui, -apple-system, 'SF Pro Display', sans-serif"
            fontWeight="900"
            fontStyle="italic"
            fontSize="80"
            fill="url(#greenGrad)"
            letterSpacing="-1"
          >
            100
          </text>
        </g>

        {/* Tagline text: "HELP TODAY • SUPPORT TOMORROW • GROW TOGETHER" */}
        <text
          x="250"
          y="386"
          textAnchor="middle"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="800"
          fontSize="9.5"
          fill="#06224C"
          letterSpacing="1.2"
        >
          HELP TODAY  •  SUPPORT TOMORROW  •  GROW TOGETHER
        </text>
      </svg>
    </div>
  );
}
