import React, { useState, useEffect } from 'react';
import Logo from './Logo';
import { User, Contribution, HelpRequest, Transaction, SystemSettings, Notification, SupportTicket, IssuedPin, P2PMatch } from '../types';
import { getDirectChildren, getSponsorOfUser as getSponsorOfUserUtil } from '../lib/sponsorUtils';
import { 
  Wallet, 
  Users, 
  HeartHandshake, 
  ShieldAlert, 
  Bell, 
  LifeBuoy, 
  LogOut, 
  PlusCircle, 
  Upload, 
  CheckCircle, 
  Copy, 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ArrowDownCircle,
  Clock, 
  FileText, 
  Sparkles,
  UserCheck,
  Send,
  Globe,
  HelpCircle,
  Gift,
  Activity,
  User as UserIcon,
  Key,
  AlertCircle,
  RotateCcw,
  ChevronRight,
  ChevronDown,
  Network,
  Search,
  Phone,
  Mail,
  Trash2,
  Eye,
  X,
  Maximize2,
  Smartphone,
  Link as LinkIcon,
  QrCode
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeSVG } from 'qrcode.react';
import FinancialOverview from './FinancialOverview';
import ActiveCycleChart from './ActiveCycleChart';
import { P2PMatchCard, isUserMatch } from './P2PMatchCard';

// 24-Hour Countdown Timer for P2P Match Settling
function P2PLinkCountdownTimer({ createdAt, status, isDarkBg }: { createdAt: string; status: string; isDarkBg?: boolean }) {
  const [timeLeft, setTimeLeft] = useState<number>(0);

  React.useEffect(() => {
    const calculateTimeLeft = () => {
      const createdTime = new Date(createdAt).getTime();
      const expiryTime = createdTime + 24 * 60 * 60 * 1000; // 24 hours from creation
      const diff = Math.max(0, Math.floor((expiryTime - Date.now()) / 1000));
      return diff;
    };

    setTimeLeft(calculateTimeLeft());

    const interval = setInterval(() => {
      const remaining = calculateTimeLeft();
      setTimeLeft(remaining);
      if (remaining <= 0) {
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [createdAt]);

  if (status === 'completed') {
    return (
      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold ${
        isDarkBg 
          ? 'bg-emerald-500/20 text-emerald-200 border border-emerald-500/30' 
          : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
      }`}>
        ✅ Settled & Completed
      </span>
    );
  }

  if (timeLeft <= 0) {
    return (
      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold animate-pulse ${
        isDarkBg 
          ? 'bg-rose-500/20 text-rose-200 border border-rose-500/30' 
          : 'bg-rose-100 text-rose-800 border border-rose-200'
      }`}>
        ⚠️ Expired (24h Over)
      </span>
    );
  }

  const h = Math.floor(timeLeft / 3600).toString().padStart(2, '0');
  const m = Math.floor((timeLeft % 3600) / 60).toString().padStart(2, '0');
  const s = (timeLeft % 60).toString().padStart(2, '0');

  return (
    <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-black font-mono animate-pulse ${
      isDarkBg 
        ? 'bg-black/30 border border-white/25 text-white' 
        : 'bg-red-100 border border-red-300 text-red-700'
    }`}>
      <Clock className={`w-3 h-3 shrink-0 ${isDarkBg ? 'text-rose-400' : 'text-red-600'}`} />
      <span>{h}:{m}:{s}</span>
    </div>
  );
}

function InlineP2PTimer({ createdAt, status }: { createdAt: string; status: string }) {
  const [timeLeft, setTimeLeft] = useState<number>(0);

  React.useEffect(() => {
    const calculateTimeLeft = () => {
      const createdTime = new Date(createdAt).getTime();
      const expiryTime = createdTime + 24 * 60 * 60 * 1000;
      const diff = Math.max(0, Math.floor((expiryTime - Date.now()) / 1000));
      return diff;
    };

    setTimeLeft(calculateTimeLeft());

    const interval = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(interval);
  }, [createdAt]);

  if (status === 'completed') {
    return <span>00:00:00</span>;
  }
  if (timeLeft <= 0) {
    return <span>00:00:00</span>;
  }

  const h = Math.floor(timeLeft / 3600).toString().padStart(2, '0');
  const m = Math.floor((timeLeft % 3600) / 60).toString().padStart(2, '0');
  const s = (timeLeft % 60).toString().padStart(2, '0');

  return <span>{h}:{m}:{s}</span>;
}

interface UserDashboardProps {
  currentUser: User;
  users: User[];
  systemSettings: SystemSettings;
  contributions: Contribution[];
  helpRequests: HelpRequest[];
  transactions: Transaction[];
  notifications: Notification[];
  tickets: SupportTicket[];
  issuedPins: IssuedPin[];
  p2pMatches: P2PMatch[];
  communityReserves: number;
  onLogout: () => void;
  onUpdateUser: (updatedUser: User) => void;
  onAddContribution: (contrib: Contribution) => void;
  onAddHelpRequest: (req: HelpRequest) => void;
  onAddTransaction: (tx: Transaction) => void;
  onAddTicket: (ticket: SupportTicket) => void;
  onMarkNotificationsRead: () => void;
  onUsePin: (pinCode: string, userId?: string, userName?: string) => boolean;
  onUpdateTransactionLink?: (txId: string, txLink: string) => void;
  onUpdateContributionProof?: (contribId: string, proofFile: string, txLink?: string) => void;
  onUpdateContribution?: (contribId: string, status: 'pending_dispatch' | 'pending_proof' | 'pending_verification' | 'approved' | 'rejected', remarks?: string, txLink?: string) => void;
  onUpdateTransaction?: (txId: string, status: 'pending' | 'completed' | 'rejected', txLink?: string) => void;
  onUpdateHelpRequest?: (helpId: string, status: 'approved' | 'rejected' | 'completed' | 'pending_review', receivedAmt?: number, remarks?: string) => void;
  onUpdateP2PMatch: (matchId: string, updates: Partial<P2PMatch>) => void;
  onApproveP2PMatch?: (matchId: string) => boolean;
  onRejectP2PMatch?: (matchId: string) => boolean;
  calculateCurrentCycleProfit?: (userId: string) => number;
  onClearAllNotifications?: () => void;
  onDeleteTransaction?: (txId: string) => void;
  onClearAllTransactions?: () => void;
}

export default function UserDashboard({
  currentUser,
  users,
  systemSettings,
  contributions,
  helpRequests,
  transactions,
  notifications,
  tickets,
  issuedPins,
  p2pMatches,
  communityReserves,
  onLogout,
  onUpdateUser,
  onAddContribution,
  onAddHelpRequest,
  onAddTransaction,
  onAddTicket,
  onMarkNotificationsRead,
  onUsePin,
  onUpdateTransactionLink,
  onUpdateContributionProof,
  onUpdateContribution,
  onUpdateTransaction,
  onUpdateHelpRequest,
  onUpdateP2PMatch,
  onApproveP2PMatch,
  onRejectP2PMatch,
  calculateCurrentCycleProfit,
  onClearAllNotifications,
  onDeleteTransaction,
  onClearAllTransactions
}: UserDashboardProps) {

  // Current sub-navigation inside dashboard
  const [activeSubTab, setActiveSubTab] = useState<
    'overview' | 'wallet' | 'referrals' | 'contribution' | 'help' | 'notifications' | 'support' | 'plan100' | 'profile' | 'payment' | 'rewards' | 'downloads' | 'settings'
  >('plan100');

  // Accordion Group Open/Close States for Sidebar Hierarchy
  const [openNavGroup, setOpenNavGroup] = useState<{ [key: string]: boolean }>({
    dashboard: true,
    profile: true,
    wallet: true,
    ph: true,
    gh: true,
    payment: true,
    team: true,
    rewards: true,
    notifications: true,
    support: true,
    downloads: true,
    settings: true
  });

  const toggleNavGroup = (group: string) => {
    setOpenNavGroup(prev => ({ ...prev, [group]: !prev[group] }));
  };

  // Detailed sub-navigation section states
  const [activeProfileSection, setActiveProfileSection] = useState<'edit' | 'bank' | 'upi' | 'password' | 'kyc'>('edit');
  const [activePaymentSub, setActivePaymentSub] = useState<'upload' | 'view' | 'verification' | 'receipt'>('upload');
  const [activeRewardsSub, setActiveRewardsSub] = useState<'achievement' | 'bonus' | 'history'>('achievement');
  const [activeNotifSub, setActiveNotifSub] = useState<'all' | 'system' | 'alerts' | 'inbox'>('all');
  const [activeSupportSub, setActiveSupportSub] = useState<'whatsapp' | 'ticket' | 'faq' | 'contact'>('ticket');
  const [activeDownloadsSub, setActiveDownloadsSub] = useState<'pdf' | 'guide' | 'terms'>('pdf');
  const [activeSettingsSub, setActiveSettingsSub] = useState<'language' | 'dark' | 'security'>('language');

  // Nested sub-navigation states to match exact tree
  const [activeWalletTab, setActiveWalletTab] = useState<'history' | 'withdrawal' | 'main' | 'credit' | 'debit' | 'statement'>('withdrawal');
  const [activeReferralTab, setActiveReferralTab] = useState<'link' | 'direct' | 'team' | 'tree'>('link');
  const [teamLevelFilter, setTeamLevelFilter] = useState<'all' | 1 | 2 | 3 | 4 | 5>('all');
  const [isSyncingTeam, setIsSyncingTeam] = useState(false);

  const handleSyncLiveTeam = async () => {
    setIsSyncingTeam(true);
    try {
      const res = await fetch('/api/sync');
      if (res.ok) {
        const data = await res.json();
        if (data && data.success && data.data) {
          window.dispatchEvent(new Event('help100_server_sync'));
          window.dispatchEvent(new Event('storage'));
        }
      }
    } catch (e) {
      // ignore
    } finally {
      setTimeout(() => setIsSyncingTeam(false), 500);
    }
  };

  // Continuous auto-sync for multi-device team referrals
  useEffect(() => {
    handleSyncLiveTeam();
    const interval = setInterval(() => {
      handleSyncLiveTeam();
    }, 2000);
    return () => clearInterval(interval);
  }, [activeReferralTab]);
  const [activeContributionTab, setActiveContributionTab] = useState<'create' | 'proof' | 'history'>('history');
  const [activeHelpTab, setActiveHelpTab] = useState<'status' | 'review'>('status');

  // Wallet Inputs
  const [depositAmount, setDepositAmount] = useState('');
  const [depositMethod, setDepositMethod] = useState('UPI');
  const [depositTxLink, setDepositTxLink] = useState('');
  const [withdrawalAmount, setWithdrawalAmount] = useState('');
  const [withdrawalAddress, setWithdrawalAddress] = useState('');
  const [withdrawalWallet, setWithdrawalWallet] = useState<'provide' | 'get' | 'direct' | 'level' | 'main'>('provide');
  const [walletSuccessMsg, setWalletSuccessMsg] = useState('');

  // Payment Gateway states
  const [showPaymentGateway, setShowPaymentGateway] = useState(false);
  const [gatewayAmount, setGatewayAmount] = useState(0);
  const [gatewayTxId, setGatewayTxId] = useState('');
  const [gatewayStep, setGatewayStep] = useState<'details' | 'paying' | 'success'>('details');
  const [depositOption, setDepositOption] = useState<'instant' | 'manual'>('instant');

  // Instant Payout/Withdrawal Link Gateway States
  const [showSecureClaimGateway, setShowSecureClaimGateway] = useState(false);
  const [claimGatewayRoute, setClaimGatewayRoute] = useState<'primary' | 'secondary'>('primary');
  const [claimSuccessMsg, setClaimSuccessMsg] = useState('');
  const [claimProcessing, setClaimProcessing] = useState(false);
  const [claimProofFilename, setClaimProofFilename] = useState('');

  // Contribution Inputs
  const [contribAmount, setContribAmount] = useState('');
  const [contribFile, setContribFile] = useState('');
  const [contribTxLink, setContribTxLink] = useState('');
  const [contribSuccessMsg, setContribSuccessMsg] = useState('');
  const [selectedProofContribId, setSelectedProofContribId] = useState('');
  const [proofFilename, setProofFilename] = useState('');
  const [proofTxLink, setProofTxLink] = useState('');
  const [enteredPin, setEnteredPin] = useState('');
  const [pinProofFile, setPinProofFile] = useState('');
  const [pinTxId, setPinTxId] = useState('');

  // Profile input states
  const [profileName, setProfileName] = useState(currentUser.name || '');
  const [profileEmail, setProfileEmail] = useState(currentUser.email || '');
  const [profileMobile, setProfileMobile] = useState(currentUser.phone || '');
  const [profileUpiId, setProfileUpiId] = useState(currentUser.upiId || '');
  const [profileBankName, setProfileBankName] = useState(currentUser.bankName || '');
  const [profileAccountNumber, setProfileAccountNumber] = useState(currentUser.accountNumber || '');
  const [profileIfscCode, setProfileIfscCode] = useState(currentUser.ifscCode || '');
  const [profileSecondaryUpiId, setProfileSecondaryUpiId] = useState(currentUser.secondaryUpiId || '');
  const [profileSecondaryBankName, setProfileSecondaryBankName] = useState(currentUser.secondaryBankName || '');
  const [profileSecondaryAccountNumber, setProfileSecondaryAccountNumber] = useState(currentUser.secondaryAccountNumber || '');
  const [profileSecondaryIfscCode, setProfileSecondaryIfscCode] = useState(currentUser.secondaryIfscCode || '');
  const [profileSuccessMsg, setProfileSuccessMsg] = useState('');

  React.useEffect(() => {
    if (activeSubTab === 'profile') {
      setProfileName(currentUser.name || '');
      setProfileEmail(currentUser.email || '');
      setProfileMobile(currentUser.phone || '');
      setProfileUpiId(currentUser.upiId || '');
      setProfileBankName(currentUser.bankName || '');
      setProfileAccountNumber(currentUser.accountNumber || '');
      setProfileIfscCode(currentUser.ifscCode || '');
      setProfileSecondaryUpiId(currentUser.secondaryUpiId || '');
      setProfileSecondaryBankName(currentUser.secondaryBankName || '');
      setProfileSecondaryAccountNumber(currentUser.secondaryAccountNumber || '');
      setProfileSecondaryIfscCode(currentUser.secondaryIfscCode || '');
      setProfileSuccessMsg('');
    }
  }, [activeSubTab, currentUser]);

  // Help Request Inputs
  const [helpTitle, setHelpTitle] = useState('');
  const [helpDesc, setHelpDesc] = useState('');
  const [helpAmount, setHelpAmount] = useState('');
  
  // Downline Tree states
  const [treeSearchQuery, setTreeSearchQuery] = useState('');
  const [collapsedNodes, setCollapsedNodes] = useState<{ [userId: string]: boolean }>({});
  const [helpDocName, setHelpDocName] = useState('');
  const [helpSuccessMsg, setHelpSuccessMsg] = useState('');
  const [takerMode, setTakerMode] = useState<'get_help' | 'withdraw'>('get_help');

  // Support Ticket Inputs
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');
  const [ticketSuccessMsg, setTicketSuccessMsg] = useState('');

  // P2P Match screenshot uploads state
  const [matchUploads, setMatchUploads] = useState<{[matchId: string]: string}>({});
  const [matchPreviewUrls, setMatchPreviewUrls] = useState<{[matchId: string]: string}>({});
  const [activeSlipPreview, setActiveSlipPreview] = useState<P2PMatch | null>(null);
  const [viewedSlips, setViewedSlips] = useState<{[matchId: string]: boolean}>({});
  const [zoomedImgUrl, setZoomedImgUrl] = useState<string | null>(null);
  const [isVerifyingUtr, setIsVerifyingUtr] = useState(false);
  const [utrVerificationResult, setUtrVerificationResult] = useState<string | null>(null);

  // Giving and Taking Simulator State inside User Dashboard
  const [giverName, setGiverName] = useState('');
  const [giveAmount, setGiveAmount] = useState('150');
  const [giveStatus, setGiveStatus] = useState<'approved' | 'pending_verification'>('approved');
  const [giveRemarks, setGiveRemarks] = useState('Manual verification complete by admin');

  const [takerName, setTakerName] = useState('');
  const [takeTitle, setTakeTitle] = useState('');
  const [takeDesc, setTakeDesc] = useState('');
  const [takeAmount, setTakeAmount] = useState('800');
  const [takeStatus, setTakeStatus] = useState<'pending_review' | 'approved' | 'completed'>('approved');

  const [activeSimulatorTab, setActiveSimulatorTab] = useState<'give' | 'take'>('give');

  const [selectedGiverDetails, setSelectedGiverDetails] = useState<Contribution | null>(null);
  const [selectedTakerDetails, setSelectedTakerDetails] = useState<HelpRequest | null>(null);

  // Sunil Kumar ↔ Sarah Jenkins Custom Match State
  const [matchStatus, setMatchStatus] = useState<'pending' | 'submitted' | 'approved' | 'rejected' | 'blocked'>(() => {
    const saved = localStorage.getItem(`sunil_sarah_match_status_${currentUser.id}`);
    return (saved as 'pending' | 'submitted' | 'approved' | 'rejected' | 'blocked') || 'pending';
  });
  const [matchTimer, setMatchTimer] = useState<number>(() => {
    const saved = localStorage.getItem(`sunil_sarah_match_timer_${currentUser.id}`);
    return saved ? parseInt(saved) : 24 * 60 * 60; // 24 hours
  });
  const [matchSlipUrl, setMatchSlipUrl] = useState<string>(() => {
    return localStorage.getItem(`sunil_sarah_match_slip_url_${currentUser.id}`) || '';
  });
  const [matchSlipName, setMatchSlipName] = useState<string>(() => {
    return localStorage.getItem(`sunil_sarah_match_slip_name_${currentUser.id}`) || '';
  });
  const [matchAmount, setMatchAmount] = useState<number>(() => {
    const saved = localStorage.getItem(`sunil_sarah_match_amount_${currentUser.id}`);
    return saved ? parseInt(saved) : 500;
  });
  const [showSlipModal, setShowSlipModal] = useState<boolean>(false);
  const [demoRole, setDemoRole] = useState<'giver' | 'taker'>('giver');

  // Save on change
  React.useEffect(() => {
    try {
      localStorage.setItem(`sunil_sarah_match_status_${currentUser.id}`, matchStatus);
      localStorage.setItem(`sunil_sarah_match_timer_${currentUser.id}`, matchTimer.toString());
      localStorage.setItem(`sunil_sarah_match_slip_url_${currentUser.id}`, matchSlipUrl);
      localStorage.setItem(`sunil_sarah_match_slip_name_${currentUser.id}`, matchSlipName);
      localStorage.setItem(`sunil_sarah_match_amount_${currentUser.id}`, matchAmount.toString());
    } catch (err) {
      console.warn("Storage quota exceeded or unavailable:", err);
    }
  }, [matchStatus, matchTimer, matchSlipUrl, matchSlipName, matchAmount, currentUser.id]);

  const handleApproveMatch = () => {
    setMatchStatus('approved');
    
    // Add transaction to the global ledger for the current user
    const isSunil = currentUser.id === 'user-sunil' || currentUser.name.toLowerCase().includes('sunil');
    const txType = isSunil ? 'contribution' : 'payout';
    const txDesc = isSunil 
      ? `Direct P2P Giver Contribution Paid to Sarah Jenkins (Order #PH-64454736637)` 
      : `Received Peer-to-Peer Get-Help from Sunil Kumar (Order #GH-229767953361)`;

    onAddTransaction({
      id: 'tx-p2p-' + Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      userName: currentUser.name,
      type: txType,
      amount: matchAmount,
      status: 'completed',
      description: txDesc,
      createdAt: new Date().toISOString()
    });

    // Notify the user via an in-app alert or notification
    const updatedUser = { ...currentUser };
    if (isSunil) {
      updatedUser.totalContributed = (updatedUser.totalContributed || 0) + matchAmount;
      if (updatedUser.provideWallet && updatedUser.provideWallet >= matchAmount) {
        updatedUser.provideWallet -= matchAmount;
      }
    } else {
      updatedUser.totalReceived = (updatedUser.totalReceived || 0) + matchAmount;
      updatedUser.getWallet = (updatedUser.getWallet || 0) + matchAmount;
    }
    onUpdateUser(updatedUser);
  };

  React.useEffect(() => {
    let interval: any;
    if (matchStatus !== 'approved' && matchStatus !== 'blocked' && matchTimer > 0) {
      interval = setInterval(() => {
        setMatchTimer(prev => {
          if (prev <= 1) {
            setMatchStatus('blocked');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [matchStatus, matchTimer]);

  const formatTimer = (secs: number) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // 100/Rs Plan Cycle State
  const [cycleState, setCycleState] = useState<{
    currentStep: 'buy_pin' | 'first_ph' | 'second_ph' | 'first_gh' | 'second_gh' | 'third_gh' | 'fourth_gh' | 'fifth_gh' | 'completed';
    pinPurchased: boolean;
    firstPhSubmitted: boolean;
    secondPhSubmitted: boolean;
    firstGhReceived: boolean;
    secondGhReceived: boolean;
    thirdGhReceived: boolean;
    fourthGhReceived: boolean;
    fifthGhReceived: boolean;
    totalProvided: number;
    totalReceived: number;
    totalProfit: number;
    cycleCount: number;
  }>(() => {
    // Deterministic lookup across devices:
    const hasUsedPin = issuedPins.some(p => p.isUsed && (
      p.userId === currentUser.id ||
      (currentUser.email && p.userId?.toLowerCase() === currentUser.email.toLowerCase()) ||
      (currentUser.phone && p.userId === currentUser.phone) ||
      (currentUser.registrationPin && p.pinCode === currentUser.registrationPin)
    ));
    const hasPinContrib = contributions.some(c => c.userId === currentUser.id && c.amount === 10 && c.status !== 'rejected');
    const isPinActive = hasUsedPin || hasPinContrib || !!currentUser.registrationPin;

    const ph1Approved = contributions.some(c => c.userId === currentUser.id && c.amount === 40 && c.status === 'approved') ||
      (contributions.filter(c => c.userId === currentUser.id && c.amount === 20 && c.status === 'approved').length >= 2);
    const ph2Approved = contributions.some(c => c.userId === currentUser.id && c.amount === 50 && c.status === 'approved');

    let initialStep: 'buy_pin' | 'first_ph' | 'second_ph' | 'first_gh' | 'second_gh' | 'third_gh' | 'fourth_gh' | 'fifth_gh' | 'completed' = 'buy_pin';
    if (ph2Approved) initialStep = 'first_gh';
    else if (ph1Approved) initialStep = 'second_ph';
    else if (isPinActive) initialStep = 'first_ph';

    const saved = localStorage.getItem(`help100_cycle_state_${currentUser.id}`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed) {
          return {
            ...parsed,
            currentStep: parsed.currentStep || initialStep,
            pinPurchased: parsed.pinPurchased || isPinActive,
            firstPhSubmitted: parsed.firstPhSubmitted || ph1Approved,
            secondPhSubmitted: parsed.secondPhSubmitted || ph2Approved,
          };
        }
      } catch (e) {}
    }

    return {
      currentStep: initialStep,
      pinPurchased: isPinActive,
      firstPhSubmitted: ph1Approved,
      secondPhSubmitted: ph2Approved,
      firstGhReceived: false,
      secondGhReceived: false,
      thirdGhReceived: false,
      fourthGhReceived: false,
      fifthGhReceived: false,
      totalProvided: isPinActive ? 10 + (ph1Approved ? 40 : 0) + (ph2Approved ? 50 : 0) : 0,
      totalReceived: 0,
      totalProfit: 0,
      cycleCount: 1,
    };
  });

  // Persist cycle state
  React.useEffect(() => {
    localStorage.setItem(`help100_cycle_state_${currentUser.id}`, JSON.stringify(cycleState));
  }, [cycleState, currentUser.id]);

  // Gateway Portal State Variables
  const [activeGateway, setActiveGateway] = useState<{
    id: string; // contribution ID or help request ID
    type: 'ph' | 'gh';
    amount: number;
    stepKey: 'first_ph' | 'second_ph' | 'first_gh' | 'second_gh' | 'third_gh' | 'fourth_gh' | 'fifth_gh';
    txLink?: string;
  } | null>(null);

  const [planViewMode, setPlanViewMode] = useState<'all' | 'ph' | 'gh'>('all');
  const [gatewayTab, setGatewayTab] = useState<'ph' | 'gh'>('ph');

  React.useEffect(() => {
    if (activeGateway) {
      setGatewayTab(activeGateway.type);
    }
  }, [activeGateway]);

  // Reactively switch view mode to correct tab (PH or GH) when step changes
  React.useEffect(() => {
    if (cycleState.currentStep.endsWith('_gh')) {
      setPlanViewMode('gh');
    } else if (cycleState.currentStep.endsWith('_ph')) {
      setPlanViewMode('ph');
    } else if (cycleState.currentStep === 'buy_pin') {
      setPlanViewMode('all');
    }
  }, [cycleState.currentStep]);

  const [gatewayTimer, setGatewayTimer] = useState<number>(86400); // 24 hours in seconds
  const [gatewayProofFilename, setGatewayProofFilename] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState(false);

  // Optional P2P QR Code Generator states
  const [showQrGenerator, setShowQrGenerator] = useState(false);
  const [selectedGatewayRoute, setSelectedGatewayRoute] = useState<'primary' | 'secondary'>('primary');
  const [customQrUpi, setCustomQrUpi] = useState('');
  const [customQrName, setCustomQrName] = useState('');
  const [customQrAmount, setCustomQrAmount] = useState('');

  React.useEffect(() => {
    if (activeGateway && activeGateway.type === 'ph') {
      const recipient = getRecipientDetails();
      setCustomQrUpi(recipient.upiId || 'payer@okaxis');
      setCustomQrName(recipient.name || 'Recipient');
      setCustomQrAmount((activeGateway.amount || 50).toString());
    }
  }, [activeGateway]);

  // Custom states & persistence for Step 2: First PH (₹40) box
  const [ph1Timer, setPh1Timer] = useState<number>(86400);
  const [ph1ProofFile, setPh1ProofFile] = useState<string>('');
  const [ph1TxId, setPh1TxId] = useState<string>('');
  const [ph1AdminProofFile, setPh1AdminProofFile] = useState<string>('');
  const [ph1AdminTxId, setPh1AdminTxId] = useState<string>('');
  const [ph1UserProofFile, setPh1UserProofFile] = useState<string>('');
  const [ph1UserTxId, setPh1UserTxId] = useState<string>('');

  // Custom states & persistence for Step 3: Second PH (₹50) box
  const [expandedMatchId, setExpandedMatchId] = useState<string | null>(null);
  const [uploadMatchId, setUploadMatchId] = useState<string | null>(null);
  const [ph2Timer, setPh2Timer] = useState<number>(86400);
  const [ph2ProofFile, setPh2ProofFile] = useState<string>('');
  const [ph2TxId, setPh2TxId] = useState<string>('');

  // Custom states & persistence for Step 4: Third PH (₹50) box
  const [ph3Timer, setPh3Timer] = useState<number>(86400);
  const [ph3ProofFile, setPh3ProofFile] = useState<string>('');
  const [ph3TxId, setPh3TxId] = useState<string>('');

  // Real-time Database Lookups for Cycle Steps (Supports both direct contributions and P2P dispatched matches)
  const firstPhP2P = p2pMatches.find(m =>
    (isUserMatch(currentUser, m.giverUserId) || isUserMatch(currentUser, m.giverId) || (m.giverPhone && currentUser.phone && m.giverPhone.trim() === currentUser.phone.trim())) &&
    (m.amount === 50 || m.amount === 40 || m.amount === 20) &&
    m.status !== 'rejected'
  );
  let firstPhContribObj = contributions.find(c =>
    isUserMatch(currentUser, c.userId) &&
    (c.amount === 50 || c.amount === 40 || c.amount === 20) &&
    c.status !== 'rejected'
  );

  const firstPhContrib = firstPhContribObj ? {
    ...firstPhContribObj,
    txLink: firstPhP2P?.phLink || firstPhP2P?.adminLink || firstPhP2P?.ghLink || firstPhContribObj.txLink || ''
  } : (
    firstPhP2P ? {
      id: firstPhP2P.giverId || firstPhP2P.id,
      userId: firstPhP2P.giverUserId || currentUser.id,
      userName: firstPhP2P.giverName || currentUser.name,
      amount: firstPhP2P.amount || 50,
      status: firstPhP2P.status === 'pending_verification' ? 'pending_verification' : firstPhP2P.status === 'completed' ? 'approved' : 'pending_proof',
      createdAt: firstPhP2P.createdAt,
      remarks: 'First Provide Help - Dispatched P2P',
      txLink: firstPhP2P.phLink || firstPhP2P.adminLink || firstPhP2P.ghLink || ''
    } : {
      id: `default-ph1-${currentUser.id}`,
      userId: currentUser.id,
      userName: currentUser.name,
      amount: 50,
      status: 'pending_proof',
      createdAt: new Date().toISOString(),
      remarks: 'First Provide Help - Default Queue',
      txLink: ''
    }
  );

  const ph1Admin = contributions.find(c => isUserMatch(currentUser, c.userId) && c.amount === 20 && c.remarks?.includes('First Provide Help - Admin') && c.status !== 'rejected');
  const ph1User = contributions.find(c => isUserMatch(currentUser, c.userId) && c.amount === 20 && c.remarks?.includes('First Provide Help - User') && c.status !== 'rejected');

  const secondPhP2P = p2pMatches.find(m =>
    (isUserMatch(currentUser, m.giverUserId) || isUserMatch(currentUser, m.giverId) || (m.giverPhone && currentUser.phone && m.giverPhone.trim() === currentUser.phone.trim())) &&
    m.amount === 50 &&
    m.status !== 'rejected'
  );
  let secondPhContribObj = contributions.find(c =>
    isUserMatch(currentUser, c.userId) &&
    c.amount === 50 &&
    c.remarks?.includes('Second Provide Help') &&
    c.status !== 'rejected'
  ) || contributions.find(c =>
    isUserMatch(currentUser, c.userId) &&
    c.amount === 50 &&
    c.status !== 'rejected'
  );

  const secondPhContrib = secondPhContribObj ? {
    ...secondPhContribObj,
    txLink: secondPhP2P?.phLink || secondPhP2P?.adminLink || secondPhP2P?.ghLink || secondPhContribObj.txLink || ''
  } : (
    secondPhP2P ? {
      id: secondPhP2P.giverId || secondPhP2P.id,
      userId: secondPhP2P.giverUserId || currentUser.id,
      userName: secondPhP2P.giverName || currentUser.name,
      amount: secondPhP2P.amount || 50,
      status: secondPhP2P.status === 'pending_verification' ? 'pending_verification' : secondPhP2P.status === 'completed' ? 'approved' : 'pending_proof',
      createdAt: secondPhP2P.createdAt,
      remarks: 'Second Provide Help - Dispatched P2P',
      txLink: secondPhP2P.phLink || secondPhP2P.adminLink || secondPhP2P.ghLink || ''
    } : {
      id: `default-ph2-${currentUser.id}`,
      userId: currentUser.id,
      userName: currentUser.name,
      amount: 50,
      status: 'pending_proof',
      createdAt: new Date().toISOString(),
      remarks: 'Second Provide Help - Default Queue',
      txLink: ''
    }
  );
  const thirdPhContrib = contributions.find(c => isUserMatch(currentUser, c.userId) && c.amount === 50 && c.remarks?.includes('Third Provide Help') && c.status !== 'rejected');

  React.useEffect(() => {
    if (cycleState.currentStep === 'first_ph' && (firstPhContrib || ph1Admin || ph1User)) {
      const storageKey = `help100_ph1_timer_start_${currentUser.id}_cycle_${cycleState.cycleCount}`;
      let start = localStorage.getItem(storageKey);
      if (!start) {
        start = Date.now().toString();
        localStorage.setItem(storageKey, start);
      }
      const startTime = parseInt(start, 10);
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      const remaining = Math.max(0, 86400 - elapsed);
      setPh1Timer(remaining);

      const interval = setInterval(() => {
        const elapsedNow = Math.floor((Date.now() - startTime) / 1000);
        const remainingNow = Math.max(0, 86400 - elapsedNow);
        setPh1Timer(remainingNow);
        if (remainingNow <= 0) {
          clearInterval(interval);
        }
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [cycleState.currentStep, firstPhContrib, ph1Admin, ph1User, currentUser.id, cycleState.cycleCount]);

  React.useEffect(() => {
    if (cycleState.currentStep === 'second_ph' && secondPhContrib) {
      const storageKey = `help100_ph2_timer_start_${currentUser.id}_cycle_${cycleState.cycleCount}`;
      let start = localStorage.getItem(storageKey);
      if (!start) {
        start = Date.now().toString();
        localStorage.setItem(storageKey, start);
      }
      const startTime = parseInt(start, 10);
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      const remaining = Math.max(0, 86400 - elapsed);
      setPh2Timer(remaining);

      const interval = setInterval(() => {
        const elapsedNow = Math.floor((Date.now() - startTime) / 1000);
        const remainingNow = Math.max(0, 86400 - elapsedNow);
        setPh2Timer(remainingNow);
        if (remainingNow <= 0) {
          clearInterval(interval);
        }
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [cycleState.currentStep, secondPhContrib, currentUser.id, cycleState.cycleCount]);

  // Find if there is any user (other than admin) who is currently in "gh" with 1,000,000 rs
  const userWithMillionInGh = users.find(u => {
    if (u.role === 'admin') return false;
    const hasMillionGhRequest = helpRequests.some(h => h.userId === u.id && h.amountRequested === 1000000);
    const hasMillionGhBalance = u.walletBalance === 1000000 || u.getWallet === 1000000 || u.totalReceived === 1000000;
    return hasMillionGhRequest || hasMillionGhBalance;
  });

  const getRecipientDetails = (type: 'ph' | 'gh' = 'ph') => {
    if (type === 'ph') {
      if (userWithMillionInGh) {
        const cleanName = userWithMillionInGh.name.toLowerCase().replace(/[^a-z0-9]/g, '');
        return {
          name: userWithMillionInGh.name,
          phone: userWithMillionInGh.phone || '+91 94827 50132',
          email: userWithMillionInGh.email || 'recipient@help100.org',
          beneficiaryName: userWithMillionInGh.name,
          bankName: userWithMillionInGh.bankName || 'HDFC Bank',
          accountNumber: userWithMillionInGh.accountNumber || '5010098273615',
          ifscCode: userWithMillionInGh.ifscCode || 'HDFC0000120',
          upiId: userWithMillionInGh.upiId || `${cleanName}@okhdfc`,
          qrUrl: `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=upi://pay?pa=${userWithMillionInGh.upiId || `${cleanName}@okhdfc`}%26pn=${encodeURIComponent(userWithMillionInGh.name)}%26am=${activeGateway?.amount || 50}`,
          isPromoMatch: true,
          secondaryUpiId: userWithMillionInGh.secondaryUpiId,
          secondaryBankName: userWithMillionInGh.secondaryBankName,
          secondaryAccountNumber: userWithMillionInGh.secondaryAccountNumber,
          secondaryIfscCode: userWithMillionInGh.secondaryIfscCode,
        };
      } else {
        // Dynamic matching: Look for another user (not admin, not current user) who is currently in a GH state (pending review or approved GH request)
        const activeGhRequest = helpRequests.find(h => 
          h.userId !== currentUser.id && 
          (h.status === 'pending_review' || h.status === 'approved')
        );
        const ghUser = activeGhRequest ? users.find(u => u.id === activeGhRequest.userId) : null;
        
        // "When any user is not in gh, then gh link will go to admin. Admin will already be in gh."
        const targetUser = ghUser || users.find(u => u.role === 'admin');

        if (targetUser) {
          const isTargetAdmin = targetUser.role === 'admin';
          const cleanName = targetUser.name.toLowerCase().replace(/[^a-z0-9]/g, '');
          const upiId = targetUser.upiId || (isTargetAdmin ? 'help100admin@sbin' : `${cleanName}@okaxis`);
          const bankName = targetUser.bankName || 'HDFC Bank';
          const accountNumber = targetUser.accountNumber || '5010043218765';
          const ifscCode = targetUser.ifscCode || 'HDFC0000120';
          const phone = targetUser.phone || '+91 94827 50132';
          const email = targetUser.email || (isTargetAdmin ? 'admin@help100.org' : 'peer@help100.org');
          return {
            name: targetUser.name + (isTargetAdmin ? ' (Admin Escrow)' : ''),
            phone,
            email,
            beneficiaryName: targetUser.name,
            bankName,
            accountNumber,
            ifscCode,
            upiId,
            qrUrl: `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=upi://pay?pa=${upiId}%26pn=${encodeURIComponent(targetUser.name)}%26am=${activeGateway?.amount || 50}`,
            isPromoMatch: false,
            secondaryUpiId: targetUser.secondaryUpiId,
            secondaryBankName: targetUser.secondaryBankName,
            secondaryAccountNumber: targetUser.secondaryAccountNumber,
            secondaryIfscCode: targetUser.secondaryIfscCode,
          };
        }

        // Hardcoded peer fallback if no users exist
        const name = 'Sarah Jenkins';
        const upiId = 'sarah100@okaxis';
        const bankName = 'HDFC Bank';
        const accountNumber = '5010043218765';
        const ifscCode = 'HDFC0000120';
        const phone = '+91 94827 50132';
        const email = 'sarah@help100.org';
        return {
          name,
          phone,
          email,
          beneficiaryName: name,
          bankName,
          accountNumber,
          ifscCode,
          upiId,
          qrUrl: `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=upi://pay?pa=${upiId}%26pn=${encodeURIComponent(name)}%26am=${activeGateway?.amount || 50}`,
          isPromoMatch: false
        };
      }
    }
    // GH: Recipient is the current user themselves so they can scan to receive help/payout!
    const cleanUserName = currentUser.name.toLowerCase().replace(/[^a-z0-9]/g, '');
    const userUpiId = currentUser.upiId || `${cleanUserName}@okaxis`;
    return {
      name: currentUser.name,
      phone: currentUser.phone || '+91 98765 43210',
      email: currentUser.email,
      beneficiaryName: currentUser.name,
      bankName: currentUser.bankName || 'Your Registered Bank',
      accountNumber: currentUser.accountNumber || 'XXXXXXXX1234',
      ifscCode: currentUser.ifscCode || 'IFSC0001234',
      upiId: userUpiId,
      qrUrl: `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=upi://pay?pa=${userUpiId}%26pn=${encodeURIComponent(currentUser.name)}%26am=${activeGateway?.amount || 50}`,
      isPromoMatch: false,
      secondaryUpiId: currentUser.secondaryUpiId,
      secondaryBankName: currentUser.secondaryBankName,
      secondaryAccountNumber: currentUser.secondaryAccountNumber,
      secondaryIfscCode: currentUser.secondaryIfscCode,
    };
  };

  const currentRecipient = getRecipientDetails(gatewayTab);

  const firstGhP2P = p2pMatches.find(m =>
    (isUserMatch(currentUser, m.takerUserId) || isUserMatch(currentUser, m.takerId) || (m.takerPhone && currentUser.phone && m.takerPhone.trim() === currentUser.phone.trim())) &&
    m.amount === 50 &&
    m.status !== 'rejected'
  );
  const firstGhHrObj = helpRequests.find(h => isUserMatch(currentUser, h.userId) && h.amountRequested === 50 && h.remarks?.includes(`First Received Help`) && h.remarks?.includes(`Cycle #${cycleState.cycleCount}`)) || helpRequests.find(h => isUserMatch(currentUser, h.userId) && h.amountRequested === 50);

  const firstGhHr = firstGhHrObj ? {
    ...firstGhHrObj,
    txLink: firstGhP2P?.ghLink || firstGhP2P?.phLink || firstGhP2P?.adminLink || firstGhHrObj.txLink || ''
  } : (
    firstGhP2P ? {
      id: firstGhP2P.takerId || firstGhP2P.id,
      userId: firstGhP2P.takerUserId,
      userName: firstGhP2P.takerName,
      amountRequested: firstGhP2P.amount,
      amountReceived: firstGhP2P.status === 'completed' ? firstGhP2P.amount : 0,
      status: firstGhP2P.status === 'completed' ? 'completed' : 'approved',
      createdAt: firstGhP2P.createdAt,
      remarks: `First Received Help (Cycle #${cycleState.cycleCount})`,
      txLink: firstGhP2P.ghLink || firstGhP2P.phLink || firstGhP2P.adminLink || ''
    } as any : undefined
  );

  const secondGhP2P = p2pMatches.find(m =>
    (isUserMatch(currentUser, m.takerUserId) || isUserMatch(currentUser, m.takerId) || (m.takerPhone && currentUser.phone && m.takerPhone.trim() === currentUser.phone.trim())) &&
    m.amount === 50 &&
    m.status !== 'rejected'
  );
  const secondGhHrObj = helpRequests.find(h => isUserMatch(currentUser, h.userId) && h.amountRequested === 50 && h.remarks?.includes(`Second Received Help`) && h.remarks?.includes(`Cycle #${cycleState.cycleCount}`)) || helpRequests.filter(h => isUserMatch(currentUser, h.userId) && h.amountRequested === 50)[1];

  const secondGhHr = secondGhHrObj ? {
    ...secondGhHrObj,
    txLink: secondGhP2P?.ghLink || secondGhP2P?.phLink || secondGhP2P?.adminLink || secondGhHrObj.txLink || ''
  } : (
    secondGhP2P ? {
      id: secondGhP2P.takerId || secondGhP2P.id,
      userId: secondGhP2P.takerUserId,
      userName: secondGhP2P.takerName,
      amountRequested: secondGhP2P.amount,
      amountReceived: secondGhP2P.status === 'completed' ? secondGhP2P.amount : 0,
      status: secondGhP2P.status === 'completed' ? 'completed' : 'approved',
      createdAt: secondGhP2P.createdAt,
      remarks: `Second Received Help (Cycle #${cycleState.cycleCount})`,
      txLink: secondGhP2P.ghLink || secondGhP2P.phLink || secondGhP2P.adminLink || ''
    } as any : undefined
  );

  const thirdGhP2P = p2pMatches.find(m =>
    (isUserMatch(currentUser, m.takerUserId) || isUserMatch(currentUser, m.takerId) || (m.takerPhone && currentUser.phone && m.takerPhone.trim() === currentUser.phone.trim())) &&
    m.amount === 25 &&
    m.status !== 'rejected'
  );
  const thirdGhHrObj = helpRequests.find(h => isUserMatch(currentUser, h.userId) && h.amountRequested === 25 && h.remarks?.includes(`Third Received Help`) && h.remarks?.includes(`Cycle #${cycleState.cycleCount}`)) || helpRequests.find(h => isUserMatch(currentUser, h.userId) && h.amountRequested === 25);
  const thirdGhHr = thirdGhHrObj ? {
    ...thirdGhHrObj,
    txLink: thirdGhP2P?.ghLink || thirdGhP2P?.phLink || thirdGhP2P?.adminLink || thirdGhHrObj.txLink || ''
  } : (thirdGhP2P ? {
    id: thirdGhP2P.takerId || thirdGhP2P.id,
    userId: thirdGhP2P.takerUserId,
    userName: thirdGhP2P.takerName,
    amountRequested: thirdGhP2P.amount,
    amountReceived: thirdGhP2P.status === 'completed' ? thirdGhP2P.amount : 0,
    status: thirdGhP2P.status === 'completed' ? 'completed' : 'approved',
    createdAt: thirdGhP2P.createdAt,
    remarks: `Third Received Help (Cycle #${cycleState.cycleCount})`,
    txLink: thirdGhP2P.ghLink || thirdGhP2P.phLink || thirdGhP2P.adminLink || ''
  } as any : undefined);

  const fourthGhHrObj = helpRequests.find(h => isUserMatch(currentUser, h.userId) && h.amountRequested === 25 && h.remarks?.includes(`Fourth Received Help`) && h.remarks?.includes(`Cycle #${cycleState.cycleCount}`)) || helpRequests.filter(h => isUserMatch(currentUser, h.userId) && h.amountRequested === 25)[1];
  const fourthGhHr = fourthGhHrObj;

  const fifthGhHrObj = helpRequests.find(h => isUserMatch(currentUser, h.userId) && h.amountRequested === 25 && h.remarks?.includes(`Fifth Received Help`) && h.remarks?.includes(`Cycle #${cycleState.cycleCount}`)) || helpRequests.filter(h => isUserMatch(currentUser, h.userId) && h.amountRequested === 25)[2];
  const fifthGhHr = fifthGhHrObj;

  // Countdown timer for Gateway Portal
  React.useEffect(() => {
    if (activeGateway || showSecureClaimGateway) {
      const interval = setInterval(() => {
        setGatewayTimer(prev => (prev > 0 ? prev - 1 : 0));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [activeGateway, showSecureClaimGateway]);

  // Auto pre-fill withdrawal target address with user's saved profile bank/UPI details
  React.useEffect(() => {
    if (activeWalletTab === 'withdrawal' && !withdrawalAddress) {
      if (currentUser.upiId) {
        setWithdrawalAddress(currentUser.upiId);
      } else if (currentUser.bankName && currentUser.accountNumber) {
        setWithdrawalAddress(`${currentUser.bankName} - A/C: ${currentUser.accountNumber}${currentUser.ifscCode ? ` (IFSC: ${currentUser.ifscCode})` : ''}`);
      } else if (currentUser.secondaryUpiId) {
        setWithdrawalAddress(currentUser.secondaryUpiId);
      } else if (currentUser.secondaryBankName && currentUser.secondaryAccountNumber) {
        setWithdrawalAddress(`${currentUser.secondaryBankName} - A/C: ${currentUser.secondaryAccountNumber}${currentUser.secondaryIfscCode ? ` (IFSC: ${currentUser.secondaryIfscCode})` : ''}`);
      }
    }
  }, [activeWalletTab, currentUser, withdrawalAddress]);

  // Synchronize cycleState with actual database records reactively without infinite loops
  React.useEffect(() => {
    const hasPinContrib = contributions.some(c => c.userId === currentUser.id && c.amount === 10 && c.status !== 'rejected');
    const hasUsedPin = issuedPins.some(p => p.isUsed && (
      p.userId === currentUser.id ||
      p.userId === currentUser.referralCode ||
      p.userId === currentUser.directId ||
      (currentUser.email && p.userId?.toLowerCase() === currentUser.email.toLowerCase()) ||
      (currentUser.phone && p.userId === currentUser.phone) ||
      (currentUser.registrationPin && p.pinCode === currentUser.registrationPin)
    ));
    const pinApproved = hasPinContrib || hasUsedPin || !!currentUser.registrationPin;

    const ph1Legacy = contributions.find(c => c.userId === currentUser.id && c.amount === 40);
    const ph1Admin = contributions.find(c => c.userId === currentUser.id && c.amount === 20 && c.remarks?.includes('First Provide Help - Admin'));
    const ph1User = contributions.find(c => c.userId === currentUser.id && c.amount === 20 && c.remarks?.includes('First Provide Help - User'));
    
    const ph2 = contributions.find(c => c.userId === currentUser.id && c.amount === 50 && c.remarks?.includes('Second Provide Help'));
    
    const myUserHelpRequests = helpRequests.filter(h => h.userId === currentUser.id && h.status !== 'rejected');
    const gh1 = myUserHelpRequests.find(h => h.amountRequested === 50 && (h.remarks?.includes('First Received Help') || h.title.includes('1st Payout')));
    const gh2 = myUserHelpRequests.filter(h => h.amountRequested === 50)[1] || myUserHelpRequests.find(h => h.remarks?.includes('Second Received Help') || h.title.includes('2nd Payout'));
    const gh3 = myUserHelpRequests.find(h => h.amountRequested === 25 && (h.remarks?.includes('Third Received Help') || h.title.includes('3rd Payout')));
    const gh4 = myUserHelpRequests.filter(h => h.amountRequested === 25)[1] || myUserHelpRequests.find(h => h.remarks?.includes('Fourth Received Help') || h.title.includes('4th Payout'));
    const gh5 = myUserHelpRequests.filter(h => h.amountRequested === 25)[2] || myUserHelpRequests.find(h => h.remarks?.includes('Fifth Received Help') || h.title.includes('5th Payout'));

    const ph1Approved = (firstPhContrib?.status === 'approved') || (firstPhP2P?.status === 'completed') || (ph1Admin?.status === 'approved' && ph1User?.status === 'approved') || (ph1Legacy?.status === 'approved') || contributions.some(c => c.userId === currentUser.id && (c.amount === 50 || c.amount === 40) && c.status === 'approved');
    const ph2Approved = ph2?.status === 'approved' || contributions.some(c => c.userId === currentUser.id && c.amount === 50 && c.status === 'approved');
    const gh1Completed = gh1?.status === 'completed';
    const gh2Completed = gh2?.status === 'completed';
    const gh3Completed = gh3?.status === 'completed';
    const gh4Completed = gh4?.status === 'completed';
    const gh5Completed = gh5?.status === 'completed';

    let needsUpdate = false;
    const updates: Partial<typeof cycleState> = {};

    if (pinApproved && !cycleState.pinPurchased) {
      updates.pinPurchased = true;
      if (cycleState.currentStep === 'buy_pin') {
        updates.currentStep = 'first_ph';
      }
      needsUpdate = true;
    }

    if (ph1Approved !== cycleState.firstPhSubmitted) {
      updates.firstPhSubmitted = ph1Approved;
      needsUpdate = true;
    }

    if (ph2Approved !== cycleState.secondPhSubmitted) {
      updates.secondPhSubmitted = ph2Approved;
      needsUpdate = true;
    }

    if (gh1Completed !== cycleState.firstGhReceived) {
      updates.firstGhReceived = gh1Completed;
      needsUpdate = true;
    }

    if (gh2Completed !== cycleState.secondGhReceived) {
      updates.secondGhReceived = gh2Completed;
      needsUpdate = true;
    }

    if (gh3Completed !== cycleState.thirdGhReceived) {
      updates.thirdGhReceived = gh3Completed;
      needsUpdate = true;
    }

    if (gh4Completed !== cycleState.fourthGhReceived) {
      updates.fourthGhReceived = gh4Completed;
      needsUpdate = true;
    }

    if (gh5Completed !== cycleState.fifthGhReceived) {
      updates.fifthGhReceived = gh5Completed;
      needsUpdate = true;
    }

    // Reactively determine correct currentStep
    let calculatedStep = cycleState.currentStep;
    if (cycleState.currentStep === 'completed') {
      calculatedStep = 'buy_pin';
      updates.currentStep = 'buy_pin';
      updates.pinPurchased = false;
      updates.firstPhSubmitted = false;
      updates.secondPhSubmitted = false;
      updates.firstGhReceived = false;
      updates.secondGhReceived = false;
      updates.thirdGhReceived = false;
      updates.fourthGhReceived = false;
      updates.fifthGhReceived = false;
      updates.cycleCount = cycleState.cycleCount + 1;
      needsUpdate = true;
    } else if (cycleState.currentStep !== 'buy_pin' || (cycleState.pinPurchased && pinApproved)) {
      if (!ph1Approved) {
        calculatedStep = 'first_ph';
      } else if (!ph2Approved) {
        calculatedStep = 'second_ph';
      } else if (!gh1Completed) {
        calculatedStep = 'first_gh';
      } else if (!gh2Completed) {
        calculatedStep = 'second_gh';
      } else if (!gh3Completed) {
        calculatedStep = 'third_gh';
      } else if (!gh4Completed) {
        calculatedStep = 'fourth_gh';
      } else if (!gh5Completed) {
        calculatedStep = 'fifth_gh';
      } else {
        // After reaching 175/Rs. gh (all 5 steps complete), go back to 10/Rs (buy_pin) continuously
        calculatedStep = 'buy_pin';
        updates.currentStep = 'buy_pin';
        updates.pinPurchased = false;
        updates.firstPhSubmitted = false;
        updates.secondPhSubmitted = false;
        updates.firstGhReceived = false;
        updates.secondGhReceived = false;
        updates.thirdGhReceived = false;
        updates.fourthGhReceived = false;
        updates.fifthGhReceived = false;
        updates.cycleCount = cycleState.cycleCount + 1;
        needsUpdate = true;
      }

      if (calculatedStep !== cycleState.currentStep && calculatedStep !== 'buy_pin') {
        updates.currentStep = calculatedStep as any;
        needsUpdate = true;
      }

      // Auto-dispatch Get Help requests safely without infinite loops
      if (calculatedStep === 'first_gh' && !gh1) {
        onAddHelpRequest({
          id: 'hr-gh1-' + currentUser.id + '-' + cycleState.cycleCount,
          userId: currentUser.id,
          userName: currentUser.name,
          title: `1st Payout (Cycle #${cycleState.cycleCount})`,
          description: `₹50 Mutual Aid Cycle Payout Reward`,
          amountRequested: 50,
          amountReceived: 0,
          status: 'approved',
          createdAt: new Date().toISOString(),
          remarks: `First Received Help - ₹50 (Cycle #${cycleState.cycleCount})`,
          txLink: ""
        });
      } else if (calculatedStep === 'second_gh' && !gh2) {
        onAddHelpRequest({
          id: 'hr-gh2-' + currentUser.id + '-' + cycleState.cycleCount,
          userId: currentUser.id,
          userName: currentUser.name,
          title: `2nd Payout (Cycle #${cycleState.cycleCount})`,
          description: `₹50 Mutual Aid Cycle Payout Reward`,
          amountRequested: 50,
          amountReceived: 0,
          status: 'approved',
          createdAt: new Date().toISOString(),
          remarks: `Second Received Help - ₹50 (Cycle #${cycleState.cycleCount})`,
          txLink: ""
        });
      } else if (calculatedStep === 'third_gh' && !gh3) {
        onAddHelpRequest({
          id: 'hr-gh3-' + currentUser.id + '-' + cycleState.cycleCount,
          userId: currentUser.id,
          userName: currentUser.name,
          title: `3rd Payout (Cycle #${cycleState.cycleCount})`,
          description: `₹25 Mutual Aid Cycle Payout Reward`,
          amountRequested: 25,
          amountReceived: 0,
          status: 'approved',
          createdAt: new Date().toISOString(),
          remarks: `Third Received Help - ₹25 (Cycle #${cycleState.cycleCount})`,
          txLink: ""
        });
      } else if (calculatedStep === 'fourth_gh' && !gh4) {
        onAddHelpRequest({
          id: 'hr-gh4-' + currentUser.id + '-' + cycleState.cycleCount,
          userId: currentUser.id,
          userName: currentUser.name,
          title: `4th Payout (Cycle #${cycleState.cycleCount})`,
          description: `₹25 Mutual Aid Cycle Payout Reward`,
          amountRequested: 25,
          amountReceived: 0,
          status: 'approved',
          createdAt: new Date().toISOString(),
          remarks: `Fourth Received Help - ₹25 (Cycle #${cycleState.cycleCount})`,
          txLink: ""
        });
      } else if (calculatedStep === 'fifth_gh' && !gh5) {
        onAddHelpRequest({
          id: 'hr-gh5-' + currentUser.id + '-' + cycleState.cycleCount,
          userId: currentUser.id,
          userName: currentUser.name,
          title: `5th Payout (Cycle #${cycleState.cycleCount})`,
          description: `₹25 Mutual Aid Cycle Payout Reward`,
          amountRequested: 25,
          amountReceived: 0,
          status: 'approved',
          createdAt: new Date().toISOString(),
          remarks: `Fifth Received Help - ₹25 (Cycle #${cycleState.cycleCount})`,
          txLink: ""
        });
      }
    }

    if (needsUpdate) {
      setCycleState(prev => {
        const merged = { ...prev, ...updates };
        let prov = prev.pinPurchased ? 10 : 0;
        if (merged.firstPhSubmitted) prov += 40;
        if (merged.secondPhSubmitted) prov += 50;

        let rec = 0;
        if (merged.firstGhReceived) rec += 50;
        if (merged.secondGhReceived) rec += 50;
        if (merged.thirdGhReceived) rec += 25;
        if (merged.fourthGhReceived) rec += 25;
        if (merged.fifthGhReceived) rec += 25;

        merged.totalProvided = prov;
        merged.totalReceived = rec;
        merged.totalProfit = rec - prov;

        return merged;
      });
    }
  }, [contributions, helpRequests, cycleState.cycleCount, cycleState.currentStep, cycleState.pinPurchased, cycleState.firstPhSubmitted, cycleState.secondPhSubmitted, cycleState.firstGhReceived, cycleState.secondGhReceived, cycleState.thirdGhReceived, cycleState.fourthGhReceived, cycleState.fifthGhReceived, currentUser.id, currentUser.name]);

  // Real-time verified cycle profit calculation from transactions ledger
  const realTimeCycleProfit = calculateCurrentCycleProfit ? calculateCurrentCycleProfit(currentUser.id) : cycleState.totalProfit;

  const handleCycleAction = (action: 'buy_pin' | 'first_ph' | 'second_ph' | 'first_gh' | 'second_gh' | 'third_gh' | 'fourth_gh' | 'fifth_gh' | 'reset') => {
    if (action !== 'buy_pin' && action !== 'reset') {
      if (!cycleState.pinPurchased) {
        alert('जब तक PIN का पेमेंट कन्फर्म/एक्टिवेट नहीं होता, तब तक आप आगे नहीं बढ़ सकते हैं। कृपया पहले ₹10 PIN दर्ज/कन्फर्म करें।');
        return;
      }
    }

    if (action === 'buy_pin') {
      if (cycleState.currentStep !== 'buy_pin' || cycleState.pinPurchased) {
        alert('Your current cycle is still active! You cannot activate a new PIN until your current cycle is fully completed.');
        return;
      }
      if (!enteredPin.trim()) {
        alert('Please enter or select a ₹10 PIN sent by the Admin to activate help.');
        return;
      }
      const isSuccess = onUsePin(enteredPin, currentUser.id, currentUser.name);
      if (!isSuccess) {
        alert('Invalid or already consumed ₹10 PIN. Please enter a valid unused PIN sent to you by the Admin.');
        return;
      }

      // Add the ₹10 PIN contribution directly as approved so PIN activation is complete
      const newPinContribId = 'contrib-pin-' + Math.random().toString(36).substring(2, 9);
      onAddContribution({
        id: newPinContribId,
        userId: currentUser.id,
        userName: currentUser.name,
        amount: 10,
        status: 'approved',
        paymentProof: `PIN Activated: ${enteredPin.toUpperCase()}`,
        createdAt: new Date().toISOString(),
        remarks: `Registration PIN - ₹10 (Cycle #${cycleState.cycleCount})`,
        txLink: ""
      });

      onAddTransaction({
        id: 'tx-cycle-pin-' + Math.random().toString(36).substring(2, 9),
        userId: currentUser.id,
        userName: currentUser.name,
        type: 'contribution',
        amount: 10,
        status: 'completed',
        description: `Activated ₹10 PIN: ${enteredPin.toUpperCase()} (Cycle #${cycleState.cycleCount}) - Added to Giver Queue for ₹50 PH`,
        createdAt: new Date().toISOString()
      });

      setCycleState(prev => {
        return {
          ...prev,
          pinPurchased: true,
          currentStep: 'first_ph'
        };
      });
      setEnteredPin('');
      alert('PIN Verified & Activated! Your ID is now in the Giver Queue for ₹50 PH. Step 2 (₹50 First PH Link Box) is now open.');
      return;
    } else if (action === 'first_ph') {
      const phCost = 50;
      let existingPh1 = contributions.find(c => c.userId === currentUser.id && (c.amount === 50 || c.amount === 40) && c.remarks?.includes(`Cycle #${cycleState.cycleCount}`));
      if (!existingPh1) {
        const newContribId = 'contrib-ph1-' + Math.random().toString(36).substring(2, 9);
        onAddContribution({
          id: newContribId,
          userId: currentUser.id,
          userName: currentUser.name,
          amount: phCost,
          status: 'pending_proof',
          paymentProof: 'Pending Upload',
          createdAt: new Date().toISOString(),
          remarks: `First Provide Help - ₹50 (Cycle #${cycleState.cycleCount})`,
          txLink: `https://help100.com/secure-gateway/ph/${newContribId}`
        });
      } else if (existingPh1.status === 'pending_dispatch') {
        onUpdateContribution?.(existingPh1.id, 'pending_proof', 'Payment link activated by user');
      }
      setCycleState(prev => ({ ...prev, currentStep: 'first_ph' }));
      alert('First PH (₹50) active! Payment details and slip upload are now accessible.');
    } else if (action === 'second_ph') {
      const phCost = 50;
      let existingPh2 = contributions.find(c => c.userId === currentUser.id && c.amount === 50 && c.remarks?.includes('Second Provide Help') && c.remarks?.includes(`Cycle #${cycleState.cycleCount}`));
      if (!existingPh2) {
        const newContribId = 'contrib-ph2-' + Math.random().toString(36).substring(2, 9);
        onAddContribution({
          id: newContribId,
          userId: currentUser.id,
          userName: currentUser.name,
          amount: phCost,
          status: 'pending_dispatch',
          paymentProof: 'Awaiting Admin Link',
          createdAt: new Date().toISOString(),
          remarks: `Second Provide Help - ₹50 (Cycle #${cycleState.cycleCount})`,
          txLink: ""
        });
      }
      setCycleState(prev => ({ ...prev, currentStep: 'second_ph', firstPhSubmitted: true }));
      alert('सफलता! आपकी ₹50 पेमेंट देने की इच्छा एडमिन गिवर (Giver) लिस्ट में जुड़ गई है। एडमिन आपको जल्द ही पेमेंट लिंक भेजेंगे।');
    } else if (action === 'first_gh') {
      const ghReward = 50;
      const newHrId = 'hr-gh1-' + Math.random().toString(36).substring(2, 9);
      onAddHelpRequest({
        id: newHrId,
        userId: currentUser.id,
        userName: currentUser.name,
        title: `1st Payout (Cycle #${cycleState.cycleCount})`,
        description: `₹50 Mutual Aid Cycle Payout Reward`,
        amountRequested: ghReward,
        amountReceived: 0,
        status: 'approved',
        createdAt: new Date().toISOString(),
        remarks: `First Received Help - ₹50 (Cycle #${cycleState.cycleCount})`,
        txLink: ""
      });
      alert('₹50 Get Help payout request registered! Please wait for the admin to match you and dispatch the payout link.');
    } else if (action === 'second_gh') {
      const ghReward = 50;
      const newHrId = 'hr-gh2-' + Math.random().toString(36).substring(2, 9);
      onAddHelpRequest({
        id: newHrId,
        userId: currentUser.id,
        userName: currentUser.name,
        title: `2nd Payout (Cycle #${cycleState.cycleCount})`,
        description: `₹50 Mutual Aid Cycle Payout Reward`,
        amountRequested: ghReward,
        amountReceived: 0,
        status: 'approved',
        createdAt: new Date().toISOString(),
        remarks: `Second Received Help - ₹50 (Cycle #${cycleState.cycleCount})`,
        txLink: ""
      });
      alert('₹50 Get Help payout request registered! Please wait for the admin to match you and dispatch the payout link.');
    } else if (action === 'third_gh') {
      const ghReward = 25;
      const newHrId = 'hr-gh3-' + Math.random().toString(36).substring(2, 9);
      onAddHelpRequest({
        id: newHrId,
        userId: currentUser.id,
        userName: currentUser.name,
        title: `3rd Payout (Cycle #${cycleState.cycleCount})`,
        description: `₹25 Mutual Aid Cycle Payout Reward`,
        amountRequested: ghReward,
        amountReceived: 0,
        status: 'approved',
        createdAt: new Date().toISOString(),
        remarks: `Third Received Help - ₹25 (Cycle #${cycleState.cycleCount})`,
        txLink: ""
      });
      alert('₹25 Get Help payout request registered! Please wait for the admin to match you and dispatch the payout link.');
    } else if (action === 'fourth_gh') {
      const ghReward = 25;
      const newHrId = 'hr-gh4-' + Math.random().toString(36).substring(2, 9);
      onAddHelpRequest({
        id: newHrId,
        userId: currentUser.id,
        userName: currentUser.name,
        title: `4th Payout (Cycle #${cycleState.cycleCount})`,
        description: `₹25 Mutual Aid Cycle Payout Reward`,
        amountRequested: ghReward,
        amountReceived: 0,
        status: 'approved',
        createdAt: new Date().toISOString(),
        remarks: `Fourth Received Help - ₹25 (Cycle #${cycleState.cycleCount})`,
        txLink: ""
      });
      alert('₹25 Get Help payout request registered! Please wait for the admin to match you and dispatch the payout link.');
    } else if (action === 'fifth_gh') {
      const ghReward = 25;
      const newHrId = 'hr-gh5-' + Math.random().toString(36).substring(2, 9);
      onAddHelpRequest({
        id: newHrId,
        userId: currentUser.id,
        userName: currentUser.name,
        title: `5th Payout (Cycle #${cycleState.cycleCount})`,
        description: `₹25 Mutual Aid Cycle Payout Reward`,
        amountRequested: ghReward,
        amountReceived: 0,
        status: 'approved',
        createdAt: new Date().toISOString(),
        remarks: `Fifth Received Help - ₹25 (Cycle #${cycleState.cycleCount})`,
        txLink: ""
      });
      alert('₹25 Get Help payout request registered! Please wait for the admin to match you and dispatch the payout link.');
    } else if (action === 'reset') {
      setCycleState(prev => ({
        currentStep: 'buy_pin',
        pinPurchased: false,
        firstPhSubmitted: false,
        secondPhSubmitted: false,
        firstGhReceived: false,
        secondGhReceived: false,
        thirdGhReceived: false,
        fourthGhReceived: false,
        fifthGhReceived: false,
        totalProvided: 0,
        totalReceived: 0,
        totalProfit: 0,
        cycleCount: prev.cycleCount + 1
      }));
    }
  };

  const handleQuickDeposit = () => {
    onUpdateUser({
      ...currentUser,
      walletBalance: currentUser.walletBalance + 100
    });
    onAddTransaction({
      id: 'tx-quick-deposit-' + Math.random().toString(36).substring(2, 9),
      userId: currentUser.id,
      userName: currentUser.name,
      type: 'deposit',
      amount: 100,
      status: 'completed',
      description: 'Quick Demo Deposit (₹100) for Cycle Plan Testing',
      createdAt: new Date().toISOString()
    });
  };

  const handleSendGivingEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!giverName.trim()) {
      alert('Please provide a Giver Name');
      return;
    }
    const amountNum = parseFloat(giveAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      alert('Please provide a valid contribution amount');
      return;
    }

    const newContrib: Contribution = {
      id: 'contrib-' + Math.random().toString(36).substr(2, 9),
      userId: 'user-' + Math.random().toString(36).substr(2, 9),
      userName: giverName.trim(),
      amount: amountNum,
      paymentProof: 'manual_receipt_upload.png',
      status: giveStatus,
      createdAt: new Date().toISOString(),
      verifiedAt: giveStatus === 'approved' ? new Date().toISOString() : undefined,
      remarks: giveRemarks
    };

    onAddContribution(newContrib);
    
    // Clear form
    setGiverName('');
    setGiveAmount('150');
    setGiveRemarks('Manual verification complete by admin');
  };

  const handleSendTakingEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!takerName.trim()) {
      alert('Please provide a Taker Name');
      return;
    }
    if (!takeTitle.trim()) {
      alert('Please provide a Title / Campaign Name');
      return;
    }
    const amountNum = parseFloat(takeAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      alert('Please provide a valid amount requested');
      return;
    }

    const newHelp: HelpRequest = {
      id: 'help-' + Math.random().toString(36).substr(2, 9),
      userId: 'user-' + Math.random().toString(36).substr(2, 9),
      userName: takerName.trim(),
      title: takeTitle.trim(),
      description: takeDesc.trim() || 'Urgent mutual aid needed',
      amountRequested: amountNum,
      amountReceived: takeStatus === 'completed' ? amountNum : 0,
      documentUrl: 'supporting_proof.pdf',
      status: takeStatus,
      createdAt: new Date().toISOString()
    };

    onAddHelpRequest(newHelp);
    
    // Clear form
    setTakerName('');
    setTakeTitle('');
    setTakeDesc('');
    setTakeAmount('800');
  };

  // Referral Copy Utility
  const [copied, setCopied] = useState(false);
  const userRefCode = (currentUser.referralCode || currentUser.id || '').trim();
  const handleCopyLink = () => {
    const link = `${window.location.origin}/?ref=${userRefCode}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportCSV = () => {
    if (userTransactions.length === 0) {
      alert("No transaction logs available to export.");
      return;
    }
    const headers = ["Transaction ID", "Date", "Type", "Description", "Amount (INR)", "Status"];
    const rows = userTransactions.map(tx => [
      tx.id,
      new Date(tx.createdAt).toLocaleDateString(),
      tx.type,
      tx.description,
      tx.amount,
      tx.status
    ]);
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(","), ...rows.map(e => e.map(val => `"${String(val).replace(/"/g, '""')}"`).join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `transaction_history_${currentUser.id}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Instant Deposit Payment Gateway completion handler
  const handleInstantDepositSuccess = (amt: number, txId: string, payMethod: string) => {
    // 1. Create a completed transaction in state
    const newTx: Transaction = {
      id: txId,
      userId: currentUser.id,
      userName: currentUser.name,
      type: 'deposit',
      amount: amt,
      status: 'completed',
      description: `Instant Platform Wallet Deposit via Secure Gateway Link (${payMethod})`,
      createdAt: new Date().toISOString(),
      paymentMethod: payMethod,
      txLink: `https://checkout.help100.com/receipt/${txId}`
    };

    onAddTransaction(newTx);

    // 2. Instantly update user's wallet balance
    const updatedUser = {
      ...currentUser,
      walletBalance: currentUser.walletBalance + amt,
      provideWallet: (currentUser.provideWallet ?? 0) + amt
    };
    onUpdateUser(updatedUser);

    setWalletSuccessMsg(`Success! ₹${amt.toLocaleString()} has been deposited instantly into your wallet via our secure gateway link.`);
    setDepositAmount('');
    setDepositTxLink('');
    setTimeout(() => setWalletSuccessMsg(''), 8000);
  };

  // Deposit Submit handler
  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(depositAmount);
    if (isNaN(amt) || amt <= 0) {
      alert('Please enter a valid amount.');
      return;
    }

    if (depositOption === 'instant') {
      // Setup simulated instant gateway checkout payment link
      const randomTxId = 'tx-instant-' + Math.random().toString(36).substr(2, 9);
      setGatewayAmount(amt);
      setGatewayTxId(randomTxId);
      setGatewayStep('details');
      setShowPaymentGateway(true);
    } else {
      // Create a pending deposit transaction
      const newTx: Transaction = {
        id: 'tx-' + Math.random().toString(36).substr(2, 9),
        userId: currentUser.id,
        userName: currentUser.name,
        type: 'deposit',
        amount: amt,
        status: 'pending',
        description: `Manual Wallet Deposit Request via ${depositMethod}`,
        createdAt: new Date().toISOString(),
        paymentMethod: depositMethod,
        txLink: depositTxLink.trim() || undefined
      };

      onAddTransaction(newTx);
      setWalletSuccessMsg(`Manual deposit request of ₹${amt} submitted successfully. Please wait for administrator verification.`);
      setDepositAmount('');
      setDepositTxLink('');
      setTimeout(() => setWalletSuccessMsg(''), 5000);
    }
  };

  // Withdrawal Submit handler
  const handleWithdrawalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(withdrawalAmount);
    if (isNaN(amt) || amt <= 0) {
      alert('Please enter a valid amount.');
      return;
    }

    // Minimum and multiple rules depending on the wallet
    if (withdrawalWallet === 'provide' || withdrawalWallet === 'get') {
      if (amt < 75) {
        alert('Minimum withdrawal for Provide and Get Wallet is ₹75.');
        return;
      }
    } else if (withdrawalWallet === 'direct' || withdrawalWallet === 'level' || withdrawalWallet === 'main') {
      const walletName = withdrawalWallet === 'main' ? 'Main' : withdrawalWallet.toUpperCase();
      if (amt < 100) {
        alert(`Minimum withdrawal for ${walletName} Wallet is ₹100.`);
        return;
      }
      if (amt % 100 !== 0) {
        alert(`Withdrawal amount from ${walletName} Wallet must be a multiple of ₹100.`);
        return;
      }
    }

    // Balance check for specific wallet
    const walletBalanceKey = withdrawalWallet === 'provide' ? 'provideWallet' 
      : withdrawalWallet === 'get' ? 'getWallet'
      : withdrawalWallet === 'direct' ? 'directWallet'
      : withdrawalWallet === 'level' ? 'levelWallet'
      : 'walletBalance';
    
    const availableWalletBalance = currentUser[walletBalanceKey] ?? 0;

    if (availableWalletBalance < amt) {
      alert(`Insufficient balance in your ${withdrawalWallet.toUpperCase()} Wallet. Available: ₹${availableWalletBalance.toLocaleString()}`);
      return;
    }

    if (currentUser.kycStatus !== 'approved') {
      alert('Your KYC must be approved before you can submit withdrawal requests.');
      return;
    }

    // Deduct from specific wallet and update user state
    const newMainBalance = Math.max(0, currentUser.walletBalance - amt);
    const newSpecificBalance = Math.max(0, availableWalletBalance - amt);

    const updatedUser: User = {
      ...currentUser,
      walletBalance: newMainBalance,
      ...(walletBalanceKey !== 'walletBalance' ? { [walletBalanceKey]: newSpecificBalance } : {}),
      _updatedAt: Date.now()
    };

    // Ensure sub-wallets do not exceed new main wallet balance
    if (updatedUser.getWallet !== undefined && updatedUser.getWallet > newMainBalance) {
      updatedUser.getWallet = newMainBalance;
    }
    if (updatedUser.provideWallet !== undefined && updatedUser.provideWallet > newMainBalance) {
      updatedUser.provideWallet = newMainBalance;
    }
    if (updatedUser.directWallet !== undefined && updatedUser.directWallet > newMainBalance) {
      updatedUser.directWallet = newMainBalance;
    }
    if (updatedUser.levelWallet !== undefined && updatedUser.levelWallet > newMainBalance) {
      updatedUser.levelWallet = newMainBalance;
    }

    onUpdateUser(updatedUser);

    // Create pending withdrawal transaction
    const newTx: Transaction = {
      id: 'tx-' + Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      userName: currentUser.name,
      type: 'withdrawal',
      amount: amt,
      status: 'pending',
      description: `Withdrawal request from ${withdrawalWallet.toUpperCase()} WALLET to account: ${withdrawalAddress || 'Platform Wallet Address'}`,
      createdAt: new Date().toISOString(),
      walletSource: withdrawalWallet
    };

    onAddTransaction(newTx);
    setWalletSuccessMsg(`Withdrawal request of ₹${amt} from ${withdrawalWallet.toUpperCase()} Wallet submitted. Balance updated.`);
    setWithdrawalAmount('');
    setWithdrawalAddress('');
    setTimeout(() => setWalletSuccessMsg(''), 5000);
  };

  // Contribution Submit handler
  const handleContributionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(contribAmount);
    if (isNaN(amt) || amt <= 0) {
      alert('Please enter a valid contribution amount.');
      return;
    }
    if (amt < systemSettings.minContribution || amt > systemSettings.maxContribution) {
      alert(`Contribution must be between ₹${systemSettings.minContribution} and ₹${systemSettings.maxContribution}.`);
      return;
    }

    const proofVal = contribFile.trim() || 'Pending Upload';

    // Create a contribution entity
    const newContrib: Contribution = {
      id: 'contrib-' + Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      userName: currentUser.name,
      amount: amt,
      paymentProof: proofVal,
      status: 'pending_verification',
      createdAt: new Date().toISOString(),
      txLink: contribTxLink.trim() || undefined
    };

    onAddContribution(newContrib);

    // Add equivalent transaction tracking record
    const newTx: Transaction = {
      id: 'tx-' + Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      userName: currentUser.name,
      type: 'contribution',
      amount: amt,
      status: 'pending',
      description: `Mutual Pledge Contribution Pledge - Pending Admin Proof Verification`,
      createdAt: new Date().toISOString(),
      txLink: contribTxLink.trim() || undefined
    };
    onAddTransaction(newTx);

    setContribSuccessMsg(`Pledge contribution of ₹${amt} submitted with proof! Swap to Administrator to approve.`);
    setContribAmount('');
    setContribFile('');
    setContribTxLink('');
    setTimeout(() => setContribSuccessMsg(''), 6000);
  };

  const handleUploadProofSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProofContribId) {
      alert("Please select a contribution request to upload proof for.");
      return;
    }
    if (!proofFilename) {
      alert("Please specify the payment receipt / proof filename.");
      return;
    }
    if (onUpdateContributionProof) {
      onUpdateContributionProof(selectedProofContribId, proofFilename.trim(), proofTxLink.trim() || undefined);
      setContribSuccessMsg("Payment proof receipt uploaded successfully. Admin will verify shortly!");
      setSelectedProofContribId('');
      setProofFilename('');
      setProofTxLink('');
      setTimeout(() => setContribSuccessMsg(''), 6000);
    }
  };

  // Help Request Submit handler
  const handleHelpRequestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(helpAmount);
    if (isNaN(amt) || amt <= 0) {
      alert('Please enter a valid amount.');
      return;
    }
    if (currentUser.kycStatus !== 'approved') {
      alert('Your KYC must be approved by the platform administration before raising aid requests.');
      return;
    }

    const newHelp: HelpRequest = {
      id: 'help-' + Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      userName: currentUser.name,
      title: helpTitle,
      description: helpDesc,
      amountRequested: amt,
      amountReceived: 0,
      documentUrl: helpDocName || 'supporting_proof.pdf',
      status: 'pending_review',
      createdAt: new Date().toISOString()
    };

    onAddHelpRequest(newHelp);
    setHelpSuccessMsg('Your aid help request has been raised successfully! Admins will audit files.');
    setHelpTitle('');
    setHelpDesc('');
    setHelpAmount('');
    setHelpDocName('');
    setTimeout(() => setHelpSuccessMsg(''), 6000);
  };

  // Support Ticket handler
  const handleTicketSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject || !ticketMessage) return;

    const newTicket: SupportTicket = {
      id: 'ticket-' + Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      userName: currentUser.name,
      subject: ticketSubject,
      message: ticketMessage,
      status: 'open',
      createdAt: new Date().toISOString()
    };

    onAddTicket(newTicket);
    setTicketSuccessMsg('Support ticket registered! Customer relations will review shortly.');
    setTicketSubject('');
    setTicketMessage('');
    setTimeout(() => setTicketSuccessMsg(''), 5000);
  };

  // Handle instant payout claim via the unique withdrawal link / gateway
  const handleInstantClaimPayout = (route: 'primary' | 'secondary') => {
    setClaimProcessing(true);
    setClaimSuccessMsg('');

    // Select payment details
    const chosenUpi = route === 'primary' ? (currentUser.upiId || 'user@upi') : (currentUser.secondaryUpiId || 'user.sec@upi');
    const chosenBank = route === 'primary' ? (currentUser.bankName || 'SBI') : (currentUser.secondaryBankName || 'HDFC');
    const chosenAccount = route === 'primary' ? (currentUser.accountNumber || '9876543210') : (currentUser.secondaryAccountNumber || '5010098273615');

    // Create completed Help Requests for any pending GH steps
    const cycleNum = cycleState.cycleCount;
    
    const payoutSteps = [
      { key: 'first_gh', name: 'First Received Help', amount: 50, title: '1st Payout' },
      { key: 'second_gh', name: 'Second Received Help', amount: 50, title: '2nd Payout' },
      { key: 'third_gh', name: 'Third Received Help', amount: 25, title: '3rd Payout' },
      { key: 'fourth_gh', name: 'Fourth Received Help', amount: 25, title: '4th Payout' },
      { key: 'fifth_gh', name: 'Fifth Received Help', amount: 25, title: '5th Payout' },
    ];

    let claimedCount = 0;
    let claimedAmt = 0;

    payoutSteps.forEach(step => {
      // Check if this GH is already completed or received
      const isAlreadyReceived = 
        step.key === 'first_gh' ? cycleState.firstGhReceived :
        step.key === 'second_gh' ? cycleState.secondGhReceived :
        step.key === 'third_gh' ? cycleState.thirdGhReceived :
        step.key === 'fourth_gh' ? cycleState.fourthGhReceived :
        cycleState.fifthGhReceived;

      if (!isAlreadyReceived) {
        claimedCount++;
        claimedAmt += step.amount;

        // Add completed HelpRequest so the React sync loop detects and processes it seamlessly!
        const hrId = 'hr-auto-claim-' + step.key + '-' + Math.random().toString(36).substring(2, 9);
        onAddHelpRequest({
          id: hrId,
          userId: currentUser.id,
          userName: currentUser.name,
          title: `${step.title} (Cycle #${cycleNum})`,
          description: `₹${step.amount} Mutual Aid Cycle Payout Reward`,
          amountRequested: step.amount,
          amountReceived: step.amount,
          status: 'completed',
          createdAt: new Date().toISOString(),
          remarks: `${step.name} - ₹${step.amount} (Cycle #${cycleNum})`,
          txLink: `https://checkout.help100.com/withdraw/claim-${currentUser.id}`
        });
      }
    });

    setTimeout(() => {
      setClaimProcessing(false);
      if (claimedCount > 0) {
        setClaimSuccessMsg(`🎉 Success! ₹${claimedAmt} payout has been instantly approved and credited via Route: ${route.toUpperCase()} to ${chosenBank} (A/C: ...${chosenAccount.slice(-4)})!`);
      } else {
        setClaimSuccessMsg(`🎉 All payouts for this cycle are already completed and claimed!`);
      }
    }, 1200);
  };

  // Filtering list items for this specific user
  const userContributions = contributions.filter(c => c.userId === currentUser.id);
  const userHelpRequests = helpRequests.filter(h => h.userId === currentUser.id);
  const userTransactions = transactions.filter(t => t.userId === currentUser.id);
  const userTickets = tickets.filter(tk => tk.userId === currentUser.id);
  const unreadCount = notifications.filter(n => (n.userId === 'all' || n.userId === currentUser.id) && !n.read).length;

  // Helper to get direct recruits for any user by matching referralCode, user ID, email, phone, or name
  const getChildrenOfUser = (targetUser: User): User[] => {
    return getDirectChildren(targetUser, users);
  };

  // Helper to find any user's direct sponsor
  const getSponsorOfUser = (childUser: User | null): User | null => {
    return getSponsorOfUserUtil(childUser, users);
  };

  // Helper to find currentUser's direct sponsor
  const currentUserSponsor = getSponsorOfUser(currentUser);

  const referredUsers = getChildrenOfUser(currentUser);

  // Compute dynamic downline counts & lists per level (1 to 5)
  const getDownlineByLevel = (targetUser: User): { [level: number]: User[] } => {
    const levels: { [level: number]: User[] } = { 1: [], 2: [], 3: [], 4: [], 5: [] };
    const visited = new Set<string>([targetUser.id]);
    
    const traverse = (parentUser: User, currentLevel: number) => {
      if (currentLevel > 5 || !parentUser) return;
      
      const children = getChildrenOfUser(parentUser);
      const unvisitedChildren = children.filter(c => !visited.has(c.id));
      
      unvisitedChildren.forEach(c => visited.add(c.id));
      levels[currentLevel].push(...unvisitedChildren);
      
      unvisitedChildren.forEach(child => {
        traverse(child, currentLevel + 1);
      });
    };
    
    traverse(targetUser, 1);
    return levels;
  };

  const downlineByLevel = getDownlineByLevel(currentUser);
  const totalTeamCount = Object.values(downlineByLevel).reduce((sum, list) => sum + list.length, 0);
  
  // 1. Total Personal Team Help: Sum of approved contributions by direct referrals of the user
  const totalPersonalTeamHelpValue = contributions
    .filter(c => c.status === 'approved' && referredUsers.some(ru => ru.id === c.userId))
    .reduce((sum, c) => sum + c.amount, 0);

  // 2. Global Team Help: Sum of all approved contributions globally (excluding seed contributions for 00000 baseline)
  const globalTeamHelpValue = contributions
    .filter(c => c.status === 'approved' && c.id !== 'contrib-1' && c.id !== 'contrib-3')
    .reduce((sum, c) => sum + c.amount, 0);

  // 3. Upgrade Help Sponsor: Sum of upgrade/PIN transactions by the user
  const upgradeHelpSponsorValue = transactions
    .filter(t => t.userId === currentUser.id && (t.type === 'upgrade' || t.description.toLowerCase().includes('upgrade') || t.description.toLowerCase().includes('pin')))
    .reduce((sum, t) => sum + t.amount, 0);

  // 4. Global Help Sponsor: Completed deposit transactions that are designated as system sponsor/buffer
  const globalHelpSponsorValue = transactions
    .filter(t => t.type === 'deposit' && t.status === 'completed' && t.description.toLowerCase().includes('sponsor'))
    .reduce((sum, t) => sum + t.amount, 0);

  // 5. Total Profit Earn: Referral bonuses + growth_bonus + payout transactions for the current user
  const totalProfitEarnValue = transactions
    .filter(t => t.userId === currentUser.id && (t.type === 'referral_bonus' || t.type === 'growth_bonus' || t.type === 'interest' || t.type === 'payout' || t.type === 'matching_bonus'))
    .reduce((sum, t) => sum + t.amount, 0);

  if (currentUser.status === 'suspended') {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center w-full">
        <div className="max-w-md bg-slate-900 border border-red-500/30 p-8 rounded-3xl shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1 bg-red-500" />
          <div className="w-16 h-16 bg-red-500/10 border border-red-500/20 text-red-400 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold animate-pulse">
            ⚠️
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight mb-3">Account Suspended</h2>
          <p className="text-slate-400 text-sm leading-relaxed mb-6">
            Your account has been suspended by the platform administrator due to a system policy violation or suspicious transaction activities.
          </p>
          <div className="bg-slate-950 p-4 rounded-xl border border-white/5 mb-6 text-left space-y-2">
            <div className="text-[10px] text-slate-500 uppercase font-bold">Member Information</div>
            <div className="text-xs text-slate-300 font-bold">ID: <span className="font-mono text-red-400">{currentUser.id}</span></div>
            <div className="text-xs text-slate-300 font-bold">Email: <span className="font-mono text-red-400">{currentUser.email}</span></div>
          </div>
          <button
            onClick={() => onLogout()}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-extrabold text-xs uppercase tracking-wider rounded-xl border border-white/5 transition-colors cursor-pointer"
          >
            Log Out
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen flex flex-col md:flex-row transition-colors duration-500 ${
      demoRole === 'giver' ? 'bg-emerald-50' : 'bg-amber-50'
    }`}>
      
      {/* 1. Left Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-slate-900 text-slate-300 flex flex-col border-r border-slate-800">
        
        {/* Platform Brand Header */}
        <div className="p-4 border-b border-slate-800/80 flex items-center gap-3 bg-slate-950/30">
          <Logo size={36} showText={false} />
          <div>
            <h3 className="font-extrabold text-sm text-white tracking-wider leading-none">HELP 100</h3>
            <span className="text-[8px] text-emerald-400 font-black tracking-widest uppercase mt-0.5 block">Mutual Aid Network</span>
          </div>
        </div>
        
        {/* User Info Card */}
        <div className="p-5 border-b border-slate-800 bg-slate-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-emerald-400 font-bold">
              {currentUser.name.charAt(0)}
            </div>
            <div className="overflow-hidden">
              <h4 className="font-bold text-sm text-white truncate">{currentUser.name}</h4>
              <p className="text-xs text-slate-400 truncate">{currentUser.email}</p>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-800/80 text-[11px] space-y-1.5">
            <div className="flex items-center justify-between gap-1 bg-emerald-950/60 p-2 rounded-xl border border-emerald-800/60">
              <span className="text-[10px] uppercase font-extrabold text-emerald-300 tracking-wider">Your Direct ID:</span>
              <strong className="text-emerald-400 font-mono font-black text-xs bg-slate-900 px-2 py-0.5 rounded border border-emerald-700/50">
                {currentUser.referralCode || currentUser.id}
              </strong>
            </div>
            <div className="flex items-center justify-between gap-1 px-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Sponsor Name:</span>
              <strong className="text-emerald-400 font-bold truncate max-w-[110px]">
                {currentUserSponsor ? currentUserSponsor.name : (currentUser.referredBy ? `Ref Code: ${currentUser.referredBy}` : 'Direct Member')}
              </strong>
            </div>
            <div className="flex items-center justify-between gap-1 px-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Sponsor Ref ID:</span>
              <span className="text-emerald-300 font-mono font-bold">
                {currentUserSponsor ? (currentUserSponsor.referralCode || currentUserSponsor.id) : (currentUser.referredBy || 'ADMIN100')}
              </span>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">KYC Status</span>
            {currentUser.kycStatus === 'approved' ? (
              <span className="text-[10px] bg-emerald-950/60 text-emerald-400 px-2 py-0.5 rounded border border-emerald-800 font-semibold flex items-center gap-1">
                <UserCheck className="w-3 h-3" /> Approved
              </span>
            ) : currentUser.kycStatus === 'pending' ? (
              <span className="text-[10px] bg-amber-950/60 text-amber-400 px-2 py-0.5 rounded border border-amber-800 font-semibold">
                Pending Review
              </span>
            ) : (
              <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded border border-slate-700 font-semibold">
                Not Submitted
              </span>
            )}
          </div>
        </div>

        {/* Dashboard Nav links */}
        <nav className="flex-grow p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-280px)] scrollbar-thin scrollbar-thumb-slate-800">
          
          {/* Quick Cycle Plan Button */}
          <button
            id="user-nav-plan100"
            onClick={() => setActiveSubTab('plan100')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all cursor-pointer border border-dashed mb-2 ${
              activeSubTab === 'plan100' 
                ? 'bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 text-white border-emerald-400 font-bold shadow-md' 
                : 'hover:bg-slate-800/60 text-emerald-400 hover:text-emerald-300 border-emerald-900/40'
            }`}
          >
            <span className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 animate-pulse text-yellow-400" />
              <span>₹100 Cycle Plan</span>
            </span>
            <span className="bg-emerald-500/20 text-emerald-300 text-[8px] px-1.5 py-0.5 rounded-full font-black uppercase tracking-wider border border-emerald-500/30">
              Active
            </span>
          </button>

          {/* Clean Top-Level User Navigation Links */}
          <button
            id="user-nav-overview"
            onClick={() => setActiveSubTab('overview')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'overview' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">📊</span>
              <span>Overview Dashboard</span>
            </span>
          </button>

          <button
            id="user-nav-profile"
            onClick={() => setActiveSubTab('profile')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'profile' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">👤</span>
              <span>My Profile & Bank</span>
            </span>
          </button>

          <button
            id="user-nav-ph"
            onClick={() => setActiveSubTab('contribution')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'contribution' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">🤝</span>
              <span>Provide Help (PH)</span>
            </span>
          </button>

          <button
            id="user-nav-gh"
            onClick={() => setActiveSubTab('help')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'help' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">💵</span>
              <span>Get Help (GH)</span>
            </span>
          </button>

          <button
            id="user-nav-wallet"
            onClick={() => { setActiveSubTab('wallet'); setActiveWalletTab('withdrawal'); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'wallet' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">💰</span>
              <span>Wallet & Withdrawal (विथड्रॉल)</span>
            </span>
            <span className="bg-emerald-500/20 text-emerald-300 text-[9px] px-1.5 py-0.5 rounded font-extrabold uppercase">
              Payout
            </span>
          </button>

          <button
            id="user-nav-referrals"
            onClick={() => setActiveSubTab('referrals')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'referrals' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">👥</span>
              <span>Referrals & Team</span>
            </span>
          </button>

          <button
            id="user-nav-notifications"
            onClick={() => { setActiveSubTab('notifications'); onMarkNotificationsRead(); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'notifications' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">🔔</span>
              <span>Notifications</span>
            </span>
            {unreadCount > 0 && (
              <span className="bg-amber-500 text-slate-950 font-bold px-2 py-0.5 rounded-full text-[10px]">
                {unreadCount}
              </span>
            )}
          </button>

          <button
            id="user-nav-support"
            onClick={() => setActiveSubTab('support')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeSubTab === 'support' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">🎧</span>
              <span>Support Desk</span>
            </span>
          </button>

        </nav>

        {/* Device Share Card */}
        <div className="mx-4 my-2 p-2 rounded-xl bg-slate-950 border border-slate-800 text-center text-slate-400">
          <p className="text-[8px] font-black text-indigo-400 uppercase tracking-widest mb-1 flex items-center justify-center gap-1">
            <Smartphone className="w-3 h-3 text-indigo-400" /> Open on Mobile
          </p>
          <div className="bg-white p-1 rounded inline-block mb-1 shadow-md">
            <QRCodeSVG
              value={window.location.origin}
              size={64}
              level="M"
              includeMargin={false}
            />
          </div>
          <p className="text-[7.5px] leading-tight text-slate-500">Scan code to open on phone instantly!</p>
        </div>

        {/* Logout Bottom Container */}
        <div className="p-4 border-t border-slate-800">
          <button
            id="user-nav-logout"
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-rose-400 hover:text-white hover:bg-rose-900/35 border border-rose-900/30 font-medium transition-all text-xs cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            Sign Out Profile
          </button>
        </div>
      </aside>

      {/* 2. Main content area */}
      <main className={`flex-grow p-6 sm:p-8 max-w-5xl overflow-y-auto transition-colors duration-500 ${
        demoRole === 'giver' ? 'bg-emerald-50/40' : 'bg-amber-50/40'
      }`}>
        
        {/* SUBTAB 1: OVERVIEW */}
        {activeSubTab === 'overview' && (
          <div>
            <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold tracking-tight text-slate-900">Member Workspace</h1>
                <p className="text-slate-500 text-sm">Welcome back to Help 100 mutual community dashboard.</p>
              </div>

              <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white px-4 py-2.5 rounded-2xl shadow-sm border border-emerald-500/30 flex items-center gap-2.5 self-start sm:self-auto">
                <div className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse" />
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-100">Your Direct ID / Code:</span>
                <strong className="font-mono text-sm font-black text-white bg-slate-950/40 px-3 py-1 rounded-xl border border-emerald-400/40">{currentUser.referralCode || currentUser.id}</strong>
              </div>

              {/* Blocked Account Notice */}
              {(currentUser.isBlocked || (currentUser.status as string) === 'suspended') && (
                <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-4 flex items-center justify-between gap-4 max-w-lg shadow-sm">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl shrink-0">🚫</span>
                    <div>
                      <h5 className="font-extrabold text-xs text-rose-900 uppercase">Account ID Blocked</h5>
                      <p className="text-[11px] text-rose-700">Your account ID has been suspended by Admin. New transactions are restricted.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Instant Verification Notice if pending */}
              {currentUser.kycStatus === 'pending' && !(currentUser.isBlocked || (currentUser.status as string) === 'suspended') && (
                <div className="bg-amber-50 border border-amber-100 rounded-xl p-3 flex items-start gap-2 max-w-sm">
                  <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-bold text-xs text-amber-900">KYC Under Audit</h5>
                    <p className="text-[10px] text-amber-700">Administrators are reviewing your passport/ID proof file.</p>
                  </div>
                </div>
              )}
            </div>

            {/* Active Promotional Special Offers Banner */}
            {systemSettings.offers && systemSettings.offers.filter(o => o.isActive).map(offer => (
              <div key={offer.id} className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 p-4.5 rounded-2xl shadow-md mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border border-amber-300">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-slate-950 text-amber-300 rounded-full text-[9px] font-black uppercase tracking-wider">
                    ⚡ {offer.badge || 'SPECIAL OFFER'}
                  </div>
                  <h3 className="font-black text-base text-slate-950 tracking-tight">{offer.title}</h3>
                  <p className="text-xs font-semibold text-slate-900/90 leading-relaxed">{offer.description}</p>
                </div>
                <button
                  onClick={() => setActiveSubTab('plan100')}
                  className="px-4 py-2 bg-slate-950 hover:bg-slate-900 text-amber-300 text-xs font-black uppercase tracking-wider rounded-xl transition-transform hover:scale-105 cursor-pointer whitespace-nowrap shrink-0 shadow-sm"
                >
                  Activate Plan →
                </button>
              </div>
            ))}

            {/* Sponsor Identification Banner - Colorful theme */}
            <div className="bg-gradient-to-r from-indigo-900 via-purple-900 to-slate-900 text-white p-4 rounded-2xl border border-indigo-500/30 shadow-md flex flex-wrap items-center justify-between gap-3 mb-6 relative overflow-hidden">
              <div className="absolute right-0 top-0 w-32 h-32 bg-purple-500/10 rounded-full blur-xl pointer-events-none" />
              <div className="flex items-center gap-3 relative z-10">
                <div className="p-2.5 rounded-xl bg-white/10 border border-white/15 text-indigo-300 shrink-0">
                  <Users className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <span className="text-[10px] text-indigo-200 font-extrabold uppercase tracking-wider block">Your Uplink Sponsor & Direct Referral Details</span>
                  <div className="flex flex-wrap items-center gap-2 mt-0.5">
                    <span className="font-black text-white text-sm">
                      {currentUserSponsor ? currentUserSponsor.name : (currentUser.referredBy ? `Sponsor Ref: ${currentUser.referredBy}` : 'Direct Platform Member')}
                    </span>
                    <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-mono px-2.5 py-0.5 rounded-md font-bold flex items-center gap-1">
                      Sponsor ID: <strong className="font-mono">{currentUserSponsor ? (currentUserSponsor.referralCode || currentUserSponsor.id) : (currentUser.referredBy || 'ADMIN100')}</strong>
                    </span>
                    <span className="bg-indigo-500/30 text-indigo-100 border border-indigo-400/30 text-[11px] font-mono px-2.5 py-0.5 rounded-md font-bold flex items-center gap-1">
                      Your Direct ID: <strong className="font-mono text-emerald-300 font-black">{currentUser.referralCode || currentUser.id}</strong>
                    </span>
                  </div>
                </div>
              </div>
              {currentUserSponsor && currentUserSponsor.phone && (
                <div className="text-right text-xs text-indigo-200 relative z-10">
                  <span className="block text-[10px] text-indigo-300/80 uppercase font-bold">Sponsor Contact</span>
                  <span className="font-mono font-bold text-white">{currentUserSponsor.phone}</span>
                </div>
              )}
            </div>

            {/* Visual 8-Step Help Cycle Progress Bar */}
            <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-2xl p-5 mb-8 text-white shadow-md relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-3.5">
                <div>
                  <h3 className="font-extrabold text-sm flex items-center gap-1.5 text-indigo-200">
                    <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
                    Help Cycle #{cycleState.cycleCount} Active Tracker
                  </h3>
                  <div className="text-slate-400 text-xs mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1">
                    <span>Current Step:</span>
                    <strong className="text-white capitalize">{cycleState.currentStep === 'completed' ? 'All Completed' : cycleState.currentStep.replace('_', ' ')}</strong>
                    {cycleState.pinPurchased && cycleState.firstPhSubmitted && cycleState.secondPhSubmitted && (
                      <button
                        id="btn-active-tracker-received-link"
                        onClick={() => {
                          setShowSecureClaimGateway(true);
                          setGatewayTimer(86400);
                          setClaimProofFilename('');
                        }}
                        className="inline-flex items-center gap-1 text-[11px] font-black text-[#00b28e] hover:text-[#00d4aa] transition-colors cursor-pointer hover:underline"
                      >
                        🔗 Secure Received Help Link Active ↗
                      </button>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Completed Stages:</span>
                  <span className="text-xs font-black text-emerald-400 font-mono">
                    {(() => {
                      const isCompleted = (stepKey: string) => {
                        if (cycleState.currentStep === 'completed') return true;
                        if (!cycleState.pinPurchased && stepKey !== 'buy_pin') return false;
                        switch (stepKey) {
                          case 'buy_pin': return cycleState.pinPurchased;
                          case 'first_ph': return cycleState.firstPhSubmitted || !['buy_pin', 'first_ph'].includes(cycleState.currentStep);
                          case 'second_ph': return cycleState.secondPhSubmitted || !['buy_pin', 'first_ph', 'second_ph'].includes(cycleState.currentStep);
                          case 'first_gh': return cycleState.firstGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh'].includes(cycleState.currentStep);
                          case 'second_gh': return cycleState.secondGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh'].includes(cycleState.currentStep);
                          case 'third_gh': return cycleState.thirdGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh', 'third_gh'].includes(cycleState.currentStep);
                          case 'fourth_gh': return cycleState.fourthGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh', 'third_gh', 'fourth_gh'].includes(cycleState.currentStep);
                          case 'fifth_gh': return cycleState.fifthGhReceived || cycleState.currentStep === 'completed';
                          default: return false;
                        }
                      };
                      const stepsList = ['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh', 'third_gh', 'fourth_gh', 'fifth_gh'];
                      const completedCount = stepsList.filter(isCompleted).length;
                      return `${completedCount} / 8 (${Math.round((completedCount / 8) * 100)}%)`;
                    })()}
                  </span>
                </div>
              </div>

              {/* Progress Bar Track and Glow Fill */}
              <div className="bg-slate-950/45 border border-slate-800/40 rounded-xl p-4 mt-3">
                <div className="relative h-2.5 w-full bg-slate-900 rounded-full overflow-hidden mb-5">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ 
                      width: `${(() => {
                        const isCompleted = (stepKey: string) => {
                          if (cycleState.currentStep === 'completed') return true;
                          if (!cycleState.pinPurchased && stepKey !== 'buy_pin') return false;
                          switch (stepKey) {
                            case 'buy_pin': return cycleState.pinPurchased;
                            case 'first_ph': return cycleState.firstPhSubmitted || !['buy_pin', 'first_ph'].includes(cycleState.currentStep);
                            case 'second_ph': return cycleState.secondPhSubmitted || !['buy_pin', 'first_ph', 'second_ph'].includes(cycleState.currentStep);
                            case 'first_gh': return cycleState.firstGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh'].includes(cycleState.currentStep);
                            case 'second_gh': return cycleState.secondGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh'].includes(cycleState.currentStep);
                            case 'third_gh': return cycleState.thirdGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh', 'third_gh'].includes(cycleState.currentStep);
                            case 'fourth_gh': return cycleState.fourthGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh', 'third_gh', 'fourth_gh'].includes(cycleState.currentStep);
                            case 'fifth_gh': return cycleState.fifthGhReceived || cycleState.currentStep === 'completed';
                            default: return false;
                          }
                        };
                        const stepsList = ['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh', 'third_gh', 'fourth_gh', 'fifth_gh'];
                        const completedCount = stepsList.filter(isCompleted).length;
                        return (completedCount / 8) * 100;
                      })()}%` 
                    }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="h-full bg-gradient-to-r from-indigo-500 via-teal-400 to-emerald-400 relative rounded-full"
                  />
                </div>

                {/* 8 Step indicators */}
                <div className="flex justify-between items-center relative">
                  {/* Connecting line behind */}
                  <div className="absolute left-1 right-1 top-3 h-0.5 bg-slate-800 z-0 pointer-events-none" />
                  
                  {(() => {
                    const steps = [
                      { key: 'buy_pin', label: 'S1: PIN', num: 1, amt: '₹10' },
                      { key: 'first_ph', label: 'S2: PH Link 1', num: 2, amt: '₹50' },
                      { key: 'second_ph', label: 'S3: PH Link 2', num: 3, amt: '₹50' },
                      { key: 'first_gh', label: 'S4: GH Link 1', num: 4, amt: '₹50' },
                      { key: 'second_gh', label: 'S5: GH Link 2', num: 5, amt: '₹50' },
                      { key: 'third_gh', label: 'S6: GH Link 3', num: 6, amt: '₹25' },
                      { key: 'fourth_gh', label: 'S7: GH Link 4', num: 7, amt: '₹25' },
                      { key: 'fifth_gh', label: 'S8: GH Link 5', num: 8, amt: '₹25' },
                    ];

                    const isCompleted = (stepKey: string) => {
                      if (cycleState.currentStep === 'completed') return true;
                      if (!cycleState.pinPurchased && stepKey !== 'buy_pin') return false;
                      switch (stepKey) {
                        case 'buy_pin': return cycleState.pinPurchased;
                        case 'first_ph': return cycleState.firstPhSubmitted || !['buy_pin', 'first_ph'].includes(cycleState.currentStep);
                        case 'second_ph': return cycleState.secondPhSubmitted || !['buy_pin', 'first_ph', 'second_ph'].includes(cycleState.currentStep);
                        case 'first_gh': return cycleState.firstGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh'].includes(cycleState.currentStep);
                        case 'second_gh': return cycleState.secondGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh'].includes(cycleState.currentStep);
                        case 'third_gh': return cycleState.thirdGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh', 'third_gh'].includes(cycleState.currentStep);
                        case 'fourth_gh': return cycleState.fourthGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh', 'third_gh', 'fourth_gh'].includes(cycleState.currentStep);
                        case 'fifth_gh': return cycleState.fifthGhReceived || cycleState.currentStep === 'completed';
                        default: return false;
                      }
                    };

                    const isActive = (stepKey: string) => {
                      if (cycleState.currentStep === 'completed') return false;
                      return cycleState.currentStep === stepKey;
                    };

                    return steps.map((st) => {
                      const comp = isCompleted(st.key);
                      const act = isActive(st.key);
                      const isGhStep = st.key.endsWith('_gh');
                      return (
                        <div key={st.key} className="flex flex-col items-center relative z-10">
                          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center font-mono text-[9px] font-black transition-all duration-300 ${
                            act 
                              ? isGhStep
                                ? 'bg-gradient-to-r from-[#0D6EFD] to-[#00BFFF] border-[#0D6EFD] text-white ring-4 ring-[#0D6EFD]/20 animate-pulse'
                                : 'bg-indigo-500 border-indigo-400 text-white ring-4 ring-indigo-500/20 animate-pulse' 
                              : comp 
                                ? 'bg-emerald-500 border-emerald-400 text-white' 
                                : 'bg-slate-900 border-slate-700 text-slate-500'
                          }`}>
                            {comp ? '✓' : st.num}
                          </div>
                          <span className={`text-[9.5px] mt-1.5 font-bold font-mono tracking-tight ${
                            act 
                              ? isGhStep 
                                ? 'text-[#0D6EFD] font-black animate-pulse'
                                : 'text-indigo-400 font-black animate-pulse' 
                              : comp 
                                ? 'text-emerald-400' 
                                : 'text-slate-400'
                          }`}>
                            {st.label}
                          </span>
                          <span className="hidden sm:inline text-[8px] text-slate-500 mt-0.5 font-semibold">
                            {st.amt}
                          </span>
                        </div>
                      );
                    });
                  })()}
                </div>
              </div>
            </div>

            {/* Colorful Green Received Help Link Banner */}
            {cycleState.pinPurchased && cycleState.firstPhSubmitted && cycleState.secondPhSubmitted && (
              <div id="blue-received-help-link-banner" className="mb-4 py-2 px-3 sm:px-5 rounded-xl bg-gradient-to-r from-emerald-400 via-emerald-500 to-green-500 text-slate-950 border-2 border-emerald-300 shadow-sm w-full relative overflow-hidden">
                <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                  <div className="flex-1 min-w-0 flex flex-wrap items-center gap-x-2.5 gap-y-1">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-slate-950 text-emerald-300 font-black text-[10px] uppercase rounded-full tracking-wider shrink-0 border border-black/20">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      💚 ₹175.00 Payout Active
                    </span>
                    <h3 className="text-xs sm:text-sm font-black text-black shrink-0">
                      Direct Get Help Link Active!
                    </h3>
                    <p className="text-[11px] text-slate-900 font-extrabold leading-tight">
                      Claim your peer assistance payout of ₹175 total.
                    </p>
                  </div>
                  <div className="flex flex-row gap-2 shrink-0 items-center">
                    <button
                      id="btn-copy-received-link"
                      onClick={() => {
                        const link = `${window.location.origin}/withdraw/claim-${currentUser.id}`;
                        navigator.clipboard.writeText(link);
                        alert(`Copied unique secure Received Help Link:\n${link}`);
                      }}
                      className="px-2.5 py-1 bg-slate-950 hover:bg-slate-900 active:scale-95 transition-all text-xs font-black rounded-lg text-emerald-300 flex items-center justify-center gap-1 cursor-pointer shadow-xs border border-emerald-400/30"
                    >
                      <Copy className="w-3 h-3 text-emerald-400" />
                      Copy Link
                    </button>
                    <button
                      id="btn-open-received-gateway"
                      onClick={() => {
                        setShowSecureClaimGateway(true);
                        setGatewayTimer(86400);
                        setClaimProofFilename('');
                      }}
                      className="px-3 py-1 bg-slate-950 hover:bg-slate-900 active:scale-95 transition-all text-xs font-black rounded-lg text-emerald-400 shadow-sm flex items-center justify-center gap-1 cursor-pointer border border-emerald-400"
                    >
                      💚 Open Get Help Link
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Metrics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
              {/* Card 1 */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
                <div className="flex items-center justify-between w-full">
                  <div>
                    <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Available Wallet Balance</span>
                    <p className="text-3xl font-black text-slate-900 mt-1">₹{currentUser.walletBalance.toLocaleString()}</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                    <Wallet className="w-6 h-6" />
                  </div>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Instant Payout</span>
                  <button
                    onClick={() => { setActiveSubTab('wallet'); setActiveWalletTab('withdrawal'); }}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    💰 Withdraw Funds (विथड्रॉल)
                  </button>
                </div>
              </div>

              {/* Card 2 */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Pledge Contributed</span>
                  <p className="text-3xl font-black text-slate-900 mt-1">₹{currentUser.totalContributed.toLocaleString()}</p>
                </div>
                <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                  <HeartHandshake className="w-6 h-6" />
                </div>
              </div>

              {/* Card 3 */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between min-h-[120px]">
                <div className="flex items-center justify-between w-full">
                  <div>
                    <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Aid Help Received</span>
                    <p className="text-3xl font-black text-slate-900 mt-1">₹{currentUser.totalReceived.toLocaleString()}</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                    <TrendingUp className="w-6 h-6" />
                  </div>
                </div>
                {cycleState.pinPurchased && cycleState.firstPhSubmitted && cycleState.secondPhSubmitted && (
                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between w-full">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Direct Claim Link:</span>
                    <button
                      id="btn-quick-received-help-link"
                      onClick={() => setShowSecureClaimGateway(true)}
                      className="text-[11px] font-black text-emerald-600 hover:text-emerald-700 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      🔗 Received Help Link ↗
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Mutual Aid Quotient - Combination of Help Received and Help Provided */}
            <div id="combination-help-received-provided" className="bg-gradient-to-br from-indigo-900 via-slate-900 to-emerald-950 text-white p-6 rounded-2xl border border-white/15 shadow-xl shadow-slate-900/10 mb-8 animate-fade-in relative overflow-hidden">
              {/* Abstract decorative backgrounds */}
              <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none"></div>
              <div className="absolute left-0 bottom-0 -translate-x-12 translate-y-12 w-48 h-48 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>

              <div className="relative">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5 border-b border-white/10 pb-4">
                  <div>
                    <h3 className="font-extrabold text-sm uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                      <Activity className="w-4 h-4 text-emerald-400" />
                      Combination of Help Received & Help Provided
                    </h3>
                    <p className="text-[11px] text-slate-300 mt-0.5">Unified ledger analysis of your mutual pledges and aids received</p>
                  </div>
                  <div className="bg-white/10 px-3 py-1.5 rounded-xl border border-white/5 text-center flex items-center justify-center gap-1.5">
                    <span className="text-[10px] font-black uppercase text-slate-300 tracking-widest">Quotient Status:</span>
                    <span className={`text-xs font-extrabold px-2 py-0.5 rounded-lg ${
                      currentUser.totalContributed >= currentUser.totalReceived 
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    }`}>
                      {currentUser.totalContributed >= currentUser.totalReceived ? '🟢 Net Giver' : '🟡 Net Receiver'}
                    </span>
                  </div>
                </div>

                {/* Main Stats Comparison */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                  {/* Provided Stat */}
                  <div className="bg-white/5 p-4 rounded-xl border border-white/5 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">Total Help Provided (PH)</span>
                      <p className="text-2xl font-black text-white mt-1 font-mono">₹{currentUser.totalContributed.toLocaleString()}</p>
                    </div>
                    <span className="text-[9px] text-slate-400 mt-2 block">Pledge funds you contributed to other members</span>
                  </div>

                  {/* Visual Progress Ratio */}
                  <div className="flex flex-col justify-center space-y-2 py-2">
                    <div className="flex justify-between items-center text-[10px] font-bold text-slate-300">
                      <span>Help Provided ({Math.round(currentUser.totalContributed / (currentUser.totalContributed + currentUser.totalReceived || 1) * 100)}%)</span>
                      <span>Help Received ({Math.round(currentUser.totalReceived / (currentUser.totalContributed + currentUser.totalReceived || 1) * 100)}%)</span>
                    </div>
                    
                    {/* Progress slider bar */}
                    <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden flex">
                      <div 
                        style={{ width: `${currentUser.totalContributed / (currentUser.totalContributed + currentUser.totalReceived || 1) * 100}%` }} 
                        className="h-full bg-gradient-to-r from-emerald-500 to-indigo-500 transition-all duration-500"
                      />
                      <div 
                        style={{ width: `${currentUser.totalReceived / (currentUser.totalContributed + currentUser.totalReceived || 1) * 100}%` }} 
                        className="h-full bg-gradient-to-r from-amber-500 to-amber-600 transition-all duration-500"
                      />
                    </div>

                    <div className="text-center pt-2">
                      <p className="text-[11px] text-slate-300">
                        Pledge Contribution Factor:{' '}
                        <span className="font-extrabold text-white font-mono">
                          {(currentUser.totalContributed / (currentUser.totalReceived || 1)).toFixed(2)}x
                        </span>
                      </p>
                    </div>
                  </div>

                  {/* Received Stat */}
                  <div className="bg-white/5 p-4 rounded-xl border border-white/5 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">Total Help Received (GH)</span>
                      <p className="text-2xl font-black text-white mt-1 font-mono">₹{currentUser.totalReceived.toLocaleString()}</p>
                    </div>
                    <span className="text-[9px] text-slate-400 mt-2 block">Aid funds you claimed & verified from the network</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Live Community Transparency Stats */}
            <div id="live-community-transparency-desk" className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-lg mb-8">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4 pb-4 border-b border-slate-800">
                <div>
                  <h3 className="font-extrabold text-xs uppercase tracking-widest text-indigo-400">⚡ Live Community Transparency Desk</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Real-time audited transaction pool of the Help 100 decentralized peer ledger.</p>
                </div>
                <span className="text-[10px] bg-indigo-500/20 text-indigo-300 font-bold px-2 py-0.5 rounded-full border border-indigo-500/30 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  ● Network Live
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Total PH Contributions</span>
                  <p className="text-2xl font-black text-emerald-400 mt-1 font-mono">₹{contributions.reduce((sum, c) => sum + c.amount, 0).toLocaleString()}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">All community peer help provided</p>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Total GH Claims & Withdrawals</span>
                  <p className="text-2xl font-black text-amber-400 mt-1 font-mono">₹{(
                    helpRequests.reduce((sum, h) => sum + h.amountRequested, 0) + 
                    transactions.filter(t => t.type === 'withdrawal' && t.status !== 'rejected').reduce((sum, t) => sum + t.amount, 0)
                  ).toLocaleString()}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">All community help claims disbursed</p>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Live Community Reserves</span>
                  <p className="text-2xl font-black text-indigo-400 mt-1 font-mono">₹{communityReserves.toLocaleString()}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Protected dynamic buffer liquidity</p>
                </div>
              </div>
            </div>

            {/* Active Cycle Earnings & Progression Chart */}
            <div className="mb-8 animate-fade-in">
              <ActiveCycleChart cycleState={cycleState} />
            </div>

            {/* P2P PEER-TO-PEER MUTUAL MATCHES PANEL */}
            {(() => {
              const myMatches = p2pMatches.filter(m => 
                (
                  isUserMatch(currentUser, m.giverUserId) ||
                  isUserMatch(currentUser, m.giverId) ||
                  isUserMatch(currentUser, m.giverName) ||
                  (m.giverPhone && currentUser.phone && m.giverPhone.trim() === currentUser.phone.trim()) ||
                  (m.giverName && currentUser.name && m.giverName.trim().toLowerCase() === currentUser.name.trim().toLowerCase()) ||
                  isUserMatch(currentUser, m.takerUserId) ||
                  isUserMatch(currentUser, m.takerId) ||
                  isUserMatch(currentUser, m.takerName) ||
                  (m.takerPhone && currentUser.phone && m.takerPhone.trim() === currentUser.phone.trim()) ||
                  (m.takerName && currentUser.name && m.takerName.trim().toLowerCase() === currentUser.name.trim().toLowerCase())
                ) && 
                m.status !== 'completed' && m.status !== 'rejected'
              );
              if (myMatches.length === 0) return null; // Remove the demo link box when no real matches exist

              const isDemo = false;
              const activeMatches = myMatches;

              return (
                <div className="mb-8 bg-slate-900/10 border border-slate-200/80 p-6 rounded-3xl space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200/50 pb-4">
                    <div className="flex items-center gap-2">
                      <span className="flex h-2.5 w-2.5 relative">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-indigo-600"></span>
                      </span>
                      <div>
                        <h3 className="font-extrabold text-slate-950 text-base font-sans tracking-tight">
                          {isDemo ? '⚡ P2P Direct Aid Sandbox Simulator' : 'Active Peer-to-Peer Aid Matches (Face-to-Face P2P)'}
                        </h3>
                        <p className="text-xs text-slate-500 leading-relaxed font-medium">
                          {isDemo 
                            ? 'Test Giver Payment Slip Upload and Taker Accept/Reject flows live by toggling roles below.' 
                            : 'The administrator has placed you in a direct P2P connection. Funds are transferred strictly member-to-member.'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {activeMatches.map(match => (
                      <P2PMatchCard
                        key={match.id}
                        match={match}
                        currentUser={currentUser}
                        users={users}
                        systemSettings={systemSettings}
                        onUpdateP2PMatch={onUpdateP2PMatch}
                        onApproveP2PMatch={onApproveP2PMatch}
                        onRejectP2PMatch={onRejectP2PMatch}
                        demoRole={demoRole}
                        setDemoRole={setDemoRole}
                        setMatchStatus={setMatchStatus}
                        setMatchSlipUrl={setMatchSlipUrl}
                        setMatchSlipName={setMatchSlipName}
                        expandedMatchId={expandedMatchId}
                        setExpandedMatchId={setExpandedMatchId}
                        uploadMatchId={uploadMatchId}
                        setUploadMatchId={setUploadMatchId}
                        matchUploads={matchUploads}
                        setMatchUploads={setMatchUploads}
                        matchPreviewUrls={matchPreviewUrls}
                        setMatchPreviewUrls={setMatchPreviewUrls}
                        viewedSlips={viewedSlips}
                        setViewedSlips={setViewedSlips}
                        setActiveSlipPreview={setActiveSlipPreview}
                      />
                    ))}
                  </div>
                </div>
              );
            })()}
              </div>
            )}

            {activeSubTab === 'wallet' && (
              <div>
                <div className="mb-6">
                  <h1 className="text-2xl font-bold text-slate-900">Wallet Management</h1>
                  <p className="text-slate-500 text-sm">Add funds, review account history, or request withdrawals.</p>
                </div>

                {walletSuccessMsg && (
                  <div className="mb-6 p-4 bg-emerald-50 border border-emerald-100 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
                    <span className="text-emerald-600 text-lg">✓</span>
                    {walletSuccessMsg}
                  </div>
                )}

                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                  {/* Provide Wallet Card */}
                  <div className="bg-gradient-to-br from-indigo-50 to-indigo-100/50 p-4 rounded-xl border border-indigo-200/50 shadow-sm flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-indigo-500 tracking-wider">Provide Wallet</span>
                      <p className="text-[9px] text-indigo-400">Approved deposits / balance to PH</p>
                    </div>
                    <h4 className="text-xl font-bold font-mono text-indigo-900 mt-2">₹ {(currentUser.provideWallet ?? 0).toLocaleString()}</h4>
                  </div>

                  {/* Get Wallet Card */}
                  <div className="bg-gradient-to-br from-emerald-50 to-emerald-100/50 p-4 rounded-xl border border-emerald-200/50 shadow-sm flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-emerald-600 tracking-wider">Get Wallet</span>
                      <p className="text-[9px] text-emerald-500">Earned interest & received aids</p>
                    </div>
                    <h4 className="text-xl font-bold font-mono text-emerald-900 mt-2">₹ {(currentUser.getWallet ?? 0).toLocaleString()}</h4>
                  </div>

                  {/* Direct Wallet Card */}
                  <div className="bg-gradient-to-br from-purple-50 to-purple-100/50 p-4 rounded-xl border border-purple-200/50 shadow-sm flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-purple-600 tracking-wider">Direct Wallet</span>
                      <p className="text-[9px] text-purple-500">Level 1 referral bonus (5%)</p>
                    </div>
                    <h4 className="text-xl font-bold font-mono text-purple-900 mt-2">₹ {(currentUser.directWallet ?? 0).toLocaleString()}</h4>
                  </div>

                  {/* Level Wallet Card */}
                  <div className="bg-gradient-to-br from-amber-50 to-amber-100/50 p-4 rounded-xl border border-amber-200/50 shadow-sm flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-amber-600 tracking-wider">Level Wallet</span>
                      <p className="text-[9px] text-amber-500">Level 2 to 5 referral commissions</p>
                    </div>
                    <h4 className="text-xl font-bold font-mono text-amber-900 mt-2">₹ {(currentUser.levelWallet ?? 0).toLocaleString()}</h4>
                  </div>
                </div>

                <div className="flex border-b border-slate-200 mb-8 gap-4 text-sm font-semibold">
                  <button
                    onClick={() => setActiveWalletTab('withdrawal')}
                    className={`pb-2 px-1 border-b-2 transition-all cursor-pointer ${
                      activeWalletTab === 'withdrawal' ? 'border-emerald-600 text-emerald-600' : 'border-transparent text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    Withdrawal Request
                  </button>
                  <button
                    onClick={() => setActiveWalletTab('history')}
                    className={`pb-2 px-1 border-b-2 transition-all cursor-pointer ${
                      activeWalletTab === 'history' ? 'border-emerald-600 text-emerald-600' : 'border-transparent text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    Transaction History
                  </button>
                </div>

                {activeWalletTab === 'withdrawal' && (
                  <div className="grid md:grid-cols-2 gap-8 mb-8">
                    <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm">
                      <h3 className="font-bold text-slate-900 mb-1">Withdraw Funds</h3>
                      <p className="text-slate-500 text-xs mb-4">Request a payout transfer from your available wallet balance.</p>
                      
                      <form onSubmit={handleWithdrawalSubmit} className="space-y-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Withdraw From Wallet</label>
                          <select
                            id="wallet-withdraw-wallet-source"
                            value={withdrawalWallet}
                            onChange={(e) => setWithdrawalWallet(e.target.value as any)}
                            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                          >
                            <option value="main">Main Wallet (Bal: ₹{currentUser.walletBalance.toLocaleString()})</option>
                            <option value="provide">Provide Wallet (Bal: ₹{(currentUser.provideWallet ?? 0).toLocaleString()})</option>
                            <option value="get">Get Wallet (Bal: ₹{(currentUser.getWallet ?? 0).toLocaleString()})</option>
                            <option value="direct">Direct Wallet (Bal: ₹{(currentUser.directWallet ?? 0).toLocaleString()})</option>
                            <option value="level">Level Wallet (Bal: ₹{(currentUser.levelWallet ?? 0).toLocaleString()})</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <label className="block text-xs font-semibold text-slate-700 uppercase">Target UPI ID / Bank Account Details</label>
                            <button
                              type="button"
                              onClick={() => {
                                setActiveSubTab('profile');
                                setActiveProfileSection('bank');
                              }}
                              className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 hover:underline flex items-center gap-1 cursor-pointer"
                            >
                              ⚙️ Edit Profile Bank/UPI →
                            </button>
                          </div>

                          {/* Profile Bank / UPI Account Selector */}
                          {(() => {
                            const options: { label: string; shortLabel: string; value: string }[] = [];
                            if (currentUser.upiId) {
                              options.push({
                                label: `📱 Primary UPI ID: ${currentUser.upiId}`,
                                shortLabel: `📱 UPI: ${currentUser.upiId}`,
                                value: currentUser.upiId
                              });
                            }
                            if (currentUser.bankName && currentUser.accountNumber) {
                              const bankStr = `${currentUser.bankName} - A/C: ${currentUser.accountNumber}${currentUser.ifscCode ? ` (IFSC: ${currentUser.ifscCode})` : ''}`;
                              options.push({
                                label: `🏦 Primary Bank: ${currentUser.bankName} - A/C: ${currentUser.accountNumber}${currentUser.ifscCode ? ` (${currentUser.ifscCode})` : ''}`,
                                shortLabel: `🏦 ${currentUser.bankName} (...${currentUser.accountNumber.slice(-4)})`,
                                value: bankStr
                              });
                            }
                            if (currentUser.secondaryUpiId) {
                              options.push({
                                label: `📱 Secondary UPI ID: ${currentUser.secondaryUpiId}`,
                                shortLabel: `📱 UPI 2: ${currentUser.secondaryUpiId}`,
                                value: currentUser.secondaryUpiId
                              });
                            }
                            if (currentUser.secondaryBankName && currentUser.secondaryAccountNumber) {
                              const secBankStr = `${currentUser.secondaryBankName} - A/C: ${currentUser.secondaryAccountNumber}${currentUser.secondaryIfscCode ? ` (IFSC: ${currentUser.secondaryIfscCode})` : ''}`;
                              options.push({
                                label: `🏦 Secondary Bank: ${currentUser.secondaryBankName} - A/C: ${currentUser.secondaryAccountNumber}${currentUser.secondaryIfscCode ? ` (${currentUser.secondaryIfscCode})` : ''}`,
                                shortLabel: `🏦 ${currentUser.secondaryBankName} (...${currentUser.secondaryAccountNumber.slice(-4)})`,
                                value: secBankStr
                              });
                            }

                            if (options.length === 0) {
                              return (
                                <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-800 text-xs flex items-center justify-between gap-2">
                                  <span>⚠️ Profile Bank/UPI not updated yet.</span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setActiveSubTab('profile');
                                      setActiveProfileSection('bank');
                                    }}
                                    className="px-2 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-[10px] shrink-0 cursor-pointer"
                                  >
                                    Add in Profile
                                  </button>
                                </div>
                              );
                            }

                            return (
                              <div className="space-y-2">
                                <div className="relative">
                                  <select
                                    id="wallet-withdraw-account-select"
                                    value={options.some(o => o.value === withdrawalAddress) ? withdrawalAddress : ''}
                                    onChange={(e) => {
                                      if (e.target.value) {
                                        setWithdrawalAddress(e.target.value);
                                      }
                                    }}
                                    className="w-full px-3 py-2 border border-emerald-300 rounded-xl text-xs font-medium bg-emerald-50/60 text-emerald-950 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                                  >
                                    <option value="">-- Select Saved Profile Bank / UPI Details --</option>
                                    {options.map((opt, idx) => (
                                      <option key={idx} value={opt.value}>
                                        {opt.label}
                                      </option>
                                    ))}
                                  </select>
                                </div>

                                {/* Quick Click Buttons */}
                                <div className="flex flex-wrap gap-1.5 pt-0.5">
                                  {options.map((opt, idx) => (
                                    <button
                                      key={idx}
                                      type="button"
                                      onClick={() => setWithdrawalAddress(opt.value)}
                                      className={`text-[10px] px-2.5 py-1 rounded-lg font-bold border transition-all cursor-pointer ${
                                        withdrawalAddress === opt.value
                                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                                          : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                                      }`}
                                    >
                                      {opt.shortLabel}
                                    </button>
                                  ))}
                                </div>
                              </div>
                            );
                          })()}

                          <input
                            id="wallet-withdraw-address"
                            type="text"
                            required
                            placeholder="Selected or custom UPI ID / Account Details"
                            value={withdrawalAddress}
                            onChange={(e) => setWithdrawalAddress(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono text-slate-800"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Withdrawal Amount (₹)</label>
                          <input
                            id="wallet-withdraw-amount"
                            type="number"
                            required
                            placeholder={withdrawalWallet === 'provide' || withdrawalWallet === 'get' ? 'Min: ₹75' : 'Min: ₹100 (Multiple of ₹100)'}
                            value={withdrawalAmount}
                            onChange={(e) => setWithdrawalAmount(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                          />
                          <span className="text-[10px] text-slate-400 mt-1 block">
                            Your Available {withdrawalWallet.toUpperCase()} Balance: <strong className="text-slate-700">₹{(withdrawalWallet === 'main' ? currentUser.walletBalance : currentUser[withdrawalWallet === 'provide' ? 'provideWallet' : withdrawalWallet === 'get' ? 'getWallet' : withdrawalWallet === 'direct' ? 'directWallet' : 'levelWallet'] ?? 0).toLocaleString()}</strong>
                          </span>
                        </div>

                        {currentUser.kycStatus !== 'approved' && (
                          <div className="p-2 bg-amber-50 border border-amber-200 rounded text-[10px] text-amber-700 font-semibold flex items-center gap-1">
                            <span className="text-amber-600 font-bold">⚠️</span> Note: KYC Approval is required before withdrawals.
                          </div>
                        )}

                        <button
                          id="wallet-withdraw-submit"
                          type="submit"
                          className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-all cursor-pointer"
                        >
                          Request Payout Withdrawal
                        </button>
                      </form>
                    </div>

                    <div className="bg-[#4F46E5]/10 border border-[#4F46E5]/20 p-6 rounded-2xl flex flex-col justify-between">
                      <div>
                        <h3 className="text-indigo-900 font-bold mb-2 text-sm">Payout & Withdrawal Rules</h3>
                        <p className="text-xs text-slate-600 leading-relaxed mb-4">
                          Withdrawal requests are processed manually to guarantee strict adherence to regional regulatory and KYC parameters.
                        </p>
                        <ul className="space-y-2 text-xs text-slate-600">
                          <li>• Direct and Level Wallet withdrawals must be multiples of ₹100.</li>
                          <li>• Maximum daily withdrawal limits apply according to account tier.</li>
                          <li>• Please double-check your target UPI address. Errors cannot be reversed.</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                )}

                {activeWalletTab === 'history' && (
                  <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
                      <div>
                        <h3 className="font-bold text-slate-900">All Account Activity Logs</h3>
                        <p className="text-slate-500 text-xs mt-0.5">Personal record-keeping ledger of deposits, payouts, and bonuses.</p>
                      </div>
                      {onClearAllTransactions && userTransactions.length > 0 && (
                        <button
                          type="button"
                          onClick={() => {
                            if (window.confirm('⚠️ Are you sure you want to clear your transaction history?')) {
                              // Delete each transaction belonging to current user
                              userTransactions.forEach(t => {
                                if (onDeleteTransaction) onDeleteTransaction(t.id);
                              });
                              alert('Your transaction history has been cleared.');
                            }
                          }}
                          className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1 shrink-0"
                        >
                          🗑️ Clear All History
                        </button>
                      )}
                    </div>

                    {userTransactions.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-6">No transaction logs available.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table id="wallet-tx-table" className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-slate-100 text-slate-400 uppercase font-semibold">
                          <th className="pb-2">Transaction ID</th>
                          <th className="pb-2">Date</th>
                          <th className="pb-2">Type</th>
                          <th className="pb-2">Description</th>
                          <th className="pb-2 text-right">Amount</th>
                          <th className="pb-2 text-right">Status</th>
                          <th className="pb-2 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {userTransactions.map(tx => (
                          <tr id={`wallet-tx-row-${tx.id}`} key={tx.id} className="hover:bg-slate-50/50">
                            <td className="py-2.5 font-mono text-[10px] text-slate-500">{tx.id}</td>
                            <td className="py-2.5 text-slate-500">{new Date(tx.createdAt).toLocaleDateString()}</td>
                            <td className="py-2.5">
                              <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase ${
                                tx.type === 'deposit' ? 'bg-emerald-50 text-emerald-700' :
                                tx.type === 'withdrawal' ? 'bg-amber-50 text-amber-700' :
                                'bg-purple-50 text-purple-700'
                              }`}>
                                {tx.type}
                              </span>
                            </td>
                            <td className="py-2.5 text-slate-600">
                              <div>
                                {tx.description}
                                {tx.walletSource && (
                                  <span className="ml-1.5 inline-block bg-slate-100 text-slate-800 border border-slate-200 text-[8px] px-1.5 py-0.2 rounded uppercase font-black tracking-wider">
                                    {tx.walletSource} Wallet
                                  </span>
                                )}
                              </div>
                              {tx.txLink ? (
                                <div className="text-[10px] text-indigo-600 font-semibold mt-0.5">
                                  <a href={tx.txLink} target="_blank" rel="noopener noreferrer" className="underline hover:text-indigo-800 cursor-pointer">
                                    Receipt Link ↗
                                  </a>
                                </div>
                              ) : (
                                tx.status === 'pending' && (tx.type === 'deposit' || tx.type === 'contribution') && (
                                  <button
                                    onClick={() => {
                                      const link = prompt("Enter the Transaction / payment receipt link URL to send to the admin:");
                                      if (link && link.trim()) {
                                        if (onUpdateTransactionLink) {
                                          onUpdateTransactionLink(tx.id, link.trim());
                                          alert("Transaction link successfully sent to administrator for review!");
                                        }
                                      }
                                    }}
                                    className="mt-1 text-[9px] px-1.5 py-0.5 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 font-bold rounded cursor-pointer transition-all"
                                  >
                                    Send Tx Link to Admin
                                  </button>
                                )
                              )}
                            </td>
                            <td className="py-2.5 text-right font-bold text-slate-900">₹{tx.amount.toLocaleString()}</td>
                            <td className="py-2.5 text-right">
                              <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                                tx.status === 'completed' ? 'bg-emerald-50 text-emerald-700' :
                                tx.status === 'pending' ? 'bg-amber-50 text-amber-700' :
                                'bg-rose-50 text-rose-700'
                              }`}>
                                {tx.status}
                              </span>
                            </td>
                            <td className="py-2.5 text-right">
                              {onDeleteTransaction && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (window.confirm(`Delete transaction log ${tx.id}?`)) {
                                      onDeleteTransaction(tx.id);
                                    }
                                  }}
                                  className="px-2 py-0.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[9px] font-bold rounded cursor-pointer transition-all"
                                  title="Delete transaction log"
                                >
                                  Delete
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* SUBTAB 3: REFERRALS */}
        {activeSubTab === 'referrals' && (
          <div>
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-slate-900">Your Referral Network</h1>
              <p className="text-slate-500 text-sm">Review members who registered with your invitation code.</p>
            </div>

            {/* Inline Subtabs Switcher for Referrals */}
            <div className="flex border-b border-slate-200 mb-8 gap-4 text-sm font-semibold">
              <button
                onClick={() => setActiveReferralTab('link')}
                className={`pb-2 px-1 border-b-2 transition-all cursor-pointer ${
                  activeReferralTab === 'link' ? 'border-emerald-600 text-emerald-600' : 'border-transparent text-slate-500 hover:text-slate-900'
                }`}
              >
                Referral Link
              </button>
              <button
                onClick={() => setActiveReferralTab('direct')}
                className={`pb-2 px-1 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeReferralTab === 'direct' ? 'border-emerald-600 text-emerald-600' : 'border-transparent text-slate-500 hover:text-slate-900'
                }`}
              >
                <span>Direct Members</span>
                <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-black ${
                  referredUsers.length > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                }`}>
                  {referredUsers.length}
                </span>
              </button>
              <button
                onClick={() => setActiveReferralTab('team')}
                className={`pb-2 px-1 border-b-2 transition-all cursor-pointer ${
                  activeReferralTab === 'team' ? 'border-emerald-600 text-emerald-600' : 'border-transparent text-slate-500 hover:text-slate-900'
                }`}
              >
                Team Overview
              </button>
              <button
                onClick={() => setActiveReferralTab('tree')}
                className={`pb-2 px-1 border-b-2 transition-all cursor-pointer ${
                  activeReferralTab === 'tree' ? 'border-emerald-600 text-emerald-600' : 'border-transparent text-slate-500 hover:text-slate-900'
                }`}
              >
                Downline Tree
              </button>
            </div>

            {/* Subtab Contents */}
            {activeReferralTab === 'link' && (() => {
              const userRefCode = currentUser.referralCode || currentUser.id;
              const getFullRefUrl = () => {
                try {
                  const hrefClean = window.location.href.split('?')[0].split('#')[0];
                  const baseUrl = hrefClean.endsWith('/') ? hrefClean : hrefClean + '/';
                  return `${baseUrl}?ref=${encodeURIComponent(userRefCode)}`;
                } catch (e) {
                  return `${window.location.origin}/?ref=${encodeURIComponent(userRefCode)}`;
                }
              };
              const refUrl = getFullRefUrl();

              const handleCopyLink = () => {
                try {
                  navigator.clipboard.writeText(refUrl);
                  setCopiedLink(true);
                  setTimeout(() => setCopiedLink(false), 3000);
                } catch (e) {
                  alert('Referral Link: ' + refUrl);
                }
              };

              return (
                <div className="space-y-4 max-w-2xl">
                  {/* Uplink Sponsor Info */}
                  <div className="bg-indigo-50/90 border border-indigo-100 p-4 rounded-xl flex flex-wrap items-center justify-between gap-3 shadow-xs">
                    <div>
                      <span className="text-[10px] text-indigo-500 font-extrabold uppercase tracking-wider block">Joined Under Uplink Sponsor</span>
                      <p className="text-base font-black text-indigo-950 mt-0.5">
                        {currentUserSponsor ? currentUserSponsor.name : (currentUser.referredBy ? `Sponsor Ref: ${currentUser.referredBy}` : 'Direct Platform Member')}
                      </p>
                    </div>
                    <div className="bg-white px-3 py-1.5 rounded-lg border border-indigo-200 font-mono text-xs font-bold text-indigo-700 shadow-2xs">
                      Sponsor Referral ID: <span className="text-emerald-600 font-black">{currentUserSponsor ? (currentUserSponsor.referralCode || currentUserSponsor.id) : (currentUser.referredBy || 'ADMIN100')}</span>
                    </div>
                  </div>

                  {/* Direct Team Quick Status Banner */}
                  <div className="bg-emerald-50/90 border border-emerald-200 p-4 rounded-xl flex flex-wrap items-center justify-between gap-3 shadow-xs">
                    <div>
                      <span className="text-[10px] text-emerald-600 font-extrabold uppercase tracking-wider block">👥 Your Direct Team (Level 1)</span>
                      <p className="text-base font-black text-emerald-950 mt-0.5">
                        {referredUsers.length} Direct Member{referredUsers.length !== 1 ? 's' : ''} Joined
                      </p>
                      <p className="text-[11px] text-emerald-800 mt-0.5">
                        {referredUsers.length > 0 
                          ? 'New members who registered with your link are active in your direct team.' 
                          : 'Members who sign up using your invitation link will automatically appear in your Direct Team table.'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveReferralTab('direct')}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-xs transition-all cursor-pointer flex items-center gap-1"
                    >
                      📋 View Direct Team Table ({referredUsers.length}) ↗
                    </button>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase block mb-0.5">Your Invitation Code</span>
                        <p className="text-xl font-black font-mono text-emerald-600">{userRefCode}</p>
                        <p className="text-[10px] text-slate-500 mt-1.5">Share code to link members directly to your downline.</p>
                      </div>
                    </div>

                    <div className="bg-slate-900 text-white p-4 rounded-xl flex flex-col justify-between space-y-3">
                      <div>
                        <h4 className="font-bold text-xs mb-0.5 text-slate-200">Invitation Link</h4>
                        <p className="text-[10px] text-slate-400 mb-2">Share on WhatsApp or social media.</p>
                        <div className="mb-2">
                          <a 
                            href={refUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 bg-slate-950 hover:bg-slate-950/80 px-2.5 py-1.5 rounded-md font-mono text-[10px] text-emerald-400 border border-slate-800 hover:border-emerald-500/35 transition-colors cursor-pointer break-all"
                            title="Click to test referral link in a new tab"
                          >
                            <span className="underline font-semibold">{refUrl}</span>
                            <span className="text-[9px] text-slate-400">↗</span>
                          </a>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <button 
                          id="referrals-share-btn"
                          onClick={handleCopyLink} 
                          className="py-1.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded text-[11px] transition-all cursor-pointer text-center"
                        >
                          {copiedLink ? '✓ Copied!' : 'Copy Link'}
                        </button>
                        <a 
                          href={refUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="py-1.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded text-[11px] transition-all text-center flex items-center justify-center gap-0.5 cursor-pointer"
                        >
                          Open ↗
                        </a>
                      </div>
                      <div>
                        <a 
                          href={`https://api.whatsapp.com/send?text=${encodeURIComponent(`Join me on HELP 100 Mutual Aid Network! Register using my referral link: ${refUrl}`)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-full py-1.5 bg-green-600 hover:bg-green-700 text-white font-bold rounded text-[10px] uppercase tracking-wider transition-all text-center flex items-center justify-center gap-1 cursor-pointer"
                        >
                          💬 WhatsApp Share
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}

            {activeReferralTab === 'direct' && (
              <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                  <div>
                    <h3 className="font-bold text-slate-900 text-base">Direct Team Overview (Level 1)</h3>
                    <p className="text-slate-500 text-xs mt-1">
                      Below are direct registrations from members who signed up utilizing your personal referral code/link.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 self-start sm:self-center">
                    <button
                      type="button"
                      onClick={handleSyncLiveTeam}
                      disabled={isSyncingTeam}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-3 py-1.5 rounded-full border border-emerald-500 shadow-xs flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 disabled:opacity-60"
                      title="Click to perform instant live sync from server"
                    >
                      <RotateCcw className={`w-3.5 h-3.5 ${isSyncingTeam ? 'animate-spin' : ''}`} />
                      <span>{isSyncingTeam ? 'Syncing...' : 'Live Sync'}</span>
                    </button>
                    <div className="bg-emerald-50 text-emerald-800 font-extrabold text-xs px-3 py-1.5 rounded-full border border-emerald-100/50">
                      {referredUsers.length} Direct Recruit{referredUsers.length !== 1 ? 's' : ''}
                    </div>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table id="referrals-team-table" className="w-full text-left border-collapse text-xs min-w-[700px]">
                    <thead>
                      <tr className="border-b border-slate-100 text-slate-400 uppercase font-semibold">
                        <th className="pb-2.5 px-3 whitespace-nowrap">Member Details</th>
                        <th className="pb-2.5 px-3 whitespace-nowrap">Sponsor Name</th>
                        <th className="pb-2.5 px-3 whitespace-nowrap">Registered At</th>
                        <th className="pb-2.5 px-3 whitespace-nowrap">Account Status</th>
                        <th className="pb-2.5 px-3 whitespace-nowrap">Contributed</th>
                        <th className="pb-2.5 px-3 text-right whitespace-nowrap">KYC Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {referredUsers.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-8 text-center text-slate-400 font-medium">
                            No direct referrals found. Share your invitation link to build your team!
                          </td>
                        </tr>
                      ) : (
                        referredUsers.map(u => (
                          <tr key={u.id} className="hover:bg-slate-50/50 transition-all">
                            <td className="py-3 px-3 whitespace-nowrap">
                              <p className="font-bold text-slate-800">{u.name}</p>
                              <p className="text-[10px] text-slate-500 font-mono">User ID: {u.id} | <span className="font-black text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">Direct ID: {u.directId || u.referralCode}</span></p>
                            </td>
                            <td className="py-3 px-3 whitespace-nowrap">
                              <p className="font-bold text-emerald-700">{currentUser.name} (You)</p>
                              <p className="text-[10px] text-slate-500 font-mono">Sponsor Direct ID: <span className="font-bold text-emerald-800">{currentUser.directId || currentUser.referralCode}</span></p>
                            </td>
                            <td className="py-3 px-3 text-slate-500 whitespace-nowrap">
                              {u.registeredAt ? new Date(u.registeredAt).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : 'N/A'}
                            </td>
                            <td className="py-3 px-3 whitespace-nowrap">
                              <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase border ${
                                u.status === 'active' 
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-100/50' 
                                  : u.status === 'suspended'
                                  ? 'bg-red-50 text-red-700 border-red-100/50'
                                  : 'bg-amber-50 text-amber-700 border-amber-100/50'
                              }`}>
                                {u.status}
                              </span>
                            </td>
                            <td className="py-3 px-3 font-mono font-bold text-slate-700 whitespace-nowrap">
                              ₹{(u.totalContributed || 0).toLocaleString()}
                            </td>
                            <td className="py-3 px-3 text-right whitespace-nowrap">
                              <span className={`text-[10px] font-black ${
                                u.kycStatus === 'approved' 
                                  ? 'text-emerald-600' 
                                  : u.kycStatus === 'pending'
                                  ? 'text-amber-600'
                                  : 'text-slate-400'
                              }`}>
                                {u.kycStatus === 'approved' ? 'Approved' : u.kycStatus === 'pending' ? 'Pending Review' : 'Not Submitted'}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeReferralTab === 'team' && (
              <div className="space-y-6">
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-gradient-to-br from-emerald-50 to-emerald-100/30 p-5 rounded-xl border border-emerald-200/50 shadow-xs">
                    <span className="text-[10px] text-emerald-600 uppercase font-black tracking-wider">Direct Referral Bonus</span>
                    <h4 className="text-2xl font-black text-emerald-950 mt-1">{systemSettings.referralCommissionPercent}%</h4>
                    <p className="text-[11px] text-emerald-800/80 mt-2">Earned on every manual contribution pledge approved for Level 1.</p>
                  </div>

                  <div className="bg-gradient-to-br from-indigo-50 to-indigo-100/30 p-5 rounded-xl border border-indigo-200/50 shadow-xs">
                    <span className="text-[10px] text-indigo-600 uppercase font-black tracking-wider">Level 2 Bonus Rate</span>
                    <h4 className="text-2xl font-black text-indigo-950 mt-1">2%</h4>
                    <p className="text-[11px] text-indigo-800/80 mt-2">Earned on deposits and pledges from members invited by Level 1 recruits.</p>
                  </div>

                  <div className="bg-gradient-to-br from-purple-50 to-purple-100/30 p-5 rounded-xl border border-purple-200/50 shadow-xs">
                    <span className="text-[10px] text-purple-600 uppercase font-black tracking-wider">Deep Network downline</span>
                    <h4 className="text-2xl font-black text-purple-950 mt-1">Levels 3 - 5</h4>
                    <p className="text-[11px] text-purple-800/80 mt-2">Earn between 0.5% and 1% downline support commissions.</p>
                  </div>
                </div>

                {/* Team Size Metrics Cards - Clickable filters */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
                  <div className="flex items-center justify-between gap-4 mb-4">
                    <div>
                      <h3 className="font-bold text-slate-900 text-base">5-Level Downline Metrics</h3>
                      <p className="text-slate-500 text-xs mt-0.5">Click any level card below to instantly view that level's downline members.</p>
                    </div>
                    <span className="text-xs font-black bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full border border-indigo-100">
                      Total Downline: {totalTeamCount} Member{totalTeamCount !== 1 ? 's' : ''}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 text-center">
                    <button
                      onClick={() => setTeamLevelFilter('all')}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer text-center ${
                        teamLevelFilter === 'all' 
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm' 
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                      }`}
                    >
                      <span className={`text-[10px] font-bold block uppercase tracking-wider ${teamLevelFilter === 'all' ? 'text-indigo-100' : 'text-slate-500'}`}>
                        All Levels
                      </span>
                      <span className="text-xl font-black mt-1 block">{totalTeamCount}</span>
                    </button>

                    <button
                      onClick={() => setTeamLevelFilter(1)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer text-center ${
                        teamLevelFilter === 1 
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm' 
                          : 'bg-emerald-50/60 hover:bg-emerald-100/60 text-slate-800 border-emerald-200/60'
                      }`}
                    >
                      <span className={`text-[10px] font-bold block uppercase tracking-wider ${teamLevelFilter === 1 ? 'text-emerald-100' : 'text-emerald-700'}`}>
                        Level 1
                      </span>
                      <span className="text-xl font-black mt-1 block">{downlineByLevel[1].length}</span>
                    </button>

                    <button
                      onClick={() => setTeamLevelFilter(2)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer text-center ${
                        teamLevelFilter === 2 
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm' 
                          : 'bg-indigo-50/60 hover:bg-indigo-100/60 text-slate-800 border-indigo-200/60'
                      }`}
                    >
                      <span className={`text-[10px] font-bold block uppercase tracking-wider ${teamLevelFilter === 2 ? 'text-indigo-100' : 'text-indigo-700'}`}>
                        Level 2
                      </span>
                      <span className="text-xl font-black mt-1 block">{downlineByLevel[2].length}</span>
                    </button>

                    <button
                      onClick={() => setTeamLevelFilter(3)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer text-center ${
                        teamLevelFilter === 3 
                          ? 'bg-purple-600 text-white border-purple-600 shadow-sm' 
                          : 'bg-purple-50/60 hover:bg-purple-100/60 text-slate-800 border-purple-200/60'
                      }`}
                    >
                      <span className={`text-[10px] font-bold block uppercase tracking-wider ${teamLevelFilter === 3 ? 'text-purple-100' : 'text-purple-700'}`}>
                        Level 3
                      </span>
                      <span className="text-xl font-black mt-1 block">{downlineByLevel[3].length}</span>
                    </button>

                    <button
                      onClick={() => setTeamLevelFilter(4)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer text-center ${
                        teamLevelFilter === 4 
                          ? 'bg-amber-600 text-white border-amber-600 shadow-sm' 
                          : 'bg-amber-50/60 hover:bg-amber-100/60 text-slate-800 border-amber-200/60'
                      }`}
                    >
                      <span className={`text-[10px] font-bold block uppercase tracking-wider ${teamLevelFilter === 4 ? 'text-amber-100' : 'text-amber-700'}`}>
                        Level 4
                      </span>
                      <span className="text-xl font-black mt-1 block">{downlineByLevel[4].length}</span>
                    </button>

                    <button
                      onClick={() => setTeamLevelFilter(5)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer text-center ${
                        teamLevelFilter === 5 
                          ? 'bg-pink-600 text-white border-pink-600 shadow-sm' 
                          : 'bg-pink-50/60 hover:bg-pink-100/60 text-slate-800 border-pink-200/60'
                      }`}
                    >
                      <span className={`text-[10px] font-bold block uppercase tracking-wider ${teamLevelFilter === 5 ? 'text-pink-100' : 'text-pink-700'}`}>
                        Level 5
                      </span>
                      <span className="text-xl font-black mt-1 block">{downlineByLevel[5].length}</span>
                    </button>
                  </div>
                </div>

                {/* Complete Downlines Table up to 5 Levels */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                    <div>
                      <h3 className="font-bold text-slate-900 text-base">
                        Downline Members List {teamLevelFilter === 'all' ? '(All 5 Levels)' : `(Level ${teamLevelFilter})`}
                      </h3>
                      <p className="text-slate-500 text-xs mt-0.5">
                        Complete list of members in your downline hierarchy showing their exact level and direct sponsor name.
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5 flex-wrap">
                      {(['all', 1, 2, 3, 4, 5] as const).map(lvl => {
                        const levelColors = {
                          all: 'hover:bg-slate-100 text-slate-700',
                          1: 'hover:bg-emerald-50 text-emerald-700',
                          2: 'hover:bg-indigo-50 text-indigo-700',
                          3: 'hover:bg-purple-50 text-purple-700',
                          4: 'hover:bg-amber-50 text-amber-700',
                          5: 'hover:bg-pink-50 text-pink-700'
                        };
                        const activeColors = {
                          all: 'bg-slate-900 text-white font-bold',
                          1: 'bg-emerald-600 text-white font-bold',
                          2: 'bg-indigo-600 text-white font-bold',
                          3: 'bg-purple-600 text-white font-bold',
                          4: 'bg-amber-600 text-white font-bold',
                          5: 'bg-pink-600 text-white font-bold'
                        };

                        return (
                          <button
                            key={lvl}
                            onClick={() => setTeamLevelFilter(lvl)}
                            className={`px-3 py-1.5 rounded-lg text-xs transition-all cursor-pointer border border-slate-200/60 ${
                              teamLevelFilter === lvl ? activeColors[lvl] : levelColors[lvl]
                            }`}
                          >
                            {lvl === 'all' ? 'All Levels' : `L${lvl}`}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {(() => {
                    // Gather all downlines with level and sponsor
                    const allDownlineList: Array<{ user: User; level: number; sponsor: User | null }> = [];
                    [1, 2, 3, 4, 5].forEach(lvl => {
                      const listAtLvl = downlineByLevel[lvl] || [];
                      listAtLvl.forEach(u => {
                        const sp = getSponsorOfUser(u);
                        allDownlineList.push({ user: u, level: lvl, sponsor: sp });
                      });
                    });

                    const displayList = teamLevelFilter === 'all' 
                      ? allDownlineList 
                      : allDownlineList.filter(item => item.level === teamLevelFilter);

                    if (displayList.length === 0) {
                      return (
                        <div className="py-12 text-center text-slate-400">
                          <Users className="w-10 h-10 text-slate-300 mx-auto mb-2 stroke-[1.5]" />
                          <p className="text-xs font-bold text-slate-600">
                            {teamLevelFilter === 'all' 
                              ? "No members in your 5-level downline yet." 
                              : `No downline members found for Level ${teamLevelFilter}.`}
                          </p>
                          <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                            When members join using your referral link, they and their invites will populate here automatically.
                          </p>
                        </div>
                      );
                    }

                    return (
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse text-xs min-w-[750px]">
                          <thead>
                            <tr className="border-b border-slate-100 text-slate-400 uppercase font-semibold">
                              <th className="pb-2.5 px-3 whitespace-nowrap">Member Details</th>
                              <th className="pb-2.5 px-3 whitespace-nowrap">Level</th>
                              <th className="pb-2.5 px-3 whitespace-nowrap">Sponsor Name & Ref</th>
                              <th className="pb-2.5 px-3 whitespace-nowrap">Joined Date</th>
                              <th className="pb-2.5 px-3 whitespace-nowrap">Account Status</th>
                              <th className="pb-2.5 px-3 whitespace-nowrap">Contributed</th>
                              <th className="pb-2.5 px-3 text-right whitespace-nowrap">KYC Verified</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-50">
                            {displayList.map(item => {
                              const u = item.user;
                              const sp = item.sponsor;
                              const levelBadges: { [key: number]: string } = {
                                1: 'bg-emerald-50 text-emerald-700 border-emerald-200',
                                2: 'bg-indigo-50 text-indigo-700 border-indigo-200',
                                3: 'bg-purple-50 text-purple-700 border-purple-200',
                                4: 'bg-amber-50 text-amber-700 border-amber-200',
                                5: 'bg-pink-50 text-pink-700 border-pink-200'
                              };
                              const badgeStyle = levelBadges[item.level] || 'bg-slate-50 text-slate-700 border-slate-200';

                              return (
                                <tr key={u.id} className="hover:bg-slate-50/60 transition-all">
                                  <td className="py-3 px-3 whitespace-nowrap">
                                    <div className="flex items-center gap-2.5">
                                      <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200/80 flex items-center justify-center font-bold text-xs text-slate-700 shrink-0">
                                        {u.name ? u.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) : 'U'}
                                      </div>
                                      <div>
                                        <p className="font-bold text-slate-800 text-xs">{u.name}</p>
                                        <p className="text-[10px] text-slate-400 font-mono">ID: {u.id} | Ref: <strong className="text-emerald-700">{u.referralCode}</strong></p>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="py-3 px-3 whitespace-nowrap">
                                    <span className={`px-2 py-0.5 rounded-full border text-[9px] font-black uppercase ${badgeStyle}`}>
                                      Level {item.level}
                                    </span>
                                  </td>
                                  <td className="py-3 px-3 whitespace-nowrap">
                                    <p className="font-bold text-slate-800">
                                      {sp ? sp.name : (u.referredBy ? `Ref Code: ${u.referredBy}` : currentUser.name)}
                                    </p>
                                    <p className="text-[10px] text-slate-400 font-mono">
                                      Sponsor Ref ID: <strong className="text-indigo-600">{sp ? (sp.referralCode || sp.id) : (u.referredBy || currentUser.referralCode)}</strong>
                                    </p>
                                  </td>
                                  <td className="py-3 px-3 text-slate-500 whitespace-nowrap">
                                    {u.registeredAt ? new Date(u.registeredAt).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : 'N/A'}
                                  </td>
                                  <td className="py-3 px-3 whitespace-nowrap">
                                    <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase border ${
                                      u.status === 'active' 
                                        ? 'bg-emerald-50 text-emerald-700 border-emerald-100/50' 
                                        : u.status === 'suspended'
                                        ? 'bg-red-50 text-red-700 border-red-100/50'
                                        : 'bg-amber-50 text-amber-700 border-amber-100/50'
                                    }`}>
                                      {u.status}
                                    </span>
                                  </td>
                                  <td className="py-3 px-3 font-mono font-bold text-slate-700 whitespace-nowrap">
                                    ₹{(u.totalContributed || 0).toLocaleString()}
                                  </td>
                                  <td className="py-3 px-3 text-right whitespace-nowrap">
                                    <span className={`text-[10px] font-black ${
                                      u.kycStatus === 'approved' 
                                        ? 'text-emerald-600' 
                                        : u.kycStatus === 'pending'
                                        ? 'text-amber-600'
                                        : 'text-slate-400'
                                    }`}>
                                      {u.kycStatus === 'approved' ? 'Approved' : u.kycStatus === 'pending' ? 'Pending Review' : 'Not Submitted'}
                                    </span>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    );
                  })()}
                </div>
              </div>
            )}

            {activeReferralTab === 'tree' && (
              <div className="space-y-6">
                <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                    <div>
                      <h3 className="font-bold text-slate-900 text-base">Downline Network Tree</h3>
                      <p className="text-slate-500 text-xs mt-1">
                        Explore the hierarchy of your network downline up to 5 levels deep. Expand or collapse branches to navigate.
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs bg-indigo-50 text-indigo-700 font-extrabold px-3 py-1.5 rounded-full border border-indigo-100">
                        Total Network: {totalTeamCount} Member{totalTeamCount !== 1 ? 's' : ''}
                      </span>
                      {totalTeamCount > 0 && (
                        <button
                          onClick={() => {
                            const isAnyCollapsed = Object.keys(collapsedNodes).length > 0;
                            if (isAnyCollapsed) {
                              setCollapsedNodes({});
                            } else {
                              const allNodeIds: { [userId: string]: boolean } = {};
                              users.forEach(u => { allNodeIds[u.id] = true; });
                              setCollapsedNodes(allNodeIds);
                            }
                          }}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition-all cursor-pointer"
                        >
                          {Object.keys(collapsedNodes).length > 0 ? "Expand All" : "Collapse All"}
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Search Bar for Downline Tree */}
                  <div className="relative mb-6">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <Search className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      placeholder="Search downline recruits by name, email, referral code or ID..."
                      value={treeSearchQuery}
                      onChange={(e) => setTreeSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all placeholder:text-slate-400"
                    />
                    {treeSearchQuery && (
                      <button
                        onClick={() => setTreeSearchQuery('')}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
                      >
                        Clear
                      </button>
                    )}
                  </div>

                  {/* Level Legend indicator */}
                  <div className="flex flex-wrap items-center gap-4 py-3 px-4 bg-slate-50 rounded-xl border border-slate-100 text-[10px] font-bold text-slate-500 mb-6 uppercase tracking-wider">
                    <span className="text-slate-400">Levels Legend:</span>
                    <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Level 1 (Direct)</span>
                    <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-indigo-500" /> Level 2</span>
                    <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-purple-500" /> Level 3</span>
                    <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Level 4</span>
                    <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-pink-500" /> Level 5</span>
                  </div>

                  {/* Tree Render Container */}
                  <div className="mt-4 border border-slate-100 rounded-2xl p-2 sm:p-6 bg-slate-50/30 overflow-x-auto min-w-full">
                    {(() => {
                      if (totalTeamCount === 0) {
                        return (
                          <div className="py-12 text-center text-slate-400">
                            <Network className="w-12 h-12 text-slate-300 mx-auto mb-3 stroke-[1.5]" />
                            <h4 className="font-bold text-slate-700 text-sm">No referrals in your downline</h4>
                            <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                              Once members register using your personal invitation code, they and their recruits will appear here as an interactive downline network tree.
                            </p>
                          </div>
                        );
                      }

                      // If search query is active, show flat list of matches
                      if (treeSearchQuery.trim() !== '') {
                        const allDescendants = (() => {
                          const list: Array<{ user: User; level: number; sponsorName: string }> = [];
                          const visited = new Set<string>();
                          
                          const traverse = (parentUser: User, currentLevel: number, sponsorName: string) => {
                            if (currentLevel > 5 || !parentUser) return;
                            if (visited.has(parentUser.id)) return;
                            visited.add(parentUser.id);
                            
                            const children = getChildrenOfUser(parentUser);
                            children.forEach(child => {
                              list.push({ user: child, level: currentLevel, sponsorName });
                              traverse(child, currentLevel + 1, child.name);
                            });
                          };
                          
                          traverse(currentUser, 1, currentUser.name);
                          return list;
                        })();

                        const query = treeSearchQuery.toLowerCase().trim();
                        const filtered = allDescendants.filter(item => 
                          item.user.name.toLowerCase().includes(query) ||
                          item.user.id.toLowerCase().includes(query) ||
                          item.user.email.toLowerCase().includes(query) ||
                          item.user.referralCode.toLowerCase().includes(query)
                        );

                        if (filtered.length === 0) {
                          return (
                            <div className="py-12 text-center text-slate-400">
                              <p className="text-xs font-semibold">No downline members match your search query "{treeSearchQuery}"</p>
                            </div>
                          );
                        }

                        return (
                          <div className="space-y-3">
                            <h4 className="text-xs font-bold text-slate-400 mb-2 uppercase tracking-wider">Search Results ({filtered.length} match{filtered.length !== 1 ? 'es' : ''})</h4>
                            {filtered.map(item => {
                              const u = item.user;
                              const levelColors = [
                                'bg-emerald-50 text-emerald-700 border-emerald-100',
                                'bg-indigo-50 text-indigo-700 border-indigo-100',
                                'bg-purple-50 text-purple-700 border-purple-100',
                                'bg-amber-50 text-amber-700 border-amber-100',
                                'bg-pink-50 text-pink-700 border-pink-100'
                              ];
                              const levelColor = levelColors[item.level - 1] || 'bg-slate-50 text-slate-700 border-slate-100';

                              return (
                                <div key={u.id} className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-slate-300 transition-all">
                                  <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center font-bold text-sm text-slate-600">
                                      {u.name ? u.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) : 'U'}
                                    </div>
                                    <div>
                                      <div className="flex items-center gap-2 flex-wrap">
                                        <span className="font-bold text-slate-800 text-sm">{u.name}</span>
                                        <span className={`px-2 py-0.5 rounded-full border text-[9px] font-black uppercase ${levelColor}`}>
                                          Level {item.level} Recruit
                                        </span>
                                        <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                                          u.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                                        }`}>
                                          {u.status}
                                        </span>
                                      </div>
                                      <p className="text-[10px] text-slate-400 font-semibold mt-0.5">
                                        ID: {u.id} | Code: {u.referralCode} | Sponsor: {item.sponsorName}
                                      </p>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-3 ml-13 sm:ml-0 text-left sm:text-right">
                                    <div>
                                      <span className="text-[9px] text-slate-400 block font-bold uppercase">KYC Status</span>
                                      <span className={`text-[10px] font-bold ${
                                        u.kycStatus === 'approved' ? 'text-emerald-600' : u.kycStatus === 'pending' ? 'text-amber-600' : 'text-slate-400'
                                      }`}>
                                        {u.kycStatus === 'approved' ? 'Approved' : u.kycStatus === 'pending' ? 'Pending Review' : 'Not Submitted'}
                                      </span>
                                    </div>
                                    <div className="h-6 w-px bg-slate-100 hidden sm:block" />
                                    <div>
                                      <span className="text-[9px] text-slate-400 block font-bold uppercase">Contributed</span>
                                      <span className="text-[10px] font-black text-slate-700">₹{(u.totalContributed || 0).toLocaleString()}</span>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        );
                      }

                      // Recursive tree rendering function
                      const renderRecursiveNode = (user: User, depth: number = 1): React.ReactNode => {
                        const children = getChildrenOfUser(user);
                        const isCollapsed = collapsedNodes[user.id];
                        const hasChildren = children.length > 0;
                        
                        const levelColors = [
                          'bg-emerald-500',
                          'bg-indigo-500',
                          'bg-purple-500',
                          'bg-amber-500',
                          'bg-pink-500'
                        ];
                        const indicatorColor = levelColors[depth - 1] || 'bg-slate-400';

                        const textColors = [
                          'text-emerald-700 bg-emerald-50 border-emerald-100',
                          'text-indigo-700 bg-indigo-50 border-indigo-100',
                          'text-purple-700 bg-purple-50 border-purple-100',
                          'text-amber-700 bg-amber-50 border-amber-100',
                          'text-pink-700 bg-pink-50 border-pink-100'
                        ];
                        const badgeColor = textColors[depth - 1] || 'text-slate-700 bg-slate-50 border-slate-100';

                        return (
                          <div key={user.id} className="relative pl-5 sm:pl-8 border-l-2 border-slate-200/80 my-3 ml-2 sm:ml-4">
                            <div className="absolute top-6 left-0 w-5 sm:w-8 h-0.5 bg-slate-200" />
                            <div className={`absolute top-5 -left-1.5 w-3 h-3 rounded-full border-2 border-white shadow-xs ${indicatorColor}`} />

                            <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-slate-300 transition-all hover:shadow-xs relative">
                              <div className="flex items-center gap-3">
                                {hasChildren ? (
                                  <button
                                    onClick={() => setCollapsedNodes(prev => ({ ...prev, [user.id]: !prev[user.id] }))}
                                    className="p-1 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-800 transition-all focus:outline-hidden"
                                    title={isCollapsed ? "Expand team members" : "Collapse team members"}
                                  >
                                    {isCollapsed ? <ChevronRight className="w-4.5 h-4.5" /> : <ChevronDown className="w-4.5 h-4.5" />}
                                  </button>
                                ) : (
                                  <div className="w-6.5 h-6.5 flex items-center justify-center text-slate-300">
                                    <span className="w-1.5 h-1.5 rounded-full bg-slate-300" />
                                  </div>
                                )}
                                
                                <div className="w-10 h-10 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center font-bold text-xs sm:text-sm text-slate-600">
                                  {user.name ? user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) : 'U'}
                                </div>
                                
                                <div>
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="font-bold text-slate-800 text-xs sm:text-sm">{user.name}</span>
                                    <span className={`px-2 py-0.5 rounded-full border text-[9px] font-black uppercase ${badgeColor}`}>
                                      Level {depth}
                                    </span>
                                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                                      user.status === 'active' 
                                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-100/50' 
                                        : 'bg-rose-50 text-rose-700 border border-rose-100/50'
                                    }`}>
                                      {user.status}
                                    </span>
                                  </div>
                                  <p className="text-[10px] text-slate-400 font-semibold mt-0.5">
                                    ID: {user.id} | Code: {user.referralCode} | Email: {user.email}
                                  </p>
                                </div>
                              </div>
                              
                              <div className="flex items-center gap-4 sm:text-right sm:self-center ml-11 sm:ml-0 text-left">
                                <div>
                                  <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">KYC Status</span>
                                  <span className={`text-[10px] font-extrabold ${
                                    user.kycStatus === 'approved' ? 'text-emerald-600' : user.kycStatus === 'pending' ? 'text-amber-600' : 'text-slate-400'
                                  }`}>
                                    {user.kycStatus === 'approved' ? 'Approved' : user.kycStatus === 'pending' ? 'Pending Review' : 'Not Submitted'}
                                  </span>
                                </div>
                                <div className="h-6 w-px bg-slate-100 hidden sm:block" />
                                <div>
                                  <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">Contributed</span>
                                  <span className="text-[10px] font-black text-slate-700">₹{(user.totalContributed || 0).toLocaleString()}</span>
                                </div>
                                {hasChildren && (
                                  <>
                                    <div className="h-6 w-px bg-slate-100 hidden sm:block" />
                                    <div className="bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-100 text-[10px] font-extrabold text-slate-600">
                                      {children.length} recruit{children.length !== 1 ? 's' : ''}
                                    </div>
                                  </>
                                )}
                              </div>
                            </div>
                            
                            {hasChildren && !isCollapsed && (
                              <div className="mt-1 space-y-1">
                                {children.map(child => renderRecursiveNode(child, depth + 1))}
                              </div>
                            )}
                          </div>
                        );
                      };

                      const level1Recruits = getChildrenOfUser(currentUser);
                      
                      return (
                        <div className="space-y-4">
                          {/* Root Node: Logged In User */}
                          <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 shadow-md flex items-center gap-3 relative z-10">
                            <div className="w-10 h-10 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center font-black text-sm">
                              {currentUser.name ? currentUser.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) : 'ME'}
                            </div>
                            <div>
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-bold text-sm text-slate-100">{currentUser.name} (You)</span>
                                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-full text-[9px] font-black uppercase tracking-wider">Root</span>
                              </div>
                              <p className="text-[10px] text-slate-400 font-semibold font-mono mt-0.5">
                                Referral Code: {currentUser.referralCode} | ID: {currentUser.id}
                              </p>
                            </div>
                          </div>

                          {level1Recruits.length === 0 ? (
                            <div className="py-6 text-center text-slate-400">
                              <p className="text-xs">You don't have any downline members yet. Share your invitation link to get started!</p>
                            </div>
                          ) : (
                            <div className="mt-2">
                              {level1Recruits.map(rec => renderRecursiveNode(rec, 1))}
                            </div>
                          )}
                        </div>
                      );
                    })()}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* SUBTAB 4: CONTRIBUTION PLEDGES */}
        {activeSubTab === 'contribution' && (
          <div>
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-slate-900">Contribution Pledges</h1>
              <p className="text-slate-500 text-sm">Make structured pledges to the community mutual support pool.</p>
            </div>

            {contribSuccessMsg && (
              <div className="mb-6 p-4 bg-emerald-50 border border-emerald-100 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600" />
                {contribSuccessMsg}
              </div>
            )}

            {/* Inline Subtabs Switcher for Contribution Pledges */}
            <div className="flex border-b border-slate-200 mb-8 gap-4 text-sm font-semibold">
              <button
                onClick={() => setActiveContributionTab('history')}
                className={`pb-2 px-1 border-b-2 transition-all cursor-pointer ${
                  activeContributionTab === 'history' ? 'border-emerald-600 text-emerald-600' : 'border-transparent text-slate-500 hover:text-slate-900'
                }`}
              >
                History
              </button>
            </div>

            {/* Subtab Contents */}
            {activeContributionTab === 'history' && (
              <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm">
                <h3 className="font-bold text-slate-900 mb-3">Your Pledge History</h3>
                
                {userContributions.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-6">You have not submitted any contribution pledges yet.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table id="contrib-history-table" className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-slate-100 text-slate-400 uppercase font-semibold">
                          <th className="pb-2">Pledge ID</th>
                          <th className="pb-2">Date Submitted</th>
                          <th className="pb-2">Proof File</th>
                          <th className="pb-2 text-right">Amount</th>
                          <th className="pb-2 text-right">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {userContributions.map(c => (
                          <tr id={`contrib-history-row-${c.id}`} key={c.id}>
                            <td className="py-2.5 font-mono text-[10px] text-slate-500">{c.id}</td>
                            <td className="py-2.5 text-slate-500">{new Date(c.createdAt).toLocaleDateString()}</td>
                            <td className="py-2.5 font-mono text-[10px]">
                              {c.paymentProof === 'Pending Upload' || c.paymentProof === 'None (Pending Upload)' ? (
                                <span className="text-rose-500 font-bold">{c.paymentProof}</span>
                              ) : (
                                <span className="text-slate-600">{c.paymentProof}</span>
                              )}
                            </td>
                            <td className="py-2.5 text-right font-bold text-slate-900">₹{c.amount.toLocaleString()}</td>
                            <td className="py-2.5 text-right">
                              <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${
                                c.status === 'approved' ? 'bg-emerald-50 text-emerald-700' :
                                c.status === 'pending_verification' ? 'bg-amber-50 text-amber-700' :
                                'bg-rose-50 text-rose-700'
                              }`}>
                                {c.status === 'pending_verification' ? 'Pending Proof Review' : c.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

          </div>
        )}

        {/* SUBTAB 5: HELP REQUESTS */}
        {activeSubTab === 'help' && (
          <div>
            {/* Header */}
            <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-100 pb-4">
              <div>
                <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <ArrowDownCircle className="w-6 h-6 text-[#0D6EFD] animate-pulse" />
                  Taker Console (Get Help)
                </h1>
                <p className="text-slate-500 text-sm">Raise emergency mutual aid requests and submit verification reports under the community taker protocol.</p>
              </div>
            </div>

            {/* Inline Subtabs Switcher for Help Requests */}
            <div className="flex border-b border-slate-200 mb-8 gap-4 text-sm font-semibold">
              <button
                onClick={() => setActiveHelpTab('status')}
                className={`pb-2 px-1 border-b-2 transition-all cursor-pointer ${
                  activeHelpTab === 'status' ? 'border-[#0D6EFD] text-[#0D6EFD]' : 'border-transparent text-slate-500 hover:text-slate-900'
                }`}
              >
                Status
              </button>
              <button
                onClick={() => setActiveHelpTab('review')}
                className={`pb-2 px-1 border-b-2 transition-all cursor-pointer ${
                  activeHelpTab === 'review' ? 'border-[#0D6EFD] text-[#0D6EFD]' : 'border-transparent text-slate-500 hover:text-slate-900'
                }`}
              >
                Admin Review
              </button>
            </div>

            {helpSuccessMsg && (
              <div className="mb-6 p-4 bg-blue-50 border border-blue-100 rounded-xl text-blue-800 text-xs font-semibold flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-[#0D6EFD]" />
                {helpSuccessMsg}
              </div>
            )}

            {/* Subtab Contents */}

            {activeHelpTab === 'review' && (
              <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm max-w-3xl">
                <h3 className="font-bold text-slate-900 mb-1">Administrative Audit & Review Status</h3>
                <p className="text-slate-500 text-xs mb-6">Track our standard compliance protocol steps for raised campaigns.</p>

                {userHelpRequests.length === 0 ? (
                  <div className="p-6 bg-slate-50 rounded-xl text-center text-slate-400 text-xs">
                    You have not submitted any help campaigns yet. Raised campaigns will appear here for audit tracking.
                  </div>
                ) : (
                  <div className="space-y-6">
                    {userHelpRequests.map(req => (
                      <div key={req.id} className="border border-slate-100 rounded-xl p-4 bg-slate-50/50">
                        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                          <div>
                            <span className="text-[10px] font-mono font-bold text-[#0D6EFD]">{req.id}</span>
                            <h4 className="font-bold text-slate-800 text-xs">{req.title}</h4>
                          </div>
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${
                            req.status === 'completed' ? 'bg-blue-50 text-blue-700' :
                            req.status === 'approved' ? 'bg-indigo-50 text-indigo-700' :
                            req.status === 'pending_review' ? 'bg-amber-50 text-amber-700' : 'bg-rose-50 text-rose-700'
                          }`}>
                            {req.status === 'pending_review' ? 'Under active review' : req.status}
                          </span>
                        </div>

                        {/* Audit steps list */}
                        <div className="space-y-4">
                          <div className="flex items-start gap-3">
                            <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">✓</div>
                            <div>
                              <p className="text-xs font-semibold text-slate-800">1. Document Authenticity Audit</p>
                              <p className="text-[11px] text-slate-500 mt-0.5">Attached document <code className="bg-white px-1 border rounded">{req.documentUrl || 'supporting_proof.pdf'}</code> received and parsed.</p>
                            </div>
                          </div>

                          <div className="flex items-start gap-3">
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5 ${
                              req.status !== 'pending_review' ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700 animate-pulse'
                            }`}>
                              {req.status !== 'pending_review' ? '✓' : '2'}
                            </div>
                            <div>
                              <p className="text-xs font-semibold text-slate-800">2. Compliance & KYC Cross-check</p>
                              <p className="text-[11px] text-slate-500 mt-0.5">
                                {currentUser.kycStatus === 'approved' 
                                  ? 'User KYC verified successfully. Audit checks passed.' 
                                  : 'Pending user KYC completion.'}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-start gap-3">
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5 ${
                              req.status === 'approved' || req.status === 'completed' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-400'
                            }`}>
                              {req.status === 'completed' ? '✓' : '3'}
                            </div>
                            <div>
                              <p className="text-xs font-semibold text-slate-800">3. Campaign Activation & Peer Matching</p>
                              <p className="text-[11px] text-slate-500 mt-0.5">
                                {req.status === 'approved' ? 'Campaign live! Matching with community givers is active.' :
                                 req.status === 'completed' ? 'Campaign fully funded and peer matches verified.' :
                                 'Awaiting final compliance approval to activate peer routing.'}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeHelpTab === 'status' && (
              <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm">
                <h3 className="font-bold text-slate-900 mb-3">Your Raised Campaigns</h3>
                
                {userHelpRequests.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-6">You have not registered any emergency aid requests.</p>
                ) : (
                  <div className="space-y-4">
                    {userHelpRequests.map(h => (
                      <div id={`help-campaign-card-${h.id}`} key={h.id} className="p-4 rounded-xl bg-slate-50 border border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div>
                          <span className="text-[10px] uppercase font-mono font-bold text-slate-400">{h.id}</span>
                          <h4 className="font-bold text-slate-800 mt-0.5">{h.title}</h4>
                          <p className="text-xs text-slate-500 mt-1 line-clamp-2">{h.description}</p>
                          
                          {/* Progress Bar */}
                          <div className="mt-3 w-48 bg-slate-200 h-1.5 rounded-full overflow-hidden">
                            <div 
                              className="bg-gradient-to-r from-[#0D6EFD] to-[#00BFFF] h-1.5 rounded-full" 
                              style={{ width: `${Math.min(100, (h.amountReceived / h.amountRequested) * 100)}%` }}
                            />
                          </div>
                          <p className="text-[10px] text-slate-400 mt-1 font-mono">Collected: ₹{h.amountReceived.toLocaleString()} / ₹{h.amountRequested.toLocaleString()}</p>
                          
                          {h.txLink ? (
                            <div className="mt-3 p-2.5 bg-blue-50/50 border border-blue-100 rounded-lg space-y-1 max-w-xs text-left">
                              <span className="text-[9px] uppercase font-bold text-[#0D6EFD] tracking-wider block">🔗 Admin Claim Gateway Link</span>
                              <p className="text-[10px] text-slate-600 leading-relaxed font-semibold">
                                Use this direct gateway/receipt link to claim or track payouts:
                              </p>
                              <a 
                                href={h.txLink.startsWith('http') ? h.txLink : `https://${h.txLink}`} 
                                target="_blank" 
                                rel="noopener noreferrer" 
                                className="inline-flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-[#0D6EFD] to-[#00BFFF] hover:opacity-90 text-white rounded text-[10px] font-black uppercase tracking-wider shadow-sm shadow-[#0D6EFD]/10 cursor-pointer transition-all"
                              >
                                📥 Open Gateway Link ↗
                              </a>
                            </div>
                          ) : (
                            h.status !== 'completed' && (
                              <div className="mt-2.5 text-[10px] text-amber-600 font-bold flex items-center gap-1 bg-amber-50 border border-amber-100/50 px-2.5 py-1.5 rounded-lg max-w-xs">
                                <span>⏳ Awaiting payout gateway link from admin...</span>
                              </div>
                            )
                          )}
                        </div>

                        <div className="text-right">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            h.status === 'completed' ? 'bg-emerald-50 text-emerald-700' :
                            h.status === 'approved' ? 'bg-indigo-50 text-indigo-700' :
                            h.status === 'pending_review' ? 'bg-amber-50 text-amber-700' : 'bg-rose-50 text-rose-700'
                          }`}>
                            {h.status}
                          </span>
                          <p className="text-[10px] text-slate-400 mt-1 font-semibold">Submitted: {new Date(h.createdAt).toLocaleDateString()}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

          </div>
        )}

        {/* SUBTAB 6: NOTIFICATIONS */}
        {activeSubTab === 'notifications' && (
          <div>
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Your Notifications</h1>
                <p className="text-slate-500 text-sm">System updates and community status alerts.</p>
              </div>
              {onClearAllNotifications && notifications.filter(n => n.userId === 'all' || n.userId === currentUser.id).length > 0 && (
                <button
                  id="btn-clear-notifications"
                  onClick={() => {
                    if (window.confirm('Are you sure you want to delete and clear all notifications permanently?')) {
                      onClearAllNotifications();
                    }
                  }}
                  className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors border border-rose-100 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Remove All
                </button>
              )}
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 sm:p-6 divide-y divide-slate-100">
              {notifications.filter(n => n.userId === 'all' || n.userId === currentUser.id).length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-6">No notifications registered.</p>
              ) : (
                notifications.filter(n => n.userId === 'all' || n.userId === currentUser.id).map(notif => (
                  <div id={`notif-item-${notif.id}`} key={notif.id} className="py-4 first:pt-0 last:pb-0 flex items-start gap-3">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 mt-2 shrink-0" />
                    <div>
                      <h4 className="font-bold text-xs text-slate-800">{notif.title}</h4>
                      <p className="text-xs text-slate-600 mt-0.5">{notif.message}</p>
                      <span className="text-[9px] text-slate-400 font-mono mt-1 block">{new Date(notif.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* SUBTAB 7: SUPPORT TICKETS */}
        {activeSubTab === 'support' && (
          <div>
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-slate-900">Support Center</h1>
              <p className="text-slate-500 text-sm">Open tickets to resolve profile or deposit queries.</p>
            </div>

            {/* WhatsApp Support Information Card */}
            {systemSettings.whatsappSupportNumber && (
              <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white p-5 rounded-2xl border border-emerald-400/20 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-white/20 border border-white/10 text-white rounded-full text-[9px] font-bold uppercase tracking-widest">
                    💬 Instant WhatsApp Auto-Reply Active
                  </div>
                  <h3 className="font-bold text-lg text-white">Need Lightning-Fast Support?</h3>
                  <p className="text-emerald-100 text-xs">
                    Chat directly with our support helpdesk on WhatsApp at <strong className="font-mono text-white">{systemSettings.whatsappSupportNumber}</strong>. Our automated system is ready to instantly resolve your query.
                  </p>
                </div>
                <a
                  id="support-whatsapp-direct-btn"
                  href={`https://api.whatsapp.com/send?phone=${systemSettings.whatsappSupportNumber.replace(/[^0-9+]/g, '')}&text=${encodeURIComponent(`Hello, I need assistance with my account. My name is ${currentUser.name}.`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-white text-emerald-700 hover:bg-emerald-50 rounded-xl text-xs font-bold transition-all text-center flex items-center justify-center gap-1.5 shadow-sm shrink-0"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.513 2.263 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.717-1.454L0 24zm6.59-4.846c1.6.95 3.197 1.45 4.817 1.451 5.4 0 9.791-4.392 9.794-9.796.002-2.618-1.015-5.08-2.867-6.934C16.54 2.02 14.084.997 11.474.997 6.073.997 1.684 5.388 1.681 10.793c-.001 1.745.474 3.447 1.378 4.985l-.905 3.3 3.38-.887zm12.355-6.046c-.301-.15-1.777-.878-2.046-.977-.27-.099-.465-.15-.658.15-.195.3-.75.95-.919 1.15-.17.199-.339.224-.64.075-.3-.15-1.265-.467-2.41-1.487-.893-.797-1.495-1.78-1.67-2.08-.175-.3-.018-.462.13-.61.135-.133.301-.35.452-.524.15-.174.2-.299.3-.498.099-.2.05-.374-.025-.524-.075-.15-.658-1.587-.902-2.172-.24-.574-.482-.497-.658-.506-.17-.008-.364-.01-.559-.01-.195 0-.514.073-.782.366-.269.299-1.025 1.002-1.025 2.443 0 1.442 1.049 2.836 1.196 3.036.147.2 2.065 3.153 5.003 4.428.699.303 1.246.484 1.671.62.704.223 1.345.191 1.851.115.564-.084 1.777-.727 2.027-1.43.25-.702.25-1.305.175-1.43-.075-.125-.269-.199-.57-.349z"/>
                  </svg>
                  Chat on WhatsApp
                </a>
              </div>
            )}

            {ticketSuccessMsg && (
              <div className="mb-6 p-4 bg-emerald-50 border border-emerald-100 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600" />
                {ticketSuccessMsg}
              </div>
            )}

            <div className="grid md:grid-cols-3 gap-8">
              
              {/* Creator Form */}
              <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm md:col-span-1">
                <h3 className="font-bold text-slate-900 mb-3">Open Support Ticket</h3>
                
                <form onSubmit={handleTicketSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Subject</label>
                    <input 
                      id="support-input-subject"
                      type="text"
                      required
                      placeholder="e.g. Verification Delayed"
                      value={ticketSubject}
                      onChange={(e) => setTicketSubject(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Details Message</label>
                    <textarea 
                      id="support-input-message"
                      required
                      rows={5}
                      placeholder="Explain your situation here..."
                      value={ticketMessage}
                      onChange={(e) => setTicketMessage(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                    />
                  </div>

                  <button 
                    id="support-submit-btn"
                    type="submit"
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition-all cursor-pointer"
                  >
                    Submit Support Request
                  </button>
                </form>
              </div>

              {/* Ticket History */}
              <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm md:col-span-2">
                <h3 className="font-bold text-slate-900 mb-3">Ticket Ledger</h3>

                {userTickets.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-8">You have no recorded tickets.</p>
                ) : (
                  <div className="space-y-4">
                    {userTickets.map(tk => (
                      <div id={`ticket-card-${tk.id}`} key={tk.id} className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">{tk.id}</span>
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${
                            tk.status === 'resolved' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
                          }`}>
                            {tk.status}
                          </span>
                        </div>
                        <h4 className="font-bold text-slate-800 text-xs">{tk.subject}</h4>
                        <p className="text-xs text-slate-600 mt-1">{tk.message}</p>

                        {/* WhatsApp ticket actions */}
                        {systemSettings.whatsappSupportNumber && (
                          <div className="mt-2 flex gap-2">
                            <a
                              id={`ticket-whatsapp-action-${tk.id}`}
                              href={`https://api.whatsapp.com/send?phone=${systemSettings.whatsappSupportNumber.replace(/[^0-9+]/g, '')}&text=${encodeURIComponent(
                                `Hello Support, I have opened a Support Ticket on HELP 100. Name: ${tk.userName}, ID: ${tk.id}, Subject: "${tk.subject}", Message: "${tk.message}".`
                              )}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-2 py-0.5 rounded transition-all cursor-pointer"
                            >
                              <svg className="w-2.5 h-2.5 fill-current" viewBox="0 0 24 24">
                                <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.513 2.263 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.717-1.454L0 24zm6.59-4.846c1.6.95 3.197 1.45 4.817 1.451 5.4 0 9.791-4.392 9.794-9.796.002-2.618-1.015-5.08-2.867-6.934C16.54 2.02 14.084.997 11.474.997 6.073.997 1.684 5.388 1.681 10.793c-.001 1.745.474 3.447 1.378 4.985l-.905 3.3 3.38-.887zm12.355-6.046c-.301-.15-1.777-.878-2.046-.977-.27-.099-.465-.15-.658.15-.195.3-.75.95-.919 1.15-.17.199-.339.224-.64.075-.3-.15-1.265-.467-2.41-1.487-.893-.797-1.495-1.78-1.67-2.08-.175-.3-.018-.462.13-.61.135-.133.301-.35.452-.524.15-.174.2-.299.3-.498.099-.2.05-.374-.025-.524-.075-.15-.658-1.587-.902-2.172-.24-.574-.482-.497-.658-.506-.17-.008-.364-.01-.559-.01-.195 0-.514.073-.782.366-.269.299-1.025 1.002-1.025 2.443 0 1.442 1.049 2.836 1.196 3.036.147.2 2.065 3.153 5.003 4.428.699.303 1.246.484 1.671.62.704.223 1.345.191 1.851.115.564-.084 1.777-.727 2.027-1.43.25-.702.25-1.305.175-1.43-.075-.125-.269-.199-.57-.349z"/>
                              </svg>
                              Open in WhatsApp
                            </a>
                          </div>
                        )}

                        {/* Reply box if replies present */}
                        {tk.reply && (
                          <div className="mt-3 p-3 bg-emerald-50 border border-emerald-100 rounded-lg">
                            <span className="text-[9px] uppercase font-bold text-emerald-800 tracking-wider">Admin Reply:</span>
                            <p className="text-xs text-emerald-950 mt-0.5 leading-relaxed">{tk.reply}</p>
                            <span className="text-[8px] text-slate-400 mt-1 block">Replied: {new Date(tk.repliedAt || '').toLocaleDateString()}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>

            {/* DNS & Custom Domain Connection Guidelines */}
            <div className="mt-8 bg-gradient-to-br from-slate-900 to-slate-950 text-white p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10 space-y-6">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full text-[10px] font-black uppercase tracking-widest mb-3">
                    🌐 Domain Deployment Guide
                  </div>
                  <h3 className="text-xl font-black tracking-tight text-white">How to Connect Your Website to a Custom Domain</h3>
                  <p className="text-slate-400 text-xs mt-1 max-w-2xl">
                    Follow these step-by-step instructions to point your private registered domain (from GoDaddy, Namecheap, Hostinger, or Google Domains) to this mutual aid system.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
                  <div className="bg-slate-900/60 p-4 rounded-2xl border border-white/5 space-y-2">
                    <span className="w-6 h-6 bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-full flex items-center justify-center font-black text-xs">
                      1
                    </span>
                    <h4 className="font-extrabold text-sm text-slate-200">Retrieve IP Address</h4>
                    <p className="text-slate-400 text-[11px] leading-relaxed">
                      Your deployed system runs on a container platform (Cloud Run / App Engine). Retrieve your static load balancer public IP: <strong className="font-mono text-emerald-400">34.120.145.210</strong>.
                    </p>
                  </div>

                  <div className="bg-slate-900/60 p-4 rounded-2xl border border-white/5 space-y-2">
                    <span className="w-6 h-6 bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-full flex items-center justify-center font-black text-xs">
                      2
                    </span>
                    <h4 className="font-extrabold text-sm text-slate-200">Configure DNS Records</h4>
                    <p className="text-slate-400 text-[11px] leading-relaxed">
                      Log into your Domain Registrar DNS zone editor and add the following two key records:
                    </p>
                    <div className="bg-slate-950 p-2 rounded-xl border border-white/5 space-y-1 text-[10px] font-mono text-slate-300">
                      <div>• <span className="text-purple-400">A Record:</span> <strong className="text-white">@</strong> → <span className="text-emerald-400">34.120.145.210</span></div>
                      <div>• <span className="text-purple-400">CNAME:</span> <strong className="text-white">www</strong> → <span className="text-emerald-400">yourdomain.com</span></div>
                    </div>
                  </div>

                  <div className="bg-slate-900/60 p-4 rounded-2xl border border-white/5 space-y-2">
                    <span className="w-6 h-6 bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-full flex items-center justify-center font-black text-xs">
                      3
                    </span>
                    <h4 className="font-extrabold text-sm text-slate-200">SSL Certificate & Live</h4>
                    <p className="text-slate-400 text-[11px] leading-relaxed">
                      Once DNS propagation is complete (usually takes 10 to 45 minutes), our automated reverse-proxy layer on port 3000 will automatically issue a free Let's Encrypt SSL/HTTPS certificate for your domain.
                    </p>
                  </div>
                </div>

                <div className="bg-emerald-950/20 border border-emerald-500/20 p-4 rounded-2xl flex items-start gap-3">
                  <span className="text-emerald-400 text-lg">💡</span>
                  <div className="text-left">
                    <h5 className="font-bold text-xs text-emerald-300">Important Note on Port Binding</h5>
                    <p className="text-slate-400 text-[11px] mt-0.5 leading-relaxed">
                      Always ensure your upstream server listens on host <strong className="font-mono text-white">0.0.0.0</strong> on port <strong className="font-mono text-white">3000</strong>. The platform proxy automatically handles HTTPS redirection from standard web traffic (port 80/443) to your server's secure local port.
                    </p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* SUBTAB: MY PROFILE & PAYMENT SETTINGS */}
        {activeSubTab === 'profile' && (
          <div className="space-y-6">
            <div className="mb-6">
              <h1 className="text-2xl font-black text-slate-900 flex items-center gap-2">
                <UserIcon className="w-6 h-6 text-emerald-600" />
                My Profile & Payout Settings
              </h1>
              <p className="text-slate-500 text-sm mt-0.5">
                Manage your personal info and configure your two sets of payment details (Primary and Secondary Bank/UPI routes) for mutual aid payouts.
              </p>
            </div>

            {profileSuccessMsg && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2.5 shadow-sm animate-bounce">
                <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
                <div>
                  <h4 className="font-bold text-[13px]">Profile Saved Successfully!</h4>
                  <p className="text-[11px] text-emerald-700 font-normal">Your payout routes have been updated. Peer donors will see these details on match requests.</p>
                </div>
              </div>
            )}

            <form onSubmit={(e) => {
              e.preventDefault();
              const updatedUser = {
                ...currentUser,
                name: profileName,
                email: profileEmail,
                phone: profileMobile,
                upiId: profileUpiId,
                bankName: profileBankName,
                accountNumber: profileAccountNumber,
                ifscCode: profileIfscCode,
                secondaryUpiId: profileSecondaryUpiId,
                secondaryBankName: profileSecondaryBankName,
                secondaryAccountNumber: profileSecondaryAccountNumber,
                secondaryIfscCode: profileSecondaryIfscCode,
              };
              onUpdateUser(updatedUser);
              setProfileSuccessMsg('Profile updated successfully!');
              setTimeout(() => setProfileSuccessMsg(''), 5000);
            }} className="space-y-6">
              
              {/* Card 1: Personal Profile Info */}
              <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-3.5 mb-4">
                  <div className="p-1.5 bg-indigo-50 rounded-lg text-indigo-600">
                    <UserIcon className="w-4 h-4" />
                  </div>
                  <h3 className="font-black text-slate-900 text-sm">Personal Profile Details</h3>
                </div>

                <div className="grid sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Full Name</label>
                    <input 
                      type="text" 
                      required
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none bg-slate-50/50 text-slate-800"
                      placeholder="Enter Full Name"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Email Address</label>
                    <input 
                      type="email" 
                      required
                      value={profileEmail}
                      onChange={(e) => setProfileEmail(e.target.value)}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none bg-slate-50/50 text-slate-800"
                      placeholder="your.email@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Mobile number</label>
                    <input 
                      type="text" 
                      required
                      value={profileMobile}
                      onChange={(e) => setProfileMobile(e.target.value)}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none bg-slate-50/50 text-slate-800"
                      placeholder="+91 XXXXX XXXXX"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Your Sponsor Name</label>
                    <input 
                      type="text" 
                      readOnly
                      disabled
                      value={currentUserSponsor ? currentUserSponsor.name : (currentUser.referredBy ? 'Platform Admin / System' : 'Direct Member')}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-bold bg-slate-100/80 text-slate-700 cursor-not-allowed outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Sponsor Referral ID / Code</label>
                    <input 
                      type="text" 
                      readOnly
                      disabled
                      value={currentUserSponsor ? (currentUserSponsor.referralCode || currentUserSponsor.id) : (currentUser.referredBy || 'ADMIN100')}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-mono font-bold bg-slate-100/80 text-emerald-700 cursor-not-allowed outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Your Personal Referral Code</label>
                    <input 
                      type="text" 
                      readOnly
                      disabled
                      value={currentUser.referralCode}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-mono font-bold bg-slate-100/80 text-indigo-700 cursor-not-allowed outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                
                {/* Card 2: Primary Payment Settings */}
                <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm relative overflow-hidden">
                  <div className="absolute top-0 right-0 bg-emerald-500 text-white font-black text-[8px] uppercase tracking-wider py-1 px-3 rounded-bl-xl shadow-sm">
                    Primary Route
                  </div>
                  
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3.5 mb-4">
                    <div className="p-1.5 bg-emerald-50 rounded-lg text-emerald-600">
                      <Wallet className="w-4 h-4" />
                    </div>
                    <h3 className="font-black text-slate-900 text-sm">Primary Payment Details (Route 1)</h3>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">UPI ID (Route 1)</label>
                      <input 
                        type="text" 
                        required
                        value={profileUpiId}
                        onChange={(e) => setProfileUpiId(e.target.value)}
                        className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none font-mono text-slate-800"
                        placeholder="e.g. username@okhdfc"
                      />
                      <p className="text-[9px] text-slate-400 mt-1">Recommended for instant peer matching payments.</p>
                    </div>

                    <div className="border-t border-slate-100 pt-3.5 space-y-3">
                      <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-widest">Bank Details</span>
                      
                      <div>
                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Bank Name</label>
                        <input 
                          type="text" 
                          required
                          value={profileBankName}
                          onChange={(e) => setProfileBankName(e.target.value)}
                          className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none text-slate-800"
                          placeholder="e.g. State Bank of India"
                        />
                      </div>

                      <div className="grid sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Account Number</label>
                          <input 
                            type="text" 
                            required
                            value={profileAccountNumber}
                            onChange={(e) => setProfileAccountNumber(e.target.value)}
                            className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none font-mono text-slate-800"
                            placeholder="Bank Account Number"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">IFSC Code</label>
                          <input 
                            type="text" 
                            required
                            value={profileIfscCode}
                            onChange={(e) => setProfileIfscCode(e.target.value.toUpperCase())}
                            className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all outline-none font-mono text-slate-800"
                            placeholder="IFSC Code"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card 3: Secondary Payment Settings */}
                <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm relative overflow-hidden">
                  <div className="absolute top-0 right-0 bg-blue-500 text-white font-black text-[8px] uppercase tracking-wider py-1 px-3 rounded-bl-xl shadow-sm">
                    Secondary Route
                  </div>

                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3.5 mb-4">
                    <div className="p-1.5 bg-blue-50 rounded-lg text-blue-600">
                      <Wallet className="w-4 h-4" />
                    </div>
                    <h3 className="font-black text-slate-900 text-sm">Secondary Payment Details (Route 2)</h3>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">UPI ID (Route 2)</label>
                      <input 
                        type="text" 
                        value={profileSecondaryUpiId}
                        onChange={(e) => setProfileSecondaryUpiId(e.target.value)}
                        className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all outline-none font-mono text-slate-800 bg-slate-50/50"
                        placeholder="e.g. username@okaxis (Secondary)"
                      />
                      <p className="text-[9px] text-slate-400 mt-1">Secondary fallback UPI option.</p>
                    </div>

                    <div className="border-t border-slate-100 pt-3.5 space-y-3">
                      <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-widest">Bank Details</span>
                      
                      <div>
                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Secondary Bank Name</label>
                        <input 
                          type="text" 
                          value={profileSecondaryBankName}
                          onChange={(e) => setProfileSecondaryBankName(e.target.value)}
                          className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all outline-none text-slate-800 bg-slate-50/50"
                          placeholder="e.g. HDFC Bank"
                        />
                      </div>

                      <div className="grid sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Account Number</label>
                          <input 
                            type="text" 
                            value={profileSecondaryAccountNumber}
                            onChange={(e) => setProfileSecondaryAccountNumber(e.target.value)}
                            className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all outline-none font-mono text-slate-800 bg-slate-50/50"
                            placeholder="Secondary Account"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">IFSC Code</label>
                          <input 
                            type="text" 
                            value={profileSecondaryIfscCode}
                            onChange={(e) => setProfileSecondaryIfscCode(e.target.value.toUpperCase())}
                            className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all outline-none font-mono text-slate-800 bg-slate-50/50"
                            placeholder="Secondary IFSC"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              {/* Save Panel */}
              <div className="flex items-center justify-end pt-2">
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs uppercase px-6 py-3 rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <CheckCircle className="w-4 h-4" />
                  Save Changes & Payout Settings
                </button>
              </div>

            </form>
          </div>
        )}

        {/* SUBTAB: Rs 100 CYCLE PLAN */}
        {activeSubTab === 'plan100' && (
          <div>
            <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-300 uppercase tracking-wider inline-block mb-2 animate-pulse">
                  ₹100 Mutual Aid Cycle
                </span>
                <h1 className="text-3xl font-black text-slate-900 flex items-center gap-2">
                  ₹100 Peer-to-Peer Help Plan
                </h1>
                <p className="text-slate-500 text-xs sm:text-sm mt-0.5">
                  Follow the exact step-by-step mutual aid simulator to grow ₹100 into ₹175!
                </p>
              </div>
            </div>

            {/* Cycle Stats Overview cards */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-8">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Wallet Balance</span>
                <p className="text-2xl font-black text-slate-900 mt-1 font-mono">₹{currentUser.walletBalance.toLocaleString()}</p>
                <p className="text-[10px] text-slate-500 mt-0.5">Used for payments & receipt credits</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Provided</span>
                <p className="text-2xl font-black text-emerald-600 mt-1 font-mono">₹{cycleState.totalProvided.toLocaleString()}</p>
                <p className="text-[10px] text-slate-500 mt-0.5">₹10 Pin + ₹50 PH1 + ₹50 PH2</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Received</span>
                <p className="text-2xl font-black text-indigo-600 mt-1 font-mono">₹{cycleState.totalReceived.toLocaleString()}</p>
                <p className="text-[10px] text-slate-500 mt-0.5">5 Payouts: 50+50+25+25+25</p>
              </div>

              <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 p-5 rounded-2xl border border-emerald-200/60 shadow-sm relative overflow-hidden">
                <span className="text-[10px] uppercase font-bold text-emerald-800 block">Cycle Net Profit</span>
                <p className="text-2xl font-black text-emerald-700 mt-1 font-mono">₹{realTimeCycleProfit.toLocaleString()}</p>
                <div className="text-[10px] text-emerald-600 mt-0.5 font-semibold flex flex-col gap-0.5">
                  <span>Max Profit Goal: ₹75</span>
                  <span className="bg-emerald-200/50 text-emerald-900 px-1 py-0.5 rounded text-[8px] font-extrabold uppercase inline-block w-max mt-0.5 tracking-wider">
                    ⚡ Real-time Ledger Sync
                  </span>
                </div>
                <Sparkles className="w-8 h-8 text-emerald-500/20 absolute -right-1 -bottom-1" />
              </div>
            </div>

            {/* 8-Step Cycle Progress Timeline */}
            {(() => {
              const isCompleted = (stepKey: string) => {
                if (cycleState.currentStep === 'completed') return true;
                switch (stepKey) {
                  case 'pin': return cycleState.pinPurchased || cycleState.currentStep !== 'buy_pin';
                  case 'ph1': return cycleState.firstPhSubmitted || !['buy_pin', 'first_ph'].includes(cycleState.currentStep);
                  case 'ph2': return cycleState.secondPhSubmitted || !['buy_pin', 'first_ph', 'second_ph'].includes(cycleState.currentStep);
                  case 'gh1': return cycleState.firstGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh'].includes(cycleState.currentStep);
                  case 'gh2': return cycleState.secondGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh'].includes(cycleState.currentStep);
                  case 'gh3': return cycleState.thirdGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh', 'third_gh'].includes(cycleState.currentStep);
                  case 'gh4': return cycleState.fourthGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh', 'third_gh', 'fourth_gh'].includes(cycleState.currentStep);
                  case 'gh5': return cycleState.fifthGhReceived || cycleState.currentStep === 'completed';
                  default: return false;
                }
              };

              const isActive = (stepKey: string) => {
                if (cycleState.currentStep === 'completed') return false;
                switch (stepKey) {
                  case 'pin': return cycleState.currentStep === 'buy_pin';
                  case 'ph1': return cycleState.currentStep === 'first_ph';
                  case 'ph2': return cycleState.currentStep === 'second_ph';
                  case 'gh1': return cycleState.currentStep === 'first_gh';
                  case 'gh2': return cycleState.currentStep === 'second_gh';
                  case 'gh3': return cycleState.currentStep === 'third_gh';
                  case 'gh4': return cycleState.currentStep === 'fourth_gh';
                  case 'gh5': return cycleState.currentStep === 'fifth_gh';
                  default: return false;
                }
              };

              let nextActionTitle = '';
              let nextActionDesc = '';
              let nextActionBadge = '';

              if (cycleState.currentStep === 'buy_pin') {
                nextActionTitle = 'Acquire & Use Registration PIN';
                nextActionDesc = 'Enter a valid ₹10 PIN key sent to you by the Admin. Note: There is no one to take payments before everyone; the Admin takes the initial payment.';
                nextActionBadge = '₹10 PIN Activation';
              } else if (cycleState.currentStep === 'first_ph') {
                nextActionTitle = 'Provide First Help (₹50)';
                nextActionDesc = 'Confirm and pledge your first peer contribution of ₹50. Note: After the PIN is activated, the PH admin will send the PH to whom it is to be sent.';
                nextActionBadge = '₹50 Provide Help';
              } else if (cycleState.currentStep === 'second_ph') {
                nextActionTitle = 'Provide Second Help (₹50)';
                nextActionDesc = 'Pledge your second peer contribution of ₹50. Note: After the PIN is activated, the PH admin will send the PH to whom it is to be sent.';
                nextActionBadge = '₹50 Provide Help';
              } else if (cycleState.currentStep === 'first_gh') {
                nextActionTitle = 'Claim First Payout (₹50)';
                nextActionDesc = 'Receive ₹50 from the mutual aid network. Click the Receive button to withdraw it to your wallet.';
                nextActionBadge = '₹50 Payout';
              } else if (cycleState.currentStep === 'second_gh') {
                nextActionTitle = 'Claim Second Payout (₹50)';
                nextActionDesc = 'Receive another ₹50 payout from the mutual aid pool. Click the Receive button to claim your second reward.';
                nextActionBadge = '₹50 Payout';
              } else if (cycleState.currentStep === 'third_gh') {
                nextActionTitle = 'Claim Third Payout (₹25)';
                nextActionDesc = 'Receive a ₹25 payout. Click the Receive button to claim your third reward from the network.';
                nextActionBadge = '₹25 Payout';
              } else if (cycleState.currentStep === 'fourth_gh') {
                nextActionTitle = 'Claim Fourth Payout (₹25)';
                nextActionDesc = 'Receive another ₹25 payout. Click the Receive button to withdraw to your wallet.';
                nextActionBadge = '₹25 Payout';
              } else if (cycleState.currentStep === 'fifth_gh') {
                nextActionTitle = 'Claim Fifth & Final Payout (₹25)';
                nextActionDesc = 'Withdraw the final ₹25 to successfully complete your current cycle. Total profit made: ₹75!';
                nextActionBadge = '₹25 Final Payout';
              } else if (cycleState.currentStep === 'completed') {
                nextActionTitle = 'Start a New Cycle';
                nextActionDesc = 'Congratulations! You have completed all 8 active stages of the ₹100 Help Cycle. Restart the cycle with a new ₹10 PIN to repeat the process and continue earning!';
                nextActionBadge = 'Cycle Completed!';
              }

              const stepsList = [
                { key: 'pin', label: 'Activation PIN', num: 1, type: 'Activation', amt: '₹10', id: 'S1' },
                { key: 'ph1', label: 'PH Link 1', num: 2, type: 'Provide', amt: '₹50', id: 'S2' },
                { key: 'ph2', label: 'PH Link 2', num: 3, type: 'Provide', amt: '₹50', id: 'S3' },
                { key: 'gh1', label: 'GH Link 1', num: 4, type: 'Receive', amt: '₹50', id: 'S4' },
                { key: 'gh2', label: 'GH Link 2', num: 5, type: 'Receive', amt: '₹50', id: 'S5' },
                { key: 'gh3', label: 'GH Link 3', num: 6, type: 'Receive', amt: '₹25', id: 'S6' },
                { key: 'gh4', label: 'GH Link 4', num: 7, type: 'Receive', amt: '₹25', id: 'S7' },
                { key: 'gh5', label: 'GH Link 5', num: 8, type: 'Receive', amt: '₹25', id: 'S8' },
              ];

              const completedCount = stepsList.filter(s => isCompleted(s.key)).length;

              return (
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 mb-8 text-white shadow-xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-emerald-500/10 to-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
                  
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="bg-emerald-900/50 text-emerald-400 border border-emerald-800/80 text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full tracking-wider animate-pulse">
                          8-Step Interactive Flow
                        </span>
                        <span className="text-slate-500 text-xs font-semibold font-mono">Cycle #{cycleState.cycleCount}</span>
                      </div>
                      <h2 className="text-xl font-extrabold text-white mt-1 flex items-center gap-2">
                        <Activity className="w-5 h-5 text-emerald-400" />
                        Help Cycle Progress Timeline
                      </h2>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Completed Stages</div>
                        <div className="text-lg font-black text-emerald-400 font-mono">
                          {completedCount} / 8
                        </div>
                      </div>
                      <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center font-mono font-black text-lg text-emerald-400 shadow-inner">
                        {Math.round((completedCount / 8) * 100)}%
                      </div>
                    </div>
                  </div>

                  {/* Visually stunning multi-segment progress bar */}
                  <div className="mb-8 bg-slate-950/85 border border-slate-800/80 rounded-2xl p-4.5 shadow-inner relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />
                    
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping" />
                        Live Cycle Tracking Status
                      </span>
                      <span className="text-[11px] font-extrabold font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-full">
                        {Math.round((completedCount / 8) * 100)}% Complete
                      </span>
                    </div>

                    {/* Progress Track and Fill */}
                    <div className="relative h-3 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800/60 shadow-inner flex items-center mb-1">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(completedCount / 8) * 100}%` }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                        className="h-full bg-gradient-to-r from-indigo-500 via-teal-500 to-emerald-500 relative rounded-full"
                      />
                    </div>

                    {/* Step Dots Overlay */}
                    <div className="flex justify-between items-center px-1 relative mt-4">
                      {/* Visual connecting trace behind */}
                      <div className="absolute left-2 right-2 top-3 h-0.5 bg-slate-800/70 -translate-y-1/2 z-0 pointer-events-none" />
                      
                      {stepsList.map((step) => {
                        const completed = isCompleted(step.key);
                        const active = isActive(step.key);
                        return (
                          <div key={step.key} className="flex flex-col items-center relative z-10 group">
                            <motion.div 
                              initial={{ scale: 0.8 }}
                              animate={{ 
                                scale: active ? 1.25 : 1,
                                boxShadow: active ? "0 0 12px rgba(99, 102, 241, 0.6)" : "none"
                              }}
                              className={`w-6 h-6 rounded-full border-2 flex items-center justify-center font-mono text-[9px] font-black transition-all duration-300 ${
                                active 
                                  ? 'bg-indigo-500 border-indigo-400 text-white' 
                                  : completed 
                                    ? 'bg-emerald-500 border-emerald-400 text-white' 
                                    : 'bg-slate-900 border-slate-700 text-slate-500'
                              }`}
                            >
                              {completed ? '✓' : step.num}
                            </motion.div>

                            <span className={`text-[10px] mt-2 font-black font-mono tracking-tight transition-colors duration-300 ${
                              active ? 'text-indigo-400 animate-pulse' : completed ? 'text-emerald-400' : 'text-slate-400'
                            }`}>
                              {step.id}
                            </span>
                            <span className="hidden sm:inline text-[8px] text-slate-500 mt-0.5 font-semibold">
                              {step.amt}
                            </span>
                            
                            {/* Desktop hover tooltips for step titles */}
                            <span className="text-[9px] mt-1.5 font-bold whitespace-nowrap absolute top-full transition-opacity opacity-0 group-hover:opacity-100 pointer-events-none bg-slate-950 border border-slate-800 text-slate-200 px-2 py-1 rounded shadow-xl z-20 translate-y-1.5">
                              Step {step.num}: {step.id} {step.label} {step.amt ? `(${step.amt})` : ''}
                              <span className="block text-[8px] font-medium text-slate-400 mt-0.5">
                                {active ? '⚡ Currently Active' : completed ? '✅ Stage Completed' : '🔒 Locked / Next Stage'}
                              </span>
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* The Timeline Steps Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-3 mb-6">
                    {stepsList.map((step) => {
                      const completed = isCompleted(step.key);
                      const active = isActive(step.key);
                      return (
                        <div 
                          key={step.key} 
                          className={`relative rounded-xl p-3 border transition-all duration-300 flex flex-col justify-between ${
                            active 
                              ? 'bg-gradient-to-b from-indigo-950/80 to-slate-900 border-indigo-500 shadow-lg shadow-indigo-500/10 ring-1 ring-indigo-500/30' 
                              : completed 
                                ? 'bg-slate-900 border-emerald-800/60 opacity-90' 
                                : 'bg-slate-950/40 border-slate-900 text-slate-500 opacity-60'
                          }`}
                        >
                          <div>
                            {/* Step Num & Type */}
                            <div className="flex items-center justify-between mb-2">
                              <span className={`text-[9px] font-bold font-mono px-1.5 py-0.5 rounded ${
                                active 
                                  ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' 
                                  : completed 
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                                    : 'bg-slate-900 text-slate-500'
                              }`}>
                                {step.type}
                              </span>
                              <span className={`text-[10px] font-black font-mono ${
                                active ? 'text-indigo-400 animate-pulse' : completed ? 'text-emerald-400' : 'text-slate-600'
                              }`}>
                                #{step.num}
                              </span>
                            </div>

                            {/* Title */}
                            <h4 className={`text-xs font-black leading-tight ${
                              active ? 'text-indigo-300' : completed ? 'text-white' : 'text-slate-500'
                            }`}>
                              {step.label}
                            </h4>
                          </div>

                          {/* Status indicator or amount */}
                          <div className="mt-4 pt-1.5 border-t border-slate-800/40 flex items-center justify-between">
                            <span className="text-[10px] font-extrabold font-mono text-slate-300">
                              {step.amt || 'System'}
                            </span>
                            
                            <div className="flex items-center justify-end">
                              {completed ? (
                                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                              ) : active ? (
                                <div className="relative flex h-2 w-2">
                                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                                  <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                                </div>
                              ) : (
                                <div className="w-1.5 h-1.5 rounded-full bg-slate-700" />
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Required Next Action Block */}
                  <div className="bg-gradient-to-r from-slate-950 to-slate-900 border border-slate-800/80 p-4 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div className={`p-2.5 rounded-xl shrink-0 border ${
                        cycleState.currentStep === 'completed' 
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                          : 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20 animate-pulse'
                      }`}>
                        <AlertCircle className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[9px] uppercase font-bold tracking-wider text-slate-400">Next Required Action</span>
                          <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                            cycleState.currentStep === 'completed' 
                              ? 'bg-emerald-500/20 text-emerald-300' 
                              : 'bg-indigo-500/25 text-indigo-300'
                          }`}>
                            {nextActionBadge}
                          </span>
                        </div>
                        <h3 className="font-extrabold text-sm text-white mt-1">
                          {nextActionTitle}
                        </h3>
                        <p className="text-slate-400 text-xs mt-0.5 leading-relaxed max-w-3xl">
                          {nextActionDesc}
                        </p>
                      </div>
                    </div>
                    
                    {cycleState.currentStep !== 'completed' && (
                      <div className="shrink-0 flex items-center">
                        <span className="text-[10px] bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 font-bold px-3 py-1.5 rounded-lg transition-all flex items-center gap-1">
                          Scroll to Step {cycleState.currentStep === 'buy_pin' ? '1' : (
                            cycleState.currentStep === 'first_ph' ? '2' :
                            cycleState.currentStep === 'second_ph' ? '3' :
                            cycleState.currentStep === 'first_gh' ? '4' :
                            cycleState.currentStep === 'second_gh' ? '5' :
                            cycleState.currentStep === 'third_gh' ? '6' :
                            cycleState.currentStep === 'fourth_gh' ? '7' : '8'
                          )} below
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })()}

            {/* Main Interactive Stage Panel */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden mb-8 grid md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-slate-100">
              
              {/* Left Column: Interactive Steps Timeline */}
              <div className="p-6 md:col-span-2 space-y-4">
                <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
                  <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                    <Activity className="w-4 h-4 text-emerald-600" />
                    Interactive Step-by-Step Ledger (Cycle #{cycleState.cycleCount})
                  </h3>
                  <span className="text-xs bg-slate-100 text-slate-600 font-mono font-extrabold px-2.5 py-0.5 rounded-full">
                    Step {cycleState.currentStep === 'completed' ? 'Completed' : (
                      cycleState.currentStep === 'buy_pin' ? '1' :
                      cycleState.currentStep === 'first_ph' ? '2' :
                      cycleState.currentStep === 'second_ph' ? '3' :
                      cycleState.currentStep === 'first_gh' ? '4' :
                      cycleState.currentStep === 'second_gh' ? '5' :
                      cycleState.currentStep === 'third_gh' ? '6' :
                      cycleState.currentStep === 'fourth_gh' ? '7' : '8'
                    )} of 8
                  </span>
                </div>

                {/* Plan View Mode Filter Switcher */}
                <div className="flex bg-slate-100 p-1.5 rounded-2xl border border-slate-200/50 gap-1.5 mb-5 shadow-inner">
                  <button
                    onClick={() => setPlanViewMode('all')}
                    className={`flex-1 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer text-center ${
                      planViewMode === 'all'
                        ? 'bg-white text-slate-900 shadow-md'
                        : 'text-slate-500 hover:text-slate-800 hover:bg-white/40'
                    }`}
                  >
                    🌐 All Stages
                  </button>
                  <button
                    onClick={() => setPlanViewMode('ph')}
                    className={`flex-1 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer text-center ${
                      planViewMode === 'ph'
                        ? 'bg-emerald-600 text-white shadow-md'
                        : 'text-emerald-600/70 hover:text-emerald-700 hover:bg-emerald-50/40'
                    }`}
                  >
                    🤝 Provide Help Only
                  </button>
                  <button
                    onClick={() => setPlanViewMode('gh')}
                    className={`flex-1 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer text-center ${
                      planViewMode === 'gh'
                        ? 'bg-gradient-to-r from-[#0D6EFD] to-[#00BFFF] text-white shadow-md font-extrabold shadow-blue-500/10'
                        : 'text-blue-500 hover:text-blue-600 hover:bg-blue-50/40'
                    }`}
                  >
                    💰 Get Help Only
                  </button>
                </div>

                <div className="space-y-4 relative">
                  
                  {/* Step 1: Pin 10/Rs Registration Pin */}
                  {(planViewMode === 'all' || planViewMode === 'ph') && (
                    <div className={`p-4 rounded-2xl border transition-all ${
                      cycleState.currentStep === 'buy_pin' 
                        ? 'border-indigo-400 bg-indigo-50/25 ring-2 ring-indigo-400/20' 
                        : cycleState.pinPurchased 
                          ? 'border-emerald-200 bg-emerald-50/10 opacity-70' 
                          : 'border-slate-100 bg-slate-50/50 opacity-40'
                    }`}>
                      <div className="flex justify-between items-start">
                        <div className="flex items-start gap-3">
                          <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black ${
                            cycleState.pinPurchased 
                              ? 'bg-emerald-600 text-white' 
                              : cycleState.currentStep === 'buy_pin'
                                ? 'bg-indigo-600 text-white animate-pulse'
                                : 'bg-slate-200 text-slate-500'
                          }`}>
                            {cycleState.pinPurchased ? '✓' : '1'}
                          </span>
                          <div>
                            <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
                              Registration PIN (Rs 10/-)
                              {cycleState.currentStep === 'buy_pin' && <span className="bg-indigo-100 text-indigo-800 text-[9px] px-1.5 py-0.5 rounded-md font-extrabold uppercase tracking-wide animate-pulse">Required</span>}
                            </h4>
                            <p className="text-slate-500 text-xs mt-1">
                              Before providing help, you must obtain and activate a ₹10 registration PIN key code sent by the Administrator. Note: There is no one to take payments before everyone; the Admin takes the initial payment.
                            </p>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="text-sm font-extrabold font-mono text-slate-900">₹10</span>
                        </div>
                      </div>
                      {cycleState.currentStep === 'buy_pin' && (() => {
                        const pinContrib = contributions.find(c => c.userId === currentUser.id && c.amount === 10 && c.remarks?.includes(`Cycle #${cycleState.cycleCount}`));
                        
                        if (cycleState.pinPurchased || (pinContrib && pinContrib.status === 'approved')) {
                          return (
                            <div className="mt-4 bg-emerald-50 border border-emerald-200 p-3.5 rounded-xl space-y-1.5">
                              <div className="flex items-center gap-2 text-emerald-900 font-extrabold text-xs">
                                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                                <span>₹10 PIN Verified & Activated — Listed in Giver Queue for ₹50 PH</span>
                              </div>
                              <p className="text-emerald-700 text-[11px] leading-relaxed">
                                आपका ₹10 PIN कन्फर्म हो चुका है। आपकी आईडी ₹50 PH देने के लिए Giver Queue (गिवर लिस्ट) में आ चुकी है। Step 2 (₹50 First PH) खुला है।
                              </p>
                            </div>
                          );
                        }

                        return (
                          <div id="active-payment-link-box" className="mt-4 bg-slate-900 border-2 border-indigo-500/60 p-4 rounded-2xl text-white space-y-4 shadow-xl shadow-indigo-900/20">
                            {/* Header */}
                            <div className="flex justify-between items-center pb-2.5 border-b border-indigo-500/30">
                              <div className="flex items-center gap-2">
                                <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-ping" />
                                <h5 className="font-extrabold text-xs text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                                  🔑 STEP 1: ₹10 PIN PAYMENT LINK BOX (एडमिन पेमेंट लिंक)
                                </h5>
                              </div>
                              <span className="bg-indigo-500/20 text-indigo-300 font-mono text-[11px] font-extrabold px-2.5 py-0.5 rounded-full border border-indigo-500/30">
                                Amount: ₹10
                              </span>
                            </div>

                            {/* Payment Details & QR Code */}
                            <div className="flex flex-col sm:flex-row gap-3.5 bg-black/50 p-3.5 rounded-xl border border-white/10 items-center">
                              <div className="shrink-0 bg-white p-1.5 rounded-xl shadow-md">
                                <img
                                  src={`https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent('upi://pay?pa=' + (systemSettings.systemWalletAddress || 'help100admin@sbin') + '&pn=Help100Admin&am=10&cu=INR&tn=PIN10_ACTIVATION')}`}
                                  alt="Pay ₹10 Admin PIN"
                                  className="w-24 h-24"
                                  referrerPolicy="no-referrer"
                                />
                              </div>
                              <div className="flex-1 space-y-1.5 text-xs text-slate-200 w-full">
                                <div className="flex justify-between items-center bg-white/5 p-2 rounded-lg border border-white/10">
                                  <span className="text-slate-400 font-bold">Admin UPI ID:</span>
                                  <div className="flex items-center gap-2 font-mono font-bold text-emerald-400">
                                    <span className="select-all text-xs">{systemSettings.systemWalletAddress || 'help100admin@sbin'}</span>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        navigator.clipboard.writeText(systemSettings.systemWalletAddress || 'help100admin@sbin');
                                        alert('UPI ID Copied!');
                                      }}
                                      className="px-2 py-0.5 bg-indigo-600 hover:bg-indigo-700 text-white text-[9px] rounded-md font-sans font-extrabold cursor-pointer transition-colors"
                                    >
                                      Copy
                                    </button>
                                  </div>
                                </div>
                                <div className="flex justify-between text-[11px] px-1">
                                  <span className="text-slate-400">Recipient Name:</span>
                                  <span className="font-bold text-white">{systemSettings.adminHolderName || 'Platform Admin'}</span>
                                </div>
                                <div className="flex justify-between text-[11px] px-1">
                                  <span className="text-slate-400">Bank Details:</span>
                                  <span className="font-mono text-slate-300">{systemSettings.adminBankName || 'SBI'} ({systemSettings.adminAccountNumber || 'XXXXXXXX1234'} / {systemSettings.adminIfscCode || 'SBIN0001234'})</span>
                                </div>
                                <div className="pt-1">
                                  <a
                                    href={`upi://pay?pa=${systemSettings.systemWalletAddress || 'help100admin@sbin'}&pn=Help100Admin&am=10&cu=INR&tn=PIN10_ACTIVATION`}
                                    className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 active:scale-95 text-white text-xs font-black py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer text-center"
                                  >
                                    ⚡ Pay ₹10 Directly via UPI App
                                  </a>
                                </div>
                              </div>
                            </div>

                            {/* Upload Payment Proof Box */}
                            <div className="bg-black/30 p-3 rounded-xl border border-white/10 space-y-2">
                              <span className="block text-[10px] text-indigo-300 font-bold uppercase tracking-wider">
                                Upload Payment Screenshot / Ref ID to Submit Proof & Activate:
                              </span>
                              <div className="flex flex-col sm:flex-row gap-2">
                                <input
                                  type="file"
                                  id="pin-slip-file"
                                  className="hidden"
                                  onChange={(e) => setPinProofFile(e.target.files?.[0]?.name || '')}
                                />
                                <button
                                  type="button"
                                  onClick={() => document.getElementById('pin-slip-file')?.click()}
                                  className="flex-1 bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-bold py-2 px-3 rounded-xl text-white text-left truncate cursor-pointer"
                                >
                                  {pinProofFile ? `📄 ${pinProofFile}` : '📁 Upload Payment Slip'}
                                </button>
                                <input
                                  type="text"
                                  placeholder="Ref ID / UTR (Optional)"
                                  value={pinTxId}
                                  onChange={(e) => setPinTxId(e.target.value)}
                                  className="flex-1 bg-white/10 border border-white/20 rounded-xl px-3 py-2 text-xs text-white font-mono placeholder:text-slate-500 focus:outline-none focus:border-indigo-400"
                                />
                                <button
                                  type="button"
                                  onClick={() => {
                                    const generatedCode = 'PIN-' + Math.random().toString(36).substring(2, 8).toUpperCase();
                                    onUsePin(generatedCode, currentUser.id, currentUser.name);
                                    setEnteredPin(generatedCode);
                                    setTimeout(() => {
                                      handleCycleAction('buy_pin');
                                      alert('✓ ₹10 Payment Proof Submitted & Activated Successfully! Welcome to Step 2 (₹40 PH).');
                                    }, 300);
                                  }}
                                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs px-4 py-2 rounded-xl transition-all shadow cursor-pointer flex items-center justify-center gap-1 shrink-0"
                                >
                                  <CheckCircle className="w-3.5 h-3.5" />
                                  Submit Proof & Activate PIN
                                </button>
                              </div>
                            </div>

                            {/* Pre-issued Key Auto-Fill or PIN Input Section */}
                            <div className="pt-2 border-t border-white/10 space-y-2.5">
                              {(() => {
                                const directPins = issuedPins.filter(p => 
                                  !p.isUsed && (
                                    p.userId === currentUser.id || 
                                    (currentUser.referralCode && p.userId === currentUser.referralCode) ||
                                    (currentUser.directId && p.userId === currentUser.directId) ||
                                    (currentUser.email && p.userId?.toLowerCase() === currentUser.email.toLowerCase()) ||
                                    (currentUser.phone && p.userId === currentUser.phone) ||
                                    (p.userName && currentUser.name && p.userName.trim().toLowerCase() === currentUser.name.trim().toLowerCase())
                                  )
                                );
                                const systemPins = issuedPins.filter(p => !p.isUsed && (p.userId === 'system' || p.userId === 'unassigned'));
                                const myUnusedPins = directPins.length > 0 ? directPins : systemPins;
                                const isDirect = directPins.length > 0;

                                return myUnusedPins.length > 0 ? (
                                  <div>
                                    <span className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1.5">
                                      {isDirect ? '✓ Your Direct Admin PIN Keys (Click to auto-fill):' : '⚡ Available System PIN Keys (Click to auto-fill):'}
                                    </span>
                                    <div className="flex flex-wrap gap-1.5">
                                      {myUnusedPins.map(p => (
                                        <button
                                          key={p.id}
                                          onClick={() => setEnteredPin(p.pinCode)}
                                          className={`px-2.5 py-1 rounded-lg text-[10px] font-bold font-mono border transition-colors flex items-center gap-1 cursor-pointer ${
                                            isDirect ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40 hover:bg-emerald-900' : 'bg-indigo-950 text-indigo-300 border-indigo-500/40 hover:bg-indigo-900'
                                          }`}
                                        >
                                          <Key className="w-3 h-3" />
                                          {p.pinCode}
                                        </button>
                                      ))}
                                    </div>
                                  </div>
                                ) : (
                                  <div className="text-[11px] text-amber-200 bg-amber-950/40 p-2.5 rounded-xl flex items-center justify-between gap-2 border border-amber-500/30">
                                    <div className="flex items-center gap-2">
                                      <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                                      <span>Click to generate a fresh ₹10 PIN Key instantly:</span>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => setEnteredPin('PIN-' + Math.random().toString(36).substring(2, 8).toUpperCase())}
                                      className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-[10px] font-bold uppercase tracking-wider shrink-0 transition-colors shadow cursor-pointer"
                                    >
                                      ⚡ Generate PIN Key
                                    </button>
                                  </div>
                                );
                              })()}

                              <div className="flex flex-col sm:flex-row gap-2 pt-1">
                                <input
                                  type="text"
                                  placeholder="Enter ₹10 PIN code (e.g. PIN-A32B9C)"
                                  value={enteredPin}
                                  onChange={(e) => setEnteredPin(e.target.value.toUpperCase())}
                                  className="flex-grow bg-black/40 border border-slate-700 rounded-xl px-3.5 py-2 text-xs font-mono font-bold text-white placeholder-slate-500 uppercase focus:outline-none focus:border-indigo-500 transition-colors"
                                />
                                <button
                                  onClick={() => handleCycleAction('buy_pin')}
                                  className="bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white text-xs font-black px-4 py-2 rounded-xl transition-all shadow cursor-pointer flex items-center justify-center gap-1.5"
                                >
                                  <CheckCircle className="w-3.5 h-3.5" />
                                  Use PIN Code & Activate
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  )}

                   {/* Step 2: First PH 40/Rs */}
                   {(planViewMode === 'all' || planViewMode === 'ph') && (
                     <div className={`p-4 rounded-2xl border transition-all ${
                       cycleState.currentStep === 'first_ph' 
                         ? 'border-fuchsia-400 bg-gradient-to-br from-purple-900 via-fuchsia-950 to-slate-950 text-white shadow-xl shadow-purple-500/20 ring-2 ring-fuchsia-400/30' 
                         : cycleState.firstPhSubmitted 
                           ? 'border-emerald-200 bg-emerald-50/10 opacity-70' 
                           : 'border-slate-100 bg-slate-50/50 opacity-40'
                     }`}>
                    {/* Header bar styled like PH LINK reference image */}
                    {cycleState.currentStep === 'first_ph' && (
                      <div className="flex justify-between items-center bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 p-2.5 rounded-xl border border-fuchsia-300/40 text-white shadow-md shadow-purple-500/20 mb-3">
                        <div className="flex items-center gap-2">
                          <Activity className="w-5 h-5 text-lime-300 animate-pulse shrink-0" />
                          <span className="font-extrabold text-xs uppercase tracking-wider text-lime-300">PH LINK 1 (Rs 50/-)</span>
                        </div>
                        <UserIcon className="w-5 h-5 text-white/80 shrink-0" />
                      </div>
                    )}

                    <div className="flex justify-between items-start">
                      <div className="flex items-start gap-2.5">
                        <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black ${
                          cycleState.firstPhSubmitted 
                            ? 'bg-emerald-600 text-white' 
                            : cycleState.currentStep === 'first_ph'
                              ? 'bg-gradient-to-r from-purple-500 to-fuchsia-500 text-white animate-pulse'
                              : 'bg-slate-200 text-slate-500'
                        }`}>
                          {cycleState.firstPhSubmitted ? '✓' : '2'}
                        </span>
                        <div>
                          <h4 className={`font-extrabold text-xs flex items-center gap-1 ${
                            cycleState.currentStep === 'first_ph' ? 'text-white' : 'text-slate-900'
                          }`}>
                            First PH Link (Rs 50/-)
                            {cycleState.currentStep === 'first_ph' && (
                              <span className="bg-fuchsia-600 text-white text-[8px] px-1.5 py-0.5 rounded font-black uppercase tracking-wider animate-pulse">
                                Active PH Link Stage
                              </span>
                            )}
                          </h4>
                          <p className={`text-[10px] mt-0.5 ${
                            cycleState.currentStep === 'first_ph' ? 'text-indigo-200/80' : 'text-slate-400'
                          }`}>
                            PIN Active (₹10 Admin). 1st PH link is ₹50/- paid directly User-to-User to a Taker member. Confirmed directly without admin approval.
                          </p>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className={`text-xs font-black font-mono ${
                          cycleState.currentStep === 'first_ph' ? 'text-pink-300' : 'text-slate-900'
                        }`}>₹50</span>
                      </div>
                    </div>

                    {cycleState.currentStep === 'first_ph' && (
                      <div className="mt-3 flex flex-col gap-3">
                        {/* Pending verification message if slip uploaded */}
                        {((ph1Admin && ph1Admin.status === 'pending_verification') ||
                          (ph1User && ph1User.status === 'pending_verification') ||
                          (firstPhContrib && firstPhContrib.status === 'pending_verification')) && (
                          <div className="bg-indigo-500/10 border border-indigo-500/30 p-3.5 rounded-2xl text-indigo-200 space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-pulse" />
                              <h5 className="font-extrabold text-xs text-indigo-300">⏳ Payment Slip Uploaded — Awaiting Verification</h5>
                            </div>
                            <p className="text-[10px] text-slate-300 leading-relaxed">
                              Your payment slip has been uploaded successfully! Sent to recipient/admin for verification. Once accepted, your payment will be confirmed.
                            </p>
                          </div>
                        )}

                        {/* Active link box when admin has dispatched link */}
                        {((ph1Admin && ph1Admin.status === 'pending_proof') || 
                          (ph1User && ph1User.status === 'pending_proof') || 
                          (firstPhContrib && firstPhContrib.status === 'pending_proof')) && (
                          <div className="space-y-3">
                            {/* 1. Admin Link Box */}
                            {ph1Admin && ph1Admin.status === 'pending_proof' && (
                              <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-950 border-2 border-pink-500/40 p-2 rounded-lg flex flex-col gap-1.5 text-white shadow-lg shadow-pink-500/5 relative overflow-hidden">
                                <div className="absolute -right-6 -top-6 w-16 h-16 bg-pink-500/10 rounded-full blur-2xl" />
                                <div className="flex justify-between items-center pb-1 border-b border-pink-500/20">
                                  <span className="text-[9px] font-black text-pink-400 uppercase flex items-center gap-1">
                                    👑 ADMIN LINK (₹20)
                                  </span>
                                  <span className="text-[7px] px-1.5 py-0.5 rounded-full font-black uppercase tracking-wider bg-pink-500/20 text-pink-300 animate-pulse">
                                    Pay
                                  </span>
                                </div>

                                {/* Countdown timer for Admin Link specifically */}
                                <div className="bg-black/40 border border-pink-500/10 px-1.5 py-0.5 rounded flex items-center justify-between shadow-inner">
                                  <div className="flex items-center gap-1">
                                    <Clock className="w-2.5 h-2.5 text-pink-400 animate-spin" style={{ animationDuration: '4s' }} />
                                    <span className="text-[7px] font-black uppercase tracking-widest text-slate-400">Timer</span>
                                  </div>
                                  <div className="font-mono text-[8px] font-black text-pink-400 animate-pulse tracking-wider">
                                    {formatTimer(ph1Timer)}
                                  </div>
                                </div>

                                {/* Admin Recipient Details & QR Code side-by-side */}
                                <div className="flex gap-1.5 items-center bg-black/35 p-1 rounded border border-white/5">
                                  <div className="shrink-0 bg-white p-0.5 rounded">
                                    <img 
                                      src={systemSettings.systemQRUrl || `https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent('upi://pay?pa=' + (systemSettings.systemWalletAddress || 'admin@okaxis') + '&pn=' + encodeURIComponent(systemSettings.adminHolderName || 'Platform Admin') + '&am=20')}`} 
                                      alt="Pay Admin" 
                                      className="w-10 h-10"
                                      referrerPolicy="no-referrer"
                                    />
                                  </div>
                                  <div className="flex-1 min-w-0 space-y-0.5 text-[7px] text-slate-200 leading-tight">
                                    <div className="flex justify-between gap-1">
                                      <span className="text-slate-400">UPI:</span>
                                      <span className="font-mono font-bold text-white select-all truncate max-w-[80px]" title={systemSettings.systemWalletAddress || 'admin@okaxis'}>
                                        {systemSettings.systemWalletAddress || 'admin@okaxis'}
                                      </span>
                                    </div>
                                    <div className="flex justify-between gap-1">
                                      <span className="text-slate-400">Name/Bank:</span>
                                      <span className="font-bold text-white truncate max-w-[80px]">
                                        {systemSettings.adminHolderName || 'Admin'} ({systemSettings.adminBankName || 'SBI'})
                                      </span>
                                    </div>
                                    <div className="flex justify-between gap-1">
                                      <span className="text-slate-400">Acc/IFSC:</span>
                                      <span className="font-mono text-white truncate max-w-[80px]">
                                        {systemSettings.adminAccountNumber || 'XXXXXXXX1234'} / {systemSettings.adminIfscCode || 'SBIN0001234'}
                                      </span>
                                    </div>
                                  </div>
                                </div>

                                {/* Upload Section */}
                                <div className="pt-0.5 border-t border-white/5 space-y-1">
                                  <div className="flex gap-1">
                                    <input 
                                      type="file" 
                                      id="ph1-admin-slip-upload" 
                                      className="hidden" 
                                      onChange={(e) => setPh1AdminProofFile(e.target.files?.[0]?.name || '')} 
                                    />
                                    <button 
                                      type="button" 
                                      onClick={() => document.getElementById('ph1-admin-slip-upload')?.click()}
                                      className="flex-1 bg-black/30 hover:bg-black/50 border border-white/10 text-[6.5px] font-bold py-0.5 px-1 rounded truncate text-white text-left"
                                    >
                                      {ph1AdminProofFile ? `📄 ${ph1AdminProofFile}` : '📁 Upload Slip'}
                                    </button>
                                    <button 
                                      type="button" 
                                      onClick={() => {
                                        if (!ph1AdminProofFile) { alert('Please select your payment slip first!'); return; }
                                        onUpdateContributionProof?.(ph1Admin.id, ph1AdminProofFile, ph1AdminTxId ? `https://help100.com/secure-gateway/ph/${ph1AdminTxId}` : undefined);
                                        if (onUpdateContribution) {
                                          onUpdateContribution(ph1Admin.id, 'pending_verification', 'Admin payment slip uploaded, awaiting verification.');
                                        }
                                        alert('Admin payment slip submitted successfully! Awaiting verification.');
                                      }}
                                      className="bg-pink-600 hover:bg-pink-700 active:scale-95 text-white text-[7px] font-black px-1.5 py-0.5 rounded transition-all"
                                    >
                                      Submit
                                    </button>
                                  </div>
                                  <input
                                    type="text"
                                    placeholder="Ref ID (Optional)"
                                    value={ph1AdminTxId}
                                    onChange={(e) => setPh1AdminTxId(e.target.value)}
                                    className="w-full bg-black/30 border border-white/10 rounded px-1 py-0.5 text-[6.5px] text-white font-mono placeholder:text-slate-600 focus:outline-none"
                                  />
                                </div>
                              </div>
                            )}

                            {/* 2. User Link Box */}
                            {ph1User && ph1User.status === 'pending_proof' && (() => {
                              const activeGhRequest = helpRequests.find(h => 
                                h.userId !== currentUser.id && 
                                (h.status === 'pending_review' || h.status === 'approved')
                              );
                              const ghUser = activeGhRequest ? users.find(u => u.id === activeGhRequest.userId) : null;
                              const sponsor = getSponsorOfUser(currentUser);
                              const firstPhRecipient = ghUser || (sponsor && sponsor.role !== 'admin' && sponsor.referralCode !== 'ADMIN100' ? sponsor : null) || users.find(u => u.role === 'admin') || {
                                    name: 'Platform Admin',
                                    upiId: 'help100admin@sbin',
                                    bankName: 'HDFC Bank',
                                    accountNumber: '5010043218765',
                                    ifscCode: 'HDFC0000120'
                                  };
                              const displayUpi = firstPhRecipient.upiId || 'sarah100@okaxis';
                              
                              return (
                                <div className="bg-gradient-to-br from-teal-950 via-slate-900 to-teal-950 border-2 border-emerald-500/40 p-2 rounded-lg flex flex-col gap-1.5 text-white shadow-lg shadow-emerald-500/5 relative overflow-hidden">
                                  <div className="absolute -right-6 -top-6 w-16 h-16 bg-emerald-500/10 rounded-full blur-2xl" />
                                  <div className="flex justify-between items-center pb-1 border-b border-emerald-500/20">
                                    <span className="text-[9px] font-black text-emerald-400 uppercase flex items-center gap-1">
                                      👥 USER LINK (₹50)
                                    </span>
                                    <span className="text-[7px] px-1.5 py-0.5 rounded-full font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 animate-pulse">
                                      Pay
                                    </span>
                                  </div>

                                  {/* Countdown timer for User Link specifically */}
                                  <div className="bg-black/40 border border-emerald-500/10 px-1.5 py-0.5 rounded flex items-center justify-between shadow-inner">
                                    <div className="flex items-center gap-1">
                                      <Clock className="w-2.5 h-2.5 text-emerald-400 animate-spin" style={{ animationDuration: '4s' }} />
                                      <span className="text-[7px] font-black uppercase tracking-widest text-slate-400">Timer</span>
                                    </div>
                                    <div className="font-mono text-[8px] font-black text-pink-400 animate-pulse tracking-wider">
                                      {formatTimer(ph1Timer)}
                                    </div>
                                  </div>

                                  {/* User Recipient Details & QR Code side-by-side */}
                                  <div className="flex gap-1.5 items-center bg-black/35 p-1 rounded border border-white/5">
                                    <div className="shrink-0 bg-white p-0.5 rounded">
                                      <img 
                                        src={`https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent('upi://pay?pa=' + displayUpi + '&pn=' + encodeURIComponent(firstPhRecipient.name) + '&am=40')}`} 
                                        alt="Pay User" 
                                        className="w-10 h-10"
                                        referrerPolicy="no-referrer"
                                      />
                                    </div>
                                    <div className="flex-1 min-w-0 space-y-0.5 text-[7px] text-slate-200 leading-tight">
                                      <div className="flex justify-between gap-1">
                                        <span className="text-slate-400">UPI:</span>
                                        <span className="font-mono font-bold text-white select-all truncate max-w-[80px]" title={displayUpi}>{displayUpi}</span>
                                      </div>
                                      <div className="flex justify-between gap-1">
                                        <span className="text-slate-400">Name/Bank:</span>
                                        <span className="font-bold text-white truncate max-w-[80px]">{firstPhRecipient.name} ({firstPhRecipient.bankName || "HDFC"})</span>
                                      </div>
                                      <div className="flex justify-between gap-1">
                                        <span className="text-slate-400">Acc/IFSC:</span>
                                        <span className="font-mono text-white truncate max-w-[80px]">
                                          ...{firstPhRecipient.accountNumber?.slice(-4) || "8765"} / {firstPhRecipient.ifscCode || "IFSC0001234"}
                                        </span>
                                      </div>
                                    </div>
                                  </div>

                                  {/* Upload Section */}
                                  <div className="pt-0.5 border-t border-white/5 space-y-1">
                                    <div className="flex gap-1">
                                      <input 
                                        type="file" 
                                        id="ph1-user-slip-upload" 
                                        className="hidden" 
                                        onChange={(e) => setPh1UserProofFile(e.target.files?.[0]?.name || '')} 
                                      />
                                      <button 
                                        type="button" 
                                        onClick={() => document.getElementById('ph1-user-slip-upload')?.click()}
                                        className="flex-1 bg-black/30 hover:bg-black/50 border border-white/10 text-[6.5px] font-bold py-0.5 px-1 rounded truncate text-white text-left"
                                      >
                                        {ph1UserProofFile ? `📄 ${ph1UserProofFile}` : '📁 Upload Slip'}
                                      </button>
                                      <button 
                                        type="button" 
                                        onClick={() => {
                                          if (!ph1UserProofFile) { alert('Please select your payment slip first!'); return; }
                                          onUpdateContributionProof?.(ph1User.id, ph1UserProofFile, ph1UserTxId ? `https://help100.com/secure-gateway/ph/${ph1UserTxId}` : undefined);
                                          if (onUpdateContribution) {
                                            onUpdateContribution(ph1User.id, 'pending_verification', 'Payment slip uploaded, awaiting recipient verification.');
                                          }
                                          alert('Success! ₹50 User-to-User payment slip submitted! Awaiting recipient verification.');
                                        }}
                                        className="bg-pink-600 hover:bg-pink-700 active:scale-95 text-white text-[7px] font-black px-1.5 py-0.5 rounded transition-all"
                                      >
                                        Submit
                                      </button>
                                    </div>
                                    <input
                                      type="text"
                                      placeholder="Ref ID (Optional)"
                                      value={ph1UserTxId}
                                      onChange={(e) => setPh1UserTxId(e.target.value)}
                                      className="w-full bg-black/30 border border-white/10 rounded px-1 py-0.5 text-[6.5px] text-white font-mono placeholder:text-slate-600 focus:outline-none"
                                    />
                                  </div>
                                </div>
                              );
                            })()}

                            {/* 3. Unified Direct Dispatched PH Link Box (Always visible during 1st PH step) */}
                            {cycleState.currentStep === 'first_ph' && !ph1Admin && !ph1User && (() => {
                              const recipient = getRecipientDetails('ph');
                              let displayUpi = recipient.upiId;
                              let recipientName = recipient.beneficiaryName;
                              if (firstPhContrib?.txLink && firstPhContrib.txLink.includes('pa=')) {
                                try {
                                  const urlParams = new URLSearchParams(firstPhContrib.txLink.split('?')[1] || '');
                                  if (urlParams.get('pa')) displayUpi = urlParams.get('pa')!;
                                  if (urlParams.get('pn')) recipientName = decodeURIComponent(urlParams.get('pn')!);
                                } catch (e) {
                                  // fallback
                                }
                              }

                              const payAmount = firstPhContrib?.amount || 50;

                              return (
                                <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-fuchsia-950 border-2 border-fuchsia-500/40 p-2.5 rounded-xl flex flex-col gap-2 text-white shadow-lg shadow-fuchsia-500/10 relative overflow-hidden">
                                  <div className="flex justify-between items-center pb-1 border-b border-fuchsia-500/20">
                                    <span className="text-[10px] font-black text-fuchsia-300 uppercase flex items-center gap-1">
                                      ⚡ DISPATCHED PH LINK (₹{payAmount})
                                    </span>
                                    <span className="text-[8px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider bg-fuchsia-500/20 text-fuchsia-300 animate-pulse border border-fuchsia-500/30">
                                      Pay Active
                                    </span>
                                  </div>

                                  {/* Countdown timer */}
                                  <div className="bg-black/40 border border-fuchsia-500/20 px-2 py-1 rounded-lg flex items-center justify-between shadow-inner">
                                    <div className="flex items-center gap-1.5">
                                      <Clock className="w-3 h-3 text-fuchsia-400 animate-spin" style={{ animationDuration: '4s' }} />
                                      <span className="text-[8px] font-black uppercase tracking-widest text-slate-300">Time Left</span>
                                    </div>
                                    <div className="font-mono text-xs font-black text-fuchsia-400 animate-pulse tracking-wider">
                                      {formatTimer(ph1Timer)}
                                    </div>
                                  </div>

                                  {/* Custom Dispatched Link Button if present */}
                                  {firstPhContrib?.txLink && !firstPhContrib.txLink.includes("help100.com") && !firstPhContrib.txLink.includes("pin-use") && (
                                    <div className="flex justify-center gap-2 my-1">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setActiveGateway({
                                            id: firstPhContrib.id,
                                            type: 'ph',
                                            amount: payAmount,
                                            stepKey: 'first_ph',
                                            txLink: firstPhContrib.txLink
                                          });
                                          setGatewayTimer(86400);
                                        }}
                                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-fuchsia-600 hover:bg-fuchsia-700 text-white rounded-lg text-[10px] font-black cursor-pointer transition-all shadow-md animate-pulse border border-fuchsia-300"
                                      >
                                        💳 Open Admin Gateway Link & QR (₹{payAmount}) ↗
                                      </button>
                                    </div>
                                  )}

                                  {/* Details & QR Code */}
                                  <div className="flex flex-col sm:flex-row gap-2.5 items-center bg-black/40 p-2 rounded-lg border border-white/10">
                                    <div className="shrink-0 bg-white p-1 rounded-lg shadow">
                                      <img 
                                        src={`https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent('upi://pay?pa=' + displayUpi + '&pn=' + encodeURIComponent(recipientName) + '&am=' + payAmount)}`} 
                                        alt="Pay QR" 
                                        className="w-16 h-16 sm:w-20 sm:h-20"
                                        referrerPolicy="no-referrer"
                                      />
                                    </div>
                                    <div className="flex-1 min-w-0 space-y-1 text-xs text-slate-200 w-full">
                                      <div className="flex justify-between items-center bg-white/5 p-1.5 rounded border border-white/5">
                                        <span className="text-slate-400 text-[10px]">UPI ID:</span>
                                        <div className="flex items-center gap-1 font-mono font-bold text-fuchsia-300 text-[10px]">
                                          <span className="select-all truncate max-w-[120px]">{displayUpi}</span>
                                          <button
                                            type="button"
                                            onClick={() => {
                                              navigator.clipboard.writeText(displayUpi);
                                              alert('UPI ID Copied!');
                                            }}
                                            className="px-1.5 py-0.5 bg-fuchsia-600 hover:bg-fuchsia-700 text-white text-[8px] rounded font-bold transition-colors cursor-pointer shrink-0"
                                          >
                                            Copy
                                          </button>
                                        </div>
                                      </div>
                                      <div className="flex justify-between text-[10px] px-1">
                                        <span className="text-slate-400">Recipient Name:</span>
                                        <span className="font-bold text-white truncate">{recipientName}</span>
                                      </div>
                                      <div className="flex justify-between text-[10px] px-1">
                                        <span className="text-slate-400">Bank Details:</span>
                                        <span className="font-mono text-slate-300 text-[9px] truncate">{recipient.bankName} ({recipient.accountNumber})</span>
                                      </div>
                                      <div className="pt-0.5">
                                        <a
                                          href={`upi://pay?pa=${displayUpi}&pn=${encodeURIComponent(recipientName)}&am=${payAmount}&cu=INR&tn=HELP100_PH1`}
                                          className="w-full bg-gradient-to-r from-fuchsia-600 to-indigo-600 hover:from-fuchsia-700 hover:to-indigo-700 text-white text-[10px] font-black py-1.5 px-2 rounded-lg flex items-center justify-center gap-1 transition-all shadow text-center cursor-pointer"
                                        >
                                          ⚡ Pay ₹{payAmount} via UPI App
                                        </a>
                                      </div>
                                    </div>
                                  </div>

                                  {/* Upload Section */}
                                  <div className="pt-1.5 border-t border-white/10 space-y-1.5">
                                    <label className="block text-[9px] font-black uppercase tracking-wider text-fuchsia-300">
                                      📤 Upload Payment Slip / UTR Ref ID
                                    </label>
                                    <div className="flex flex-col sm:flex-row gap-1.5">
                                      <input 
                                        type="file" 
                                        id="ph1-direct-slip-upload" 
                                        className="hidden" 
                                        onChange={(e) => setPh1UserProofFile(e.target.files?.[0]?.name || '')} 
                                      />
                                      <button 
                                        type="button" 
                                        onClick={() => document.getElementById('ph1-direct-slip-upload')?.click()}
                                        className="flex-1 bg-black/40 hover:bg-black/60 border border-white/10 text-[9px] font-bold py-1 px-2 rounded-lg truncate text-white text-left cursor-pointer"
                                      >
                                        {ph1UserProofFile ? `📄 ${ph1UserProofFile}` : '📁 Upload Payment Slip'}
                                      </button>
                                      <input
                                        type="text"
                                        placeholder="UTR / Ref ID (Optional)"
                                        value={ph1UserTxId}
                                        onChange={(e) => setPh1UserTxId(e.target.value)}
                                        className="flex-1 bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-[9px] text-white font-mono placeholder:text-slate-500 focus:outline-none"
                                      />
                                      <button 
                                        type="button" 
                                        onClick={() => {
                                          if (!ph1UserProofFile) { alert('Please select your payment slip first!'); return; }
                                          const targetId = firstPhContrib?.id || `ph1-${currentUser.id}`;
                                          onUpdateContributionProof?.(targetId, ph1UserProofFile, ph1UserTxId ? `https://help100.com/secure-gateway/ph/${ph1UserTxId}` : undefined);
                                          if (onUpdateContribution) {
                                            onUpdateContribution(targetId, 'pending_verification', 'Payment slip uploaded, awaiting verification.');
                                          }
                                          alert(`Success! ₹${payAmount} payment slip submitted! Awaiting verification.`);
                                        }}
                                        className="bg-fuchsia-600 hover:bg-fuchsia-700 active:scale-95 text-white text-[9px] font-black px-3 py-1 rounded-lg transition-all shadow cursor-pointer shrink-0"
                                      >
                                        Submit Proof
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              );
                            })()}
                          </div>
                        )}

                        {/* Awaiting Admin Dispatch Notice when NO pre-dispatched link is active */}
                        {!(ph1Admin?.status === 'pending_proof' || ph1User?.status === 'pending_proof' || firstPhContrib?.status === 'pending_proof') &&
                         !(ph1Admin?.status === 'pending_verification' || ph1User?.status === 'pending_verification' || firstPhContrib?.status === 'pending_verification') && (
                          <div className="bg-slate-900/90 border border-indigo-500/30 p-4 rounded-2xl text-slate-200 space-y-2 mt-2 shadow-inner">
                            <div className="flex items-center gap-2 text-amber-400 font-extrabold text-xs">
                              <Clock className="w-4 h-4 animate-spin text-amber-400 shrink-0" style={{ animationDuration: '4s' }} />
                              <span>⏳ Awaiting Admin Link Dispatch (एडमिन द्वारा लिंक भेजे जाने की प्रतीक्षा करें)</span>
                            </div>
                            <p className="text-[11px] text-slate-300 leading-relaxed">
                              आपकी आईडी ₹50 PH के लिए Giver Queue में दर्ज हो चुकी है। जैसे ही एडमिन आपके लिए पेमेंट लिंक जारी (dispatch) करेंगे, यहाँ Payment Link Box सक्रिय हो जाएगा।
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                   </div>
                   )}

                  {/* Step 3: Second PH 50/Rs */}
                  {(planViewMode === 'all' || planViewMode === 'ph') && (
                    <div className={`p-4 rounded-2xl border transition-all ${
                      cycleState.currentStep === 'second_ph' 
                        ? 'border-fuchsia-400 bg-gradient-to-br from-purple-900 via-fuchsia-950 to-slate-950 text-white shadow-xl shadow-purple-500/20 ring-2 ring-fuchsia-400/30' 
                        : cycleState.secondPhSubmitted 
                          ? 'border-emerald-200 bg-emerald-50/10 opacity-70' 
                          : 'border-slate-100 bg-slate-50/50 opacity-40'
                    }`}>
                    {/* Header bar styled like PH LINK reference image */}
                    {cycleState.currentStep === 'second_ph' && (
                      <div className="flex justify-between items-center bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 p-2.5 rounded-xl border border-fuchsia-300/40 text-white shadow-md shadow-purple-500/20 mb-3">
                        <div className="flex items-center gap-2">
                          <Activity className="w-5 h-5 text-lime-300 animate-pulse shrink-0" />
                          <span className="font-extrabold text-xs uppercase tracking-wider text-lime-300">PH LINK 2 (Rs 50/-)</span>
                        </div>
                        <UserIcon className="w-5 h-5 text-white/80 shrink-0" />
                      </div>
                    )}

                    <div className="flex justify-between items-start">
                      <div className="flex items-start gap-2.5">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${
                          cycleState.secondPhSubmitted 
                            ? 'bg-emerald-600 text-white' 
                            : cycleState.currentStep === 'second_ph'
                              ? 'bg-gradient-to-r from-purple-500 to-fuchsia-500 text-white animate-pulse'
                              : 'bg-slate-200 text-slate-500'
                        }`}>
                          {cycleState.secondPhSubmitted ? '✓' : '3'}
                        </span>
                        <div>
                          <h4 className={`font-extrabold text-xs flex items-center gap-1 ${
                            cycleState.currentStep === 'second_ph' ? 'text-white' : 'text-slate-900'
                          }`}>
                            Second PH Link (Rs 50/-)
                            {cycleState.currentStep === 'second_ph' && (
                              <span className="bg-fuchsia-600 text-white text-[8px] px-1.5 py-0.5 rounded font-black uppercase tracking-wider animate-pulse">
                                Active PH Link Stage
                              </span>
                            )}
                          </h4>
                          <p className={`text-[10px] mt-0.5 ${
                            cycleState.currentStep === 'second_ph' ? 'text-indigo-200/80' : 'text-slate-400'
                          }`}>
                            Provide ₹50 helper pledge to proceed. Removed instantly upon verification.
                          </p>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className={`text-xs font-black font-mono ${
                          cycleState.currentStep === 'second_ph' ? 'text-pink-300' : 'text-slate-900'
                        }`}>₹50</span>
                      </div>
                    </div>

                    {/* Second PH automatically opens when First PH is confirmed */}

                    {cycleState.currentStep === 'second_ph' && (
                      <div className="mt-2.5 flex flex-col gap-2">
                        {/* Pending Verification View */}
                        {secondPhContrib && secondPhContrib.status === 'pending_verification' && (
                          <div className="bg-indigo-500/10 border border-indigo-500/30 p-3.5 rounded-2xl text-indigo-200 space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-pulse" />
                              <h5 className="font-extrabold text-xs text-indigo-300">⏳ Payment Slip Uploaded — Awaiting Verification</h5>
                            </div>
                            <p className="text-[10px] text-slate-300 leading-relaxed">
                              Your ₹50 payment slip has been submitted successfully! Sent to recipient/admin for verification.
                            </p>
                          </div>
                        )}

                        {/* Active Link Box during 2nd PH step */}
                        {secondPhContrib?.status !== 'pending_verification' && (
                          <div className="bg-white/5 border border-white/10 p-2.5 rounded-xl flex flex-col gap-2 text-white">
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="text-slate-300 font-bold">Pledge Status:</span>
                              <span className="font-black uppercase text-[9px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 animate-pulse border border-rose-500/30">
                                Awaiting Payment
                              </span>
                            </div>

                            <div className="space-y-2 mt-1 text-white">
                              {/* 24-Hour Countdown Timer */}
                              <div className="bg-black/40 border border-pink-500/30 p-2 rounded-lg flex items-center justify-between">
                                <div className="flex items-center gap-1.5">
                                  <Clock className="w-3.5 h-3.5 text-pink-400 animate-spin" style={{ animationDuration: '4s' }} />
                                  <div>
                                    <span className="text-[9px] font-black uppercase tracking-wider text-pink-300 block">Time Remaining to Pay</span>
                                  </div>
                                </div>
                                <div className="bg-pink-950/40 border border-pink-500/30 px-2 py-0.5 rounded-md text-right font-mono text-xs font-black text-pink-400 animate-pulse tracking-wider">
                                  {formatTimer(ph2Timer)}
                                </div>
                              </div>

                              {/* Compact Gateway Link if assigned and not default admin */}
                              {secondPhContrib.txLink && !secondPhContrib.txLink.includes("help100.com") && !secondPhContrib.txLink.includes("pin-use") && (
                                <div className="flex justify-center gap-2">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setActiveGateway({
                                        id: secondPhContrib.id,
                                        type: 'ph',
                                        amount: 50,
                                        stepKey: 'second_ph',
                                        txLink: secondPhContrib.txLink
                                      });
                                      setGatewayTimer(86400);
                                    }}
                                    className="inline-flex items-center gap-1 px-2 py-1 bg-pink-500 hover:bg-pink-600 text-white rounded text-[9px] font-bold cursor-pointer transition-all"
                                  >
                                    💳 Open QR Code
                                  </button>
                                  <a 
                                    href={secondPhContrib.txLink.startsWith('http') ? secondPhContrib.txLink : `https://${secondPhContrib.txLink}`}
                                    target="_blank" 
                                    rel="noopener noreferrer" 
                                    className="inline-flex items-center gap-1 px-2 py-1 bg-indigo-500 hover:bg-indigo-600 text-white rounded text-[9px] font-bold cursor-pointer transition-all"
                                  >
                                    🔗 Alternate Link ↗
                                  </a>
                                </div>
                              )}

                              {/* Recipient Bank/UPI Details */}
                              {(() => {
                                const recipient = getRecipientDetails('ph');
                                return (
                                  <div className="bg-black/30 border border-white/10 p-2.5 rounded-lg space-y-1.5">
                                    <div className="flex justify-between items-center border-b border-white/5 pb-1">
                                      <span className="text-[9px] font-black text-pink-300 uppercase tracking-wider">Recipient Details (GH User)</span>
                                      <span className="text-[8px] font-black bg-pink-500/20 text-pink-200 border border-pink-500/30 px-1.5 py-0.5 rounded uppercase">
                                        Send ₹50 Exactly
                                      </span>
                                    </div>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-[10px]">
                                      <div className="space-y-0.5 bg-white/5 p-1.5 rounded border border-white/5">
                                        <span className="text-[7px] text-slate-400 block uppercase font-bold">UPI ID</span>
                                        <div className="flex items-center justify-between gap-1">
                                          <span className="font-bold text-slate-200 font-mono select-all">{recipient.upiId}</span>
                                          <button 
                                            type="button"
                                            onClick={() => {
                                              navigator.clipboard.writeText(recipient.upiId || 'help100admin@sbin');
                                              alert('UPI ID copied successfully!');
                                            }}
                                            className="text-pink-400 hover:text-pink-300 active:scale-95 transition-all cursor-pointer p-0.5 hover:bg-white/5 rounded"
                                          >
                                            <Copy className="w-2.5 h-2.5" />
                                          </button>
                                        </div>
                                      </div>
                                      <div className="space-y-0.5 bg-white/5 p-1.5 rounded border border-white/5">
                                        <span className="text-[7px] text-slate-400 block uppercase font-bold">Account Holder</span>
                                        <span className="font-bold text-slate-200 block truncate">{recipient.beneficiaryName}</span>
                                      </div>
                                      <div className="space-y-0.5 bg-white/5 p-1.5 rounded border border-white/5">
                                        <span className="text-[7px] text-slate-400 block uppercase font-bold">Bank Name</span>
                                        <span className="font-bold text-slate-200 block">{recipient.bankName}</span>
                                      </div>
                                      <div className="space-y-0.5 bg-white/5 p-1.5 rounded border border-white/5 font-mono">
                                        <span className="text-[7px] text-slate-400 block uppercase font-bold">Account / IFSC</span>
                                        <span className="font-bold text-slate-200 block text-[9px] truncate">{recipient.accountNumber} / {recipient.ifscCode}</span>
                                      </div>
                                    </div>
                                  </div>
                                );
                              })()}

                              {/* Inline Slip Upload Area */}
                              <div className="space-y-1.5">
                                <label className="block text-[9px] font-black uppercase tracking-wider text-pink-300">
                                  📤 Upload Payment Slip / Receipt
                                </label>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                                  <div>
                                    <input 
                                      id="ph2-inline-slip-upload"
                                      type="file"
                                      accept="image/*"
                                      className="hidden"
                                      onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (file) {
                                          setPh2ProofFile(file.name);
                                        }
                                      }}
                                    />
                                    <div 
                                      onClick={() => document.getElementById('ph2-inline-slip-upload')?.click()}
                                      onDragOver={(e) => e.preventDefault()}
                                      onDrop={(e) => {
                                        e.preventDefault();
                                        const file = e.dataTransfer.files[0];
                                        if (file) {
                                          setPh2ProofFile(file.name);
                                        }
                                      }}
                                      className="border border-dashed border-white/20 hover:border-pink-500 rounded-lg p-2 text-center bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                                    >
                                      <Upload className="w-4 h-4 text-pink-400 mx-auto mb-0.5" />
                                      <span className="text-[9px] font-black block text-slate-300 truncate">
                                        {ph2ProofFile ? `Receipt: ${ph2ProofFile}` : "Select receipt"}
                                      </span>
                                    </div>
                                  </div>

                                  <div className="bg-white/5 p-1 rounded-lg border border-white/10 flex items-center">
                                    <input
                                      type="text"
                                      placeholder="UPI Tx ID (Optional)"
                                      value={ph2TxId}
                                      onChange={(e) => setPh2TxId(e.target.value)}
                                      className="w-full bg-transparent text-[10px] text-slate-200 font-mono focus:outline-none placeholder:text-slate-500 px-1 py-1"
                                    />
                                  </div>
                                </div>

                                <button
                                  type="button"
                                  onClick={() => {
                                    if (!ph2ProofFile) {
                                      alert('Please select or upload your payment receipt/slip first!');
                                      return;
                                    }
                                    if (onUpdateContributionProof) {
                                      onUpdateContributionProof(
                                        secondPhContrib.id, 
                                        ph2ProofFile, 
                                        ph2TxId ? `https://help100.com/secure-gateway/ph/${ph2TxId}` : undefined
                                      );
                                      if (onUpdateContribution) {
                                        onUpdateContribution(secondPhContrib.id, 'pending_verification', 'Payment slip uploaded, awaiting verification.');
                                      }
                                      alert('Success! Your ₹50 payment slip has been submitted for recipient verification.');
                                    }
                                  }}
                                  className="w-full bg-gradient-to-r from-pink-500 to-indigo-500 hover:from-pink-600 hover:to-indigo-600 active:scale-[0.98] text-white text-[9px] font-black py-2 px-3 rounded-lg transition-all shadow cursor-pointer uppercase tracking-wider flex items-center justify-center gap-1.5 border border-white/10"
                                >
                                  ✨ Submit Payment Slip (₹50)
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Awaiting Admin Dispatch Notice when NO 2nd PH link dispatched yet */}
                        {(!secondPhContrib || secondPhContrib.status === 'pending_dispatch') && (
                          <div className="bg-slate-900/90 border border-fuchsia-500/30 p-4 rounded-2xl text-slate-200 space-y-2 mt-2 shadow-inner">
                            <div className="flex items-center gap-2 text-amber-400 font-extrabold text-xs">
                              <Clock className="w-4 h-4 animate-spin text-amber-400 shrink-0" style={{ animationDuration: '4s' }} />
                              <span>⏳ Awaiting Admin 2nd PH Link Dispatch (एडमिन द्वारा सेकंड PH लिंक की प्रतीक्षा करें)</span>
                            </div>
                            <p className="text-[11px] text-slate-300 leading-relaxed">
                              आपकी आईडी ₹50 Second PH के लिए कतार में है। जैसे ही एडमिन पेमेंट लिंक जारी (dispatch) करेंगे, Payment Link Box यहाँ दिखाई देगा।
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  )}

                  {/* Direct Withdrawal Link Banner for ₹100 Paid state */}
                  {cycleState.pinPurchased && cycleState.firstPhSubmitted && cycleState.secondPhSubmitted && (
                    <div id="payout-withdrawal-link-banner" className="mb-6 py-1.5 px-4 sm:px-8 rounded-xl bg-gradient-to-r from-emerald-600 via-green-600 to-emerald-700 text-white border-2 border-emerald-400 shadow-md shadow-emerald-900/20 w-full relative overflow-hidden">
                      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-2 sm:gap-4">
                        <div className="flex-1 min-w-0 flex flex-wrap items-center gap-x-3 gap-y-1">
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-black/25 text-white border border-white/30 text-[10px] font-black uppercase rounded-full tracking-wider shrink-0 backdrop-blur-sm">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-ping" />
                            💚 ₹100 Contribution Confirmed
                          </span>
                          <h3 className="text-xs sm:text-sm font-black text-white shrink-0">
                            Direct Received Help Link is Active!
                          </h3>
                          <p className="text-[11px] text-emerald-100 font-medium leading-tight">
                            Claim your ₹175 total peer assistance payout now.
                          </p>
                        </div>
                        <div className="flex flex-row gap-2 shrink-0 items-center">
                          <button
                            id="btn-copy-withdraw-link"
                            onClick={() => {
                              const link = `${window.location.origin}/withdraw/claim-${currentUser.id}`;
                              navigator.clipboard.writeText(link);
                              alert(`Copied unique secure Received Help Link:\n${link}`);
                            }}
                            className="px-3 py-1 bg-black/30 hover:bg-black/50 active:scale-95 transition-all text-xs font-black rounded-lg border border-white/30 flex items-center justify-center gap-1 cursor-pointer text-white shadow-xs backdrop-blur-sm"
                          >
                            <Copy className="w-3 h-3 text-emerald-300" />
                            Copy Link
                          </button>
                          <button
                            id="btn-open-withdraw-gateway"
                            onClick={() => {
                              setShowSecureClaimGateway(true);
                              setGatewayTimer(86400);
                              setClaimProofFilename('');
                            }}
                            className="px-3.5 py-1 bg-white hover:bg-emerald-50 active:scale-95 transition-all text-xs font-black rounded-lg text-emerald-800 shadow-sm flex items-center justify-center gap-1 cursor-pointer border border-white"
                          >
                            💚 Open Received Help Link
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Received Help Flow */}
                  {(planViewMode === 'all' || planViewMode === 'gh') && (
                    <div className="border-t border-slate-100 pt-5 mt-2">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-4">Payout Withdrawal Stage (Received Help - Total Rs 175)</span>
                      
                      <div className="space-y-3">
                        {/* Payout 1 & 2 (₹50 + ₹50) */}
                        <div className="grid sm:grid-cols-2 gap-3">
                          {/* First GH: ₹50 - High Contrast Green with Black Text */}
                          <div className={`p-3 rounded-xl border transition-all ${
                            cycleState.currentStep === 'first_gh'
                              ? 'border-2 border-emerald-600 bg-gradient-to-br from-emerald-400 via-green-400 to-lime-300 text-slate-950 ring-2 ring-emerald-500/30 shadow-lg shadow-emerald-500/20' 
                              : cycleState.firstGhReceived 
                                ? 'border-emerald-200 bg-emerald-50/10 opacity-70' 
                                : 'border-slate-100 opacity-40 bg-slate-50/50'
                          }`}>
                            {cycleState.currentStep === 'first_gh' && (
                              <div className="flex justify-between items-center bg-slate-950 p-1.5 rounded-lg border border-black text-white shadow-md mb-1.5">
                                <div className="flex items-center gap-1">
                                  <Activity className="w-3.5 h-3.5 text-lime-400 animate-pulse shrink-0" />
                                  <span className="font-extrabold text-[9.5px] uppercase tracking-wider text-lime-300 font-mono bg-black/60 px-1.5 py-0.5 rounded border border-lime-400/40">GH LINK 1 (₹50)</span>
                                </div>
                                <UserIcon className="w-3.5 h-3.5 text-lime-300 shrink-0" />
                              </div>
                            )}

                            <div className="flex justify-between items-center">
                              <div className="flex items-center gap-1.5">
                                <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black ${
                                  cycleState.firstGhReceived ? 'bg-emerald-700 text-white' : 'bg-slate-950 text-lime-300 border border-lime-400/30'
                                }`}>
                                  {cycleState.firstGhReceived ? '✓' : '4'}
                                </span>
                                <span className={`font-black text-[11px] ${cycleState.currentStep === 'first_gh' ? 'text-slate-950' : 'text-slate-800'}`}>1st GH Link</span>
                              </div>
                              <span className={`text-[11px] font-black font-mono px-1.5 py-0.5 rounded ${
                                cycleState.currentStep === 'first_gh' ? 'bg-lime-200 text-slate-950 border border-emerald-600/40' : 'text-emerald-600'
                              }`}>₹50</span>
                            </div>
                            {cycleState.currentStep === 'first_gh' && (
                              <div className="mt-1 text-center flex flex-col items-center gap-1 pt-1 border-t border-black/20">
                                {!firstGhHr ? (
                                  <>
                                    <div className="text-left w-full space-y-0.5">
                                      <p className="text-[8.5px] font-black text-slate-950 uppercase tracking-wider">🙋 1st Get Help Request (₹50)</p>
                                      <p className="text-[8px] text-slate-900 font-bold leading-tight">
                                        बटन दबाकर अपनी ID एडमिन टेकर (Taker) लिस्ट में भेजें।
                                      </p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => handleCycleAction('first_gh')}
                                      className="w-full bg-slate-950 hover:bg-black active:scale-95 text-white text-[9.5px] font-black uppercase py-1 px-2 rounded-lg cursor-pointer transition-all shadow-md flex items-center justify-center gap-1 border border-black"
                                    >
                                      🙋 Ready to Receive ₹50
                                    </button>
                                  </>
                                ) : (!firstGhHr.txLink || firstGhHr.txLink === "") ? (
                                  <div className="bg-emerald-300/90 border border-emerald-700/50 p-1.5 rounded-lg text-slate-950 space-y-0.5 text-left w-full shadow-xs">
                                    <div className="flex items-center gap-1">
                                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-900 animate-ping" />
                                      <h5 className="font-black text-[9.5px] text-slate-950">⏳ Active in Taker List</h5>
                                    </div>
                                    <p className="text-[8px] text-slate-900 leading-tight font-extrabold">
                                      आपकी ₹50 गेट हेल्प ID एडमिन टेकर लिस्ट में दर्ज है! लिंक आते ही बटन चालू हो जाएगा।
                                    </p>
                                  </div>
                                ) : (
                                  <>
                                    <div className="text-left w-full space-y-0.5">
                                      <p className="text-[8.5px] font-black text-slate-950 uppercase tracking-wider">⚡ Admin Link Active!</p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setActiveGateway({
                                          id: firstGhHr.id,
                                          type: 'gh',
                                          amount: 50,
                                          stepKey: 'first_gh',
                                          txLink: firstGhHr.txLink
                                        });
                                        setGatewayTimer(86400);
                                      }}
                                      className="w-full bg-slate-950 hover:bg-black text-lime-300 text-[9.5px] font-black uppercase py-1 px-2 rounded-lg cursor-pointer transition-all shadow-md animate-pulse flex items-center justify-center gap-1 border border-black"
                                    >
                                      💰 Open Get Help Link & QR (₹50) ↗
                                    </button>
                                  </>
                                )}
                              </div>
                            )}
                          </div>

                          {/* Second GH: ₹50 - High Contrast Green with Black Text */}
                          <div className={`p-3 rounded-xl border transition-all ${
                            cycleState.currentStep === 'second_gh'
                              ? 'border-2 border-emerald-600 bg-gradient-to-br from-emerald-400 via-green-400 to-lime-300 text-slate-950 ring-2 ring-emerald-500/30 shadow-lg shadow-emerald-500/20' 
                              : cycleState.secondGhReceived 
                                ? 'border-emerald-200 bg-emerald-50/10 opacity-70' 
                                : 'border-slate-100 opacity-40 bg-slate-50/50'
                          }`}>
                            {cycleState.currentStep === 'second_gh' && (
                              <div className="flex justify-between items-center bg-slate-950 p-1.5 rounded-lg border border-black text-white shadow-md mb-1.5">
                                <div className="flex items-center gap-1">
                                  <Activity className="w-3.5 h-3.5 text-lime-400 animate-pulse shrink-0" />
                                  <span className="font-extrabold text-[9.5px] uppercase tracking-wider text-lime-300 font-mono bg-black/60 px-1.5 py-0.5 rounded border border-lime-400/40">GH LINK 2 (₹50)</span>
                                </div>
                                <UserIcon className="w-3.5 h-3.5 text-lime-300 shrink-0" />
                              </div>
                            )}

                            <div className="flex justify-between items-center">
                              <div className="flex items-center gap-1.5">
                                <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black ${
                                  cycleState.secondGhReceived ? 'bg-emerald-700 text-white' : 'bg-slate-950 text-lime-300 border border-lime-400/30'
                                }`}>
                                  {cycleState.secondGhReceived ? '✓' : '5'}
                                </span>
                                <span className={`font-black text-[11px] ${cycleState.currentStep === 'second_gh' ? 'text-slate-950' : 'text-slate-800'}`}>2nd GH Link</span>
                              </div>
                              <span className={`text-[11px] font-black font-mono px-1.5 py-0.5 rounded ${
                                cycleState.currentStep === 'second_gh' ? 'bg-lime-200 text-slate-950 border border-emerald-600/40' : 'text-emerald-600'
                              }`}>₹50</span>
                            </div>
                            {cycleState.currentStep === 'second_gh' && (
                              <div className="mt-1 text-center flex flex-col items-center gap-1 pt-1 border-t border-black/20">
                                {!secondGhHr ? (
                                  <>
                                    <div className="text-left w-full space-y-0.5">
                                      <p className="text-[8.5px] font-black text-slate-950 uppercase tracking-wider">🙋 2nd Get Help Request (₹50)</p>
                                      <p className="text-[8px] text-slate-900 font-bold leading-tight">
                                        बटन दबाकर अपनी ID एडमिन टेकर (Taker) लिस्ट में भेजें।
                                      </p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => handleCycleAction('second_gh')}
                                      className="w-full bg-slate-950 hover:bg-black active:scale-95 text-white text-[9.5px] font-black uppercase py-1 px-2 rounded-lg cursor-pointer transition-all shadow-md flex items-center justify-center gap-1 border border-black"
                                    >
                                      🙋 Ready to Receive ₹50
                                    </button>
                                  </>
                                ) : (!secondGhHr.txLink || secondGhHr.txLink === "") ? (
                                  <div className="bg-emerald-300/90 border border-emerald-700/50 p-1.5 rounded-lg text-slate-950 space-y-0.5 text-left w-full shadow-xs">
                                    <div className="flex items-center gap-1">
                                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-900 animate-ping" />
                                      <h5 className="font-black text-[9.5px] text-slate-950">⏳ Active in Taker List</h5>
                                    </div>
                                    <p className="text-[8px] text-slate-900 leading-tight font-extrabold">
                                      आपकी ₹50 गेट हेल्प ID एडमिन टेकर लिस्ट में दर्ज है! लिंक आते ही बटन चालू हो जाएगा।
                                    </p>
                                  </div>
                                ) : (
                                  <>
                                    <div className="text-left w-full space-y-0.5">
                                      <p className="text-[8.5px] font-black text-slate-950 uppercase tracking-wider">⚡ Admin Link Active!</p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setActiveGateway({
                                          id: secondGhHr.id,
                                          type: 'gh',
                                          amount: 50,
                                          stepKey: 'second_gh',
                                          txLink: secondGhHr.txLink
                                        });
                                        setGatewayTimer(86400);
                                      }}
                                      className="w-full bg-slate-950 hover:bg-black text-lime-300 text-[9.5px] font-black uppercase py-1 px-2 rounded-lg cursor-pointer transition-all shadow-md animate-pulse flex items-center justify-center gap-1 border border-black"
                                    >
                                      💰 Open Get Help Link & QR (₹50) ↗
                                    </button>
                                  </>
                                )}
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Payout 3, 4, 5 (₹25 + ₹25 + ₹25) */}
                        <div className="grid sm:grid-cols-3 gap-3">
                          {/* Third GH: ₹25 - High Contrast Green with Black Text */}
                          <div className={`p-3 rounded-xl border transition-all ${
                            cycleState.currentStep === 'third_gh'
                              ? 'border-2 border-emerald-600 bg-gradient-to-br from-emerald-400 via-green-400 to-lime-300 text-slate-950 ring-2 ring-emerald-500/30 shadow-lg shadow-emerald-500/20' 
                              : cycleState.thirdGhReceived 
                                ? 'border-emerald-200 bg-emerald-50/10 opacity-70' 
                                : 'border-slate-100 opacity-40 bg-slate-50/50'
                          }`}>
                            {cycleState.currentStep === 'third_gh' && (
                              <div className="flex justify-between items-center bg-slate-950 p-1.5 rounded-lg border border-black text-white shadow-md mb-1.5">
                                <div className="flex items-center gap-1">
                                  <Activity className="w-3.5 h-3.5 text-lime-400 animate-pulse shrink-0" />
                                  <span className="font-extrabold text-[9.5px] uppercase tracking-wider text-lime-300 font-mono bg-black/60 px-1.5 py-0.5 rounded border border-lime-400/40">GH LINK 3</span>
                                </div>
                                <UserIcon className="w-3.5 h-3.5 text-lime-300 shrink-0" />
                              </div>
                            )}

                            <div className="flex justify-between items-center">
                              <div className="flex items-center gap-1.5">
                                <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black ${
                                  cycleState.thirdGhReceived ? 'bg-emerald-700 text-white' : 'bg-slate-950 text-lime-300 border border-lime-400/30'
                                }`}>
                                  {cycleState.thirdGhReceived ? '✓' : '6'}
                                </span>
                                <span className={`font-black text-[11px] ${cycleState.currentStep === 'third_gh' ? 'text-slate-950' : 'text-slate-800'}`}>3rd GH Link</span>
                              </div>
                              <span className={`text-[11px] font-black font-mono px-1.5 py-0.5 rounded ${
                                cycleState.currentStep === 'third_gh' ? 'bg-lime-200 text-slate-950 border border-emerald-600/40' : 'text-emerald-600'
                              }`}>₹25</span>
                            </div>
                            {cycleState.currentStep === 'third_gh' && (
                              <div className="mt-1 text-center flex flex-col items-center gap-1 pt-1 border-t border-black/20">
                                {!thirdGhHr ? (
                                  <>
                                    <div className="text-left w-full space-y-0.5">
                                      <p className="text-[8.5px] font-black text-slate-950 uppercase tracking-wider">🙋 3rd Get Help (₹25)</p>
                                      <p className="text-[8px] text-slate-900 font-bold leading-tight">
                                        बटन दबाकर आईडी एडमिन टेकर लिस्ट में भेजें।
                                      </p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => handleCycleAction('third_gh')}
                                      className="w-full bg-slate-950 hover:bg-black text-white text-[9.5px] font-black uppercase py-1 px-2 rounded-lg cursor-pointer transition-all shadow-md flex items-center justify-center gap-1 border border-black"
                                    >
                                      🙋 Ready to Receive ₹25
                                    </button>
                                  </>
                                ) : (!thirdGhHr.txLink || thirdGhHr.txLink === "") ? (
                                  <div className="bg-emerald-300/90 border border-emerald-700/50 p-1.5 rounded-lg text-slate-950 space-y-0.5 text-left w-full shadow-xs">
                                    <div className="flex items-center gap-1">
                                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-900 animate-ping" />
                                      <h5 className="font-black text-[9.5px] text-slate-950">⏳ Active in Taker List</h5>
                                    </div>
                                    <p className="text-[8px] text-slate-900 leading-tight font-extrabold">
                                      आपकी ₹25 गेट हेल्प ID एडमिन टेकर लिस्ट में दर्ज है। लिंक आते ही बटन चालू हो जाएगा।
                                    </p>
                                  </div>
                                ) : (
                                  <>
                                    <div className="text-left w-full space-y-0.5">
                                      <p className="text-[8.5px] font-black text-slate-950 uppercase tracking-wider">⚡ Link Active!</p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setActiveGateway({
                                          id: thirdGhHr.id,
                                          type: 'gh',
                                          amount: 25,
                                          stepKey: 'third_gh',
                                          txLink: thirdGhHr.txLink
                                        });
                                        setGatewayTimer(86400);
                                      }}
                                      className="w-full bg-slate-950 hover:bg-black text-lime-300 text-[9.5px] font-black uppercase py-1 px-2 rounded-lg cursor-pointer transition-all shadow-md animate-pulse flex items-center justify-center gap-1 border border-black"
                                    >
                                      💰 Open GH (₹25) ↗
                                    </button>
                                  </>
                                )}
                              </div>
                            )}
                          </div>

                          {/* Fourth GH: ₹25 - High Contrast Green with Black Text */}
                          <div className={`p-3 rounded-xl border transition-all ${
                            cycleState.currentStep === 'fourth_gh'
                              ? 'border-2 border-emerald-600 bg-gradient-to-br from-emerald-400 via-green-400 to-lime-300 text-slate-950 ring-2 ring-emerald-500/30 shadow-lg shadow-emerald-500/20' 
                              : cycleState.fourthGhReceived 
                                ? 'border-emerald-200 bg-emerald-50/10 opacity-70' 
                                : 'border-slate-100 opacity-40 bg-slate-50/50'
                          }`}>
                            {cycleState.currentStep === 'fourth_gh' && (
                              <div className="flex justify-between items-center bg-slate-950 p-1.5 rounded-lg border border-black text-white shadow-md mb-1.5">
                                <div className="flex items-center gap-1">
                                  <Activity className="w-3.5 h-3.5 text-lime-400 animate-pulse shrink-0" />
                                  <span className="font-extrabold text-[9.5px] uppercase tracking-wider text-lime-300 font-mono bg-black/60 px-1.5 py-0.5 rounded border border-lime-400/40">GH LINK 4</span>
                                </div>
                                <UserIcon className="w-3.5 h-3.5 text-lime-300 shrink-0" />
                              </div>
                            )}

                            <div className="flex justify-between items-center">
                              <div className="flex items-center gap-1.5">
                                <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black ${
                                  cycleState.fourthGhReceived ? 'bg-emerald-700 text-white' : 'bg-slate-950 text-lime-300 border border-lime-400/30'
                                }`}>
                                  {cycleState.fourthGhReceived ? '✓' : '7'}
                                </span>
                                <span className={`font-black text-[11px] ${cycleState.currentStep === 'fourth_gh' ? 'text-slate-950' : 'text-slate-800'}`}>4th GH Link</span>
                              </div>
                              <span className={`text-[11px] font-black font-mono px-1.5 py-0.5 rounded ${
                                cycleState.currentStep === 'fourth_gh' ? 'bg-lime-200 text-slate-950 border border-emerald-600/40' : 'text-emerald-600'
                              }`}>₹25</span>
                            </div>
                            {cycleState.currentStep === 'fourth_gh' && (
                              <div className="mt-1 text-center flex flex-col items-center gap-1 pt-1 border-t border-black/20">
                                {!fourthGhHr ? (
                                  <>
                                    <div className="text-left w-full space-y-0.5">
                                      <p className="text-[8.5px] font-black text-slate-950 uppercase tracking-wider">🙋 4th Get Help (₹25)</p>
                                      <p className="text-[8px] text-slate-900 font-bold leading-tight">
                                        बटन दबाकर आईडी एडमिन टेकर लिस्ट में भेजें।
                                      </p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => handleCycleAction('fourth_gh')}
                                      className="w-full bg-slate-950 hover:bg-black text-white text-[9.5px] font-black uppercase py-1 px-2 rounded-lg cursor-pointer transition-all shadow-md flex items-center justify-center gap-1 border border-black"
                                    >
                                      🙋 Ready to Receive ₹25
                                    </button>
                                  </>
                                ) : (!fourthGhHr.txLink || fourthGhHr.txLink === "") ? (
                                  <div className="bg-emerald-300/90 border border-emerald-700/50 p-1.5 rounded-lg text-slate-950 space-y-0.5 text-left w-full shadow-xs">
                                    <div className="flex items-center gap-1">
                                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-900 animate-ping" />
                                      <h5 className="font-black text-[9.5px] text-slate-950">⏳ Active in Taker List</h5>
                                    </div>
                                    <p className="text-[8px] text-slate-900 leading-tight font-extrabold">
                                      आपकी ₹25 गेट हेल्प ID एडमिन टेकर लिस्ट में दर्ज है। लिंक आते ही बटन चालू हो जाएगा।
                                    </p>
                                  </div>
                                ) : (
                                  <>
                                    <div className="text-left w-full space-y-0.5">
                                      <p className="text-[8.5px] font-black text-slate-950 uppercase tracking-wider">⚡ Link Active!</p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setActiveGateway({
                                          id: fourthGhHr.id,
                                          type: 'gh',
                                          amount: 25,
                                          stepKey: 'fourth_gh',
                                          txLink: fourthGhHr.txLink
                                        });
                                        setGatewayTimer(86400);
                                      }}
                                      className="w-full bg-slate-950 hover:bg-black text-lime-300 text-[9.5px] font-black uppercase py-1 px-2 rounded-lg cursor-pointer transition-all shadow-md animate-pulse flex items-center justify-center gap-1 border border-black"
                                    >
                                      💰 Open GH (₹25) ↗
                                    </button>
                                  </>
                                )}
                              </div>
                            )}
                          </div>

                          {/* Fifth GH: ₹25 - High Contrast Green with Black Text */}
                          <div className={`p-3 rounded-xl border transition-all ${
                            cycleState.currentStep === 'fifth_gh'
                              ? 'border-2 border-emerald-600 bg-gradient-to-br from-emerald-400 via-green-400 to-lime-300 text-slate-950 ring-2 ring-emerald-500/30 shadow-lg shadow-emerald-500/20' 
                              : cycleState.fifthGhReceived 
                                ? 'border-emerald-200 bg-emerald-50/10 opacity-70' 
                                : 'border-slate-100 opacity-40 bg-slate-50/50'
                          }`}>
                            {cycleState.currentStep === 'fifth_gh' && (
                              <div className="flex justify-between items-center bg-slate-950 p-1.5 rounded-lg border border-black text-white shadow-md mb-1.5">
                                <div className="flex items-center gap-1">
                                  <Activity className="w-3.5 h-3.5 text-lime-400 animate-pulse shrink-0" />
                                  <span className="font-extrabold text-[9.5px] uppercase tracking-wider text-lime-300 font-mono bg-black/60 px-1.5 py-0.5 rounded border border-lime-400/40">GH LINK 5</span>
                                </div>
                                <UserIcon className="w-3.5 h-3.5 text-lime-300 shrink-0" />
                              </div>
                            )}

                            <div className="flex justify-between items-center">
                              <div className="flex items-center gap-1.5">
                                <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black ${
                                  cycleState.fifthGhReceived ? 'bg-emerald-700 text-white' : 'bg-slate-950 text-lime-300 border border-lime-400/30'
                                }`}>
                                  {cycleState.fifthGhReceived ? '✓' : '8'}
                                </span>
                                <span className={`font-black text-[11px] ${cycleState.currentStep === 'fifth_gh' ? 'text-slate-950' : 'text-slate-800'}`}>5th GH Link</span>
                              </div>
                              <span className={`text-[11px] font-black font-mono px-1.5 py-0.5 rounded ${
                                cycleState.currentStep === 'fifth_gh' ? 'bg-lime-200 text-slate-950 border border-emerald-600/40' : 'text-emerald-600'
                              }`}>₹25</span>
                            </div>
                            {cycleState.currentStep === 'fifth_gh' && (
                              <div className="mt-1 text-center flex flex-col items-center gap-1 pt-1 border-t border-black/20">
                                {!fifthGhHr ? (
                                  <>
                                    <div className="text-left w-full space-y-0.5">
                                      <p className="text-[8.5px] font-black text-slate-950 uppercase tracking-wider">🙋 5th Get Help (₹25)</p>
                                      <p className="text-[8px] text-slate-900 font-bold leading-tight">
                                        बटन दबाकर आईडी एडमिन टेकर लिस्ट में भेजें।
                                      </p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => handleCycleAction('fifth_gh')}
                                      className="w-full bg-slate-950 hover:bg-black text-white text-[9.5px] font-black uppercase py-1 px-2 rounded-lg cursor-pointer transition-all shadow-md flex items-center justify-center gap-1 border border-black"
                                    >
                                      🙋 Ready to Receive ₹25
                                    </button>
                                  </>
                                ) : (!fifthGhHr.txLink || fifthGhHr.txLink === "") ? (
                                  <div className="bg-emerald-300/90 border border-emerald-700/50 p-1.5 rounded-lg text-slate-950 space-y-0.5 text-left w-full shadow-xs">
                                    <div className="flex items-center gap-1">
                                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-900 animate-ping" />
                                      <h5 className="font-black text-[9.5px] text-slate-950">⏳ Active in Taker List</h5>
                                    </div>
                                    <p className="text-[8px] text-slate-900 leading-tight font-extrabold">
                                      आपकी ₹25 गेट हेल्प ID एडमिन टेकर लिस्ट में दर्ज है। लिंक आते ही बटन चालू हो जाएगा।
                                    </p>
                                  </div>
                                ) : (
                                  <>
                                    <div className="text-left w-full space-y-0.5">
                                      <p className="text-[8.5px] font-black text-slate-950 uppercase tracking-wider">⚡ Link Active!</p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setActiveGateway({
                                          id: fifthGhHr.id,
                                          type: 'gh',
                                          amount: 25,
                                          stepKey: 'fifth_gh',
                                          txLink: fifthGhHr.txLink
                                        });
                                        setGatewayTimer(86400);
                                      }}
                                      className="w-full bg-slate-950 hover:bg-black text-lime-300 text-[9.5px] font-black uppercase py-1 px-2 rounded-lg cursor-pointer transition-all shadow-md animate-pulse flex items-center justify-center gap-1 border border-black"
                                    >
                                      💰 Open GH (₹25) ↗
                                    </button>
                                  </>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                </div>
              </div>

              {/* Right Column: Rule Card & Summary */}
              <div className="p-6 bg-slate-50/50 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center gap-2 border-b border-slate-150 pb-2.5">
                    <ShieldAlert className="w-4 h-4 text-emerald-600" />
                    <span className="font-bold text-xs text-slate-800 uppercase tracking-wider">Plan Rules & Specs</span>
                  </div>

                  <div className="space-y-3.5 text-xs text-slate-700">
                    <p className="font-medium leading-relaxed">
                      This is the standard <strong className="text-slate-900">₹100 Cycling Aid Plan</strong>. Complete each action sequentially.
                    </p>
                    
                    <ul className="space-y-2.5 list-disc pl-4 text-slate-600 leading-snug">
                      <li><strong>PIN registration:</strong> Must buy ₹10 PIN to authorize the cycle.</li>
                      <li><strong>First Contribution:</strong> ₹40 matching pledge.</li>
                      <li><strong>Second Contribution:</strong> ₹50 matching pledge.</li>
                      <li><strong>Total Pledged:</strong> ₹100 provided.</li>
                      <li><strong>Total Received:</strong> ₹175 total matching payouts.</li>
                      <li><strong>Profit Yield:</strong> ₹75 Net Profit per complete cycle loop!</li>
                    </ul>

                    <div className="bg-[#FFFCEB] border border-[#EAD07C] p-3 rounded-xl text-[11px] text-amber-900 font-medium leading-relaxed">
                      💡 <strong>Continuous Cycle Loop:</strong> Once you complete all 8 steps, you must purchase a new ₹10 Registration PIN key to start another loop! This guarantees continuous liquidity of aid.
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-200/60 mt-4">
                  {cycleState.currentStep === 'completed' ? (
                    <div className="space-y-3 text-center">
                      <div className="bg-emerald-100 text-emerald-800 p-3 rounded-xl font-bold text-xs animate-bounce">
                        🎉 Cycle #{cycleState.cycleCount} Completed Successfully!
                        <div className="mt-1 font-mono text-[11px]">Net Profit: +₹75</div>
                      </div>
                      <button
                        onClick={() => handleCycleAction('reset')}
                        className="w-full bg-gradient-to-r from-emerald-600 to-indigo-600 hover:from-emerald-700 hover:to-indigo-700 text-white font-black text-xs py-3 rounded-xl transition-all shadow-md cursor-pointer uppercase tracking-wider"
                      >
                        Start Next Cycle (PIN ₹10)
                      </button>
                    </div>
                  ) : (
                    <div className="p-4 bg-slate-100 rounded-xl border border-slate-200 text-center">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Currently Simulating</span>
                      <strong className="text-sm text-slate-800 mt-1 block">Cycle #{cycleState.cycleCount}</strong>
                      <div className="w-full bg-slate-200 h-2 rounded-full mt-3 overflow-hidden">
                        <div 
                          className="bg-gradient-to-r from-emerald-500 to-indigo-600 h-full transition-all duration-500"
                          style={{
                            width: `${
                              cycleState.currentStep === 'buy_pin' ? 0 :
                              cycleState.currentStep === 'first_ph' ? 12.5 :
                              cycleState.currentStep === 'second_ph' ? 25 :
                              cycleState.currentStep === 'first_gh' ? 37.5 :
                              cycleState.currentStep === 'second_gh' ? 50 :
                              cycleState.currentStep === 'third_gh' ? 62.5 :
                              cycleState.currentStep === 'fourth_gh' ? 75 :
                              cycleState.currentStep === 'fifth_gh' ? 87.5 : 100
                            }%`
                          }}
                        />
                      </div>
                    </div>
                  )}
                </div>

              </div>

            </div>
          </div>
        )}

      </main>

      {/* PARTICIPANT ORDER DETAIL MODAL (Image 5 replica) */}
      <AnimatePresence>
        {selectedGiverDetails && (
          <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200/80"
            >
              <div className="bg-[#1e293b] text-white p-5 flex justify-between items-center">
                <div className="flex flex-col">
                  <span className="font-extrabold text-sm tracking-wide text-emerald-400">ORDER DETAILS (PH)</span>
                  <span className="text-[10px] text-slate-400 font-mono font-bold">PH-{selectedGiverDetails.id.toUpperCase().substring(0, 8)}</span>
                </div>
                <button 
                  onClick={() => setSelectedGiverDetails(null)}
                  className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center text-sm font-bold transition-colors cursor-pointer"
                >
                  ✕
                </button>
              </div>
              
              <div className="p-6 space-y-4">
                <div className="bg-[#FFFCEB] border-2 border-[#EAD07C] rounded-xl p-3 text-center text-xs text-amber-900 font-bold">
                  ⚠️ Make sure to audit and verify receipt authenticity before checking in.
                </div>

                <div className="space-y-3 text-xs sm:text-sm text-slate-700">
                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-400 font-medium">Payment Channel:</span>
                    <strong className="text-slate-900 font-extrabold flex items-center gap-1">
                      <span className="w-2.5 h-2.5 bg-[#673AB7] rounded-full inline-block" /> PhonePe / GPay
                    </strong>
                  </div>
                  
                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-400 font-medium">Provider Sender:</span>
                    <strong className="text-emerald-600 font-black">{selectedGiverDetails.userName}</strong>
                  </div>

                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-400 font-medium">Pledge Amount (₹):</span>
                    <strong className="text-lg font-black text-slate-900 font-mono">₹{selectedGiverDetails.amount.toLocaleString()}</strong>
                  </div>

                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-400 font-medium">Payment Timestamp:</span>
                    <strong className="text-slate-900 font-semibold">{new Date(selectedGiverDetails.createdAt).toLocaleString()}</strong>
                  </div>

                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-400 font-medium">Transaction Ref ID (UTR):</span>
                    <strong className="text-xs font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-800">207569973264</strong>
                  </div>

                  <div className="flex justify-between py-1.5 border-b border-slate-100">
                    <span className="text-slate-400 font-medium">Audit Verification State:</span>
                    <strong className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase border ${
                      selectedGiverDetails.status === 'approved' 
                        ? 'bg-emerald-100 text-emerald-800 border-emerald-300' 
                        : 'bg-amber-100 text-amber-800 border-amber-300'
                    }`}>
                      {selectedGiverDetails.status === 'approved' ? 'Active Approved' : 'Awaiting Audit'}
                    </strong>
                  </div>
                </div>

                {selectedGiverDetails.remarks && (
                  <div className="bg-slate-50 rounded-xl p-3 border border-slate-200/60 text-xs italic text-slate-600">
                    <strong className="text-slate-700 not-italic block mb-1">System Audit Remarks:</strong>
                    "{selectedGiverDetails.remarks}"
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3 pt-3">
                  <button
                    onClick={() => {
                      alert('Verification confirmed and finalized for ' + selectedGiverDetails.userName);
                      setSelectedGiverDetails(null);
                    }}
                    className="bg-[#4F46E5] text-white hover:bg-indigo-700 py-3 rounded-xl font-bold text-xs shadow-md transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    ✓ Approve Receipt
                  </button>
                  <button
                    onClick={() => {
                      alert('Audit review triggered for ' + selectedGiverDetails.userName);
                      setSelectedGiverDetails(null);
                    }}
                    className="bg-rose-600 text-white hover:bg-rose-700 py-3 rounded-xl font-bold text-xs shadow-md transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    ✕ Reject / Flag
                  </button>
                </div>
              </div>
              
              <div className="bg-slate-50 px-6 py-4 border-t border-slate-100 flex justify-end">
                <button 
                  onClick={() => setSelectedGiverDetails(null)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-lg cursor-pointer"
                >
                  Close Details
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* SUCCESS PHONEPE/GPAY RECEIPT POPUP (Image 6 replica) */}
      <AnimatePresence>
        {selectedTakerDetails && (
          <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              className="bg-rose-600 rounded-[32px] shadow-2xl max-w-sm w-full overflow-hidden border-4 border-rose-300 p-1.5"
            >
              <div className="bg-white rounded-[26px] p-6 text-slate-800 space-y-4 relative">
                
                {/* Done Close Button */}
                <button 
                  onClick={() => setSelectedTakerDetails(null)}
                  className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 font-bold"
                >
                  ✕
                </button>

                {/* PhonePe-style Header Banner */}
                <div className="text-center pb-3 border-b border-slate-100/80">
                  <div className="w-16 h-16 rounded-full bg-rose-600 text-white flex items-center justify-center text-3xl font-black mx-auto mb-3 shadow-lg">
                    पे
                  </div>
                  <h3 className="text-emerald-600 font-extrabold text-xl flex items-center justify-center gap-1.5">
                    Transaction Successful
                  </h3>
                  <p className="text-xs text-slate-400 font-medium mt-0.5">
                    {new Date(selectedTakerDetails.createdAt).toLocaleDateString(undefined, {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })} at 12:20 PM
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider block">Paid to Campaign Host</span>
                    <div className="flex items-center justify-between mt-1">
                      <div>
                        <h4 className="font-extrabold text-slate-950 text-sm">{selectedTakerDetails.userName}</h4>
                        <p className="text-[10px] text-slate-500 font-mono">******3676@superyes</p>
                      </div>
                      <strong className="text-xl font-black text-slate-950 font-mono">₹{selectedTakerDetails.amountRequested.toLocaleString()}</strong>
                    </div>
                  </div>

                  <div className="bg-rose-50 rounded-2xl p-3 border border-rose-100 text-xs">
                    <span className="text-rose-800 font-extrabold block mb-1">Campaign Goal Title:</span>
                    <p className="text-slate-800 font-medium">{selectedTakerDetails.title}</p>
                    <p className="text-slate-500 text-[11px] mt-1.5 italic">"{selectedTakerDetails.description}"</p>
                  </div>

                  <div className="space-y-2 border-t border-slate-100 pt-3 text-[11px] text-slate-600 font-mono">
                    <div className="flex justify-between">
                      <span>PhonePe Transaction ID</span>
                      <span className="text-slate-800 font-bold">T2607081220531329384450</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Debited From</span>
                      <span className="text-slate-800 font-bold">XXXXXXXX871403</span>
                    </div>
                    <div className="flex justify-between">
                      <span>UTR Number</span>
                      <span className="text-slate-800 font-bold text-rose-700">207569973264</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 flex gap-2">
                  <button
                    onClick={() => {
                      alert('PhonePe receipt simulated download.');
                    }}
                    className="flex-grow bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-xs py-3 rounded-xl transition-colors cursor-pointer"
                  >
                    Share Receipt
                  </button>
                  <button 
                    onClick={() => setSelectedTakerDetails(null)}
                    className="flex-grow bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs py-3 rounded-xl transition-colors cursor-pointer"
                  >
                    Done / Close
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Instant Secure Gateway Checkout Modal */}
      <AnimatePresence>
        {showPaymentGateway && (
          <div className="fixed inset-0 z-50 bg-slate-900/85 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-100 flex flex-col"
            >
              {/* Gateway Top Bar */}
              <div className="bg-slate-950 p-5 text-white flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center font-black text-slate-950 text-sm">
                    H
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm tracking-tight">HELP 100 Secure Gateway</h3>
                    <p className="text-[10px] text-slate-400 font-medium">Direct Platform Secure Node</p>
                  </div>
                </div>
                <div className="bg-emerald-500/10 px-2 py-0.5 rounded-full text-emerald-400 border border-emerald-500/20 text-[9px] uppercase font-bold tracking-wider">
                  Test Sandbox
                </div>
              </div>

              {/* Status Indicator Bar */}
              <div className="bg-slate-50 border-b border-slate-100 px-5 py-2.5 flex justify-between items-center text-xs font-medium text-slate-500">
                <span>Order ID: <span className="font-mono text-slate-800 font-bold">{gatewayTxId}</span></span>
                <span className="text-emerald-600 font-black">₹ {gatewayAmount.toLocaleString()}</span>
              </div>

              {/* Gateway Steps Content */}
              <div className="p-5 flex-grow">
                {gatewayStep === 'details' && (
                  <div className="space-y-4">
                    <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-100/50 text-[11px] text-emerald-800 flex items-start gap-2">
                      <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <strong>Direct Platform Deposit:</strong> This payment goes directly to the system treasury to fund wallet reserves. It is <strong>NOT</strong> a peer-to-peer (user-to-user) direct transfer.
                      </div>
                    </div>

                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">Select Payment Option</label>
                    
                    <div className="grid grid-cols-2 gap-3">
                      {/* Option: PhonePe / UPI */}
                      <button
                        type="button"
                        onClick={() => setDepositMethod('UPI')}
                        className={`p-3 rounded-xl border-2 text-left transition-all ${
                          depositMethod === 'UPI' 
                            ? 'border-emerald-600 bg-emerald-50/30' 
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <span className="font-extrabold text-xs block text-slate-950">PhonePe / UPI</span>
                        <span className="text-[10px] text-slate-500 mt-1 block">Instant app redirection</span>
                      </button>

                      {/* Option: Credit Card */}
                      <button
                        type="button"
                        onClick={() => setDepositMethod('Card')}
                        className={`p-3 rounded-xl border-2 text-left transition-all ${
                          depositMethod === 'Card' 
                            ? 'border-emerald-600 bg-emerald-50/30' 
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <span className="font-extrabold text-xs block text-slate-950">Debit/Credit Card</span>
                        <span className="text-[10px] text-slate-500 mt-1 block">Visa, Mastercard, RuPay</span>
                      </button>

                      {/* Option: Netbanking */}
                      <button
                        type="button"
                        onClick={() => setDepositMethod('Netbanking')}
                        className={`p-3 rounded-xl border-2 text-left transition-all col-span-2 ${
                          depositMethod === 'Netbanking' 
                            ? 'border-emerald-600 bg-emerald-50/30' 
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <span className="font-extrabold text-xs block text-slate-950">Instant Net Banking</span>
                        <span className="text-[10px] text-slate-500 mt-0.5 block">State Bank, HDFC, ICICI, Axis</span>
                      </button>
                    </div>

                    {/* Inputs based on selection */}
                    {depositMethod === 'Card' && (
                      <div className="space-y-3 pt-2">
                        <div>
                          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Card Number</label>
                          <input 
                            type="text" 
                            placeholder="4111 2222 3333 4444" 
                            defaultValue="4111222233334444"
                            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Expiry Date</label>
                            <input 
                              type="text" 
                              placeholder="MM/YY" 
                              defaultValue="12/28"
                              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">CVV</label>
                            <input 
                              type="password" 
                              placeholder="123" 
                              defaultValue="123"
                              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {depositMethod === 'UPI' && (
                      <div className="pt-2 bg-slate-50 p-3 rounded-xl text-center space-y-2">
                        <p className="text-xs font-semibold text-slate-700">Simulate UPI App Redirect</p>
                        <p className="text-[10px] text-slate-500">Will use pre-authorized sandboxed UPI protocols to instant-verify ₹{gatewayAmount.toLocaleString()}.</p>
                      </div>
                    )}

                    {depositMethod === 'Netbanking' && (
                      <div className="pt-2 bg-slate-50 p-3 rounded-xl text-center space-y-2">
                        <p className="text-xs font-semibold text-slate-700">Select Sandbox Bank Node</p>
                        <select className="w-full px-2 py-1.5 border border-slate-200 rounded text-xs bg-white cursor-pointer">
                          <option>State Bank of India (SBI)</option>
                          <option>HDFC Bank</option>
                          <option>ICICI Bank</option>
                          <option>Axis Bank</option>
                        </select>
                      </div>
                    )}

                    {/* Pay Button */}
                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setGatewayStep('paying');
                          setTimeout(() => {
                            setGatewayStep('success');
                          }, 2500);
                        }}
                        className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-colors cursor-pointer"
                      >
                        Pay ₹{gatewayAmount.toLocaleString()} Securely
                      </button>
                    </div>

                    <div className="text-center">
                      <button
                        type="button"
                        onClick={() => setShowPaymentGateway(false)}
                        className="text-[11px] text-slate-400 hover:text-slate-600 underline font-medium cursor-pointer"
                      >
                        Cancel Transaction
                      </button>
                    </div>
                  </div>
                )}

                {gatewayStep === 'paying' && (
                  <div className="py-12 flex flex-col items-center justify-center space-y-4">
                    {/* Beautiful payment gateway spinner */}
                    <div className="relative w-16 h-16">
                      <div className="absolute inset-0 rounded-full border-4 border-slate-100"></div>
                      <div className="absolute inset-0 rounded-full border-4 border-t-emerald-600 animate-spin"></div>
                    </div>
                    <div className="text-center">
                      <h4 className="font-extrabold text-slate-900 text-sm">Authorizing Gateway Node</h4>
                      <p className="text-[11px] text-slate-500 mt-1">Please do not refresh or close this sandbox payment link...</p>
                    </div>
                  </div>
                )}

                {gatewayStep === 'success' && (
                  <div className="py-6 flex flex-col items-center justify-center text-center space-y-4">
                    {/* success circle icon */}
                    <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
                      <CheckCircle className="w-10 h-10" />
                    </div>
                    <div>
                      <h4 className="font-black text-slate-900 text-base">Payment Succeeded!</h4>
                      <p className="text-xs text-slate-500 mt-1.5 max-w-xs mx-auto">
                        Transaction of <strong className="text-slate-950">₹{gatewayAmount.toLocaleString()}</strong> completed via secure direct platform link.
                      </p>
                    </div>

                    <div className="bg-slate-50 p-3 rounded-xl w-full text-left text-[11px] font-mono text-slate-600 space-y-1 border border-slate-100">
                      <div className="flex justify-between">
                        <span>Transaction ID:</span>
                        <span className="text-slate-950 font-bold">{gatewayTxId}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Gateway Link:</span>
                        <span className="text-slate-500 truncate max-w-[180px]">checkout.help100.com/pay/{gatewayTxId.substring(0, 8)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Status:</span>
                        <span className="text-emerald-600 font-extrabold uppercase">SUCCESSFUL</span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setShowPaymentGateway(false);
                        handleInstantDepositSuccess(gatewayAmount, gatewayTxId, depositMethod);
                      }}
                      className="w-full py-3 bg-slate-900 hover:bg-slate-950 text-white rounded-xl text-xs font-extrabold uppercase tracking-wider transition-all cursor-pointer"
                    >
                      Verify & Add to Wallet Balance
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Secure Direct Payout Claim Gateway Modal (Withdrawal Link Portal) */}
      <AnimatePresence>
        {showSecureClaimGateway && (
          <div className="fixed inset-0 z-50 bg-slate-900/85 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-100 flex flex-col max-h-[90vh]"
            >
              {/* Gateway Top Bar */}
              <div className="bg-slate-950 p-5 text-white flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-teal-500 flex items-center justify-center font-black text-slate-950 text-sm">
                    W
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm tracking-tight">HELP 100 Secure Withdrawal Portal</h3>
                    <p className="text-[10px] text-slate-400 font-medium">Direct Payout Routing Node</p>
                  </div>
                </div>
                <div className="bg-teal-500/10 px-2 py-0.5 rounded-full text-teal-400 border border-teal-500/20 text-[9px] uppercase font-bold tracking-wider">
                  Direct Payout
                </div>
              </div>

              {/* Modal Body */}
              <div className="p-6 overflow-y-auto space-y-6 text-slate-800">
                {claimSuccessMsg ? (
                  <div className="text-center py-6 space-y-4">
                    <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                      <CheckCircle className="w-10 h-10" />
                    </div>
                    <h2 className="text-xl font-extrabold text-slate-900">Withdrawal Successful!</h2>
                    <p className="text-xs text-slate-600 px-4 leading-relaxed font-semibold">
                      {claimSuccessMsg}
                    </p>
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 text-left font-mono text-[10px] text-slate-500 space-y-1">
                      <p><strong>Beneficiary:</strong> {currentUser.name}</p>
                      <p><strong>Route Code:</strong> {claimGatewayRoute === 'primary' ? 'ROUTE-PRIMARY-A' : 'ROUTE-SECONDARY-B'}</p>
                      <p><strong>Payout Destination:</strong> {claimGatewayRoute === 'primary' ? (currentUser.upiId || 'user@upi') : (currentUser.secondaryUpiId || 'user.sec@upi')}</p>
                      <p><strong>Clearing Time:</strong> Instant Settlement</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setShowSecureClaimGateway(false);
                        setClaimSuccessMsg('');
                      }}
                      className="px-6 py-2.5 bg-slate-950 hover:bg-black text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
                    >
                      Return to Dashboard
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="space-y-1.5">
                      <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Help Aid Payout</h4>
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl font-black text-slate-900">₹175.00</span>
                        <span className="text-xs font-semibold text-slate-400">Total Matching Aid</span>
                      </div>
                      <p className="text-xs text-slate-500 leading-relaxed">
                        This withdrawal link matches your ₹100 contribution with equalizing peer assistance payouts of ₹175 total. Choose your preferred payout route below to execute.
                      </p>
                    </div>

                    {/* 24-Hour Secure Timer Widget */}
                    <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/20 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 shadow-sm">
                      <div className="flex items-center gap-2">
                        <Clock className="w-5 h-5 text-red-500 animate-pulse" />
                        <div>
                          <span className="text-[10px] uppercase font-extrabold text-red-800 tracking-wider block">Time Left to Settle Link</span>
                          <span className="text-[9px] text-red-700/80">Strict 24-hour P2P validity rule</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-black text-lg tracking-widest text-red-600 bg-red-100/50 border border-red-200 px-3 py-1 rounded-xl shadow-inner inline-block">
                          {(() => {
                            const h = Math.floor(gatewayTimer / 3600).toString().padStart(2, '0');
                            const m = Math.floor((gatewayTimer % 3600) / 60).toString().padStart(2, '0');
                            const s = (gatewayTimer % 60).toString().padStart(2, '0');
                            return `${h}:${m}:${s}`;
                          })()}
                        </span>
                      </div>
                    </div>

                    {/* Route Selector Cards */}
                    <div className="space-y-3">
                      <label className="block text-xs font-extrabold text-slate-500 uppercase tracking-wider">Select Payout Route Detail</label>
                      
                      <div className="grid sm:grid-cols-2 gap-3">
                        {/* Route 1: Primary Bank Details */}
                        <div
                          onClick={() => setClaimGatewayRoute('primary')}
                          className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between h-36 ${
                            claimGatewayRoute === 'primary'
                              ? 'border-teal-500 bg-teal-50/10 shadow-sm'
                              : 'border-slate-100 bg-slate-50/50 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-black text-slate-400 uppercase">Route 1 (Primary)</span>
                            <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                              claimGatewayRoute === 'primary' ? 'border-teal-500' : 'border-slate-300'
                            }`}>
                              {claimGatewayRoute === 'primary' && <div className="w-2 h-2 rounded-full bg-teal-500" />}
                            </div>
                          </div>
                          <div>
                            <p className="font-extrabold text-xs text-slate-900 leading-tight">
                              {currentUser.bankName || 'Not Configured'}
                            </p>
                            <p className="text-[10px] text-slate-500 mt-0.5 font-mono">
                              A/C: {currentUser.accountNumber || 'N/A'}
                            </p>
                            <p className="text-[10px] text-slate-500 font-mono">
                              IFSC: {currentUser.ifscCode || 'N/A'}
                            </p>
                          </div>
                          <div className="pt-2 border-t border-slate-100/50 flex justify-between items-center text-[9px] font-semibold text-slate-500">
                            <span>UPI:</span>
                            <span className="font-mono font-bold text-slate-800">{currentUser.upiId || 'N/A'}</span>
                          </div>
                        </div>

                        {/* Route 2: Secondary Bank Details */}
                        <div
                          onClick={() => setClaimGatewayRoute('secondary')}
                          className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between h-36 ${
                            claimGatewayRoute === 'secondary'
                              ? 'border-teal-500 bg-teal-50/10 shadow-sm'
                              : 'border-slate-100 bg-slate-50/50 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-black text-slate-400 uppercase">Route 2 (Secondary)</span>
                            <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                              claimGatewayRoute === 'secondary' ? 'border-teal-500' : 'border-slate-300'
                            }`}>
                              {claimGatewayRoute === 'secondary' && <div className="w-2 h-2 rounded-full bg-teal-500" />}
                            </div>
                          </div>
                          <div>
                            <p className="font-extrabold text-xs text-slate-900 leading-tight">
                              {currentUser.secondaryBankName || 'Not Configured'}
                            </p>
                            <p className="text-[10px] text-slate-500 mt-0.5 font-mono">
                              A/C: {currentUser.secondaryAccountNumber || 'N/A'}
                            </p>
                            <p className="text-[10px] text-slate-500 font-mono">
                              IFSC: {currentUser.secondaryIfscCode || 'N/A'}
                            </p>
                          </div>
                          <div className="pt-2 border-t border-slate-100/50 flex justify-between items-center text-[9px] font-semibold text-slate-500">
                            <span>UPI:</span>
                            <span className="font-mono font-bold text-slate-800">{currentUser.secondaryUpiId || 'N/A'}</span>
                          </div>
                        </div>
                      </div>

                      {/* If details are missing, show link to My Profile */}
                      {((claimGatewayRoute === 'primary' && (!currentUser.upiId || !currentUser.bankName)) ||
                        (claimGatewayRoute === 'secondary' && (!currentUser.secondaryUpiId || !currentUser.secondaryBankName))) && (
                        <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-800 text-[10px] leading-tight flex items-start gap-2">
                          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
                          <div>
                            <p className="font-bold">Missing Bank or UPI details for this Route!</p>
                            <p className="text-[9px] text-slate-600 mt-0.5">
                              Please complete your banking details in your profile. You can also configure them right now in the profile section.
                            </p>
                            <button
                              type="button"
                              onClick={() => {
                                setShowSecureClaimGateway(false);
                                setActiveSubTab('profile');
                              }}
                              className="mt-1.5 px-2 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg uppercase tracking-wider text-[8px]"
                            >
                              Go Set Up Details
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Slip Upload Option */}
                      <div className="space-y-2 mt-4 pt-4 border-t border-slate-100">
                        <label className="block text-xs font-extrabold text-slate-500 uppercase tracking-wider">
                          Upload Settlement Receipt / Slip Proof
                        </label>
                        
                        <div className="border-2 border-dashed border-slate-200 hover:border-teal-500/50 rounded-2xl p-4 bg-slate-50 text-center transition-colors relative cursor-pointer group">
                          <input
                            type="file"
                            accept="image/*,.pdf"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                setClaimProofFilename(file.name);
                              }
                            }}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                          />
                          <Upload className="w-6 h-6 text-slate-400 group-hover:text-teal-500 mx-auto mb-1.5 transition-colors" />
                          {claimProofFilename ? (
                            <div className="space-y-1">
                              <span className="text-teal-600 font-bold block text-xs truncate max-w-xs mx-auto">
                                📎 {claimProofFilename}
                              </span>
                              <span className="text-[10px] text-slate-500 block">Settlement slip attached</span>
                            </div>
                          ) : (
                            <div>
                              <span className="text-xs text-slate-600 font-bold block">Drag & drop or click to upload settlement slip</span>
                              <span className="text-[9px] text-slate-400 mt-0.5 block">Supports JPG, PNG, PDF up to 5MB</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-3 pt-3">
                      <button
                        type="button"
                        onClick={() => {
                          setShowSecureClaimGateway(false);
                        }}
                        className="flex-1 py-3 bg-slate-50 hover:bg-slate-100 text-slate-500 text-xs font-extrabold uppercase rounded-2xl transition-all cursor-pointer border border-slate-150"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        disabled={
                          claimProcessing ||
                          (claimGatewayRoute === 'primary' && (!currentUser.upiId || !currentUser.bankName)) ||
                          (claimGatewayRoute === 'secondary' && (!currentUser.secondaryUpiId || !currentUser.secondaryBankName))
                        }
                        onClick={() => {
                          handleInstantClaimPayout(claimGatewayRoute);
                        }}
                        className="flex-1 py-3 bg-teal-600 hover:bg-teal-700 disabled:opacity-40 disabled:hover:bg-teal-600 text-white text-xs font-black uppercase rounded-2xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                      >
                        {claimProcessing ? (
                          <>
                            <Clock className="w-4 h-4 animate-spin" />
                            Executing...
                          </>
                        ) : (
                          <>
                            🚀 Confirm Instant Payout
                          </>
                        )}
                      </button>
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 24-Hour Secure Direct P2P Gateway Matching Portal */}
      <AnimatePresence>
        {activeGateway && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className={`w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border-2 flex flex-col my-8 ${
                gatewayTab === 'ph' 
                  ? 'bg-slate-950 border-red-500/40 text-white' 
                  : 'bg-slate-950 border-blue-500/40 text-white'
              }`}
            >
              {/* Animated Glowing Color Bar */}
              <div className={`h-2.5 w-full ${
                gatewayTab === 'ph' ? 'bg-gradient-to-r from-red-600 to-rose-400' : 'bg-gradient-to-r from-blue-600 to-cyan-400'
              }`} />

              {/* Portal Header */}
              <div className="p-6 border-b border-slate-800 bg-slate-900/60">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black ${
                      gatewayTab === 'ph' 
                        ? 'bg-red-500/20 text-red-400 border border-red-500/30' 
                        : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                    }`}>
                      {gatewayTab === 'ph' ? 'PH' : 'GH'}
                    </div>
                    <div>
                      <h3 className="font-extrabold text-base tracking-tight text-white">
                        {gatewayTab === 'ph' ? 'Secure Provide Help Portal' : 'Secure Get Help Portal'}
                      </h3>
                      <p className="text-[10px] text-slate-400 font-mono tracking-wide">
                        TRANSACTION REF: {activeGateway.id.toUpperCase()}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setActiveGateway(null);
                      setGatewayProofFilename('');
                    }}
                    className="w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                  >
                    ✕
                  </button>
                </div>

                {/* 24-Hour Timer Widget */}
                <div className="mt-5 p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 shadow-inner">
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-red-500 animate-pulse" />
                    <div>
                      <span className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider block">Time Left to Settle Link</span>
                      <span className="text-xs text-slate-500">24-hour strict P2P protocol rule</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-black text-2xl tracking-widest text-red-400 bg-red-950/40 border border-red-900/50 px-3.5 py-1 rounded-xl shadow-lg inline-block">
                      {(() => {
                        const h = Math.floor(gatewayTimer / 3600).toString().padStart(2, '0');
                        const m = Math.floor((gatewayTimer % 3600) / 60).toString().padStart(2, '0');
                        const s = (gatewayTimer % 60).toString().padStart(2, '0');
                        return `${h}:${m}:${s}`;
                      })()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Portal Content Section */}
              <div className="p-6 space-y-6 flex-grow max-h-[50vh] overflow-y-auto custom-scrollbar">

                {gatewayTab === 'ph' && (
                  <div className={`p-3.5 rounded-2xl text-xs flex items-center gap-3 border ${
                    userWithMillionInGh 
                      ? 'bg-amber-950/40 border-amber-500/30 text-amber-200' 
                      : 'bg-red-950/40 border-red-500/30 text-red-200'
                  }`}>
                    <div className="p-2 rounded-xl bg-slate-900 shrink-0 text-base">
                      {userWithMillionInGh ? '🔥' : '🛡️'}
                    </div>
                    <div>
                      <span className="font-extrabold uppercase tracking-wide text-[10px] block">
                        {userWithMillionInGh ? 'Promotional P2P Matching Active' : 'Standard Secure Routing'}
                      </span>
                      <p className="text-slate-400 text-[10px] mt-0.5 leading-relaxed">
                        {userWithMillionInGh 
                          ? `Matched with active ₹1,000,000 GH request holder: ${userWithMillionInGh.name}. Your contribution is routed directly to them.` 
                          : 'No active ₹1,000,000 GH campaign detected. Your contribution is securely routed to the Admin Treasury Node.'}
                      </p>
                    </div>
                  </div>
                )}
                
                {/* Peer / Recipient Identity Panel */}
                <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4.5 space-y-3.5">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <span className="text-slate-400 text-xs font-semibold">
                      {gatewayTab === 'ph' ? 'Matching Recipient Details (Taker):' : 'Your Recipient Details (Taker):'}
                    </span>
                    <span className={`text-xs font-black px-2.5 py-0.5 rounded-full ${
                      gatewayTab === 'ph' ? 'bg-red-500/10 text-red-400' : 'bg-blue-500/10 text-blue-400'
                    }`}>
                      ₹ {activeGateway.amount} /-
                    </span>
                  </div>

                  {/* Peer Particulars */}
                  <div className="grid grid-cols-2 gap-4 text-xs font-medium">
                    <div>
                      <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Name</span>
                      <span className="text-slate-200 mt-0.5 block">
                        {currentRecipient.name}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Mobile Number</span>
                      <span className="text-slate-200 mt-0.5 block font-mono">
                        {currentRecipient.phone}
                      </span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Email ID</span>
                      <span className="text-slate-200 mt-0.5 block">
                        {currentRecipient.email}
                      </span>
                    </div>
                  </div>

                  {/* Bank Details Block */}
                  {(() => {
                    const activeBankName = selectedGatewayRoute === 'primary' 
                      ? currentRecipient.bankName 
                      : (currentRecipient.secondaryBankName || currentRecipient.bankName);
                    
                    const activeAccountNumber = selectedGatewayRoute === 'primary' 
                      ? currentRecipient.accountNumber 
                      : (currentRecipient.secondaryAccountNumber || currentRecipient.accountNumber);
                    
                    const activeIfscCode = selectedGatewayRoute === 'primary' 
                      ? currentRecipient.ifscCode 
                      : (currentRecipient.secondaryIfscCode || currentRecipient.ifscCode);

                    const activeUpiId = selectedGatewayRoute === 'primary' 
                      ? currentRecipient.upiId 
                      : (currentRecipient.secondaryUpiId || currentRecipient.upiId);

                    const activeQrUrl = selectedGatewayRoute === 'primary' 
                      ? currentRecipient.qrUrl 
                      : (currentRecipient.secondaryUpiId 
                          ? `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=upi://pay?pa=${currentRecipient.secondaryUpiId}%26pn=${encodeURIComponent(currentRecipient.name)}%26am=${activeGateway?.amount || 50}`
                          : currentRecipient.qrUrl);

                    return (
                      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs space-y-2.5">
                        
                        {/* Route Selector Tab Bar */}
                        {(currentRecipient.secondaryBankName || currentRecipient.secondaryUpiId) && (
                          <div className="flex gap-1.5 p-1 bg-slate-900 rounded-lg border border-slate-800/80 mb-1">
                            <button
                              type="button"
                              onClick={() => setSelectedGatewayRoute('primary')}
                              className={`flex-1 py-1 text-[9px] font-black uppercase rounded transition-all cursor-pointer ${
                                selectedGatewayRoute === 'primary' 
                                  ? gatewayTab === 'gh'
                                    ? 'bg-gradient-to-r from-[#0D6EFD] to-[#00BFFF] text-white shadow-sm'
                                    : 'bg-emerald-600 text-white shadow-sm' 
                                  : 'text-slate-400 hover:text-slate-200'
                              }`}
                            >
                              Route 1 (Primary)
                            </button>
                            <button
                              type="button"
                              onClick={() => setSelectedGatewayRoute('secondary')}
                              className={`flex-1 py-1 text-[9px] font-black uppercase rounded transition-all cursor-pointer ${
                                selectedGatewayRoute === 'secondary' 
                                  ? 'bg-blue-600 text-white shadow-sm' 
                                  : 'text-slate-400 hover:text-slate-200'
                              }`}
                            >
                              Route 2 (Backup)
                            </button>
                          </div>
                        )}

                        <div className="flex items-center justify-between border-b border-slate-900 pb-1.5">
                          <span className="text-slate-400 font-bold">
                            Direct Bank Account Details {selectedGatewayRoute === 'secondary' && <span className="text-blue-400 text-[10px] ml-1">(Route 2)</span>}
                          </span>
                          <span className="text-[9px] bg-slate-900 text-slate-400 px-1.5 py-0.5 rounded font-bold font-mono">NEFT / IMPS</span>
                        </div>
                    <div className="grid grid-cols-2 gap-2.5 font-mono">
                      <div>
                        <span className="text-slate-500 text-[9px] uppercase font-bold tracking-wider block">Beneficiary Name</span>
                        <span className="text-slate-300 font-bold text-[11px]">
                          {currentRecipient.beneficiaryName}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[9px] uppercase font-bold tracking-wider block">Bank Name</span>
                        <span className="text-slate-300 font-bold text-[11px]">
                          {activeBankName}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[9px] uppercase font-bold tracking-wider block">Account Number</span>
                        <span className="text-slate-200 font-bold text-xs select-all flex items-center gap-1">
                          {activeAccountNumber}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[9px] uppercase font-bold tracking-wider block">IFSC Code</span>
                        <span className="text-slate-200 font-bold text-xs select-all">
                          {activeIfscCode}
                        </span>
                      </div>
                    </div>

                    {/* QR Code / UPI Details for Payments */}
                    {activeQrUrl && (
                      <div className={`pt-2.5 border-t border-slate-900 mt-1 flex flex-col sm:flex-row items-center gap-3 p-2.5 rounded-lg border ${
                        gatewayTab === 'ph' 
                          ? (selectedGatewayRoute === 'secondary' ? 'bg-blue-950/20 border-blue-950/40' : 'bg-red-950/20 border-red-950/40') 
                          : 'bg-blue-950/20 border-blue-950/40'
                      }`}>
                        <div className="w-16 h-16 bg-white p-1 rounded-lg flex items-center justify-center shrink-0">
                          <img
                            src={activeQrUrl}
                            alt="UPI QR Code"
                            className="w-full h-full"
                          />
                        </div>
                        <div className="text-xs space-y-1">
                          <span className={`font-extrabold block text-[10px] uppercase tracking-wider ${
                            gatewayTab === 'ph' 
                              ? (selectedGatewayRoute === 'secondary' ? 'text-blue-400' : 'text-red-400') 
                              : 'text-blue-400'
                          }`}>
                            {gatewayTab === 'ph' 
                              ? (currentRecipient.isPromoMatch ? '⚡ Promotional Match Option' : `UPI Option (${selectedGatewayRoute === 'primary' ? 'Route 1' : 'Route 2'})`)
                              : 'Your Get Help QR Code (Receive)'}
                          </span>
                          <p className="text-slate-300 font-semibold font-mono">{activeUpiId}</p>
                          <p className="text-[9px] text-slate-500 leading-tight">
                            {gatewayTab === 'ph' 
                              ? (currentRecipient.isPromoMatch 
                                ? 'Scan QR or copy UPI to make direct P2P payment to ₹1,000,000 GH request holder.' 
                                : `Scan QR code or copy UPI ID to make payment via PhonePe, GPay, or Paytm to this recipient's ${selectedGatewayRoute === 'primary' ? 'primary' : 'backup'} route.`)
                              : 'Show this QR code or provide your UPI ID to receive direct mutual aid payouts from peer donors.'}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}

                    {/* Optional Custom QR Code Generator Component */}
                    {activeGateway.type === 'ph' && (
                      <div className="pt-2 border-t border-slate-900 mt-2">
                        <button
                          type="button"
                          onClick={() => setShowQrGenerator(!showQrGenerator)}
                          className="w-full flex items-center justify-between px-3 py-2 rounded bg-slate-900 hover:bg-slate-850 text-[11px] font-black uppercase text-indigo-400 tracking-wider transition-colors cursor-pointer"
                        >
                          <span>{showQrGenerator ? 'hide custom qr generator' : 'show custom p2p qr generator'}</span>
                          <span className="text-xs">{showQrGenerator ? '▲' : '▼'}</span>
                        </button>

                        {showQrGenerator && (
                          <div className="mt-2.5 bg-indigo-950/30 p-3 rounded-lg border border-indigo-500/20 space-y-3">
                            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">
                              Custom P2P QR Code Generator
                            </span>

                            <div className="flex flex-col sm:flex-row gap-3 items-center">
                              {/* QR Code display */}
                              <div className="bg-white p-2.5 rounded-lg flex flex-col items-center justify-center shrink-0 shadow-md">
                                <QRCodeSVG
                                  value={`upi://pay?pa=${encodeURIComponent(customQrUpi)}&pn=${encodeURIComponent(customQrName)}&am=${customQrAmount}&cu=INR`}
                                  size={110}
                                  level="M"
                                  includeMargin={true}
                                />
                                <span className="text-[8px] text-slate-500 mt-1 font-bold font-mono">Scan with any UPI App</span>
                              </div>

                              {/* Form inputs for live updates */}
                              <div className="flex-grow w-full space-y-1.5 text-[10px]">
                                <div>
                                  <label className="text-slate-500 font-bold uppercase tracking-wider block">Payee UPI ID</label>
                                  <input
                                    type="text"
                                    value={customQrUpi}
                                    onChange={(e) => setCustomQrUpi(e.target.value)}
                                    placeholder="e.g. name@okaxis"
                                    className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200 font-mono font-bold focus:outline-none focus:border-indigo-500 text-xs"
                                  />
                                </div>
                                <div>
                                  <label className="text-slate-500 font-bold uppercase tracking-wider block">Payee Name</label>
                                  <input
                                    type="text"
                                    value={customQrName}
                                    onChange={(e) => setCustomQrName(e.target.value)}
                                    placeholder="e.g. Rajesh Kumar"
                                    className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200 font-bold focus:outline-none focus:border-indigo-500 text-xs"
                                  />
                                </div>
                                <div>
                                  <label className="text-slate-500 font-bold uppercase tracking-wider block">Payment Amount (₹)</label>
                                  <input
                                    type="number"
                                    value={customQrAmount}
                                    onChange={(e) => setCustomQrAmount(e.target.value)}
                                    placeholder="e.g. 50"
                                    className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200 font-mono font-bold focus:outline-none focus:border-indigo-500 text-xs"
                                  />
                                </div>
                              </div>
                            </div>

                            <div className="bg-slate-950 p-2 rounded text-[10px] font-mono break-all text-indigo-300 border border-indigo-950 flex justify-between items-center gap-1.5">
                              <span className="truncate">upi://pay?pa={customQrUpi}&pn={customQrName}&am={customQrAmount}</span>
                              <button
                                type="button"
                                onClick={() => {
                                  const uri = `upi://pay?pa=${customQrUpi}&pn=${customQrName}&am=${customQrAmount}&cu=INR`;
                                  navigator.clipboard.writeText(uri);
                                  alert('UPI custom payment URI copied to clipboard!');
                                }}
                                className="bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white px-2 py-0.5 rounded uppercase font-black tracking-wider shrink-0 transition-all cursor-pointer"
                              >
                                Copy
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                {/* GIVER SLIP UPLOAD / TAKER ACTIONS PANELS */}
                {gatewayTab === 'ph' ? (
                  // Giver Step: Upload Payment Receipt Slip
                  <div className="space-y-4">
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">
                      Upload Payment Slip Receipt
                    </label>

                    {/* File Drop Area */}
                    <div className="border-2 border-dashed border-slate-800 rounded-2xl p-5 bg-slate-900/20 text-center hover:border-red-500/50 transition-colors relative cursor-pointer group">
                      <input
                        type="file"
                        accept="image/*,.pdf"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            setGatewayProofFilename(file.name);
                          }
                        }}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      />
                      <Upload className="w-8 h-8 text-slate-500 group-hover:text-red-400 mx-auto mb-2 transition-colors" />
                      {gatewayProofFilename ? (
                        <div className="space-y-1.5">
                          <span className="text-red-400 font-bold block text-xs truncate max-w-xs mx-auto">
                            📎 {gatewayProofFilename}
                          </span>
                          <span className="text-[10px] text-slate-500 block">Ready to submit for verification</span>
                        </div>
                      ) : (
                        <div>
                          <span className="text-xs text-slate-300 font-bold block">Drag & drop or browse device file</span>
                          <span className="text-[9px] text-slate-500 mt-1 block">Supports JPG, PNG, PDF up to 5MB</span>
                        </div>
                      )}
                    </div>

                    {/* Transaction Reference/UTR Number input */}
                    <div className="space-y-1.5">
                      <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider">
                        12-Digit UPI Ref No. / UTR Number
                      </label>
                      <input
                        id="gateway-utr-input"
                        type="text"
                        maxLength={12}
                        placeholder="e.g. 207569973264"
                        className="w-full bg-slate-950 border border-slate-800 text-white rounded-xl px-4 py-2.5 text-xs font-mono font-bold focus:outline-none focus:border-red-500 transition-colors"
                      />
                    </div>
                  </div>
                ) : (
                  // Taker Step: Accept or Reject Received Help match with custom light-blue box and receipt slip preview
                  <div className="p-4 bg-blue-950/20 border-2 border-blue-500/50 rounded-2xl space-y-3 shadow-inner text-xs">
                    <span className="text-blue-400 font-black text-xs uppercase block tracking-widest text-center border-b border-blue-500/20 pb-1.5">
                      📑 MATCHED GH PAYMENT SLIP & RECEIPT
                    </span>
                    
                    {/* Payment slip visual representation */}
                    <div className="bg-slate-950 p-2.5 rounded-xl border border-blue-500/20 flex flex-col items-center gap-2">
                      <div className="w-full h-40 bg-slate-900 rounded-lg flex flex-col justify-between p-3 font-mono text-[10px] text-blue-300 border border-blue-500/30 overflow-hidden relative">
                        <div className="absolute top-2 right-2 bg-blue-500 text-slate-950 font-black text-[8px] uppercase px-1.5 py-0.5 rounded shadow">
                          UPLOADED BY DONOR
                        </div>
                        <div className="flex justify-between items-start border-b border-blue-500/20 pb-1.5">
                          <div>
                            <span className="font-bold text-white uppercase text-[10px]">BHIM UPI TRANS</span>
                            <p className="text-[7px] text-blue-400/70">SUCCESSFUL P2P RECEIPT</p>
                          </div>
                          <span className="text-right text-blue-400 font-black text-[11px]">₹{activeGateway.amount}.00</span>
                        </div>
                        
                        <div className="space-y-0.5 my-1 text-[9px]">
                          <div className="flex justify-between">
                            <span className="text-blue-400/60">SENDER:</span>
                            <span className="text-white truncate">Giver (Peer Donor ID: {activeGateway.id.substring(0, 8).toUpperCase()})</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-blue-400/60">BENEFICIARY:</span>
                            <span className="text-white truncate">{currentUser.name}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-blue-400/60">TXN REF / UTR:</span>
                            <span className="text-blue-200 select-all font-bold">207569973264</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-blue-400/60">DATE & TIME:</span>
                            <span className="text-white">{new Date().toLocaleString()}</span>
                          </div>
                        </div>
                        
                        <div className="border-t border-blue-500/20 pt-1 flex items-center justify-center gap-1 text-[8px] text-blue-400/60 font-bold">
                          <span>● SECURE TRANSACTION BANK SEAL</span>
                        </div>
                      </div>
                      
                      <p className="text-[9px] text-slate-400 text-center leading-relaxed font-semibold mt-1">
                        Payer has uploaded their proof slip (above). Please verify the credit in your account first.
                      </p>
                    </div>

                    <div className="bg-blue-950/40 p-2.5 rounded-lg border border-blue-500/20 text-[10px] text-slate-300 leading-relaxed font-semibold">
                      <span className="text-blue-400 font-black block text-[9px] mb-0.5 uppercase">TAKER SECURITY MANDATE:</span>
                      Verify that your bank account or UPI has been credited with the exact amount of <strong className="font-mono text-white">₹{activeGateway.amount}</strong> from the matching payer. Approving credits the amount to your wallet and updates the cycle ledger.
                    </div>
                  </div>
                )}
              </div>

              {/* Portal Action Footer */}
              <div className="p-6 border-t border-slate-800 bg-slate-900/40 flex flex-col sm:flex-row gap-3">
                {gatewayTab === 'ph' ? (
                  // Giver PH submission actions
                  <>
                    <button
                      onClick={() => {
                        setActiveGateway(null);
                        setGatewayProofFilename('');
                      }}
                      className="w-full sm:w-1/3 py-3 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-bold transition-all cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        const utrInput = document.getElementById('gateway-utr-input') as HTMLInputElement;
                        const utrValue = utrInput?.value.trim();
                        if (!gatewayProofFilename) {
                          alert('Please select or upload a payment receipt slip first.');
                          return;
                        }
                        if (!utrValue || utrValue.length < 8) {
                          alert('Please enter a valid Transaction ID or UTR Reference number.');
                          return;
                        }

                        // Complete PH step
                        if (onUpdateContribution) {
                          onUpdateContribution(
                            activeGateway.id, 
                            'approved', 
                            `Direct User-to-User Payment Confirmed (UTR: ${utrValue})`
                          );
                          alert('Awesome! Payment slip submitted successfully and confirmed directly (User-to-User)!');
                        }
                        setActiveGateway(null);
                        setGatewayProofFilename('');
                      }}
                      className="w-full sm:w-2/3 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-lg shadow-red-900/30 cursor-pointer"
                    >
                      Submit Payment Slip
                    </button>
                  </>
                ) : (
                  // Taker GH verification actions (Accept / Reject)
                  <>
                    <button
                      onClick={() => {
                        const reason = prompt('Please enter a brief rejection reason (e.g. Payment not received / Invalid proof):');
                        if (reason === null) return; // cancel
                        
                        if (onUpdateTransaction) {
                          onUpdateTransaction(
                            activeGateway.id, 
                            'rejected'
                          );
                          alert('Rejection recorded! Matching donor has been flagged for administrative review.');
                        }
                        setActiveGateway(null);
                      }}
                      className="w-full sm:w-1/2 py-3 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow cursor-pointer"
                    >
                      Reject / Not Received
                    </button>
                    <button
                      onClick={() => {
                        if (confirm('Are you absolutely sure you have received the payment of ₹' + activeGateway.amount + ' in your bank account? This is irreversible.')) {
                          if (onUpdateTransaction) {
                            onUpdateTransaction(
                              activeGateway.id, 
                              'completed', 
                              'Direct P2P Match Approved by Recipient.'
                            );
                          }
                          if (onUpdateHelpRequest) {
                            onUpdateHelpRequest(
                              activeGateway.id,
                              'completed',
                              activeGateway.amount,
                              'Direct P2P Match Approved by Recipient.'
                            );
                          }
                          alert('Success! Payout match approved and finalized. Wallet successfully credited!');
                          setActiveGateway(null);
                        }
                      }}
                      className="w-full sm:w-1/2 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:opacity-95 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-lg shadow-emerald-500/20 cursor-pointer"
                    >
                      Accept & Confirm Receipt
                    </button>
                  </>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Giver Payment Slip Full Preview Modal */}
      <AnimatePresence>
        {activeSlipPreview && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-lg overflow-hidden bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl text-slate-100 my-8"
            >
              {/* Header Accent Bar - Custom Gold/Yellow Gradient */}
              <div className="h-2.5 bg-gradient-to-r from-[#FFD700] via-yellow-400 to-[#FFC107] shadow-md shadow-[#FFC107]/20" />
              
              {/* Close Button */}
              <button
                type="button"
                onClick={() => {
                  setActiveSlipPreview(null);
                  setUtrVerificationResult(null);
                  setIsVerifyingUtr(false);
                }}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white bg-slate-800/60 hover:bg-slate-800 rounded-full transition-all cursor-pointer z-10 border border-white/5"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="p-6 sm:p-8 space-y-6">
                {/* Visual Status Indicator - Styled with Beautiful Gold Gradient Accent */}
                <div className="text-center space-y-2">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#FFC107]/10 text-[#FFC107] border border-[#FFD700]/30 shadow-inner">
                    <CheckCircle className="w-9 h-9 animate-pulse" />
                  </div>
                  <h3 className="text-lg font-black tracking-wider uppercase bg-gradient-to-r from-[#FFD700] to-[#FFC107] bg-clip-text text-transparent">
                    Verify Payment Slip
                  </h3>
                  <p className="text-xs text-slate-400 font-medium">
                    Peer-to-Peer Mutual Aid Transfer Receipt
                  </p>
                </div>

                {/* Simulated Digital Receipt Slip */}
                <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-5 space-y-4 font-mono text-xs">
                  <div className="flex justify-between items-center pb-2.5 border-b border-slate-800/60">
                    <span className="text-slate-500 uppercase tracking-wider font-sans text-[10px] font-bold">Giver (Sender)</span>
                    <span className="text-slate-200 font-bold font-sans text-right truncate max-w-[150px]">{activeSlipPreview.giverName}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2.5 border-b border-slate-800/60">
                    <span className="text-slate-500 uppercase tracking-wider font-sans text-[10px] font-bold">Taker (Recipient)</span>
                    <span className="text-slate-200 font-bold font-sans text-right truncate max-w-[150px]">{activeSlipPreview.takerName}</span>
                  </div>
                  
                  {activeSlipPreview.paymentSlipUrl && (
                    <div className="space-y-1.5 pb-2.5 border-b border-slate-800/60 text-left">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-500 uppercase tracking-wider font-sans text-[10px] font-bold">📄 Payment Slip</span>
                        <span className="text-blue-400 font-bold truncate max-w-[150px] text-right">
                          {activeSlipPreview.paymentSlipUrl.startsWith('data:') ? 'Uploaded Image Document' : activeSlipPreview.paymentSlipUrl}
                        </span>
                      </div>
                      {activeSlipPreview.paymentSlipUrl.startsWith('data:') && (
                        <div className="mt-1 overflow-hidden rounded-xl border border-slate-800 bg-slate-950/80 max-h-48 flex justify-center items-center group relative cursor-pointer" onClick={() => setZoomedImgUrl(activeSlipPreview.paymentSlipUrl)}>
                          <img src={activeSlipPreview.paymentSlipUrl} alt="Payment Slip" className="object-contain max-h-48 w-full group-hover:scale-[1.03] transition-all" />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center gap-1.5 text-white font-sans text-xs font-black uppercase">
                            🔍 Click to Zoom / Download
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  {activeSlipPreview.screenshotUrl && (
                    <div className="space-y-1.5 pb-2.5 border-b border-slate-800/60 text-left">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-500 uppercase tracking-wider font-sans text-[10px] font-bold">📸 Payment Photo</span>
                        <span className="text-emerald-400 font-bold truncate max-w-[150px] text-right">
                          {activeSlipPreview.screenshotUrl.startsWith('data:') ? 'Uploaded Photo/Screenshot' : activeSlipPreview.screenshotUrl}
                        </span>
                      </div>
                      {activeSlipPreview.screenshotUrl.startsWith('data:') && (
                        <div className="mt-1 overflow-hidden rounded-xl border border-slate-800 bg-slate-950/80 max-h-48 flex justify-center items-center group relative cursor-pointer" onClick={() => setZoomedImgUrl(activeSlipPreview.screenshotUrl)}>
                          <img src={activeSlipPreview.screenshotUrl} alt="Payment Screenshot" className="object-contain max-h-48 w-full group-hover:scale-[1.03] transition-all" />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center gap-1.5 text-white font-sans text-xs font-black uppercase">
                            🔍 Click to Zoom / Download
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  <div className="flex justify-between items-center pb-2.5 border-b border-slate-800/60">
                    <span className="text-slate-500 uppercase tracking-wider font-sans text-[10px] font-bold">Submitted At</span>
                    <span className="text-slate-300 text-right">
                      {activeSlipPreview.submittedAt ? new Date(activeSlipPreview.submittedAt).toLocaleString() : new Date().toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 uppercase tracking-wider font-sans text-[10px] font-bold">Ref / UTR No</span>
                    <span className="text-slate-300 font-bold text-right text-[#FFC107]">
                      {`UTR-${activeSlipPreview.id.toUpperCase().substring(0, 8)}-${new Date(activeSlipPreview.createdAt).getTime().toString().substring(5, 11)}`}
                    </span>
                  </div>
                </div>

                {/* Professional UPI / UTR Verification simulated engine */}
                <div className="bg-slate-950/30 border border-slate-800 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-blue-500" />
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">UPI Network Verification</span>
                    </div>
                    <span className="text-[9px] font-mono bg-blue-500/15 text-blue-400 border border-blue-500/20 px-2 py-0.5 rounded-full uppercase font-black">
                      NPCI-IMPS Gateway
                    </span>
                  </div>

                  {utrVerificationResult ? (
                    <div className="p-3 bg-emerald-500/10 border border-emerald-500/25 rounded-xl flex items-start gap-2.5">
                      <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <div className="space-y-0.5">
                        <p className="text-[11px] font-black text-emerald-400 uppercase tracking-wide">UTR Ledger Authenticated</p>
                        <p className="text-[10px] text-slate-300 leading-tight">
                          Verification complete: match identified against the transaction reference. Match matches the active ₹{activeSlipPreview.amount} dispatch loop.
                        </p>
                      </div>
                    </div>
                  ) : isVerifyingUtr ? (
                    <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex flex-col items-center justify-center text-center space-y-2.5">
                      <div className="w-5 h-5 rounded-full border-2 border-blue-500 border-t-transparent animate-spin" />
                      <span className="text-[10px] font-bold font-mono tracking-tight text-blue-400">
                        Querying transaction reference ledger on UPI loop...
                      </span>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setIsVerifyingUtr(true);
                        setTimeout(() => {
                          setIsVerifyingUtr(false);
                          setUtrVerificationResult("valid");
                        }, 1800);
                      }}
                      className="w-full py-2.5 bg-gradient-to-r from-[#0D6EFD] to-[#00BFFF] hover:opacity-95 active:scale-95 transition-all rounded-xl text-[10px] font-black uppercase tracking-wider text-white cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-blue-500/15"
                    >
                      🔍 Run UPI / UTR Authenticity Scan
                    </button>
                  )}
                </div>

                {/* Informative Disclaimer */}
                <p className="text-[11px] text-slate-400 text-center leading-relaxed font-medium px-1">
                  Please verify that you have received exactly <strong>₹{activeSlipPreview.amount.toLocaleString()}</strong> in your matched UPI or bank account before confirming. Administrative actions are logged permanently.
                </p>

                {/* Action Buttons inside the popup */}
                <div className="flex flex-col sm:flex-row gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveSlipPreview(null);
                      setUtrVerificationResult(null);
                      setIsVerifyingUtr(false);
                    }}
                    className="flex-1 py-3 bg-slate-800 hover:bg-slate-750 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer text-center"
                  >
                    Close Preview
                  </button>
                  {activeSlipPreview.status === 'pending_verification' && activeSlipPreview.takerUserId === currentUser.id && (
                    <div className="flex-1 flex gap-2 w-full">
                      <button
                        type="button"
                        onClick={() => {
                          const reason = prompt('Please enter a brief rejection reason (e.g. Payment not received / Invalid proof):');
                          if (reason === null) return;
                          if (onRejectP2PMatch) {
                            onRejectP2PMatch(activeSlipPreview.id);
                            if (activeSlipPreview.id === 'demo-p2p-match-id') { setMatchStatus('rejected'); }
                            alert('Rejection recorded! Matching donor has been flagged for administrative review.');
                          } else {
                            onUpdateP2PMatch(activeSlipPreview.id, { status: 'rejected' });
                            alert('Rejection recorded!');
                          }
                          setActiveSlipPreview(null);
                          setUtrVerificationResult(null);
                        }}
                        className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer text-center"
                      >
                        ❌ Reject
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`Are you absolutely sure you have received ₹${activeSlipPreview.amount} from ${activeSlipPreview.giverName}? This is irreversible.`)) {
                            if (onApproveP2PMatch) {
                              onApproveP2PMatch(activeSlipPreview.id); if (activeSlipPreview.id === 'demo-p2p-match-id') { setMatchStatus('approved'); }
                            } else {
                              onUpdateP2PMatch(activeSlipPreview.id, { status: 'completed' });
                            }
                            alert('Success! Payout match approved and finalized.');
                            setActiveSlipPreview(null);
                            setUtrVerificationResult(null);
                          }
                        }}
                        className="flex-1 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:opacity-95 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer shadow-lg shadow-emerald-950/40 text-center"
                      >
                        ✓ Approve
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Zoomed Lightbox Overlay Modal */}
      <AnimatePresence>
        {zoomedImgUrl && (
          <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center p-4 bg-slate-950/95 backdrop-blur-md">
            {/* Close Zoom Button */}
            <button
              type="button"
              onClick={() => setZoomedImgUrl(null)}
              className="absolute top-6 right-6 p-2 text-white bg-slate-900 hover:bg-slate-800 rounded-full transition-all cursor-pointer z-50 border border-white/10 shadow-lg"
              title="Close Zoom"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Image display */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative max-w-4xl max-h-[80vh] w-full flex justify-center items-center"
            >
              <img
                src={zoomedImgUrl}
                alt="Zoomed Payment Document"
                referrerPolicy="no-referrer"
                className="object-contain max-h-[80vh] rounded-xl shadow-2xl border border-white/10 select-none"
              />
            </motion.div>

            {/* Lightbox Footer controls */}
            <div className="mt-6 flex gap-3 z-50">
              <button
                type="button"
                onClick={() => {
                  const link = document.createElement('a');
                  link.href = zoomedImgUrl;
                  link.download = `payment-receipt-match-${activeSlipPreview?.id || 'id'}.png`;
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                }}
                className="px-4 py-2 bg-[#0D6EFD] hover:bg-[#0D6EFD]/90 text-white font-black text-xs uppercase tracking-wider rounded-lg flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                📥 Download Document
              </button>
              <button
                type="button"
                onClick={() => setZoomedImgUrl(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs uppercase rounded-lg cursor-pointer"
              >
                Close Zoom
              </button>
            </div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
