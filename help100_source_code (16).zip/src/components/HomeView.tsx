import React, { useState, useEffect } from 'react';
import Logo from './Logo';
import { User, SystemSettings, Contribution, HelpRequest, IssuedPin, EmailLog } from '../types';
import { findSponsorInList } from '../lib/sponsorUtils';
import { 
  HeartHandshake, 
  ShieldCheck, 
  Users, 
  Coins, 
  ArrowRight, 
  Phone, 
  Mail, 
  UserPlus, 
  Lock, 
  Key, 
  Upload, 
  CheckCircle, 
  ExternalLink,
  ChevronRight,
  AlertCircle,
  Info,
  Gift,
  DollarSign,
  Clock,
  Sparkles,
  Activity,
  ArrowUpRight,
  Check,
  FileText,
  Filter,
  Send,
  UserCheck,
  PlusCircle,
  Globe,
  HelpCircle,
  User as UserIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeSVG } from 'qrcode.react';

interface HomeViewProps {
  systemSettings: SystemSettings;
  users: User[];
  contributions: Contribution[];
  helpRequests: HelpRequest[];
  issuedPins: IssuedPin[];
  onRegister: (newUser: User) => void;
  onLogin: (user: User) => void;
  onAddContribution: (newContrib: Contribution) => void;
  onAddHelpRequest: (newHelp: HelpRequest) => void;
  emailLogs?: EmailLog[];
  onSendEmailLog?: (recipientEmail: string, recipientName: string, subject: string, body: string, type: 'welcome' | 'forgot_password') => EmailLog;
}

export default function HomeView({ 
  systemSettings, 
  users, 
  contributions, 
  helpRequests, 
  issuedPins,
  onRegister, 
  onLogin, 
  onAddContribution, 
  onAddHelpRequest,
  emailLogs = [],
  onSendEmailLog
}: HomeViewProps) {
  // Navigation: 'hero' | 'register' | 'login' | 'admin_login'
  const [currentTab, setCurrentTab] = useState<'hero' | 'register' | 'login' | 'admin_login'>('hero');
  
  // Register step state: 'form' | 'otp' | 'profile' | 'kyc' | 'success'
  const [regStep, setRegStep] = useState<'form' | 'otp' | 'profile' | 'kyc' | 'success'>('form');

  // Forgot Password modal states
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState('');
  const [forgotError, setForgotError] = useState('');

  // Incoming Simulated Email visual overlay
  const [incomingEmail, setIncomingEmail] = useState<EmailLog | null>(null);
  
  // Registration Form Inputs
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regReferral, setRegReferral] = useState('');
  const [regPin, setRegPin] = useState('');
  const [regPassword, setRegPassword] = useState(''); // Simulated login passcode
  
  // Register generated user state
  const [tempUser, setTempUser] = useState<User | null>(null);
  
  // OTP input
  const [otpInput, setOtpInput] = useState('');
  const [otpError, setOtpError] = useState('');

  // Profile Inputs
  const [profileLocation, setProfileLocation] = useState('');
  const [profileOccupation, setProfileOccupation] = useState('');

  // KYC Inputs
  const [kycDocType, setKycDocType] = useState('National ID / Passport');
  const [kycDocNumber, setKycDocNumber] = useState('');
  const [kycFileName, setKycFileName] = useState('');
  const [dragOver, setDragOver] = useState(false);

  // Login inputs
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Admin Login inputs
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminError, setAdminError] = useState('');

  // Custom interactive confirm/error states to bypass blocking browser modals
  const [formError, setFormError] = useState('');
  const [kycError, setKycError] = useState('');
  const [pinConfirmRequired, setPinConfirmRequired] = useState(false);
  const [overwriteConfirmRequired, setOverwriteConfirmRequired] = useState(false);

  // Parse referral query code (?ref=CODE) or pathname (/register) on mount
  useEffect(() => {
    try {
      const extractParam = (keyName: string): string | null => {
        try {
          const href = window.location.href;
          const regex = new RegExp(`[?&#/]${keyName}=([^&#/?]+)`, 'i');
          const match = href.match(regex);
          if (match && match[1]) {
            return decodeURIComponent(match[1]).trim();
          }

          const searchParams = new URLSearchParams(window.location.search);
          if (searchParams.has(keyName)) {
            const val = searchParams.get(keyName)?.trim();
            if (val) return val;
          }

          if (window.location.hash.includes('?')) {
            const hashSearch = window.location.hash.split('?')[1];
            const hashParams = new URLSearchParams(hashSearch);
            if (hashParams.has(keyName)) {
              const val = hashParams.get(keyName)?.trim();
              if (val) return val;
            }
          }
        } catch (e) {
          // ignore
        }
        return null;
      };

      let ref = extractParam('ref') || extractParam('referral') || extractParam('sponsor') || extractParam('code') || extractParam('id');
      let pinParam = extractParam('pin') || extractParam('pincode') || extractParam('key');
      const isAdmin = extractParam('admin');
      const path = window.location.pathname;

      if (pinParam) {
        const cleanPin = pinParam.trim().toUpperCase();
        const formattedPin = cleanPin.startsWith('PIN-') ? cleanPin : `PIN-${cleanPin}`;
        setRegPin(formattedPin);
        setCurrentTab('register');
      }

      if (isAdmin === 'true' || isAdmin === 'secret' || path.includes('/admin') || path.includes('admin')) {
        setCurrentTab('admin_login');
      } else if (ref) {
        const cleanRef = ref.trim().toUpperCase();
        setRegReferral(cleanRef);
        try {
          localStorage.setItem('help100_saved_ref', cleanRef);
        } catch (e) {
          // ignore
        }
        setCurrentTab('register');
      } else if (path.includes('/register') || path.includes('register')) {
        setCurrentTab('register');
      } else {
        try {
          const savedRef = localStorage.getItem('help100_saved_ref');
          if (savedRef && savedRef.trim()) {
            setRegReferral(savedRef.trim().toUpperCase());
          }
        } catch (e) {
          // ignore
        }
      }
    } catch (e) {
      console.error('Error parsing URL search parameters:', e);
    }
  }, []);

  // Sync entered/parsed referral code to localStorage
  useEffect(() => {
    if (regReferral.trim()) {
      try {
        localStorage.setItem('help100_saved_ref', regReferral.trim().toUpperCase());
      } catch (e) {
        // ignore
      }
    }
  }, [regReferral]);

  // Restore saved referral code when switching to register tab if field is empty
  useEffect(() => {
    if (currentTab === 'register' && !regReferral.trim()) {
      try {
        const savedRef = localStorage.getItem('help100_saved_ref');
        if (savedRef && savedRef.trim()) {
          setRegReferral(savedRef.trim().toUpperCase());
        }
      } catch (e) {
        // ignore
      }
    }
  }, [currentTab]);

  // Helper to complete registration once validation passes
  const proceedToOtp = () => {
    // Generate random 6-digit OTP
    const generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Normalize and resolve sponsor if provided
    const cleanRef = (regReferral.trim() || localStorage.getItem('help100_saved_ref') || '').trim();
    const matchedSponsor = findSponsorInList(cleanRef, users);

    const finalReferredBy = matchedSponsor 
      ? (matchedSponsor.referralCode || matchedSponsor.id) 
      : (cleanRef.toUpperCase() || 'ADMIN100');

    // Generate guaranteed unique referral code
    let baseCode = regName.trim().split(' ')[0].toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (!baseCode) baseCode = 'USER';
    let generatedCode = baseCode + Math.floor(100 + Math.random() * 900);
    while (users.some(u => u.referralCode === generatedCode)) {
      generatedCode = baseCode + Math.floor(1000 + Math.random() * 9000);
    }

    // Generate unique email if duplicate email is entered for another ID under same phone
    let finalEmail = regEmail.trim();
    const existingEmailUsers = users.filter(u => u.email.toLowerCase() === finalEmail.toLowerCase());
    if (existingEmailUsers.length > 0) {
      const atIdx = finalEmail.indexOf('@');
      if (atIdx !== -1) {
        finalEmail = `${finalEmail.substring(0, atIdx)}+id${existingEmailUsers.length + 1}${finalEmail.substring(atIdx)}`;
      } else {
        finalEmail = `${finalEmail}_${existingEmailUsers.length + 1}`;
      }
    }

    // Generate device fingerprint
    let storedDeviceId = localStorage.getItem('help100_device_id');
    if (!storedDeviceId) {
      storedDeviceId = 'dev-' + Math.random().toString(36).substring(2, 11) + '-' + Date.now().toString(36);
      localStorage.setItem('help100_device_id', storedDeviceId);
    }
    const ua = navigator.userAgent;
    let deviceType = 'Desktop';
    if (/Mobi|Android|iPhone|iPad/i.test(ua)) {
      deviceType = /iPad|Tablet/i.test(ua) ? 'Tablet' : 'Mobile';
    }
    const platformStr = navigator.platform || 'Web';
    const deviceInfoStr = `${deviceType} (${platformStr})`;

    // Create new temporary user with role user
    const newUser: User = {
      id: 'user-' + Math.random().toString(36).substr(2, 9),
      name: regName,
      email: finalEmail,
      phone: regPhone.trim(),
      password: regPassword || '123456',
      status: 'pending_otp',
      otp: generatedOtp,
      otpVerified: false,
      kycStatus: 'not_submitted',
      walletBalance: 0,
      provideWallet: 0,
      getWallet: 0,
      directWallet: 0,
      levelWallet: 0,
      totalContributed: 0,
      totalReceived: 0,
      referralCode: generatedCode,
      directId: generatedCode,
      directReferralId: generatedCode,
      referredBy: finalReferredBy,
      sponsorId: matchedSponsor ? matchedSponsor.id : finalReferredBy,
      directSponsorId: matchedSponsor ? (matchedSponsor.referralCode || matchedSponsor.id) : finalReferredBy,
      registeredAt: new Date().toISOString(),
      role: 'user',
      registrationPin: regPin ? regPin.trim().toUpperCase() : undefined,
      deviceId: storedDeviceId,
      deviceInfo: deviceInfoStr
    };

    setTempUser(newUser);
    setRegStep('otp');
    setOtpInput('');
    setOtpError('');
    setFormError('');
    setPinConfirmRequired(false);
    setOverwriteConfirmRequired(false);

    // Register user immediately so ID is stored on server & synced to all devices right away
    try {
      onRegister(newUser);
    } catch (e) {
      console.error('Error auto-registering user:', e);
    }
  };

  // Handle register form submission
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setPinConfirmRequired(false);
    setOverwriteConfirmRequired(false);

    if (!systemSettings.isRegistrationOpen) {
      setFormError('Registration is currently closed by the Administrator.');
      return;
    }

    if (!regName.trim() || !regEmail.trim() || !regPhone.trim()) {
      setFormError('Please fill out all mandatory fields.');
      return;
    }

    // Check PIN: If empty, auto-generate a fresh ₹10 PIN Key for registration so account is pre-activated
    let activePin = regPin.trim().toUpperCase();
    if (!activePin) {
      activePin = 'PIN-JOIN-' + Math.random().toString(36).substring(2, 8).toUpperCase();
      setRegPin(activePin);
    } else if (!activePin.startsWith('PIN-')) {
      activePin = `PIN-${activePin}`;
      setRegPin(activePin);
    }

    // Limit check: Up to 5 IDs allowed per mobile number
    const cleanPhone = regPhone.trim();
    const samePhoneUsers = users.filter(u => u.phone && u.phone.trim() === cleanPhone);
    if (samePhoneUsers.length >= 5) {
      setFormError(`Maximum registration limit reached: A maximum of 5 IDs can be generated per mobile number (${cleanPhone}). You already have 5 active accounts.`);
      return;
    }

    proceedToOtp();
  };

  // Handle OTP verification
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempUser) return;

    if (otpInput === tempUser.otp || otpInput === '123456') { // Fallback 123456 for testing
      const updatedUser: User = {
        ...tempUser,
        otpVerified: true,
        status: 'pending_kyc'
      };
      setTempUser(updatedUser);
      setRegStep('profile');
      try {
        onRegister(updatedUser);
      } catch (err) {}
    } else {
      setOtpError('Invalid verification code. Please enter the correct code.');
    }
  };

  // Handle Profile setup completion
  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempUser) return;
    const updatedUser: User = {
      ...tempUser,
      location: profileLocation || tempUser.location,
      occupation: profileOccupation || tempUser.occupation
    };
    setTempUser(updatedUser);
    setRegStep('kyc');
    try {
      onRegister(updatedUser);
    } catch (err) {}
  };

  // Drag & drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = () => {
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      setKycFileName(e.dataTransfer.files[0].name);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setKycFileName(e.target.files[0].name);
    }
  };

  // Complete KYC and trigger registration callback
  const handleKycSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setKycError('');
    if (!tempUser) return;
    if (!kycDocNumber || !kycFileName) {
      setKycError('Please fill out document details and upload visual proof.');
      return;
    }

    const finalUser: User = {
      ...tempUser,
      status: 'kyc_submitted',
      kycStatus: 'pending',
      kycDetails: {
        documentType: kycDocType,
        documentNumber: kycDocNumber,
        fileUrl: kycFileName,
        submittedAt: new Date().toISOString()
      },
      registrationPin: tempUser.registrationPin
    };

    onRegister(finalUser);

    // Simulated Welcome Email Dispatch
    const welcomeSubject = '🔐 Welcome to Help 100! Your User ID & Password inside';
    const welcomeBody = `Hello ${finalUser.name},\n\nYour registration was successful!\n\nHere are your secure platform login credentials:\n----------------------------------------\nUser ID: ${finalUser.id}\nPasscode: ${finalUser.password || '123456'}\n----------------------------------------\n\nPlease keep these credentials secure. Do not share your passcode with anyone.\n\nWelcome to Help 100 decentralized mutual aid platform!\n\nBest regards,\nHelp 100 System Operations`;

    if (onSendEmailLog) {
      const welcomeMail = onSendEmailLog(finalUser.email, finalUser.name, welcomeSubject, welcomeBody, 'welcome');
      setIncomingEmail(welcomeMail);
    }

    setRegStep('success');
  };

  // Handle Login submission
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    const matchedUser = users.find(u => u.email.toLowerCase() === loginEmail.trim().toLowerCase());
    if (!matchedUser) {
      setLoginError('User credentials not found. Please register or select a simulation profile.');
      return;
    }

    if (matchedUser.status === 'suspended') {
      setLoginError('This account has been blocked / suspended by the platform administrator.');
      return;
    }

    if (matchedUser.role === 'admin') {
      setLoginError('This is the member login gateway. Administrators must authenticate via the separate Admin Portal.');
      return;
    }

    // Direct Login with password verification
    if (matchedUser.password && matchedUser.password !== loginPassword.trim()) {
      setLoginError('Incorrect passcode. Please try again.');
      return;
    }

    onLogin(matchedUser);
  };

  // Handle Forgot Password submission
  const handleForgotPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');
    setForgotSuccess('');

    if (!forgotEmail || !forgotEmail.trim()) {
      setForgotError('Please enter your registered email address.');
      return;
    }

    const matchedUser = users.find(u => u.email.toLowerCase() === forgotEmail.trim().toLowerCase());
    if (!matchedUser) {
      setForgotError('No registered member account was found with this email.');
      return;
    }

    if (matchedUser.role === 'admin') {
      setForgotError('Admin account password resets are restricted. Please modify via backend config.');
      return;
    }

    const subject = '🔐 [Help100] Passcode Recovery - Your User ID and Password';
    const body = `Hello ${matchedUser.name},\n\nYou requested a recovery of your platform login credentials.\n\nHere are your secure login credentials:\n----------------------------------------\nUser ID: ${matchedUser.id}\nPasscode: ${matchedUser.password || '123456'}\n----------------------------------------\n\nIf you did not request this recovery, please contact customer support immediately.\n\nHelp 100 Mutual Aid Network Operations`;

    if (onSendEmailLog) {
      const mailLog = onSendEmailLog(matchedUser.email, matchedUser.name, subject, body, 'forgot_password');
      setIncomingEmail(mailLog);
    }

    setForgotSuccess(`Success! A secure passcode recovery email containing your User ID and passcode has been sent to: ${matchedUser.email}`);
    setForgotEmail('');
  };

  // Handle Admin Login submission
  const handleAdminLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError('');

    const matchedUser = users.find(u => u.email.toLowerCase() === adminEmail.trim().toLowerCase());
    if (!matchedUser) {
      setAdminError('Invalid administrator credentials.');
      return;
    }

    if (matchedUser.role !== 'admin') {
      setAdminError('Access Denied. Your account is not authorized as a platform administrator.');
      return;
    }

    // Direct Admin Login with password verification
    if (matchedUser.password && matchedUser.password !== adminPassword.trim()) {
      setAdminError('Incorrect administrator password.');
      return;
    }

    onLogin(matchedUser);
  };



  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col selection:bg-emerald-100 selection:text-emerald-900">
      
      {/* Interactive Navigation Header */}
      <header className="bg-white border-b border-slate-200/80 sticky top-0 z-40 backdrop-blur-md bg-white/90">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => { setCurrentTab('hero'); setRegStep('form'); }}>
            {systemSettings.homeLogoUrl ? (
              <img src={systemSettings.homeLogoUrl} alt="Logo" className="h-10 max-w-[120px] object-contain rounded" referrerPolicy="no-referrer" />
            ) : (
              <Logo size={42} showText={false} />
            )}
            <div>
              <span className="font-bold text-xl tracking-tight text-slate-900 flex items-center gap-1.5">
                HELP 100 <span className="text-xs bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full border border-emerald-200">Community</span>
              </span>
              <p className="text-[10px] text-slate-400 font-mono tracking-widest uppercase">Mutual Aid Network</p>
            </div>
          </div>

          <nav className="flex items-center gap-4">
            {systemSettings.websiteButtonEnabled && systemSettings.websiteButtonUrl && (
              <a 
                id="nav-btn-website"
                href={systemSettings.websiteButtonUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors cursor-pointer flex items-center gap-1 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg border border-slate-200/50"
              >
                <Globe className="w-3.5 h-3.5 text-slate-500" />
                <span>{systemSettings.websiteButtonText || 'Website'}</span>
              </a>
            )}
            <button 
              id="nav-btn-home"
              onClick={() => { setCurrentTab('hero'); setRegStep('form'); }}
              className={`text-sm font-medium transition-colors cursor-pointer ${currentTab === 'hero' ? 'text-emerald-600 font-semibold' : 'text-slate-600 hover:text-slate-900'}`}
            >
              Platform Overview
            </button>
            <button 
              id="nav-btn-login"
              onClick={() => setCurrentTab('login')}
              className={`text-sm font-medium transition-colors cursor-pointer ${currentTab === 'login' ? 'text-emerald-600 font-semibold' : 'text-slate-600 hover:text-slate-900'}`}
            >
              Sign In
            </button>
            <button 
              id="nav-btn-register"
              onClick={() => { setCurrentTab('register'); setRegStep('form'); }}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-900 text-white hover:bg-slate-800 transition-all flex items-center gap-1 shadow-sm cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5" />
              Join & Register
            </button>
          </nav>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-grow flex flex-col justify-center">
        
        {/* VIEW 1: HERO / LANDING PAGE */}
        {currentTab === 'hero' && (
          <div>
            {/* Hero Splash */}
            <section 
              id="hero-section"
              className="relative overflow-hidden pt-12 md:pt-20 pb-16 md:pb-24 border-b border-slate-200 bg-[#f8fafc]"
              style={systemSettings.homeBgImageUrl ? {
                backgroundImage: `linear-gradient(to right, rgba(255, 255, 255, 0.96) 0%, rgba(255, 255, 255, 0.95) 45%, rgba(255, 255, 255, 0.8) 100%), url(${systemSettings.homeBgImageUrl})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              } : undefined}
            >
              {!systemSettings.homeBgImageUrl && (
                <div className="absolute inset-0 z-0">
                  <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-emerald-200/20 rounded-full blur-3xl translate-x-1/3 -translate-y-1/3" />
                  <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-teal-200/10 rounded-full blur-2xl -translate-x-1/3 translate-y-1/3" />
                </div>
              )}
              
              <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid md:grid-cols-12 gap-8 items-center text-center md:text-left">
                  
                  {/* Left Column: Headings & CTA */}
                  <div className="md:col-span-7 lg:col-span-6 space-y-6">
                    <motion.div 
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5 }}
                      className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-800 text-xs font-semibold"
                    >
                      <Coins className="w-3.5 h-3.5 text-emerald-600" />
                      <span>100% Peer-to-Peer Transparent Crowdfund System</span>
                    </motion.div>

                    <motion.h1 
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 0.1 }}
                      className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-slate-900 leading-none"
                    >
                      HELP <span className="text-emerald-600">100</span> <br />
                      <span className="text-slate-800 text-2xl sm:text-3xl md:text-4xl block mt-3 font-extrabold tracking-tight">Together We Help, Together We Grow</span>
                    </motion.h1>

                    <motion.p 
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 0.2 }}
                      className="text-slate-600 text-sm sm:text-base leading-relaxed max-w-xl"
                    >
                      Help 100 is a community helping platform where we support each other and grow together. Small help today, a big support tomorrow.
                    </motion.p>

                    <motion.div 
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 0.3 }}
                      className="flex flex-wrap items-center gap-4 justify-center md:justify-start"
                    >
                      <button 
                        id="hero-btn-join"
                        onClick={() => { setCurrentTab('register'); setRegStep('form'); }}
                        className="px-6 py-3.5 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-700 transition-all shadow-md flex items-center gap-2 text-xs cursor-pointer"
                      >
                        <UserPlus className="w-4 h-4" />
                        Join Now
                      </button>
                      
                      {systemSettings.websiteButtonEnabled && systemSettings.websiteButtonUrl && (
                        <a 
                          id="hero-btn-website"
                          href={systemSettings.websiteButtonUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold transition-all flex items-center gap-2 text-xs cursor-pointer shadow-md border border-slate-800"
                        >
                          <Globe className="w-4 h-4 text-emerald-400" />
                          <span>{systemSettings.websiteButtonText || 'Official Website'}</span>
                        </a>
                      )}

                      <button 
                        id="hero-btn-how-it-works"
                        onClick={() => {
                          const element = document.getElementById('why-choose-section');
                          if (element) {
                            element.scrollIntoView({ behavior: 'smooth' });
                          }
                        }}
                        className="px-6 py-3.5 rounded-xl bg-white border border-slate-300 text-slate-700 font-bold hover:bg-slate-50 transition-all flex items-center gap-1.5 text-xs cursor-pointer shadow-sm"
                      >
                        How It Works
                      </button>
                    </motion.div>
                  </div>

                  {/* Right Column: Animated Circular Hub Graphic */}
                  <div className="md:col-span-5 lg:col-span-6 flex justify-center py-6 md:py-0">
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.6, type: 'spring' }}
                      className="relative w-[280px] h-[280px] sm:w-[360px] sm:h-[360px] flex items-center justify-center"
                    >
                      {/* Central Logo Container with Outer Glow */}
                      <div className="relative z-10 bg-white p-4 rounded-full shadow-2xl border-4 border-emerald-500 w-[140px] h-[140px] sm:w-[185px] sm:h-[185px] flex items-center justify-center overflow-hidden">
                        {systemSettings.homeLogoUrl ? (
                          <img src={systemSettings.homeLogoUrl} alt="Logo" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                        ) : (
                          <Logo size={135} showText={true} />
                        )}
                      </div>

                      {/* Connecting Circle Lines */}
                      <div className="absolute inset-0 border-2 border-dashed border-slate-200/80 rounded-full animate-[spin_45s_linear_infinite]" />

                      {/* Orbiting Node 1: TOGETHER (Top) */}
                      <div className="absolute top-0 flex flex-col items-center -translate-y-1/2">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg border-2 border-white">
                          <Users className="w-4 h-4 sm:w-5 sm:h-5" />
                        </div>
                        <span className="text-[9px] sm:text-[10px] font-bold text-slate-700 tracking-wider bg-white px-2 py-0.5 rounded-full border border-slate-200 mt-1 uppercase shadow-xs">Together</span>
                      </div>

                      {/* Orbiting Node 2: GROW (Right) */}
                      <div className="absolute right-0 flex flex-col items-center translate-x-1/2">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg border-2 border-white">
                          <Activity className="w-4 h-4 sm:w-5 sm:h-5" />
                        </div>
                        <span className="text-[9px] sm:text-[10px] font-bold text-slate-700 tracking-wider bg-white px-2 py-0.5 rounded-full border border-slate-200 mt-1 uppercase shadow-xs">Grow</span>
                      </div>

                      {/* Orbiting Node 3: HELP (Bottom) */}
                      <div className="absolute bottom-0 flex flex-col items-center translate-y-1/2">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg border-2 border-white">
                          <HeartHandshake className="w-4 h-4 sm:w-5 sm:h-5" />
                        </div>
                        <span className="text-[9px] sm:text-[10px] font-bold text-slate-700 tracking-wider bg-white px-2 py-0.5 rounded-full border border-slate-200 mt-1 uppercase shadow-xs">Help</span>
                      </div>

                      {/* Orbiting Node 4: TRUST (Bottom-Left) */}
                      <div className="absolute bottom-[10%] left-[10%] -translate-x-1/3 flex flex-col items-center">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg border-2 border-white">
                          <ShieldCheck className="w-4 h-4 sm:w-5 sm:h-5" />
                        </div>
                        <span className="text-[9px] sm:text-[10px] font-bold text-slate-700 tracking-wider bg-white px-2 py-0.5 rounded-full border border-slate-200 mt-1 uppercase shadow-xs">Trust</span>
                      </div>

                      {/* Orbiting Node 5: SUPPORT (Top-Left) */}
                      <div className="absolute top-[15%] left-[10%] -translate-x-1/3 flex flex-col items-center">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg border-2 border-white">
                          <Coins className="w-4 h-4 sm:w-5 sm:h-5" />
                        </div>
                        <span className="text-[9px] sm:text-[10px] font-bold text-slate-700 tracking-wider bg-white px-2 py-0.5 rounded-full border border-slate-200 mt-1 uppercase shadow-xs">Support</span>
                      </div>
                    </motion.div>
                  </div>

                </div>
              </div>
            </section>

            {/* Platform Stats Banner */}
            <section className="bg-[#052d68] text-white py-6 md:py-8 border-b border-indigo-950">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center md:text-left">
                  
                  <div className="flex flex-col md:flex-row items-center gap-3 justify-center md:justify-start">
                    <div className="p-2 bg-white/10 rounded-lg text-emerald-400">
                      <Users className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-lg sm:text-xl font-bold">10000+</p>
                      <p className="text-[11px] text-slate-300 uppercase tracking-wider">Happy Members</p>
                    </div>
                  </div>

                  <div className="flex flex-col md:flex-row items-center gap-3 justify-center md:justify-start">
                    <div className="p-2 bg-white/10 rounded-lg text-emerald-400">
                      <HeartHandshake className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-lg sm:text-xl font-bold">50000+</p>
                      <p className="text-[11px] text-slate-300 uppercase tracking-wider">Helps Provided</p>
                    </div>
                  </div>

                  <div className="flex flex-col md:flex-row items-center gap-3 justify-center md:justify-start">
                    <div className="p-2 bg-white/10 rounded-lg text-emerald-400">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-lg sm:text-xl font-bold">100%</p>
                      <p className="text-[11px] text-slate-300 uppercase tracking-wider">Secure & Safe</p>
                    </div>
                  </div>

                  <div className="flex flex-col md:flex-row items-center gap-3 justify-center md:justify-start">
                    <div className="p-2 bg-white/10 rounded-lg text-emerald-400">
                      <Phone className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-lg sm:text-xl font-bold">24/7</p>
                      <p className="text-[11px] text-slate-300 uppercase tracking-wider">Support</p>
                    </div>
                  </div>

                </div>
              </div>
            </section>

            {/* Why Choose HELP 100 & Embedded Login Column */}
            <section id="why-choose-section" className="py-16 bg-slate-50">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid md:grid-cols-12 gap-8 items-start">
                  
                  {/* Left Column: Why Choose Grid */}
                  <div className="md:col-span-7 lg:col-span-8 space-y-8">
                    <div>
                      <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Why Choose <span className="text-emerald-600">HELP 100</span>?</h2>
                      <p className="text-slate-500 mt-1 text-sm font-medium">Our foundational values represent direct financial ledger safety with peer collaboration</p>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-6">
                      {/* Card 1 */}
                      <div className="p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
                        <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4 border border-emerald-100">
                          <Users className="w-5 h-5" />
                        </div>
                        <h3 className="font-bold text-slate-900 text-sm mb-1">Trusted Community</h3>
                        <p className="text-slate-500 text-xs leading-relaxed">
                          A trusted platform where everyone helps and supports each other.
                        </p>
                      </div>

                      {/* Card 2 */}
                      <div className="p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
                        <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4 border border-emerald-100">
                          <Coins className="w-5 h-5" />
                        </div>
                        <h3 className="font-bold text-slate-900 text-sm mb-1">Simple Plan</h3>
                        <p className="text-slate-500 text-xs leading-relaxed">
                          Easy to understand plan with transparent system for all members.
                        </p>
                      </div>

                      {/* Card 3 */}
                      <div className="p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
                        <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4 border border-emerald-100">
                          <ShieldCheck className="w-5 h-5" />
                        </div>
                        <h3 className="font-bold text-slate-900 text-sm mb-1">Secure & Safe</h3>
                        <p className="text-slate-500 text-xs leading-relaxed">
                          100% secure transactions and data protection guaranteed.
                        </p>
                      </div>

                      {/* Card 4 */}
                      <div className="p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
                        <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4 border border-emerald-100">
                          <Phone className="w-5 h-5" />
                        </div>
                        <h3 className="font-bold text-slate-900 text-sm mb-1">24/7 Support</h3>
                        <p className="text-slate-500 text-xs leading-relaxed">
                          Our support team is always here to help you anytime.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Embedded Member Login Card */}
                  <div className="md:col-span-5 lg:col-span-4">
                    <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-lg shadow-slate-100">
                      {!showForgotPassword ? (
                        <>
                          <div className="mb-5">
                            <h3 className="text-lg font-black text-slate-900">Member Login</h3>
                            <p className="text-slate-400 text-[10px] uppercase font-bold tracking-wider mt-0.5">Secure Dashboard Access</p>
                          </div>

                          {loginError && (
                            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl font-medium flex items-start gap-2 mb-4">
                              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                              <div>{loginError}</div>
                            </div>
                          )}

                          <form onSubmit={handleLoginSubmit} className="space-y-4">
                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Enter Mobile Number / Email</label>
                              <input 
                                id="home-login-email"
                                type="text"
                                required
                                placeholder="john@help100.com or phone"
                                value={loginEmail}
                                onChange={(e) => {
                                  setLoginEmail(e.target.value);
                                  setLoginError('');
                                }}
                                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-emerald-500"
                              />
                            </div>

                            <div>
                              <div className="flex justify-between mb-1">
                                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Enter Password</label>
                              </div>
                              <input 
                                id="home-login-password"
                                type="password"
                                required
                                placeholder="••••••"
                                value={loginPassword}
                                onChange={(e) => {
                                  setLoginPassword(e.target.value);
                                  setLoginError('');
                                }}
                                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-emerald-500"
                              />
                            </div>

                            <div className="flex justify-between items-center text-[10px]">
                              <span 
                                onClick={() => {
                                  setShowForgotPassword(true);
                                  setForgotError('');
                                  setForgotSuccess('');
                                }}
                                className="text-slate-400 hover:text-emerald-600 cursor-pointer hover:underline font-semibold"
                              >
                                Forgot Password?
                              </span>
                            </div>

                            <button 
                              id="home-login-submit"
                              type="submit"
                              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-sm shadow-emerald-500/10"
                            >
                              Login &rarr;
                            </button>
                          </form>
                        </>
                      ) : (
                        <>
                          <div className="mb-5">
                            <h3 className="text-lg font-black text-slate-900">Recover Passcode</h3>
                            <p className="text-slate-400 text-[10px] uppercase font-bold tracking-wider mt-0.5">Dispatches secure ID & password via SMTP email</p>
                          </div>

                          {forgotError && (
                            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl font-medium flex items-start gap-2 mb-4">
                              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                              <div>{forgotError}</div>
                            </div>
                          )}

                          {forgotSuccess && (
                            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl font-medium flex items-start gap-2 mb-4">
                              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                              <div>{forgotSuccess}</div>
                            </div>
                          )}

                          <form onSubmit={handleForgotPasswordSubmit} className="space-y-4">
                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Enter Registered Email</label>
                              <input 
                                id="forgot-password-email-home"
                                type="email"
                                required
                                placeholder="john@help100.com"
                                value={forgotEmail}
                                onChange={(e) => {
                                  setForgotEmail(e.target.value);
                                  setForgotError('');
                                  setForgotSuccess('');
                                }}
                                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-emerald-500"
                              />
                            </div>

                            <button 
                              id="forgot-password-submit-btn-home"
                              type="submit"
                              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-sm shadow-emerald-500/10 animate-pulse"
                            >
                              📧 Send Credentials &rarr;
                            </button>

                            <div className="pt-2 text-center">
                              <span 
                                onClick={() => setShowForgotPassword(false)}
                                className="text-[10px] text-slate-400 hover:text-emerald-600 cursor-pointer hover:underline font-bold uppercase tracking-wider"
                              >
                                &larr; Back to Login
                              </span>
                            </div>
                          </form>
                        </>
                      )}
                    </div>
                  </div>

                </div>
              </div>
            </section>
          </div>
        )}

        {/* VIEW 2: REGISTER STEPPER FLOW */}
        {currentTab === 'register' && (
          <div className="py-12 max-w-lg mx-auto w-full px-4">
            
            {/* Visual Steps Breadcrumbs */}
            <div className="flex items-center justify-between mb-8 text-xs font-medium text-slate-400 px-2">
              <span className={`pb-1 border-b-2 transition-all ${regStep === 'form' ? 'text-emerald-600 border-emerald-500 font-bold' : 'border-transparent text-slate-600'}`}>1. Register</span>
              <span className="text-slate-300">/</span>
              <span className={`pb-1 border-b-2 transition-all ${regStep === 'otp' ? 'text-emerald-600 border-emerald-500 font-bold' : 'border-transparent text-slate-600'}`}>2. OTP Verification</span>
              <span className="text-slate-300">/</span>
              <span className={`pb-1 border-b-2 transition-all ${regStep === 'profile' ? 'text-emerald-600 border-emerald-500 font-bold' : 'border-transparent text-slate-600'}`}>3. Profile</span>
              <span className="text-slate-300">/</span>
              <span className={`pb-1 border-b-2 transition-all ${regStep === 'kyc' ? 'text-emerald-600 border-emerald-500 font-bold' : 'border-transparent text-slate-600'}`}>4. KYC</span>
              <span className="text-slate-300">/</span>
              <span className={`pb-1 border-b-2 transition-all ${regStep === 'success' ? 'text-emerald-600 border-emerald-500 font-bold' : 'border-transparent text-slate-600'}`}>5. Dashboard</span>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xl shadow-slate-100 p-6 sm:p-8">
              
              {!systemSettings.isRegistrationOpen ? (
                <div className="text-center py-8 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-2">
                    <AlertCircle className="w-8 h-8" />
                  </div>
                  <h2 className="text-xl font-bold text-slate-950 tracking-tight">Registration Suspended</h2>
                  <p className="text-slate-600 text-xs max-w-sm mx-auto leading-relaxed font-medium">
                    The platform Administrator has temporarily suspended new user registrations. Existing members can still log in using the button below or via the header.
                  </p>
                  <div className="pt-4">
                    <button
                      type="button"
                      onClick={() => setCurrentTab('login')}
                      className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-black text-xs uppercase tracking-wider transition-all shadow-sm cursor-pointer"
                    >
                      Sign In Now
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {/* REGISTER STEP A: MAIN DETAILS */}
              {regStep === 'form' && (
                <form onSubmit={handleRegisterSubmit}>
                  <div className="mb-6">
                    <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Create Account</h2>
                    <p className="text-slate-500 text-xs mt-1">Start your mutual contribution journey in 3 quick phases.</p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Full Legal Name</label>
                      <input 
                        id="reg-input-name"
                        type="text"
                        required
                        placeholder="John Doe"
                        value={regName}
                        onChange={(e) => setRegName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Email Address</label>
                      <input 
                        id="reg-input-email"
                        type="email"
                        required
                        placeholder="john@example.com"
                        value={regEmail}
                        onChange={(e) => setRegEmail(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Phone Number</label>
                      <div className="relative">
                        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm"><Phone className="w-4 h-4" /></span>
                        <input 
                          id="reg-input-phone"
                          type="tel"
                          required
                          placeholder="+1 (555) 012-3456"
                          value={regPhone}
                          onChange={(e) => setRegPhone(e.target.value)}
                          className="w-full pl-10 pr-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm transition-all"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Create Account Password</label>
                      <div className="relative">
                        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"><Lock className="w-4 h-4" /></span>
                        <input 
                          id="reg-input-password"
                          type="password"
                          required
                          placeholder="Create login password"
                          value={regPassword}
                          onChange={(e) => setRegPassword(e.target.value)}
                          className="w-full pl-10 pr-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm transition-all"
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                          ₹10 Activation PIN Key
                        </label>
                        <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded-md">
                          Pre-activates Step 1 Queue
                        </span>
                      </div>
                      <div className="relative">
                        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                          <Key className="w-4 h-4 text-emerald-600" />
                        </span>
                        <input 
                          id="reg-input-pin"
                          type="text"
                          placeholder="Enter or Select ₹10 PIN Key (e.g. PIN-A98F12)"
                          value={regPin}
                          onChange={(e) => setRegPin(e.target.value.toUpperCase())}
                          className="w-full pl-10 pr-24 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm font-mono font-bold uppercase tracking-wider transition-all text-slate-800"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const fresh = 'PIN-' + Math.random().toString(36).substring(2, 8).toUpperCase();
                            setRegPin(fresh);
                          }}
                          className="absolute right-1.5 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold uppercase tracking-wide cursor-pointer transition-colors"
                        >
                          ⚡ Auto-Fill
                        </button>
                      </div>

                      {(() => {
                        const unusedPins = issuedPins.filter(p => !p.isUsed);
                        if (unusedPins.length > 0) {
                          return (
                            <div className="mt-2 bg-slate-50 border border-slate-200/60 p-2 rounded-lg">
                              <span className="block text-[9px] text-slate-500 font-bold uppercase tracking-wider mb-1">
                                💡 Available System PIN Keys (Click to select):
                              </span>
                              <div className="flex flex-wrap gap-1">
                                {unusedPins.slice(0, 5).map(p => (
                                  <button
                                    key={p.id}
                                    type="button"
                                    onClick={() => setRegPin(p.pinCode)}
                                    className="px-2 py-0.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[10px] font-mono font-bold border border-emerald-200 rounded transition-colors flex items-center gap-1 cursor-pointer"
                                  >
                                    <Key className="w-2.5 h-2.5 text-emerald-600" />
                                    {p.pinCode}
                                  </button>
                                ))}
                              </div>
                            </div>
                          );
                        }
                        return null;
                      })()}
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Referral Code (Optional)</label>
                      <input 
                        id="reg-input-referral"
                        type="text"
                        placeholder="e.g. JOHN100"
                        value={regReferral}
                        onChange={(e) => setRegReferral(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm uppercase tracking-wider transition-all text-emerald-700 font-mono font-bold"
                      />
                      {(() => {
                        const activeRef = (regReferral.trim() || localStorage.getItem('help100_saved_ref') || '').trim();
                        if (!activeRef) {
                          return (
                            <p className="text-[11px] text-amber-700 mt-1 flex items-center gap-1 font-medium bg-amber-50 border border-amber-200/60 p-1.5 rounded-lg">
                              <Info className="w-3.5 h-3.5 text-amber-600 shrink-0" /> Direct Registration: Linking directly under System Admin (<strong className="font-mono">ADMIN100</strong>)
                            </p>
                          );
                        }

                        const cleanRefUpper = activeRef.toUpperCase();
                        const sponsor = findSponsorInList(activeRef, users);

                        if (sponsor) {
                          return (
                            <p className="text-[11px] text-emerald-700 mt-1 flex items-center gap-1 font-medium bg-emerald-50 border border-emerald-200/60 p-1.5 rounded-lg">
                              <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0" /> Sponsor Verified: <strong className="font-bold">{sponsor.name}</strong> (Ref Code: <span className="font-mono font-bold">{sponsor.referralCode || 'N/A'}</span> | Direct ID: <span className="font-mono font-bold">{sponsor.directId || sponsor.referralCode || sponsor.id}</span>)
                            </p>
                          );
                        } else {
                          return (
                            <p className="text-[11px] text-indigo-700 mt-1 flex items-center gap-1 font-medium bg-indigo-50 border border-indigo-200/60 p-1.5 rounded-lg">
                              <Info className="w-3.5 h-3.5 text-indigo-600 shrink-0" /> Referral Code Entered: <strong className="font-mono font-bold">{cleanRefUpper}</strong> (Will link to sponsor automatically)
                            </p>
                          );
                        }
                      })()}
                    </div>

                    {formError && (
                      <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl font-medium flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                        <div>{formError}</div>
                      </div>
                    )}

                    {pinConfirmRequired && (
                      <div className="p-4 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl space-y-3">
                        <p className="text-xs font-semibold flex items-center gap-1.5 text-amber-800">
                          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                          ₹10 Activation PIN Not in Stock
                        </p>
                        <p className="text-[11px] text-amber-700 leading-relaxed font-medium">
                          The ₹10 PIN <strong className="font-bold">"{regPin.trim().toUpperCase()}"</strong> is not currently in stock. Since this is a sandbox simulation, would you like to automatically generate and consume this ₹10 PIN to pre-activate your help cycle immediately?
                        </p>
                        <div className="flex gap-2 pt-1">
                          <button
                            type="button"
                            onClick={() => {
                              // If they also need overwrite check, trigger it next. Otherwise proceed.
                              const exists = users.find(u => u.email.toLowerCase() === regEmail.trim().toLowerCase() || u.phone === regPhone.trim());
                              if (exists) {
                                setPinConfirmRequired(false);
                                setOverwriteConfirmRequired(true);
                              } else {
                                proceedToOtp();
                              }
                            }}
                            className="flex-1 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold uppercase rounded-lg transition-all shadow-sm cursor-pointer"
                          >
                            Yes, Generate & Proceed
                          </button>
                          <button
                            type="button"
                            onClick={() => setPinConfirmRequired(false)}
                            className="px-3 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold rounded-lg transition-all cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}

                    {overwriteConfirmRequired && (
                      <div className="p-4 bg-orange-50 border border-orange-200 text-orange-900 rounded-xl space-y-3">
                        <p className="text-xs font-semibold flex items-center gap-1.5 text-orange-800">
                          <AlertCircle className="w-4 h-4 text-orange-600 shrink-0" />
                          Account Already Registered
                        </p>
                        <p className="text-[11px] text-orange-700 leading-relaxed font-medium">
                          A member with this email or phone number is already registered in this sandbox. Would you like to overwrite this test profile and register fresh?
                        </p>
                        <div className="flex gap-2 pt-1">
                          <button
                            type="button"
                            onClick={() => proceedToOtp()}
                            className="flex-1 py-2 bg-orange-600 hover:bg-orange-700 text-white text-xs font-extrabold uppercase rounded-lg transition-all shadow-sm cursor-pointer"
                          >
                            Yes, Overwrite & Proceed
                          </button>
                          <button
                            type="button"
                            onClick={() => setOverwriteConfirmRequired(false)}
                            className="px-3 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold rounded-lg transition-all cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}

                    {!pinConfirmRequired && !overwriteConfirmRequired && (
                      <div className="pt-2">
                        <button 
                          id="reg-submit-btn"
                          type="submit"
                          className="w-full py-3 rounded-lg bg-emerald-600 text-white font-medium hover:bg-emerald-700 transition-all text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer"
                        >
                          Generate Verification OTP
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>

                  <p className="text-center text-slate-500 text-xs mt-6">
                    Already registered?{' '}
                    <span onClick={() => setCurrentTab('login')} className="text-emerald-600 hover:underline font-semibold cursor-pointer">
                      Log in here
                    </span>
                  </p>
                </form>
              )}

              {/* REGISTER STEP B: OTP INPUT */}
              {regStep === 'otp' && tempUser && (
                <div>
                  <div className="mb-6">
                    <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Verify Identity</h2>
                    <p className="text-slate-500 text-xs mt-1">We sent a 6-digit OTP code to <strong className="text-slate-800">{tempUser.phone}</strong></p>
                  </div>

                  {/* Dev Sandbox Hint Container */}
                  <div className="mb-5 p-3.5 bg-emerald-50 border border-emerald-100 rounded-lg text-emerald-800">
                    <p className="text-xs font-semibold flex items-center gap-1.5 mb-1">
                      <Key className="w-3.5 h-3.5 text-emerald-600" />
                      Sandbox Simulation Code:
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-lg font-mono font-black tracking-widest bg-white inline-block px-3 py-1 rounded border border-emerald-200/50">
                        {tempUser.otp}
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          setOtpInput(tempUser.otp);
                          setOtpError('');
                        }}
                        className="text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-black py-1 px-3 rounded-lg transition-all cursor-pointer shadow-xs uppercase tracking-wider"
                      >
                        ⚡ Auto-Fill
                      </button>
                    </div>
                    <p className="text-[10px] text-emerald-600 mt-1">Since we are in a sandbox simulation environment, use the code above or '123456'.</p>
                  </div>

                  <form onSubmit={handleVerifyOtp} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">6-Digit OTP</label>
                      <input 
                        id="otp-input-code"
                        type="text"
                        required
                        maxLength={6}
                        placeholder="0 0 0 0 0 0"
                        value={otpInput}
                        onChange={(e) => {
                          setOtpInput(e.target.value.replace(/\D/g, ''));
                          setOtpError('');
                        }}
                        className="w-full text-center text-xl font-bold font-mono tracking-widest py-3 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 transition-all"
                      />
                    </div>

                    {otpError && (
                      <p className="text-xs font-semibold text-rose-600 flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" />
                        {otpError}
                      </p>
                    )}

                    <button 
                      id="otp-verify-btn"
                      type="submit"
                      className="w-full py-3 rounded-lg bg-emerald-600 text-white font-medium hover:bg-emerald-700 transition-all text-sm shadow-md cursor-pointer"
                    >
                      Verify & Set Profile
                    </button>
                  </form>
                </div>
              )}

              {/* REGISTER STEP C: PROFILE COMPLETION */}
              {regStep === 'profile' && tempUser && (
                <form onSubmit={handleProfileSubmit}>
                  <div className="mb-6">
                    <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Complete Profile</h2>
                    <p className="text-slate-500 text-xs mt-1">Tell us a bit more to complete the registration process.</p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">State / City</label>
                      <input 
                        id="profile-input-location"
                        type="text"
                        placeholder="e.g. California, USA"
                        value={profileLocation}
                        onChange={(e) => setProfileLocation(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Occupation / Association</label>
                      <input 
                        id="profile-input-occupation"
                        type="text"
                        placeholder="e.g. Community organizer, Student"
                        value={profileOccupation}
                        onChange={(e) => setProfileOccupation(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm transition-all"
                      />
                    </div>

                    <button 
                      id="profile-submit-btn"
                      type="submit"
                      className="w-full py-3 rounded-lg bg-emerald-600 text-white font-medium hover:bg-emerald-700 transition-all text-sm shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      Continue to KYC
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </form>
              )}

              {/* REGISTER STEP D: KYC DOCUMENT SUBMISSION */}
              {regStep === 'kyc' && tempUser && (
                <form onSubmit={handleKycSubmit}>
                  <div className="mb-6">
                    <h2 className="text-2xl font-bold text-slate-900 tracking-tight">KYC Verification</h2>
                    <p className="text-slate-500 text-xs mt-1">Submit a document to verify your legal identity before active pledges.</p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Document Type</label>
                      <select 
                        id="kyc-select-doctype"
                        value={kycDocType}
                        onChange={(e) => setKycDocType(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm bg-white"
                      >
                        <option value="National ID / Passport">National ID / Passport</option>
                        <option value="Drivers License">Drivers License</option>
                        <option value="Tax Certificate">Tax Certificate ID</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Document Number</label>
                      <input 
                        id="kyc-input-docnumber"
                        type="text"
                        required
                        placeholder="e.g. NID-88201-99"
                        value={kycDocNumber}
                        onChange={(e) => setKycDocNumber(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Upload Scanned Proof</label>
                      
                      <div 
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                        className={`border-2 border-dashed rounded-lg p-5 text-center transition-all cursor-pointer ${
                          dragOver ? 'border-emerald-500 bg-emerald-50' : 'border-slate-300 hover:border-slate-400'
                        }`}
                      >
                        <input 
                          id="kyc-file-upload"
                          type="file" 
                          accept="image/*,.pdf" 
                          onChange={handleFileChange} 
                          className="hidden" 
                        />
                        <label htmlFor="kyc-file-upload" className="cursor-pointer">
                          <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                          <p className="text-xs font-semibold text-slate-700">Drag or click to choose a photo/PDF</p>
                          <p className="text-[10px] text-slate-400 mt-1">PNG, JPG, PDF up to 5MB</p>
                        </label>
                      </div>

                      {kycFileName && (
                        <div className="mt-2 text-xs text-emerald-700 font-semibold flex items-center gap-1 bg-emerald-50 p-2 rounded border border-emerald-100">
                          <CheckCircle className="w-3.5 h-3.5" />
                          File Selected: {kycFileName}
                        </div>
                      )}
                    </div>

                     {kycError && (
                      <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-1.5 rounded-lg">
                        <AlertCircle className="w-4 h-4 text-rose-600" />
                        {kycError}
                      </div>
                    )}

                    <div className="pt-2">
                      <button 
                        id="kyc-submit-btn"
                        type="submit"
                        className="w-full py-3 rounded-lg bg-emerald-600 text-white font-medium hover:bg-emerald-700 transition-all text-sm shadow-md cursor-pointer"
                      >
                        Submit KYC Documents
                      </button>
                    </div>
                  </div>
                </form>
              )}

              {/* REGISTER STEP E: SUCCESS / FINISH */}
              {regStep === 'success' && tempUser && (
                <div className="text-center py-6">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-5">
                    <CheckCircle className="w-10 h-10" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Registration Complete</h2>
                  <p className="text-slate-600 text-xs mt-2 max-w-sm mx-auto">
                    Your details and KYC documents have been recorded under <strong className="text-slate-800">{tempUser.name}</strong>. In our sandbox environment, we have logged you in instantly.
                  </p>

                  <div className="mt-8">
                    <button 
                      id="reg-complete-dash-btn"
                      onClick={() => onLogin(users.find(u => u.email === tempUser.email) || tempUser)}
                      className="px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm transition-all shadow-md cursor-pointer"
                    >
                      Enter Member Dashboard
                    </button>
                  </div>
                </div>
              )}
                </>
              )}

            </div>
          </div>
        )}

        {/* VIEW 3: LOGIN FORM */}
        {currentTab === 'login' && (
          <div className="py-12 max-w-md mx-auto w-full px-4">
            <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xl shadow-slate-100 p-6 sm:p-8">
              {!showForgotPassword ? (
                <>
                  <div className="mb-6">
                    <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Welcome Back</h2>
                    <p className="text-slate-500 text-xs mt-1">Please enter your verified email address to login.</p>
                  </div>

                  {loginError && (
                    <div className="mb-4 p-3 bg-rose-50 border border-rose-100 rounded-lg text-rose-700 text-xs font-semibold flex items-center gap-1.5">
                      <AlertCircle className="w-4 h-4 text-rose-600" />
                      {loginError}
                    </div>
                  )}

                  <form onSubmit={handleLoginSubmit} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Email Address</label>
                      <input 
                        id="login-input-email"
                        type="email"
                        required
                        placeholder="john@help100.com"
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm transition-all"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">Passcode / PIN</label>
                        <span 
                          onClick={() => {
                            setShowForgotPassword(true);
                            setForgotError('');
                            setForgotSuccess('');
                          }}
                          className="text-[10px] text-slate-400 hover:underline hover:text-emerald-600 cursor-pointer"
                        >
                          Forgot passcode?
                        </span>
                      </div>
                      <div className="relative">
                        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"><Lock className="w-4 h-4" /></span>
                        <input 
                          id="login-input-password"
                          type="password"
                          placeholder="••••••"
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          className="w-full pl-10 pr-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm transition-all"
                        />
                      </div>
                      <p className="text-[10px] text-slate-400 mt-1">Contact your referral partner if you do not have your passcode.</p>
                    </div>

                    <div className="pt-2">
                      <button 
                        id="login-submit-btn"
                        type="submit"
                        className="w-full py-3 rounded-lg bg-emerald-600 text-white font-medium hover:bg-emerald-700 transition-all text-sm shadow-md cursor-pointer"
                      >
                        Authenticate Securely
                      </button>
                    </div>
                  </form>
                </>
              ) : (
                <>
                  <div className="mb-6">
                    <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Recover Passcode</h2>
                    <p className="text-slate-500 text-xs mt-1">Dispatches secure ID & password via SMTP email.</p>
                  </div>

                  {forgotError && (
                    <div className="mb-4 p-3 bg-rose-50 border border-rose-100 rounded-lg text-rose-700 text-xs font-semibold flex items-center gap-1.5">
                      <AlertCircle className="w-4 h-4 text-rose-600" />
                      {forgotError}
                    </div>
                  )}

                  {forgotSuccess && (
                    <div className="mb-4 p-3 bg-emerald-50 border border-emerald-100 rounded-lg text-emerald-700 text-xs font-semibold flex items-center gap-1.5">
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                      {forgotSuccess}
                    </div>
                  )}

                  <form onSubmit={handleForgotPasswordSubmit} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Enter Registered Email</label>
                      <input 
                        id="forgot-password-email-page"
                        type="email"
                        required
                        placeholder="john@help100.com"
                        value={forgotEmail}
                        onChange={(e) => {
                          setForgotEmail(e.target.value);
                          setForgotError('');
                          setForgotSuccess('');
                        }}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 text-sm transition-all"
                      />
                    </div>

                    <div className="pt-2">
                      <button 
                        id="forgot-password-submit-btn-page"
                        type="submit"
                        className="w-full py-3 rounded-lg bg-emerald-600 text-white font-medium hover:bg-emerald-700 transition-all text-sm shadow-md cursor-pointer animate-pulse"
                      >
                        📧 Send Recovery Credentials
                      </button>
                    </div>

                    <div className="pt-2 text-center">
                      <span 
                        onClick={() => setShowForgotPassword(false)}
                        className="text-[10px] text-slate-400 hover:text-emerald-600 cursor-pointer hover:underline font-bold uppercase tracking-wider"
                      >
                        &larr; Back to Login
                      </span>
                    </div>
                  </form>
                </>
              )}

              <p className="text-center text-slate-500 text-xs mt-6">
                Don't have an account?{' '}
                <span onClick={() => { setCurrentTab('register'); setRegStep('form'); }} className="text-emerald-600 hover:underline font-semibold cursor-pointer">
                  Register here
                </span>
              </p>
            </div>
          </div>
        )}

        {/* VIEW 4: ADMIN LOGIN FORM */}
        {currentTab === 'admin_login' && (
          <div className="py-12 max-w-md mx-auto w-full px-4">
            <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-2xl p-6 sm:p-8 text-slate-100 animate-in fade-in slide-in-from-bottom-4 duration-300">
              <div className="mb-6 text-center sm:text-left">
                <span className="inline-flex px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/35 mb-2.5">
                  🛡️ Secure Administrative Gateway
                </span>
                <h2 className="text-2xl font-extrabold text-white tracking-tight">Admin Authentication</h2>
                <p className="text-slate-400 text-xs mt-1">Please log in using your registered administrative credentials.</p>
              </div>

              {adminError && (
                <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/20 rounded-lg text-rose-300 text-xs font-semibold flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-rose-400" />
                  {adminError}
                </div>
              )}

              <form onSubmit={handleAdminLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Administrative Email</label>
                  <input 
                    id="admin-input-email"
                    type="email"
                    required
                    placeholder="admin@help100.com"
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-800 bg-slate-950 text-white focus:outline-none focus:border-rose-500 text-sm transition-all placeholder-slate-600"
                  />
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest">Admin Security PIN</label>
                    <span className="text-[10px] text-slate-500 hover:underline cursor-pointer">Reset PIN</span>
                  </div>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500"><Lock className="w-4 h-4" /></span>
                    <input 
                      id="admin-input-password"
                      type="password"
                      placeholder="••••••"
                      value={adminPassword}
                      onChange={(e) => setAdminPassword(e.target.value)}
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-lg border border-slate-800 bg-slate-950 text-white focus:outline-none focus:border-rose-500 text-sm transition-all placeholder-slate-600"
                    />
                  </div>

                </div>

                <div className="pt-2">
                  <button 
                    id="admin-submit-btn"
                    type="submit"
                    className="w-full py-3 rounded-lg bg-rose-600 text-white font-extrabold hover:bg-rose-500 hover:shadow-lg hover:shadow-rose-950/40 active:scale-95 transition-all text-xs uppercase tracking-wider cursor-pointer animate-pulse-subtle"
                  >
                    Verify Signature & Access Systems
                  </button>
                </div>
              </form>

              {/* Secure Logs Disclaimer */}
              <div className="mt-6 p-3 bg-slate-950/60 border border-slate-800 rounded-xl">
                <span className="text-[9px] font-black text-rose-400 uppercase tracking-widest block mb-1">🛡️ SECURITY COMPLIANCE</span>
                <p className="text-[10px] text-slate-400 leading-normal">All IP addresses, hardware signatures, and system activities within this administrative gateway are permanently logged in compliance with platform audits.</p>
              </div>

              <p className="text-center text-slate-500 text-xs mt-6">
                Are you a member?{' '}
                <span onClick={() => setCurrentTab('login')} className="text-emerald-400 hover:underline font-semibold cursor-pointer">
                  Go to Member Sign In
                </span>
              </p>
            </div>
          </div>
        )}

      </main>

      {/* Landing Footer */}
      <footer className="bg-white border-t border-slate-200 py-8 text-center text-xs text-slate-500 mt-auto flex flex-col items-center justify-center gap-4">
        <div className="space-y-1">
          <p>© 2026 HELP 100 Mutual Aid Network. All Rights Reserved.</p>
          <p className="text-slate-400">Powered by the One Hundred Mutual Pledge Core. Zero Platform Fees.</p>
        </div>
      </footer>

      {/* Visual Simulated Email Client Delivery Notification Popup */}
      <AnimatePresence>
        {incomingEmail && (
          <motion.div 
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 flex flex-col max-h-[90vh]">
              {/* Header */}
              <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="animate-ping rounded-full h-2 w-2 bg-emerald-400"></span>
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-200">📬 SMTP Outbox Dispatch Simulator</div>
                </div>
                <button 
                  onClick={() => setIncomingEmail(null)}
                  className="text-slate-400 hover:text-white font-bold text-sm bg-slate-800 hover:bg-slate-700 h-6 w-6 rounded-full flex items-center justify-center cursor-pointer transition-all"
                >
                  ✕
                </button>
              </div>

              {/* Message Details */}
              <div className="bg-slate-50 border-b border-slate-200 p-4 text-xs space-y-2">
                <div className="flex"><span className="w-16 font-semibold text-slate-500">From:</span><span className="text-slate-800 font-bold">Help 100 SMTP Server &lt;noreply@help2-dcc45.firebaseapp.com&gt;</span></div>
                <div className="flex"><span className="w-16 font-semibold text-slate-500">To:</span><span className="text-slate-800 font-bold">{incomingEmail.recipientName} &lt;{incomingEmail.recipientEmail}&gt;</span></div>
                <div className="flex"><span className="w-16 font-semibold text-slate-500">Subject:</span><span className="text-emerald-700 font-extrabold">{incomingEmail.subject}</span></div>
                <div className="flex"><span className="w-16 font-semibold text-slate-500">Sent via:</span><span className="text-slate-400">Secured Node SMTP Gateway (Simulation active)</span></div>
              </div>

              {/* Email Content Frame */}
              <div className="p-6 overflow-y-auto bg-white flex-1 min-h-[250px]">
                <div className="max-w-md mx-auto space-y-6">
                  {/* Logo header */}
                  <div className="flex justify-center border-b border-slate-100 pb-4">
                    <Logo />
                  </div>

                  {/* Body Text */}
                  <div className="text-slate-700 text-xs leading-relaxed space-y-4 whitespace-pre-line font-medium font-sans">
                    {incomingEmail.body}
                  </div>

                  {/* Platform notice */}
                  <div className="text-[10px] text-slate-400 text-center border-t border-slate-100 pt-4 font-semibold">
                    🔐 Help 100 System Operations • SECURE TRANSACTION DISPATCHER • Bengaluru, India
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="bg-slate-50 p-4 border-t border-slate-100 flex items-center justify-between">
                <div className="text-[10px] text-emerald-600 font-black flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Logged in Admin Portal &rarr; Email Logs tab</span>
                </div>
                <button
                  onClick={() => setIncomingEmail(null)}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-black uppercase tracking-wider cursor-pointer shadow-md shadow-slate-900/10"
                >
                  Got it & Close
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
