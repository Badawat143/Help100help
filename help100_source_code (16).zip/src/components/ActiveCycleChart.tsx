import React from 'react';
import { 
  ResponsiveContainer, 
  ComposedChart, 
  Bar, 
  Area, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend 
} from 'recharts';
import { TrendingUp, ArrowUpRight, ArrowDownLeft, Landmark, Zap, Compass } from 'lucide-react';

interface ActiveCycleChartProps {
  cycleState: {
    currentStep: 'buy_pin' | 'first_ph' | 'second_ph' | 'first_gh' | 'second_gh' | 'third_gh' | 'fourth_gh' | 'fifth_gh' | 'completed';
    pinPurchased: boolean;
    firstPhSubmitted: boolean;
    secondPhSubmitted: boolean;
    firstGhReceived: boolean;
    secondGhReceived: boolean;
    thirdGhReceived: boolean;
    fourthGhReceived: boolean;
    fifthGhReceived: boolean;
    totalProvided: number;
    totalReceived: number;
    totalProfit: number;
    cycleCount: number;
  };
}

export default function ActiveCycleChart({ cycleState }: ActiveCycleChartProps) {
  // 1. Calculate cumulative progression through the 9 stages of the help 100 plan
  const getProgressionData = () => {
    const steps = [
      { 
        id: 'buy_pin', 
        name: 'Step 1: PIN', 
        ph: 10, 
        gh: 0, 
        isCompleted: cycleState.pinPurchased || cycleState.currentStep !== 'buy_pin' 
      },
      { 
        id: 'first_ph', 
        name: 'Step 2: PH Link 1', 
        ph: 50, // Cumulative: 10 (pin) + 40 (ph1)
        gh: 0, 
        isCompleted: cycleState.firstPhSubmitted || !['buy_pin', 'first_ph'].includes(cycleState.currentStep) 
      },
      { 
        id: 'second_ph', 
        name: 'Step 3: PH Link 2', 
        ph: 100, // Cumulative: 50 + 50 (ph2)
        gh: 0, 
        isCompleted: cycleState.secondPhSubmitted || !['buy_pin', 'first_ph', 'second_ph'].includes(cycleState.currentStep) 
      },
      { 
        id: 'first_gh', 
        name: 'Step 4: GH Link 1', 
        ph: 100, 
        gh: 50, // Cumulative Received
        isCompleted: cycleState.firstGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh'].includes(cycleState.currentStep) 
      },
      { 
        id: 'second_gh', 
        name: 'Step 5: GH Link 2', 
        ph: 100, 
        gh: 100, // Cumulative Received
        isCompleted: cycleState.secondGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh'].includes(cycleState.currentStep) 
      },
      { 
        id: 'third_gh', 
        name: 'Step 6: GH Link 3', 
        ph: 100, 
        gh: 125, // Cumulative Received
        isCompleted: cycleState.thirdGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh', 'third_gh'].includes(cycleState.currentStep) 
      },
      { 
        id: 'fourth_gh', 
        name: 'Step 7: GH Link 4', 
        ph: 100, 
        gh: 150, // Cumulative Received
        isCompleted: cycleState.fourthGhReceived || !['buy_pin', 'first_ph', 'second_ph', 'first_gh', 'second_gh', 'third_gh', 'fourth_gh'].includes(cycleState.currentStep) 
      },
      { 
        id: 'fifth_gh', 
        name: 'Step 8: GH Link 5', 
        ph: 100, 
        gh: 175, // Cumulative Received
        isCompleted: cycleState.fifthGhReceived || cycleState.currentStep === 'completed' 
      }
    ];

    return steps.map(s => {
      // If the step is not reached/completed yet in the active cycle, we show what is projected,
      // but color it differently or display with lighter stroke in the legend/tooltip.
      return {
        name: s.name.replace('Step ', 'S'),
        fullName: s.name,
        Provided: s.ph,
        Received: s.gh,
        'Net Profit': s.gh - s.ph,
        status: s.isCompleted ? 'Completed' : (cycleState.currentStep === s.id ? 'Current' : 'Upcoming')
      };
    });
  };

  const chartData = getProgressionData();

  // Custom tooltips to present beautifully formatted Indian Rupees
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const stepDetails = chartData.find(d => d.name === label);
      return (
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow-xl text-xs space-y-1.5 font-sans">
          <p className="font-extrabold text-indigo-300">{stepDetails?.fullName}</p>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 inline-block"></span>
            <span className="text-slate-400 font-medium">Provided (PH Link):</span>
            <span className="text-white font-bold font-mono">₹{payload[0].value}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block"></span>
            <span className="text-slate-400 font-medium">Received (GH Link):</span>
            <span className="text-white font-bold font-mono">₹{payload[1].value}</span>
          </div>
          <div className="flex items-center gap-1.5 pt-1 border-t border-slate-800">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block"></span>
            <span className="text-slate-400 font-medium">Net Position:</span>
            <span className={`font-black font-mono ${payload[2].value >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {payload[2].value >= 0 ? '+' : ''}₹{payload[2].value}
            </span>
          </div>
          <p className="text-[10px] text-slate-500 italic mt-1 pt-1 font-mono border-t border-slate-800/50">
            Stage Status: <strong className="text-indigo-400 uppercase">{stepDetails?.status}</strong>
          </p>
        </div>
      );
    }
    return null;
  };

  // Quick stats calculations
  const netEarnings = cycleState.totalReceived - cycleState.totalProvided;
  const progressPercent = Math.min(100, Math.round((cycleState.totalReceived / 175) * 100));

  return (
    <div id="active-cycle-chart-panel" className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-sm space-y-6">
      {/* Upper header statistics */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
              <TrendingUp className="w-4 h-4" />
            </span>
            <h3 className="font-extrabold text-slate-900 text-sm tracking-tight uppercase">
              Cycle #{cycleState.cycleCount} Earnings & Capital Flow Chart
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Track cumulative PH Link inputs vs GH Link payouts for your active cycle milestones.
          </p>
        </div>

        {/* Real-time Indicators */}
        <div className="flex flex-wrap items-center gap-4 text-xs">
          <div className="bg-indigo-50/70 border border-indigo-100/50 px-3 py-1.5 rounded-xl flex items-center gap-2">
            <ArrowUpRight className="w-3.5 h-3.5 text-indigo-600" />
            <div>
              <span className="text-[9px] text-slate-400 uppercase font-bold block leading-none">Cycle PH Link</span>
              <span className="font-extrabold text-indigo-700 font-mono text-xs">₹{cycleState.totalProvided}</span>
            </div>
          </div>

          <div className="bg-emerald-50/70 border border-emerald-100/50 px-3 py-1.5 rounded-xl flex items-center gap-2">
            <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-600" />
            <div>
              <span className="text-[9px] text-slate-400 uppercase font-bold block leading-none">Cycle GH Link</span>
              <span className="font-extrabold text-emerald-700 font-mono text-xs">₹{cycleState.totalReceived}</span>
            </div>
          </div>

          <div className="bg-amber-50/80 border border-amber-100/50 px-3 py-1.5 rounded-xl flex items-center gap-2">
            <Landmark className="w-3.5 h-3.5 text-amber-600" />
            <div>
              <span className="text-[9px] text-slate-400 uppercase font-bold block leading-none">Net Growth</span>
              <span className={`font-black font-mono text-xs ${netEarnings >= 0 ? 'text-emerald-700' : 'text-slate-700'}`}>
                {netEarnings >= 0 ? '+' : ''}₹{netEarnings}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of chart and radial/mini metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-center">
        {/* RECHARTS COMPOSED CHART CONTAINER */}
        <div className="lg:col-span-3 h-[280px] w-full" id="cycle-flow-recharts-container">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={chartData}
              margin={{ top: 10, right: 5, left: -20, bottom: 0 }}
            >
              <defs>
                <linearGradient id="providedGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.15}/>
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="receivedGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.01}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis 
                dataKey="name" 
                stroke="#94a3b8" 
                fontSize={10} 
                fontWeight={700}
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                stroke="#94a3b8" 
                fontSize={10} 
                fontWeight={700}
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => `₹${val}`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                verticalAlign="top" 
                height={36} 
                iconType="circle"
                iconSize={8}
                wrapperStyle={{ fontSize: '11px', fontWeight: 700 }}
              />
              
              {/* Received cumulative filled area */}
              <Area 
                type="monotone" 
                name="Cumulative Received (GH Link)" 
                dataKey="Received" 
                stroke="#10b981" 
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#receivedGrad)" 
              />
              
              {/* Provided cumulative bar chart */}
              <Bar 
                name="Cumulative Provided (PH Link)" 
                dataKey="Provided" 
                barSize={18} 
                fill="#6366f1" 
                radius={[4, 4, 0, 0]}
              />

              {/* Net profit/position line trend */}
              <Line 
                type="monotone" 
                name="Milestone Net Position" 
                dataKey="Net Profit" 
                stroke="#f59e0b" 
                strokeWidth={3} 
                dot={{ stroke: '#f59e0b', strokeWidth: 2, r: 4, fill: '#fff' }}
                activeDot={{ r: 6, strokeWidth: 0 }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {/* SIDEBAR RADIAL/PROGRESS SUMMARY */}
        <div className="bg-slate-50/70 border border-slate-100 rounded-2xl p-4 space-y-4 h-full flex flex-col justify-between">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-black tracking-wider flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-500" /> Current Step Target
            </span>
            <p className="text-sm font-black text-slate-800 capitalize mt-1">
              {cycleState.currentStep === 'completed' ? 'All Steps Finished' : cycleState.currentStep.replace('_', ' ')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
              Your cycle completes once you unlock step 8 and receive all ₹175 total matching aid.
            </p>
          </div>

          <div className="space-y-2 py-3 border-t border-b border-slate-200/50">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-500 font-bold">GH Link Yield Achieved:</span>
              <span className="font-black text-slate-900">{progressPercent}%</span>
            </div>
            
            {/* Visual Custom Progress bar */}
            <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            
            <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold">
              <span>₹{cycleState.totalReceived} Received</span>
              <span>₹175 Goal</span>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-white border border-slate-100 p-2.5 rounded-xl shadow-2xs">
            <Compass className="w-4 h-4 text-indigo-500 shrink-0" />
            <p className="text-[10px] text-slate-500 font-medium leading-normal">
              Need assistance? Proceed to provide or receive help in the active board below to keep the progression metrics updated.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
