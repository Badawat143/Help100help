import express from 'express';
import path from 'path';
import fs from 'fs';
import { execSync } from 'child_process';
import { createServer as createViteServer } from 'vite';
import { INITIAL_USERS } from './src/data';
import { findSponsorInList } from './src/lib/sponsorUtils';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(process.cwd(), 'public')));

// ZIP file download endpoint with on-demand fallback build
const serveZipFile = (req: express.Request, res: express.Response) => {
  const primaryPath = path.join(process.cwd(), 'public', 'help100_source_code.zip');
  const possiblePaths = [
    primaryPath,
    path.join(process.cwd(), 'help100_source_code.zip'),
    path.join(process.cwd(), 'public', 'help100_source.zip'),
    path.join(process.cwd(), 'help100_source.zip')
  ];

  for (const zipPath of possiblePaths) {
    if (fs.existsSync(zipPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="help100_source_code.zip"');
      return res.sendFile(zipPath);
    }
  }

  // Generate on demand if missing or corrupted
  try {
    const pyScript = `
import zipfile, os, shutil
out_path = '${primaryPath}'
tmp_path = os.path.join(os.path.dirname(out_path), 'temp_build.zip')
os.makedirs(os.path.dirname(out_path), exist_ok=True)
if os.path.exists(tmp_path):
    os.remove(tmp_path)
with zipfile.ZipFile(tmp_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        if any(x in root for x in ['node_modules', 'dist', '.git', '.aistudio']):
            continue
        for file in files:
            if file.endswith('.zip'):
                continue
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, '.')
            zipf.write(file_path, arcname)
shutil.move(tmp_path, out_path)
shutil.copy(out_path, 'help100_source_code.zip')
`;
    execSync(`python3 -c "${pyScript.replace(/\n/g, ' ')}"`, { cwd: process.cwd() });
    if (fs.existsSync(primaryPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="help100_source_code.zip"');
      return res.sendFile(primaryPath);
    }
  } catch (e) {
    console.error('Failed to generate ZIP file on demand:', e);
  }

  res.status(500).send('Unable to generate ZIP file at this moment.');
};

app.get('/help100_source_code.zip', serveZipFile);
app.get('/help100_source.zip', serveZipFile);
app.get('/download-zip', serveZipFile);
app.get('/api/download-zip', serveZipFile);

// Path to persistent server data store
const DATA_FILE = path.join(process.cwd(), 'server_data.json');

interface ServerData {
  users?: any[];
  contributions?: any[];
  helpRequests?: any[];
  transactions?: any[];
  systemSettings?: any;
  notifications?: any[];
  tickets?: any[];
  issuedPins?: any[];
  p2pMatches?: any[];
  communityReserves?: number;
  emailLogs?: any[];
  cycleStates?: Record<string, any>;
  lastUpdated?: string;
}

// In-memory data cache
let serverMemoryData: ServerData = {};

// Helper to load data from disk and seed initial users
function loadServerData(): ServerData {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, 'utf-8');
      serverMemoryData = JSON.parse(content);
    }
  } catch (e) {
    console.error('Failed to read server_data.json:', e);
  }

  // Ensure default seed users exist in serverMemoryData
  if (!serverMemoryData.users || serverMemoryData.users.length === 0) {
    serverMemoryData.users = [...INITIAL_USERS];
  } else {
    const existingMap = new Map<string, any>();
    serverMemoryData.users.forEach((u: any) => {
      if (u && u.id) existingMap.set(u.id, u);
    });
    INITIAL_USERS.forEach((initUser: any) => {
      if (!existingMap.has(initUser.id)) {
        serverMemoryData.users!.push(initUser);
      }
    });
  }

  return serverMemoryData;
}

// Helper to save data to disk
function saveServerData(newData: Partial<ServerData>) {
  try {
    serverMemoryData = {
      ...serverMemoryData,
      ...newData,
      lastUpdated: new Date().toISOString()
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(serverMemoryData, null, 2), 'utf-8');
  } catch (e) {
    console.error('Failed to write server_data.json:', e);
  }
}

// Initialize server data on boot
loadServerData();

// --- API ROUTES ---

app.get(['/download-zip', '/help100_source_code.zip', '/help100-source-code.zip', '/help100_source.zip', '/help100-source.zip'], (_req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  const possiblePaths = [
    path.join(process.cwd(), 'public', 'help100_source_code.zip'),
    path.join(process.cwd(), 'dist', 'help100_source_code.zip'),
    path.join(process.cwd(), 'help100_source_code.zip'),
    path.join(process.cwd(), 'public', 'help100_source.zip'),
    path.join(process.cwd(), 'help100_source.zip'),
  ];
  for (const p of possiblePaths) {
    if (fs.existsSync(p)) {
      res.setHeader('Content-Type', 'application/zip');
      return res.download(p, 'help100_source_code.zip');
    }
  }
  // If no zip file exists, build it on the fly
  try {
    const primaryPath = path.join(process.cwd(), 'public', 'help100_source_code.zip');
    const cmd = `python3 -c "import zipfile, os; out = '${primaryPath}'; os.makedirs(os.path.dirname(out), exist_ok=True); zipf = zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED); [zipf.write(os.path.join(r, f), os.path.relpath(os.path.join(r, f), '.')) for r, d, files in os.walk('.') if not any(x in r for x in ['node_modules', 'dist', '.git', '.aistudio']) for f in files if not f.endswith('.zip')]; zipf.close()"`;
    execSync(cmd, { cwd: process.cwd() });
    if (fs.existsSync(primaryPath)) {
      res.setHeader('Content-Type', 'application/zip');
      return res.download(primaryPath, 'help100_source_code.zip');
    }
  } catch (err) {
    console.error('Error generating zip on fly:', err);
  }
  res.status(404).send('Zip file not found');
});

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Force regenerate the latest source code ZIP archive
app.post('/api/update-zip', (_req, res) => {
  const primaryPath = path.join(process.cwd(), 'public', 'help100_source_code.zip');
  try {
    const cmd = `python3 -c "import zipfile, os; out = '${primaryPath}'; os.makedirs(os.path.dirname(out), exist_ok=True); zipf = zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED); [zipf.write(os.path.join(r, f), os.path.relpath(os.path.join(r, f), '.')) for r, d, files in os.walk('.') if not any(x in r for x in ['node_modules', 'dist', '.git', '.aistudio']) for f in files if not f.endswith('.zip')]; zipf.close()"`;
    execSync(cmd, { cwd: process.cwd() });
    return res.json({ success: true, message: 'Source code ZIP file successfully updated on server!', updatedAt: new Date().toISOString() });
  } catch (e: any) {
    console.error('Error regenerating ZIP:', e);
    return res.status(500).json({ success: false, error: e?.message || 'Failed to generate ZIP' });
  }
});

// Full Sync GET - All connected devices fetch current state
app.get('/api/sync', (_req, res) => {
  const current = loadServerData();
  if (current && Array.isArray(current.users)) {
    const rawUsers = current.users;
    current.users = rawUsers.map((u: any) => sanitizeUserSponsors(u, rawUsers));
  }
  res.json({
    success: true,
    data: current
  });
});

// Helper to automatically link and sanitize user sponsor relationships across devices
function sanitizeUserSponsors(user: any, usersList: any[]): any {
  if (!user || !user.id) return user;

  const candidateRefs = [
    user.sponsorId,
    user.directSponsorId,
    user.referredBy
  ].filter(Boolean);

  let sponsor: any = null;
  // 1. Try candidate refs that are NOT 'ADMIN100' or 'admin-id' first
  for (const ref of candidateRefs) {
    if (typeof ref === 'string' && ref.trim() && ref.trim().toUpperCase() !== 'ADMIN100' && ref.trim().toLowerCase() !== 'admin-id') {
      const found = findSponsorInList(ref, usersList);
      if (found) {
        sponsor = found;
        break;
      }
    }
  }

  // 2. If no non-admin sponsor found, try any candidate ref
  if (!sponsor) {
    for (const ref of candidateRefs) {
      if (typeof ref === 'string' && ref.trim()) {
        const found = findSponsorInList(ref, usersList);
        if (found) {
          sponsor = found;
          break;
        }
      }
    }
  }

  const finalReferredBy = sponsor ? (sponsor.referralCode || sponsor.id) : (user.referredBy || 'ADMIN100');
  const finalSponsorId = sponsor ? sponsor.id : (user.sponsorId || finalReferredBy);
  const finalDirectSponsorId = sponsor ? (sponsor.referralCode || sponsor.id) : (user.directSponsorId || finalReferredBy);

  return {
    ...user,
    referredBy: finalReferredBy,
    sponsorId: finalSponsorId,
    directSponsorId: finalDirectSponsorId
  };
}

// Full Sync POST - Any client updates central state
app.post('/api/sync', (req, res) => {
  const payload = req.body || {};
  loadServerData();
  
  // Merge users safely preserving all user records across all devices
  if (Array.isArray(payload.users)) {
    const existingUsers: any[] = serverMemoryData.users || [];
    const userMap = new Map<string, any>();
    
    existingUsers.forEach(u => {
      if (u && u.id) userMap.set(u.id, u);
    });
    payload.users.forEach(u => {
      if (u && u.id) {
        const existing = userMap.get(u.id);
        if (!existing) {
          userMap.set(u.id, u);
        } else {
          let merged = { ...existing, ...u };
          if (existing.sponsorId && existing.sponsorId.startsWith('user-') && (!u.sponsorId || !u.sponsorId.startsWith('user-'))) {
            merged.sponsorId = existing.sponsorId;
            merged.directSponsorId = existing.directSponsorId;
            merged.referredBy = existing.referredBy;
          }
          userMap.set(u.id, merged);
        }
      }
    });

    const mergedList = Array.from(userMap.values());
    serverMemoryData.users = mergedList.map(u => sanitizeUserSponsors(u, mergedList));
  }

  if (Array.isArray(payload.contributions)) {
    const map = new Map<string, any>();
    (serverMemoryData.contributions || []).forEach(c => map.set(c.id, c));
    payload.contributions.forEach(c => map.set(c.id, c));
    serverMemoryData.contributions = Array.from(map.values());
  }

  if (Array.isArray(payload.helpRequests)) {
    const map = new Map<string, any>();
    (serverMemoryData.helpRequests || []).forEach(h => map.set(h.id, h));
    payload.helpRequests.forEach(h => map.set(h.id, h));
    serverMemoryData.helpRequests = Array.from(map.values());
  }

  if (Array.isArray(payload.transactions)) {
    const map = new Map<string, any>();
    (serverMemoryData.transactions || []).forEach(t => map.set(t.id, t));
    payload.transactions.forEach(t => map.set(t.id, t));
    serverMemoryData.transactions = Array.from(map.values());
  }

  if (Array.isArray(payload.issuedPins)) {
    const map = new Map<string, any>();
    (serverMemoryData.issuedPins || []).forEach(p => map.set(p.id, p));
    payload.issuedPins.forEach(p => {
      if (p && p.id) {
        const existing = map.get(p.id);
        if (!existing) {
          map.set(p.id, p);
        } else {
          map.set(p.id, { ...existing, ...p });
        }
      }
    });
    serverMemoryData.issuedPins = Array.from(map.values());
  }

  if (payload.cycleStates && typeof payload.cycleStates === 'object') {
    serverMemoryData.cycleStates = {
      ...(serverMemoryData.cycleStates || {}),
      ...payload.cycleStates
    };
  }

  if (payload.p2pMatches && Array.isArray(payload.p2pMatches)) {
    const map = new Map<string, any>();
    (serverMemoryData.p2pMatches || []).forEach(m => map.set(m.id, m));
    payload.p2pMatches.forEach(m => map.set(m.id, m));
    serverMemoryData.p2pMatches = Array.from(map.values());
  }

  if (payload.systemSettings && typeof payload.systemSettings === 'object') {
    serverMemoryData.systemSettings = {
      ...(serverMemoryData.systemSettings || {}),
      ...payload.systemSettings
    };
  }

  if (Array.isArray(payload.notifications)) {
    const map = new Map<string, any>();
    (serverMemoryData.notifications || []).forEach(n => map.set(n.id, n));
    payload.notifications.forEach(n => map.set(n.id, n));
    serverMemoryData.notifications = Array.from(map.values());
  }

  saveServerData(serverMemoryData);
  res.json({ success: true, timestamp: new Date().toISOString(), data: serverMemoryData });
});

// Single user POST endpoint
app.post('/api/users', (req, res) => {
  const newUser = req.body;
  if (!newUser || !newUser.id) {
    return res.status(400).json({ error: 'Invalid user payload' });
  }

  loadServerData();
  const existingUsers: any[] = serverMemoryData.users || [];

  const sanitizedUser = sanitizeUserSponsors(newUser, existingUsers);

  const existingIndex = existingUsers.findIndex(u => u.id === sanitizedUser.id || (u.email && u.email === sanitizedUser.email));
  if (existingIndex !== -1) {
    existingUsers[existingIndex] = { ...existingUsers[existingIndex], ...sanitizedUser };
  } else {
    existingUsers.push(sanitizedUser);
  }

  const updatedList = existingUsers.map(u => sanitizeUserSponsors(u, existingUsers));
  saveServerData({ users: updatedList });

  res.json({
    success: true,
    user: sanitizedUser,
    users: updatedList
  });
});

// Register Endpoint - Realtime multi-device user registration
app.post('/api/users/register', (req, res) => {
  const newUser = req.body;
  if (!newUser || !newUser.name) {
    return res.status(400).json({ error: 'Invalid user payload' });
  }

  loadServerData();
  const existingUsers: any[] = serverMemoryData.users || [];

  const sanitizedUser = sanitizeUserSponsors({
    ...newUser,
    registeredAt: newUser.registeredAt || new Date().toISOString(),
    _updatedAt: newUser._updatedAt || Date.now()
  }, existingUsers);

  // Check if user already exists
  const existingIndex = existingUsers.findIndex(u => u.id === sanitizedUser.id || (u.email && u.email === sanitizedUser.email));
  if (existingIndex !== -1) {
    existingUsers[existingIndex] = { ...existingUsers[existingIndex], ...sanitizedUser };
  } else {
    existingUsers.push(sanitizedUser);
  }

  const updatedList = existingUsers.map(u => sanitizeUserSponsors(u, existingUsers));
  saveServerData({ users: updatedList });

  res.json({
    success: true,
    user: sanitizedUser,
    users: updatedList
  });
});

async function startServer() {
  // Vite Middleware for development mode
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Express server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
