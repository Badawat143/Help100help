export default function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const newUser = req.body;
  if (!newUser || !newUser.name) {
    return res.status(400).json({ error: 'Invalid user payload' });
  }

  return res.status(200).json({
    success: true,
    user: newUser
  });
}
