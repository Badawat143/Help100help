// Global shared cache across Vercel function calls
let serverMemoryData: any = {
  users: [],
  contributions: [],
  helpRequests: [],
  transactions: [],
  issuedPins: [],
  p2pMatches: [],
  notifications: [],
  tickets: []
};

export default function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method === 'POST') {
    const payload = req.body || {};
    
    if (Array.isArray(payload.users)) {
      const userMap = new Map<string, any>();
      (serverMemoryData.users || []).forEach((u: any) => userMap.set(u.id, u));
      payload.users.forEach((u: any) => {
        if (u && u.id) {
          userMap.set(u.id, { ...(userMap.get(u.id) || {}), ...u });
        }
      });
      serverMemoryData.users = Array.from(userMap.values());
    }

    if (Array.isArray(payload.contributions)) {
      const cMap = new Map<string, any>();
      (serverMemoryData.contributions || []).forEach((c: any) => cMap.set(c.id, c));
      payload.contributions.forEach((c: any) => { if (c && c.id) cMap.set(c.id, c); });
      serverMemoryData.contributions = Array.from(cMap.values());
    }

    return res.status(200).json({ success: true, timestamp: new Date().toISOString() });
  }

  return res.status(200).json({
    success: true,
    data: serverMemoryData
  });
}
