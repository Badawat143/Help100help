import React, { useState } from 'react';
import Logo from './Logo';
import { User, Contribution, HelpRequest, Transaction, SystemSettings, Notification, SupportTicket, IssuedPin, P2PMatch, EmailLog, SpecialOffer } from '../types';
import { findSponsorInList, getDirectChildren } from '../lib/sponsorUtils';
import { 
  Users, 
  ArrowRightLeft,
  ShieldAlert, 
  Activity, 
  HeartHandshake, 
  FileCheck, 
  Wallet, 
  Settings, 
  HardDrive, 
  Lock, 
  FileText, 
  UserCheck, 
  XCircle, 
  CheckCircle, 
  Trash2, 
  PlusCircle,
  TrendingUp,
  AlertTriangle,
  Info,
  Key,
  Cpu,
  History,
  Link2,
  Copy,
  Save,
  ShieldCheck,
  Download,
  Smartphone,
  Mail,
  ChevronDown,
  ChevronRight
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { resetCloudConnection } from '../lib/firebase';

interface AdminDashboardProps {
  systemSettings: SystemSettings;
  users: User[];
  contributions: Contribution[];
  helpRequests: HelpRequest[];
  transactions: Transaction[];
  notifications: Notification[];
  tickets: SupportTicket[];
  issuedPins: IssuedPin[];
  p2pMatches: P2PMatch[];
  communityReserves: number;
  onUpdateSettings: (settings: SystemSettings) => void;
  onUpdateUser: (updatedUser: User) => void;
  onUpdateContribution: (contribId: string, status: 'pending_dispatch' | 'pending_proof' | 'pending_verification' | 'approved' | 'rejected', remarks?: string, txLink?: string) => void;
  onUpdateHelpRequest: (helpId: string, status: 'approved' | 'rejected' | 'completed' | 'pending_review', receivedAmt?: number, remarks?: string, txLink?: string) => void;
  onUpdateTransaction: (txId: string, status: 'pending' | 'completed' | 'rejected', txLink?: string, amount?: number) => void;
  onUpdateTicket: (ticketId: string, reply: string) => void;
  onAddNotification: (notif: Notification) => void;
  onSendPin: (userId: string, amount?: number) => void;
  onAssignPin?: (pinId: string, userId: string) => void;
  onTriggerAutoMatch: () => number;
  onManualMatch: (giverId: string, takerId: string, amount: number, phLink?: string, ghLink?: string, adminLink?: string) => boolean;
  onAddTransaction: (tx: Transaction) => void;
  onAddContribution?: (newContrib: Contribution) => void;
  onAddHelpRequest?: (req: HelpRequest) => void;
  onUpdateP2PMatch?: (matchId: string, updates: Partial<P2PMatch>) => void;
  onApproveP2PMatch?: (matchId: string) => void;
  onRejectP2PMatch?: (matchId: string) => void;
  onGlobalSystemReset?: () => void;
  onLogout?: () => void;
  firebaseEnabled?: boolean;
  firebaseSyncing?: boolean;
  isFirebaseConfigured?: boolean;
  isCloudConnectionFailed?: boolean;
  onForceSyncPush?: () => void;
  onForceSyncPull?: () => void;
  onBulkAddUsersAndPins?: (newUsers: User[], newPins: IssuedPin[]) => void;
  emailLogs?: EmailLog[];
  onDeletePin?: (pinId: string) => void;
  onDeleteUsedPins?: () => void;
  onDeleteTransaction?: (txId: string) => void;
  onClearAllTransactions?: () => void;
}

export default function AdminDashboard({
  systemSettings,
  users,
  contributions,
  helpRequests,
  transactions,
  notifications,
  tickets,
  issuedPins,
  p2pMatches,
  communityReserves,
  onUpdateSettings,
  onUpdateUser,
  onUpdateContribution,
  onUpdateHelpRequest,
  onUpdateTransaction,
  onUpdateTicket,
  onAddNotification,
  onSendPin,
  onAssignPin,
  onTriggerAutoMatch,
  onManualMatch,
  onAddTransaction,
  onAddContribution,
  onAddHelpRequest,
  onUpdateP2PMatch,
  onApproveP2PMatch,
  onRejectP2PMatch,
  onGlobalSystemReset,
  onLogout,
  firebaseEnabled,
  firebaseSyncing,
  isFirebaseConfigured,
  isCloudConnectionFailed,
  onForceSyncPush,
  onForceSyncPull,
  onBulkAddUsersAndPins,
  emailLogs = [],
  onDeletePin,
  onDeleteUsedPins,
  onDeleteTransaction,
  onClearAllTransactions
}: AdminDashboardProps) {

  // Active admin tab inside dashboard
  // 'overview' | 'members' | 'kyc' | 'contributions' | 'help_requests' | 'wallet' | 'reports' | 'settings' | 'security' | 'backup'
  const [activeAdminTab, setActiveAdminTab] = useState<'overview' | 'members' | 'kyc' | 'contributions' | 'help_requests' | 'wallet' | 'reports' | 'settings' | 'security' | 'backup' | 'pins_admin' | 'p2p_matching' | 'audit_history' | 'option_two_ph_gh' | 'email_logs'>('p2p_matching');

  // Accordion Group Open/Close States for Admin Navigation Tree
  const [openAdminNavGroup, setOpenAdminNavGroup] = useState<{ [key: string]: boolean }>({
    dashboard: true,
    user_mgmt: true,
    wallet_mgmt: true,
    ph_mgmt: true,
    gh_mgmt: true,
    payment_mgmt: true,
    pin_mgmt: true,
    referral_mgmt: true,
    cms_mgmt: true,
    rewards: true,
    support: true,
    reports: true,
    settings: true
  });

  const toggleAdminNavGroup = (group: string) => {
    setOpenAdminNavGroup(prev => ({ ...prev, [group]: !prev[group] }));
  };

  // Input states for editing settings
  const [minContrib, setMinContrib] = useState(systemSettings.minContribution.toString());
  const [maxContrib, setMaxContrib] = useState(systemSettings.maxContribution.toString());
  const [minWith, setMinWith] = useState(systemSettings.minWithdrawal.toString());
  const [refComm, setRefComm] = useState(systemSettings.referralCommissionPercent.toString());
  const [levelAmounts, setLevelAmounts] = useState<number[]>(
    systemSettings.levelAmounts || [5, 3, 1, 0.5, 0.4, 0.3, 0.2, 0.1, 0.1, 0.1]
  );
  const [activationPinPrice, setActivationPinPrice] = useState<string>((systemSettings.activationPinPrice || 10).toString());
  const [giverPaymentAmount, setGiverPaymentAmount] = useState<string>((systemSettings.giverPaymentAmount || 40).toString());
  const [offers, setOffers] = useState<SpecialOffer[]>(systemSettings.offers || []);
  const [newOfferTitle, setNewOfferTitle] = useState('');
  const [newOfferDesc, setNewOfferDesc] = useState('');
  const [newOfferBadge, setNewOfferBadge] = useState('SPECIAL OFFER');
  const [sysWallet, setSysWallet] = useState(systemSettings.systemWalletAddress);
  const [isRegOpen, setIsRegOpen] = useState(systemSettings.isRegistrationOpen);
  const [maintenance, setMaintenance] = useState(systemSettings.maintenanceMode);
  const [homeBgImageUrl, setHomeBgImageUrl] = useState(systemSettings.homeBgImageUrl || '');
  const [homeLogoUrl, setHomeLogoUrl] = useState(systemSettings.homeLogoUrl || '');
  const [adminHolderName, setAdminHolderName] = useState(systemSettings.adminHolderName || 'Platform Admin');
  const [adminBankName, setAdminBankName] = useState(systemSettings.adminBankName || 'SBI');
  const [adminAccountNumber, setAdminAccountNumber] = useState(systemSettings.adminAccountNumber || 'XXXXXXXX1234');
  const [adminIfscCode, setAdminIfscCode] = useState(systemSettings.adminIfscCode || 'SBIN0001234');
  const [systemQRUrl, setSystemQRUrl] = useState(systemSettings.systemQRUrl || '');
  const [whatsappSupportNumber, setWhatsappSupportNumber] = useState(systemSettings.whatsappSupportNumber || '+919876543210');
  const [whatsappAutoReplyEnabled, setWhatsappAutoReplyEnabled] = useState(systemSettings.whatsappAutoReplyEnabled !== false);
  const [whatsappAutoReplyMessage, setWhatsappAutoReplyMessage] = useState(systemSettings.whatsappAutoReplyMessage || 'Hello {name}! We have received your support request about "{subject}". Our team will assist you shortly on Ticket ID {ticket_id}.');
  const [websiteButtonEnabled, setWebsiteButtonEnabled] = useState(systemSettings.websiteButtonEnabled !== false);
  const [websiteButtonText, setWebsiteButtonText] = useState(systemSettings.websiteButtonText || 'Visit Official Website');
  const [websiteButtonUrl, setWebsiteButtonUrl] = useState(systemSettings.websiteButtonUrl || 'https://help100.org');

  const [cycleRefresher, setCycleRefresher] = useState(0);
  const [isUpdatingZip, setIsUpdatingZip] = useState(false);
  const [zipStatusMsg, setZipStatusMsg] = useState('');

  const handleUpdateZipFile = async () => {
    setIsUpdatingZip(true);
    setZipStatusMsg('Re-building full source ZIP archive on server...');
    try {
      const res = await fetch('/api/update-zip', { method: 'POST' });
      const data = await res.json();
      if (data && data.success) {
        setZipStatusMsg(`✅ ZIP Updated Successfully! (${new Date().toLocaleTimeString()})`);
        alert('✅ Source Code ZIP File successfully updated & regenerated on the server! You can now download the updated package.');
      } else {
        setZipStatusMsg('⚠️ Failed to update ZIP.');
        alert('Could not update ZIP file: ' + (data?.error || 'Unknown error'));
      }
    } catch (e: any) {
      setZipStatusMsg('Error updating ZIP.');
      alert('Error updating ZIP: ' + e?.message);
    } finally {
      setIsUpdatingZip(false);
    }
  };

  // Function to Fast-Track a user's cycle step
  const handleFastTrackCycleStep = (userId: string, userName: string) => {
    // 1. Get current cycle state
    const saved = localStorage.getItem(`help100_cycle_state_${userId}`);
    let cycleState = {
      currentStep: 'buy_pin',
      pinPurchased: false,
      firstPhSubmitted: false,
      secondPhSubmitted: false,
      thirdPhSubmitted: false,
      firstGhReceived: false,
      secondGhReceived: false,
      thirdGhReceived: false,
      fourthGhReceived: false,
      fifthGhReceived: false,
      totalProvided: 0,
      totalReceived: 0,
      totalProfit: 0,
      cycleCount: 1,
    };
    
    if (saved) {
      try {
        cycleState = { ...cycleState, ...JSON.parse(saved) };
      } catch (e) {}
    }

    const { currentStep, cycleCount } = cycleState;

    if (currentStep === 'completed') {
      alert(`${userName} has already completed Cycle #${cycleCount}!`);
      return;
    }

    // Determine current user object
    const userObj = users.find(u => u.id === userId);
    if (!userObj) {
      alert("User not found!");
      return;
    }

    if (currentStep === 'buy_pin') {
      // Complete PIN step
      cycleState.pinPurchased = true;
      cycleState.totalProvided = cycleState.totalProvided + 10;
      cycleState.totalProfit = cycleState.totalReceived - cycleState.totalProvided;
      cycleState.currentStep = 'first_ph';
      
      // Save
      localStorage.setItem(`help100_cycle_state_${userId}`, JSON.stringify(cycleState));

      // Create transaction record
      if (onAddTransaction) {
        onAddTransaction({
          id: 'tx-cycle-pin-' + Math.random().toString(36).substring(2, 9),
          userId: userId,
          userName: userName,
          type: 'contribution',
          amount: 10,
          status: 'completed',
          description: `Successfully Consumed ₹10 Admin PIN (Admin Fast-Track) (Cycle #${cycleCount})`,
          createdAt: new Date().toISOString()
        });
      }

      // Add a contribution so it appears in the active lists
      if (onAddContribution) {
        onAddContribution({
          id: 'contrib-pin-' + Math.random().toString(36).substring(2, 9),
          userId: userId,
          userName: userName,
          amount: 10,
          status: 'approved',
          paymentProof: `PIN: FAST-TRACK-ADMIN`,
          createdAt: new Date().toISOString(),
          remarks: `Registration PIN - ₹10 (Cycle #${cycleCount})`,
          txLink: `https://help100.com/secure-gateway/ph/pin-use-FASTTRACK`
        });

        // Instantly generate the split ₹20 contributions on PIN fast-track
        onAddContribution({
          id: 'contrib-ph1-admin-' + Math.random().toString(36).substring(2, 9),
          userId: userId,
          userName: userName,
          amount: 20,
          status: 'pending_proof',
          paymentProof: 'Pending Upload',
          createdAt: new Date().toISOString(),
          remarks: `First Provide Help - Admin - ₹20 (Cycle #${cycleCount})`,
          txLink: ""
        });

        onAddContribution({
          id: 'contrib-ph1-user-' + Math.random().toString(36).substring(2, 9),
          userId: userId,
          userName: userName,
          amount: 20,
          status: 'pending_proof',
          paymentProof: 'Pending Upload',
          createdAt: new Date().toISOString(),
          remarks: `First Provide Help - User - ₹20 (Cycle #${cycleCount})`,
          txLink: ""
        });
      }

      // Send notification
      const notif: Notification = {
        id: 'notif-' + Math.random().toString(36).substr(2, 9),
        userId: userId,
        title: '🔑 PIN Verification Fast-Tracked',
        message: `Your activation PIN registration step has been fast-tracked by the Administrator! Cycle #${cycleCount} is active.`,
        type: 'success',
        read: false,
        createdAt: new Date().toISOString()
      };
      onAddNotification(notif);

      setCycleRefresher(prev => prev + 1);
      alert(`Successfully fast-tracked ${userName} from PIN purchase to Provide ₹40 Help stage!`);
      return;
    }

    if (currentStep === 'first_ph') {
      // Find or create first_ph contribution
      let existing = contributions.find(c => c.userId === userId && c.amount === 40 && c.remarks?.includes(`Cycle #${cycleCount}`));
      if (!existing) {
        const newId = 'contrib-ph1-' + Math.random().toString(36).substring(2, 9);
        existing = {
          id: newId,
          userId: userId,
          userName: userName,
          amount: 40,
          status: 'approved',
          paymentProof: 'Admin Fast-Track Dispatch',
          createdAt: new Date().toISOString(),
          remarks: `First Provide Help - ₹40 (Cycle #${cycleCount})`,
          txLink: `https://help100.com/secure-gateway/ph/${newId}`
        };
        if (onAddContribution) {
          onAddContribution(existing);
        }
      } else if (existing.status !== 'approved') {
        onUpdateContribution(existing.id, 'approved', 'Approved via Admin Fast-Track Panel');
      }

      cycleState.firstPhSubmitted = true;
      cycleState.totalProvided = cycleState.totalProvided + 40;
      cycleState.totalProfit = cycleState.totalReceived - cycleState.totalProvided;
      cycleState.currentStep = 'second_ph';

      // Deduct from wallet and update contributed amount
      onUpdateUser({
        ...userObj,
        totalContributed: (userObj.totalContributed || 0) + 40
      });

      localStorage.setItem(`help100_cycle_state_${userId}`, JSON.stringify(cycleState));

      // Send notification
      const notif: Notification = {
        id: 'notif-' + Math.random().toString(36).substr(2, 9),
        userId: userId,
        title: '💖 First PH Verified (Fast-Track)',
        message: `Your first Provide Help of ₹40 has been verified & approved. Please proceed to Provide ₹50 Help.`,
        type: 'success',
        read: false,
        createdAt: new Date().toISOString()
      };
      onAddNotification(notif);

      setCycleRefresher(prev => prev + 1);
      alert(`Successfully approved First PH of ₹40 and fast-tracked ${userName} to Provide ₹50 Help!`);
      return;
    }

    if (currentStep === 'second_ph') {
      // Find or create second_ph contribution
      let existing = contributions.find(c => c.userId === userId && c.amount === 50 && c.remarks?.includes(`Second Provide Help`) && c.remarks?.includes(`Cycle #${cycleCount}`));
      if (!existing) {
        const newId = 'contrib-ph2-' + Math.random().toString(36).substring(2, 9);
        existing = {
          id: newId,
          userId: userId,
          userName: userName,
          amount: 50,
          status: 'approved',
          paymentProof: 'Admin Fast-Track Dispatch',
          createdAt: new Date().toISOString(),
          remarks: `Second Provide Help - ₹50 (Cycle #${cycleCount})`,
          txLink: `https://help100.com/secure-gateway/ph/${newId}`
        };
        if (onAddContribution) {
          onAddContribution(existing);
        }
      } else if (existing.status !== 'approved') {
        onUpdateContribution(existing.id, 'approved', 'Approved via Admin Fast-Track Panel');
      }

      cycleState.secondPhSubmitted = true;
      cycleState.totalProvided = cycleState.totalProvided + 50;
      cycleState.totalProfit = cycleState.totalReceived - cycleState.totalProvided;
      cycleState.currentStep = 'first_gh';

      onUpdateUser({
        ...userObj,
        totalContributed: (userObj.totalContributed || 0) + 50
      });

      localStorage.setItem(`help100_cycle_state_${userId}`, JSON.stringify(cycleState));

      const notif: Notification = {
        id: 'notif-' + Math.random().toString(36).substr(2, 9),
        userId: userId,
        title: '💖 Second PH Verified (Fast-Track)',
        message: `Your second Provide Help of ₹50 has been approved. Your Get Help (GH) queue is now active!`,
        type: 'success',
        read: false,
        createdAt: new Date().toISOString()
      };
      onAddNotification(notif);

      setCycleRefresher(prev => prev + 1);
      alert(`Successfully approved Second PH of ₹50 and fast-tracked ${userName} to First Get Help (GH) of ₹50!`);
      return;
    }

    // Helper for GH steps
    const processGhStep = (
      stepKey: 'first_gh' | 'second_gh' | 'third_gh' | 'fourth_gh' | 'fifth_gh',
      nextStepKey: 'second_gh' | 'third_gh' | 'fourth_gh' | 'fifth_gh' | 'completed',
      rewardAmt: number,
      payoutNum: string,
      cycleStateProp: 'firstGhReceived' | 'secondGhReceived' | 'thirdGhReceived' | 'fourthGhReceived' | 'fifthGhReceived'
    ) => {
      let existingHr = helpRequests.find(h => h.userId === userId && h.amountRequested === rewardAmt && h.remarks?.includes(`${payoutNum} Received Help`) && h.remarks?.includes(`Cycle #${cycleCount}`));
      if (!existingHr) {
        const newHrId = 'hr-' + stepKey + '-' + Math.random().toString(36).substring(2, 9);
        existingHr = {
          id: newHrId,
          userId: userId,
          userName: userName,
          title: `${payoutNum} Payout (Cycle #${cycleCount})`,
          description: `₹${rewardAmt} Mutual Aid Cycle Payout Reward`,
          amountRequested: rewardAmt,
          amountReceived: rewardAmt,
          status: 'completed',
          createdAt: new Date().toISOString(),
          remarks: `${payoutNum} Received Help - ₹${rewardAmt} (Cycle #${cycleCount})`,
          txLink: `https://help100.com/secure-gateway/gh/${newHrId}`
        };
        if (onAddHelpRequest) {
          onAddHelpRequest(existingHr);
        }
      } else if (existingHr.status !== 'completed') {
        onUpdateHelpRequest(existingHr.id, 'completed', rewardAmt, `Completed via Admin Fast-Track`);
      }

      cycleState[cycleStateProp] = true;
      cycleState.totalReceived = cycleState.totalReceived + rewardAmt;
      cycleState.totalProfit = cycleState.totalReceived - cycleState.totalProvided;
      cycleState.currentStep = nextStepKey;

      onUpdateUser({
        ...userObj,
        totalReceived: (userObj.totalReceived || 0) + rewardAmt
      });

      localStorage.setItem(`help100_cycle_state_${userId}`, JSON.stringify(cycleState));

      // Create payout transaction record
      if (onAddTransaction) {
        onAddTransaction({
          id: 'tx-' + stepKey + '-complete-' + Math.random().toString(36).substring(2, 9),
          userId: userId,
          userName: userName,
          type: 'payout',
          amount: rewardAmt,
          status: 'completed',
          description: `${payoutNum} Received Help Fast-Tracked +₹${rewardAmt} (Cycle #${cycleCount})`,
          createdAt: new Date().toISOString()
        });
      }

      const notif: Notification = {
        id: 'notif-' + Math.random().toString(36).substr(2, 9),
        userId: userId,
        title: `💸 ${payoutNum} GH Received!`,
        message: `Your ₹${rewardAmt} Get Help payout has been credited and settled via Admin Fast-Track.`,
        type: 'success',
        read: false,
        createdAt: new Date().toISOString()
      };
      onAddNotification(notif);

      setCycleRefresher(prev => prev + 1);
      alert(`Successfully settled ${payoutNum} GH of ₹${rewardAmt} for ${userName}! Unlocked next stage.`);
    };

    if (currentStep === 'first_gh') {
      processGhStep('first_gh', 'second_gh', 50, 'First', 'firstGhReceived');
      return;
    }
    if (currentStep === 'second_gh') {
      processGhStep('second_gh', 'third_gh', 50, 'Second', 'secondGhReceived');
      return;
    }
    if (currentStep === 'third_gh') {
      processGhStep('third_gh', 'fourth_gh', 25, 'Third', 'thirdGhReceived');
      return;
    }
    if (currentStep === 'fourth_gh') {
      processGhStep('fourth_gh', 'fifth_gh', 25, 'Fourth', 'fourthGhReceived');
      return;
    }
    if (currentStep === 'fifth_gh') {
      processGhStep('fifth_gh', 'completed', 25, 'Fifth', 'fifthGhReceived');
      return;
    }
  };

  // Function to instantly complete the ENTIRE cycle for a user
  const handleCompleteEntireCycle = (userId: string, userName: string) => {
    // We want to run a loop or apply all steps instantly to completed state!
    const saved = localStorage.getItem(`help100_cycle_state_${userId}`);
    let cycleCount = 1;
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        cycleCount = parsed?.cycleCount || 1;
      } catch (e) {}
    }

    const userObj = users.find(u => u.id === userId);
    if (!userObj) {
      alert("User not found!");
      return;
    }

    if (!confirm(`Are you sure you want to INSTANTLY complete the entire Cycle #${cycleCount} for ${userName}? This will approve three PH steps (₹40, ₹50, ₹50) and fulfill all 5 GH payout steps (₹50, ₹50, ₹25, ₹25, ₹25 = ₹175 total) and credit their balance immediately.`)) {
      return;
    }

    // 1. PIN ₹10
    const pinId = 'contrib-pin-' + Math.random().toString(36).substring(2, 9);
    if (onAddContribution) {
      onAddContribution({
        id: pinId,
        userId: userId,
        userName: userName,
        amount: 10,
        status: 'approved',
        paymentProof: 'Admin Cycle Auto-Complete PIN',
        createdAt: new Date().toISOString(),
        remarks: `Registration PIN - ₹10 (Cycle #${cycleCount})`,
        txLink: `https://help100.com/secure-gateway/ph/pin-use-AUTO`
      });
    }

    // 2. PH1 ₹40
    const ph1Id = 'contrib-ph1-' + Math.random().toString(36).substring(2, 9);
    if (onAddContribution) {
      onAddContribution({
        id: ph1Id,
        userId: userId,
        userName: userName,
        amount: 40,
        status: 'approved',
        paymentProof: 'Admin Cycle Auto-Complete PH1',
        createdAt: new Date().toISOString(),
        remarks: `First Provide Help - ₹40 (Cycle #${cycleCount})`,
        txLink: `https://help100.com/secure-gateway/ph/${ph1Id}`
      });
    }

    // 3. PH2 ₹50
    const ph2Id = 'contrib-ph2-' + Math.random().toString(36).substring(2, 9);
    if (onAddContribution) {
      onAddContribution({
        id: ph2Id,
        userId: userId,
        userName: userName,
        amount: 50,
        status: 'approved',
        paymentProof: 'Admin Cycle Auto-Complete PH2',
        createdAt: new Date().toISOString(),
        remarks: `Second Provide Help - ₹50 (Cycle #${cycleCount})`,
        txLink: `https://help100.com/secure-gateway/ph/${ph2Id}`
      });
    }

    // 4. GH1 ₹50
    const gh1Id = 'hr-gh1-' + Math.random().toString(36).substring(2, 9);
    if (onAddHelpRequest) {
      onAddHelpRequest({
        id: gh1Id,
        userId: userId,
        userName: userName,
        title: `1st Payout (Cycle #${cycleCount})`,
        description: `₹50 Mutual Aid Cycle Payout Reward`,
        amountRequested: 50,
        amountReceived: 50,
        status: 'completed',
        createdAt: new Date().toISOString(),
        remarks: `First Received Help - ₹50 (Cycle #${cycleCount})`,
        txLink: `https://help100.com/secure-gateway/gh/${gh1Id}`
      });
    }

    // 5. GH2 ₹50
    const gh2Id = 'hr-gh2-' + Math.random().toString(36).substring(2, 9);
    if (onAddHelpRequest) {
      onAddHelpRequest({
        id: gh2Id,
        userId: userId,
        userName: userName,
        title: `2nd Payout (Cycle #${cycleCount})`,
        description: `₹50 Mutual Aid Cycle Payout Reward`,
        amountRequested: 50,
        amountReceived: 50,
        status: 'completed',
        createdAt: new Date().toISOString(),
        remarks: `Second Received Help - ₹50 (Cycle #${cycleCount})`,
        txLink: `https://help100.com/secure-gateway/gh/${gh2Id}`
      });
    }

    // 6. GH3 ₹25
    const gh3Id = 'hr-gh3-' + Math.random().toString(36).substring(2, 9);
    if (onAddHelpRequest) {
      onAddHelpRequest({
        id: gh3Id,
        userId: userId,
        userName: userName,
        title: `3rd Payout (Cycle #${cycleCount})`,
        description: `₹25 Mutual Aid Cycle Payout Reward`,
        amountRequested: 25,
        amountReceived: 25,
        status: 'completed',
        createdAt: new Date().toISOString(),
        remarks: `Third Received Help - ₹25 (Cycle #${cycleCount})`,
        txLink: `https://help100.com/secure-gateway/gh/${gh3Id}`
      });
    }

    // 7. GH4 ₹25
    const gh4Id = 'hr-gh4-' + Math.random().toString(36).substring(2, 9);
    if (onAddHelpRequest) {
      onAddHelpRequest({
        id: gh4Id,
        userId: userId,
        userName: userName,
        title: `4th Payout (Cycle #${cycleCount})`,
        description: `₹25 Mutual Aid Cycle Payout Reward`,
        amountRequested: 25,
        amountReceived: 25,
        status: 'completed',
        createdAt: new Date().toISOString(),
        remarks: `Fourth Received Help - ₹25 (Cycle #${cycleCount})`,
        txLink: `https://help100.com/secure-gateway/gh/${gh4Id}`
      });
    }

    // 8. GH5 ₹25
    const gh5Id = 'hr-gh5-' + Math.random().toString(36).substring(2, 9);
    if (onAddHelpRequest) {
      onAddHelpRequest({
        id: gh5Id,
        userId: userId,
        userName: userName,
        title: `5th Payout (Cycle #${cycleCount})`,
        description: `₹25 Mutual Aid Cycle Payout Reward`,
        amountRequested: 25,
        amountReceived: 25,
        status: 'completed',
        createdAt: new Date().toISOString(),
        remarks: `Fifth Received Help - ₹25 (Cycle #${cycleCount})`,
        txLink: `https://help100.com/secure-gateway/gh/${gh5Id}`
      });
    }

    // Create completed ledger entries
    if (onAddTransaction) {
      const completionTxs = [
        { desc: 'First Provide Help Verified - ₹40', type: 'contribution' as const, amt: 40 },
        { desc: 'Second Provide Help Verified - ₹50', type: 'contribution' as const, amt: 50 },
        { desc: 'First Received Help Deposited +₹50', type: 'payout' as const, amt: 50 },
        { desc: 'Second Received Help Deposited +₹50', type: 'payout' as const, amt: 50 },
        { desc: 'Third Received Help Deposited +₹25', type: 'payout' as const, amt: 25 },
        { desc: 'Fourth Received Help Deposited +₹25', type: 'payout' as const, amt: 25 },
        { desc: 'Fifth Received Help Deposited +₹25', type: 'payout' as const, amt: 25 },
      ];
      completionTxs.forEach(ctx => {
        onAddTransaction({
          id: 'tx-auto-complete-' + Math.random().toString(36).substring(2, 9),
          userId: userId,
          userName: userName,
          type: ctx.type,
          amount: ctx.amt,
          status: 'completed',
          description: `${ctx.desc} (Auto-Completed) (Cycle #${cycleCount})`,
          createdAt: new Date().toISOString()
        });
      });
    }

    // Set localStorage state to fully completed
    const fullCycleState = {
      currentStep: 'completed',
      pinPurchased: true,
      firstPhSubmitted: true,
      secondPhSubmitted: true,
      firstGhReceived: true,
      secondGhReceived: true,
      thirdGhReceived: true,
      fourthGhReceived: true,
      fifthGhReceived: true,
      totalProvided: 100, // 10 PIN + 40 PH1 + 50 PH2
      totalReceived: 175, // 50 + 50 + 25 + 25 + 25
      totalProfit: 75,
      cycleCount: cycleCount,
    };
    localStorage.setItem(`help100_cycle_state_${userId}`, JSON.stringify(fullCycleState));

    // Update user's wallet fields
    onUpdateUser({
      ...userObj,
      totalContributed: (userObj.totalContributed || 0) + 90,
      totalReceived: (userObj.totalReceived || 0) + 175
    });

    // Send high-priority notification
    const notif: Notification = {
      id: 'notif-' + Math.random().toString(36).substr(2, 9),
      userId: userId,
      title: '🏆 HELP 100 CYCLE COMPLETED!',
      message: `Congratulations! The administrator has fully fast-tracked & completed your Cycle #${cycleCount}. Total rewards of ₹175 are credited to your wallet balance. You may now start a new Cycle!`,
      type: 'success',
      read: false,
      createdAt: new Date().toISOString()
    };
    onAddNotification(notif);

    setCycleRefresher(prev => prev + 1);
    alert(`🏆 Success! Cycle #${cycleCount} has been fully completed for ${userName}! Both PH stages were verified and all 5 GH rewards have been disbursed successfully.`);
  };

  // Input states for manual ticket reply
  const [selectedTicketId, setSelectedTicketId] = useState('');
  const [ticketReplyText, setTicketReplyText] = useState('');

  // Input states for manual transaction creation
  const [selectedUserId, setSelectedUserId] = useState('');
  const [manualTxType, setManualTxType] = useState<'deposit' | 'payout' | 'referral_bonus'>('deposit');
  const [manualTxAmount, setManualTxAmount] = useState('');
  const [manualTxDesc, setManualTxDesc] = useState('');
  const [targetWallet, setTargetWallet] = useState<'all' | 'provide' | 'get' | 'direct' | 'level'>('all');

  // Backup states
  const [backupLog, setBackupLog] = useState<string[]>([]);
  const [exportDataText, setExportDataText] = useState('');

  // System Notifications sender state
  const [newNotifTitle, setNewNotifTitle] = useState('');
  const [newNotifMessage, setNewNotifMessage] = useState('');
  const [notifTargetUser, setNotifTargetUser] = useState('all');

  // Member Search and edit balances
  const [memberSearch, setMemberSearch] = useState('');
  const [editingUserId, setEditingUserId] = useState('');
  const [editBalanceAmt, setEditBalanceAmt] = useState('');

  // Multi-user Quick Funding states
  const [fundUser1Id, setFundUser1Id] = useState('');
  const [fundUser1Amount, setFundUser1Amount] = useState('');
  const [fundUser2Id, setFundUser2Id] = useState('');
  const [fundUser2Amount, setFundUser2Amount] = useState('');

  // Manual Matching states
  const [manualGiverId, setManualGiverId] = useState('');
  const [manualTakerId, setManualTakerId] = useState('');
  const [manualMatchAmount, setManualMatchAmount] = useState('');
  const [manualGiverLink, setManualGiverLink] = useState('');
  const [manualTakerLink, setManualTakerLink] = useState('');
  const [manualAdminLink, setManualAdminLink] = useState('');
  const [matchGiverSearch, setMatchGiverSearch] = useState('');
  const [matchReceiverSearch, setMatchReceiverSearch] = useState('');
  const [isFaceToFaceAligned, setIsFaceToFaceAligned] = useState(false);

  // Admin Initiated GetHelp states
  const [adminInitTakerUserId, setAdminInitTakerUserId] = useState('');
  const [adminInitTakerName, setAdminInitTakerName] = useState('');
  const [adminInitTakerTitle, setAdminInitTakerTitle] = useState('');
  const [adminInitTakerAmount, setAdminInitTakerAmount] = useState('');

  // Audit History view filters
  const [auditSearchQuery, setAuditSearchQuery] = useState('');
  const [auditMethodFilter, setAuditMethodFilter] = useState<'all' | 'auto' | 'manual'>('all');
  const [auditStatusFilter, setAuditStatusFilter] = useState<'all' | 'completed' | 'pending' | 'rejected'>('all');
  const [auditTypeFilter, setAuditTypeFilter] = useState<'all' | 'get_help' | 'withdrawal'>('all');
  const [expandedAuditMatchId, setExpandedAuditMatchId] = useState<string | null>(null);

  // Admin Send PH/GH Links states
  const [editingMatchLinksId, setEditingMatchLinksId] = useState<string | null>(null);
  const [tempPhLink, setTempPhLink] = useState('');
  const [tempGhLink, setTempGhLink] = useState('');


  // Side-by-side PH & GH Rapid Action control states
  const [inlinePhLinks, setInlinePhLinks] = useState<Record<string, string>>({});
  const [inlineGhLinks, setInlineGhLinks] = useState<Record<string, string>>({});
  const [inlineGhAmounts, setInlineGhAmounts] = useState<Record<string, string>>({});

  // Active matcher object derivations
  const selectedGiverContrib = contributions.find(c => c.id === manualGiverId);
  const selectedGiverUser = users.find(u => u.id === manualGiverId || `PH-VIRT-${u.id}` === manualGiverId || u.email === manualGiverId || u.phone === manualGiverId);
  const selectedGiverObj = selectedGiverContrib ? {
    id: selectedGiverContrib.id,
    userId: selectedGiverContrib.userId,
    userName: selectedGiverContrib.userName,
    amount: selectedGiverContrib.amount
  } : (selectedGiverUser ? {
    id: selectedGiverUser.id,
    userId: selectedGiverUser.id,
    userName: selectedGiverUser.name,
    amount: 40
  } : null);
  const selectedTakerHelp = helpRequests.find(h => h.id === manualTakerId);
  const selectedTakerTx = transactions.find(t => t.id === manualTakerId);
  const matchedSumForSelected = p2pMatches.filter(m => m.takerId === manualTakerId && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0);
  const selectedTakerObj = selectedTakerHelp 
    ? { name: selectedTakerHelp.userName, amountNeeded: Math.max(0, selectedTakerHelp.amountRequested - Math.max(selectedTakerHelp.amountReceived, matchedSumForSelected)), type: 'get_help' } 
    : (selectedTakerTx ? { name: selectedTakerTx.userName, amountNeeded: Math.max(0, selectedTakerTx.amount - matchedSumForSelected), type: 'withdrawal' } : null);

  // PIN Administration states
  const [pinGenAmount, setPinGenAmount] = useState('10');
  const [pinGenUser, setPinGenUser] = useState('system'); // 'system' for unassigned stock, or specific user ID
  const [pinGenQty, setPinGenQty] = useState('1');
  const [pinTransferPinId, setPinTransferPinId] = useState('');
  const [pinTransferUserId, setPinTransferUserId] = useState('');

  // PIN-Active User matching link generation states
  const [selectedGiverForUser, setSelectedGiverForUser] = useState<Record<string, string>>({});
  const [generatedPhLinks, setGeneratedPhLinks] = useState<Record<string, string>>({});

  // Filtering states
  const [contribFilter, setContribFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [takerFilter, setTakerFilter] = useState<'all' | 'pending' | 'approved' | 'completed'>('all');

  // Option Two Lists states
  const [optionTwoSubTab, setOptionTwoSubTab] = useState<'ph' | 'gh' | 'pin_active' | 'new_joiners'>('ph');
  const [optionTwoSearch, setOptionTwoSearch] = useState('');
  const [optionTwoStatusFilter, setOptionTwoStatusFilter] = useState<'all' | 'pending' | 'approved' | 'completed'>('all');
  const [newJoinersLimit, setNewJoinersLimit] = useState(10);
  const [membersLimit, setMembersLimit] = useState(10);
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: SystemSettings = {
      ...systemSettings,
      minContribution: parseFloat(minContrib) || 10,
      maxContribution: parseFloat(maxContrib) || 5000,
      minWithdrawal: parseFloat(minWith) || 20,
      referralCommissionPercent: parseFloat(refComm) || 10,
      activationPinPrice: parseFloat(activationPinPrice) || 10,
      giverPaymentAmount: parseFloat(giverPaymentAmount) || 40,
      levelAmounts: levelAmounts,
      offers: offers,
      systemWalletAddress: sysWallet,
      systemQRUrl: systemQRUrl || `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(sysWallet)}`,
      isRegistrationOpen: isRegOpen,
      maintenanceMode: maintenance,
      homeBgImageUrl: homeBgImageUrl,
      homeLogoUrl: homeLogoUrl,
      adminHolderName: adminHolderName,
      adminBankName: adminBankName,
      adminAccountNumber: adminAccountNumber,
      adminIfscCode: adminIfscCode,
      whatsappSupportNumber: whatsappSupportNumber,
      whatsappAutoReplyEnabled: whatsappAutoReplyEnabled,
      whatsappAutoReplyMessage: whatsappAutoReplyMessage,
      websiteButtonEnabled: websiteButtonEnabled,
      websiteButtonText: websiteButtonText,
      websiteButtonUrl: websiteButtonUrl
    };
    onUpdateSettings(updated);
    alert('System Settings updated successfully!');
  };

  // Handle saving member balance edit
  const handleSaveBalanceEdit = (userId: string) => {
    const matched = users.find(u => u.id === userId);
    if (!matched) return;
    const newBal = parseFloat(editBalanceAmt);
    if (isNaN(newBal)) return;

    const updated: User = {
      ...matched,
      walletBalance: newBal
    };
    onUpdateUser(updated);
    setEditingUserId('');
    setEditBalanceAmt('');
    alert(`Wallet balance for ${matched.name} updated to ₹${newBal.toLocaleString()}`);
  };

  // Handle applying double-user quick funding credits
  const handleApplyDoubleCredit = () => {
    const user1 = users.find(u => u.id === fundUser1Id);
    const user2 = users.find(u => u.id === fundUser2Id);
    const amt1 = parseFloat(fundUser1Amount) || 0;
    const amt2 = parseFloat(fundUser2Amount) || 0;

    if (!user1 && !user2) {
      alert("Please select at least one user to fund.");
      return;
    }

    if (user1 && amt1 <= 0) {
      alert(`Please enter a valid amount to credit for ${user1.name}.`);
      return;
    }

    if (user2 && amt2 <= 0) {
      alert(`Please enter a valid amount to credit for ${user2.name}.`);
      return;
    }

    let msg = "Funding Actions Taken:\n";

    if (user1 && amt1 > 0) {
      onUpdateUser({
        ...user1,
        walletBalance: user1.walletBalance + amt1
      });
      if (onAddTransaction) {
        onAddTransaction({
          id: 'tx-credit-' + Math.random().toString(36).substring(2, 9),
          userId: user1.id,
          userName: user1.name,
          type: 'deposit',
          amount: amt1,
          status: 'completed',
          description: `Direct Administrative Wallet Credit of ₹${amt1}`,
          createdAt: new Date().toISOString()
        });
      }
      msg += `• Credited ₹${amt1} to ${user1.name}\n`;
    }

    if (user2 && amt2 > 0) {
      onUpdateUser({
        ...user2,
        walletBalance: user2.walletBalance + amt2
      });
      if (onAddTransaction) {
        onAddTransaction({
          id: 'tx-credit-' + Math.random().toString(36).substring(2, 9),
          userId: user2.id,
          userName: user2.name,
          type: 'deposit',
          amount: amt2,
          status: 'completed',
          description: `Direct Administrative Wallet Credit of ₹${amt2}`,
          createdAt: new Date().toISOString()
        });
      }
      msg += `• Credited ₹${amt2} to ${user2.name}\n`;
    }

    alert(msg);
    // Reset state inputs
    setFundUser1Id('');
    setFundUser1Amount('');
    setFundUser2Id('');
    setFundUser2Amount('');
  };

  // Send global notification
  const handleSendNotification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNotifTitle || !newNotifMessage) return;

    const notif: Notification = {
      id: 'notif-' + Math.random().toString(36).substr(2, 9),
      userId: notifTargetUser,
      title: newNotifTitle,
      message: newNotifMessage,
      type: 'info',
      read: false,
      createdAt: new Date().toISOString()
    };

    onAddNotification(notif);
    setNewNotifTitle('');
    setNewNotifMessage('');
    alert('Community Notification broadcasted successfully!');
  };

  // Perform Backup trigger simulation
  const handleTriggerBackup = () => {
    const timestamp = new Date().toISOString();
    const logs = [
      `[${timestamp}] Initiating automated system cluster backup...`,
      `[${timestamp}] Backing up ${users.length} member profiles...`,
      `[${timestamp}] Archiving ${contributions.length} pledges and ${transactions.length} transactions...`,
      `[${timestamp}] Syncing configurations with backup cold server...`,
      `[${timestamp}] Backup bundle verified successfully! MD5: ${Math.random().toString(36).substring(7).toUpperCase()}`
    ];
    setBackupLog(logs);

    // Prepare JSON for export box
    const fullState = {
      timestamp,
      users,
      contributions,
      helpRequests,
      transactions,
      notifications,
      tickets,
      systemSettings
    };
    setExportDataText(JSON.stringify(fullState, null, 2));
  };

  // Handle ticket reply
  const handleReplyTicketSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicketId || !ticketReplyText) return;

    onUpdateTicket(selectedTicketId, ticketReplyText);
    setTicketReplyText('');
    setSelectedTicketId('');
    alert('Ticket reply processed successfully!');
  };

  // Handle manual deposit/payout generation
  const handleManualTxSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const targetUser = users.find(u => u.id === selectedUserId);
    const amt = parseFloat(manualTxAmount);
    if (!targetUser || isNaN(amt) || amt <= 0) {
      alert('Please select a valid user and positive amount.');
      return;
    }

    // Direct wallet update
    let updatedBalance = targetUser.walletBalance;
    let updatedProvide = targetUser.provideWallet ?? 0;
    let updatedGet = targetUser.getWallet ?? 0;
    let updatedDirect = targetUser.directWallet ?? 0;
    let updatedLevel = targetUser.levelWallet ?? 0;

    const isCredit = manualTxType === 'deposit' || manualTxType === 'referral_bonus';
    
    if (targetWallet === 'all') {
      if (isCredit) {
        updatedBalance += amt;
      } else {
        updatedBalance = Math.max(0, updatedBalance - amt);
      }
    } else if (targetWallet === 'provide') {
      if (isCredit) {
        updatedProvide += amt;
        updatedBalance += amt;
      } else {
        updatedProvide = Math.max(0, updatedProvide - amt);
        updatedBalance = Math.max(0, updatedBalance - amt);
      }
    } else if (targetWallet === 'get') {
      if (isCredit) {
        updatedGet += amt;
        updatedBalance += amt;
      } else {
        updatedGet = Math.max(0, updatedGet - amt);
        updatedBalance = Math.max(0, updatedBalance - amt);
      }
    } else if (targetWallet === 'direct') {
      if (isCredit) {
        updatedDirect += amt;
        updatedBalance += amt;
      } else {
        updatedDirect = Math.max(0, updatedDirect - amt);
        updatedBalance = Math.max(0, updatedBalance - amt);
      }
    } else if (targetWallet === 'level') {
      if (isCredit) {
        updatedLevel += amt;
        updatedBalance += amt;
      } else {
        updatedLevel = Math.max(0, updatedLevel - amt);
        updatedBalance = Math.max(0, updatedBalance - amt);
      }
    }

    const updatedUser: User = {
      ...targetUser,
      walletBalance: updatedBalance,
      provideWallet: updatedProvide,
      getWallet: updatedGet,
      directWallet: updatedDirect,
      levelWallet: updatedLevel
    };
    onUpdateUser(updatedUser);

    // Transaction ledger record
    const newTx: Transaction = {
      id: 'tx-' + Math.random().toString(36).substr(2, 9),
      userId: targetUser.id,
      userName: targetUser.name,
      type: manualTxType,
      amount: amt,
      status: 'completed',
      description: manualTxDesc || `Administrative Manual Adjusted ${manualTxType} (${targetWallet.toUpperCase()} Wallet)`,
      createdAt: new Date().toISOString(),
      walletSource: targetWallet === 'all' ? undefined : targetWallet
    };

    onAddTransaction(newTx); // Direct completion since admin-initiated
    // Let's call the transaction callback
    alert(`Wallet adjusted. New balance for ${targetUser.name}: ₹${updatedBalance.toLocaleString()} (Provide: ₹${updatedProvide}, Get: ₹${updatedGet}, Direct: ₹${updatedDirect}, Level: ₹${updatedLevel})`);
    setSelectedUserId('');
    setManualTxAmount('');
    setManualTxDesc('');
    setTargetWallet('all');
  };

  // Core Math Metrics
  const totalUserCount = users.filter(u => u.role === 'user').length;
  const pendingKycCount = users.filter(u => u.kycStatus === 'pending').length;
  const pendingContributions = contributions.filter(c => c.status === 'pending_verification').length;
  const pendingHelpRequests = helpRequests.filter(h => h.status === 'pending_review').length;
  const openTicketsCount = tickets.filter(t => t.status === 'open').length;

  const totalPlatformVolume = contributions.reduce((sum, c) => sum + c.amount, 0);
  const totalHelpDisbursed = helpRequests.reduce((sum, h) => sum + h.amountReceived, 0);

  const totalPHContributions = contributions.reduce((sum, c) => sum + c.amount, 0);
  const totalGHClaimsAndWithdrawals = helpRequests.reduce((sum, h) => sum + h.amountRequested, 0) + 
    transactions.filter(t => t.type === 'withdrawal' && t.status !== 'rejected').reduce((sum, t) => sum + t.amount, 0);

  const pinActiveMembers = users.filter(u => {
    if (u.role === 'admin') return false;
    try {
      const saved = localStorage.getItem(`help100_cycle_state_${u.id}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && (parsed.pinPurchased === true || parsed.currentStep !== 'buy_pin')) {
          return true;
        }
      }
    } catch (e) {}
    const hasUsedPin = issuedPins.some(pin => pin.isUsed && (pin.userId === u.id || (u.email && pin.userId === u.email) || (u.phone && pin.userId === u.phone)));
    if (hasUsedPin) return true;
    const hasPinContrib = contributions.some(c => c.userId === u.id && c.amount === 10 && c.status === 'approved');
    if (hasPinContrib) return true;
    return false;
  });

  // Givers and Takers counts and lists for admin visibility
  const parsedUserSteps = users.filter(u => u.role === 'user').map(u => {
    let step = 'buy_pin';
    let cycleCount = 1;
    let pinPurchased = false;
    try {
      const saved = localStorage.getItem(`help100_cycle_state_${u.id}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed) {
          step = parsed.currentStep || 'buy_pin';
          cycleCount = parsed.cycleCount || 1;
          pinPurchased = parsed.pinPurchased || false;
        }
      }
    } catch (e) {}

    const hasUsedPin = issuedPins.some(pin => pin.isUsed && (
      pin.userId === u.id || 
      (u.email && pin.userId?.toLowerCase() === u.email.toLowerCase()) || 
      (u.phone && pin.userId === u.phone) ||
      (u.registrationPin && pin.pinCode === u.registrationPin)
    ));
    const hasPinContrib = contributions.some(c => c.userId === u.id && c.amount === 10 && c.status !== 'rejected');
    if (hasUsedPin || hasPinContrib || u.registrationPin) {
      pinPurchased = true;
    }

    const ph1Approved = contributions.some(c => c.userId === u.id && c.amount === 40 && c.status === 'approved') ||
      (contributions.filter(c => c.userId === u.id && c.amount === 20 && c.status === 'approved').length >= 2);
    const ph2Approved = contributions.some(c => c.userId === u.id && c.amount === 50 && c.status === 'approved');

    const gh1Completed = helpRequests.some(h => h.userId === u.id && h.amountRequested === 50 && (h.status === 'completed' || h.amountReceived >= 50));
    const gh2Completed = helpRequests.filter(h => h.userId === u.id && h.amountRequested === 50 && (h.status === 'completed' || h.amountReceived >= 50)).length >= 2;
    const gh3Completed = helpRequests.some(h => h.userId === u.id && h.amountRequested === 25 && (h.status === 'completed' || h.amountReceived >= 25));
    const gh4Completed = helpRequests.filter(h => h.userId === u.id && h.amountRequested === 25 && (h.status === 'completed' || h.amountReceived >= 25)).length >= 2;
    const gh5Completed = helpRequests.filter(h => h.userId === u.id && h.amountRequested === 25 && (h.status === 'completed' || h.amountReceived >= 25)).length >= 3;

    if (gh5Completed) step = 'completed';
    else if (gh4Completed) step = 'fifth_gh';
    else if (gh3Completed) step = 'fourth_gh';
    else if (gh2Completed) step = 'third_gh';
    else if (gh1Completed) step = 'second_gh';
    else if (ph2Approved) step = 'first_gh';
    else if (ph1Approved) step = 'second_ph';
    else if (pinPurchased) step = 'first_ph';
    else step = 'buy_pin';

    return {
      user: u,
      step,
      cycleCount,
      pinPurchased
    };
  });

  // Givers: users with PIN active or in 'buy_pin', 'first_ph', or 'second_ph'
  const giversList = parsedUserSteps.filter(item => {
    const isTakerStep = ['first_gh', 'second_gh', 'third_gh', 'fourth_gh', 'fifth_gh', 'completed'].includes(item.step);
    if (isTakerStep) return false;
    return item.pinPurchased || ['buy_pin', 'first_ph', 'second_ph'].includes(item.step);
  }).map(item => {
    let initialAmount = 50;
    if (item.step === 'buy_pin' && !item.pinPurchased) initialAmount = 10;
    else if (item.step === 'buy_pin' && item.pinPurchased) initialAmount = 50;
    else if (item.step === 'first_ph') initialAmount = 50;
    else if (item.step === 'second_ph') initialAmount = 50;

    // Real-time deduction: subtract active P2P matches and submitted contributions
    const userMatches = p2pMatches.filter(m => (m.giverUserId === item.user.id || m.giverId?.includes(item.user.id)) && m.status !== 'rejected');
    const userContribs = contributions.filter(c => c.userId === item.user.id && (c.status === 'approved' || c.status === 'pending_verification' || c.status === 'pending_proof'));
    const matchedSum = userMatches.reduce((s, m) => s + m.amount, 0);
    const contribsSum = userContribs.reduce((s, c) => s + c.amount, 0);
    const totalDeduction = Math.max(matchedSum, contribsSum);
    const remainingPledge = Math.max(0, initialAmount - totalDeduction);

    return {
      ...item,
      amount: remainingPledge
    };
  }).filter(item => item.amount > 0);

  // Sort giversList so newest PIN active / newest registered users appear right at the TOP (Index 0) of the Give Help List!
  giversList.sort((a, b) => {
    const getNewestTime = (item: typeof a) => {
      const u = item.user;
      let maxT = 0;
      if (u.registeredAt) {
        const d = new Date(u.registeredAt).getTime();
        if (!isNaN(d)) maxT = Math.max(maxT, d);
      }
      if (u._updatedAt) {
        maxT = Math.max(maxT, u._updatedAt);
      }
      const pinObj = issuedPins.find(p => p.isUsed && (
        p.userId === u.id || 
        (u.email && p.userId?.toLowerCase() === u.email.toLowerCase()) || 
        (u.phone && p.userId === u.phone) ||
        (u.registrationPin && p.pinCode === u.registrationPin)
      ));
      if (pinObj?.usedAt) {
        const pd = new Date(pinObj.usedAt).getTime();
        if (!isNaN(pd)) maxT = Math.max(maxT, pd);
      }
      const uContribs = contributions.filter(c => c.userId === u.id);
      uContribs.forEach(c => {
        if (c.createdAt) {
          const cd = new Date(c.createdAt).getTime();
          if (!isNaN(cd)) maxT = Math.max(maxT, cd);
        }
      });
      return maxT;
    };

    return getNewestTime(b) - getNewestTime(a);
  });

  // Unified Givers Queue for P2P router & dispatch desk (includes all new registered IDs, PIN active IDs, and cycle PHs)
  const unifiedGiversQueue = (() => {
    const list: Array<{
      id: string;
      userId: string;
      userName: string;
      userPhone?: string;
      userEmail?: string;
      amount: number;
      availablePledge: number;
      status: string;
      createdAt: string;
      cycleCount?: number;
      remarks?: string;
    }> = [];

    const processedUserIds = new Set<string>();

    // 1. First add all non-rejected contributions
    contributions.forEach(c => {
      if ((c.status as string) === 'rejected' || (c.status as string) === 'completed') return;
      const matchedSum = p2pMatches
        .filter(m => (m.giverId === c.id || m.giverUserId === c.userId) && m.status !== 'rejected')
        .reduce((s, m) => s + m.amount, 0);
      const availablePledge = Math.max(0, c.amount - matchedSum);
      if (availablePledge <= 0) return; // Deduct fully matched givers from active queue!

      const uObj = users.find(u => u.id === c.userId);
      
      list.push({
        id: c.id,
        userId: c.userId,
        userName: c.userName,
        userPhone: uObj?.phone,
        userEmail: uObj?.email,
        amount: c.amount,
        availablePledge: availablePledge,
        status: c.status,
        createdAt: c.createdAt,
        cycleCount: 1,
        remarks: c.remarks
      });
      processedUserIds.add(c.userId);
    });

    // 2. Add all users from giversList (new registered users, PIN active users, cycle PH users) who don't already have an active contribution
    giversList.forEach(item => {
      if (!processedUserIds.has(item.user.id)) {
        const userMatched = p2pMatches
          .filter(m => (m.giverUserId === item.user.id || m.giverId === `PH-VIRT-${item.user.id}`) && m.status !== 'rejected')
          .reduce((s, m) => s + m.amount, 0);
        const availablePledge = Math.max(0, item.amount - userMatched);
        if (availablePledge <= 0) return; // Deduct fully matched virtual givers from active queue!

        list.push({
          id: `PH-VIRT-${item.user.id}`,
          userId: item.user.id,
          userName: item.user.name,
          userPhone: item.user.phone,
          userEmail: item.user.email,
          amount: item.amount,
          availablePledge: availablePledge,
          status: item.pinPurchased ? 'pin_active' : 'ready_ph',
          createdAt: item.user.registeredAt || new Date().toISOString(),
          cycleCount: item.cycleCount,
          remarks: `Provide Help (${item.step === 'buy_pin' ? 'PIN Active' : item.step === 'first_ph' ? '1st PH' : '2nd PH'}) - Cycle #${item.cycleCount}`
        });
        processedUserIds.add(item.user.id);
      }
    });

    // Sort so newest registered / newest PIN active / newest pledge appears right at the TOP (Index 0)
    list.sort((a, b) => {
      const timeA = new Date(a.createdAt || 0).getTime();
      const timeB = new Date(b.createdAt || 0).getTime();
      return timeB - timeA;
    });

    return list;
  })();

  // Takers: users in 'first_gh', 'second_gh', 'third_gh', 'fourth_gh', 'fifth_gh'
  const adminUser = users.find(u => u.role === 'admin') || users[0];
  const adminDispatched = adminUser ? (
    helpRequests.filter(h => h.userId === adminUser.id).reduce((s, h) => s + h.amountReceived, 0) + 
    transactions.filter(t => t.userId === adminUser.id && t.type === 'withdrawal' && t.status === 'completed').reduce((s, t) => s + t.amount, 0) +
    p2pMatches.filter(m => m.takerId === adminUser.id && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0)
  ) : 0;
  const adminRemaining = Math.max(0, 100 - adminDispatched);

  const adminTakerObj = (adminUser && adminRemaining > 0) ? {
    user: adminUser,
    step: 'admin_gh',
    cycleCount: 1,
    pinPurchased: true,
    amount: adminRemaining
  } : null;

  const baseTakers = parsedUserSteps.filter(item => 
    ['first_gh', 'second_gh', 'third_gh', 'fourth_gh', 'fifth_gh'].includes(item.step)
  ).map(item => {
    let initialAmount = 0;
    if (item.step === 'first_gh' || item.step === 'second_gh') initialAmount = 50;
    else if (['third_gh', 'fourth_gh', 'fifth_gh'].includes(item.step)) initialAmount = 25;

    const userHrs = helpRequests.filter(h => h.userId === item.user.id);
    const userMatches = p2pMatches.filter(m => m.takerId === item.user.id && m.status !== 'rejected');
    const userTxs = transactions.filter(t => t.userId === item.user.id && t.type === 'withdrawal' && t.status === 'completed');

    const hrsReceived = userHrs.reduce((s, h) => s + h.amountReceived, 0);
    const matchesSum = userMatches.reduce((s, m) => s + m.amount, 0);
    const txsSum = userTxs.reduce((s, t) => s + t.amount, 0);

    const totalDispatched = Math.max(hrsReceived, matchesSum, txsSum);
    const remainingNeed = Math.max(0, initialAmount - totalDispatched);

    return {
      ...item,
      amount: remainingNeed
    };
  }).filter(item => item.amount > 0);

  const takersList = adminTakerObj ? [adminTakerObj, ...baseTakers] : baseTakers;

  // Unified Takers Queue for all GH campaigns, withdrawals, and system payouts
  const unifiedTakersQueue = (() => {
    const list: Array<{
      id: string;
      userId: string;
      userName: string;
      userPhone?: string;
      userEmail?: string;
      upiId?: string;
      amountRequested: number;
      amountNeeded: number;
      amountReceived: number;
      status: string;
      stepName: string;
      type: 'get_help' | 'withdrawal' | 'admin';
      title: string;
      createdAt: string;
      cycleCount?: number;
    }> = [];

    const processedRequestIds = new Set<string>();

    // 1. Admin Platform Reserve Taker
    if (adminUser && adminRemaining > 0) {
      list.push({
        id: `admin-system-taker-${adminUser.id}`,
        userId: adminUser.id,
        userName: `Platform Reserve (${adminUser.name})`,
        userPhone: adminUser.phone || 'N/A',
        userEmail: adminUser.email || '',
        upiId: adminUser.upiId || 'help100admin@sbin',
        amountRequested: 100,
        amountNeeded: adminRemaining,
        amountReceived: 100 - adminRemaining,
        status: 'approved',
        stepName: 'Platform Escrow Reserve',
        type: 'admin',
        title: 'Platform Admin Escrow Reserve (₹100)',
        createdAt: new Date().toISOString(),
        cycleCount: 1
      });
      processedRequestIds.add(`admin-system-taker-${adminUser.id}`);
    }

    // 2. Approved Help Requests (GH Payouts)
    helpRequests.forEach(h => {
      if (h.status === 'rejected' || h.status === 'completed') return;
      const matchSum = p2pMatches
        .filter(m => m.takerId === h.id && m.status !== 'rejected')
        .reduce((s, m) => s + m.amount, 0);
      const effectiveRec = Math.max(h.amountReceived, matchSum);
      const amountNeeded = Math.max(0, h.amountRequested - effectiveRec);
      if (amountNeeded <= 0) return;

      const uObj = users.find(u => u.id === h.userId);
      list.push({
        id: h.id,
        userId: h.userId,
        userName: h.userName,
        userPhone: uObj?.phone,
        userEmail: uObj?.email,
        upiId: uObj?.upiId || uObj?.secondaryUpiId || 'admin@upi',
        amountRequested: h.amountRequested,
        amountNeeded: amountNeeded,
        amountReceived: effectiveRec,
        status: h.status,
        stepName: h.title || `Get Help (₹${h.amountRequested})`,
        type: 'get_help',
        title: h.title || `Payout (₹${h.amountRequested})`,
        createdAt: h.createdAt || new Date().toISOString(),
        cycleCount: 1
      });
      processedRequestIds.add(h.id);
    });

    // 3. Active Pending Withdrawals
    transactions.forEach(t => {
      if (t.type !== 'withdrawal' || t.status === 'rejected') return;
      const matchSum = p2pMatches
        .filter(m => m.takerId === t.id && m.status !== 'rejected')
        .reduce((s, m) => s + m.amount, 0);
      const amountNeeded = Math.max(0, t.amount - matchSum);
      if (amountNeeded <= 0) return;

      const uObj = users.find(u => u.id === t.userId);
      list.push({
        id: t.id,
        userId: t.userId,
        userName: t.userName,
        userPhone: uObj?.phone,
        userEmail: uObj?.email,
        upiId: (t as any).withdrawalAddress || uObj?.upiId || 'admin@upi',
        amountRequested: t.amount,
        amountNeeded: amountNeeded,
        amountReceived: matchSum,
        status: t.status,
        stepName: `Wallet Withdrawal (${t.walletSource?.toUpperCase() || 'WALLET'})`,
        type: 'withdrawal',
        title: `Wallet Withdrawal (₹${t.amount})`,
        createdAt: t.createdAt || new Date().toISOString(),
        cycleCount: 1
      });
      processedRequestIds.add(t.id);
    });

    // 4. Base Takers from user steps who don't already have an active request in list
    takersList.forEach(item => {
      const hasExisting = list.some(t => t.userId === item.user.id);
      if (hasExisting) return;

      const userMatches = p2pMatches.filter(m => (m.takerUserId === item.user.id || m.takerId === `GH-VIRT-${item.user.id}`) && m.status !== 'rejected');
      const matchesSum = userMatches.reduce((s, m) => s + m.amount, 0);
      const amountNeeded = Math.max(0, item.amount - matchesSum);
      if (amountNeeded <= 0) return;

      const stepTitle = item.step === 'first_gh' ? '1st Payout (₹50)' : item.step === 'second_gh' ? '2nd Payout (₹50)' : item.step === 'third_gh' ? '3rd Payout (₹25)' : item.step === 'fourth_gh' ? '4th Payout (₹25)' : '5th Payout (₹25)';

      list.push({
        id: `GH-VIRT-${item.user.id}`,
        userId: item.user.id,
        userName: item.user.name,
        userPhone: item.user.phone,
        userEmail: item.user.email,
        upiId: item.user.upiId || item.user.secondaryUpiId || 'admin@upi',
        amountRequested: item.amount,
        amountNeeded: amountNeeded,
        amountReceived: matchesSum,
        status: 'approved',
        stepName: stepTitle,
        type: 'get_help',
        title: `${stepTitle} - Cycle #${item.cycleCount}`,
        createdAt: item.user.registeredAt || new Date().toISOString(),
        cycleCount: item.cycleCount
      });
    });

    list.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    return list;
  })();

  // Filtered members by search
  const filteredMembers = users.filter(u => 
    u.name.toLowerCase().includes(memberSearch.toLowerCase()) || 
    u.phone.includes(memberSearch) || 
    u.email.toLowerCase().includes(memberSearch.toLowerCase())
  );

  // Auto P2P Router matching function triggered by Admin "Auto Button"
  const handleRunAutoP2PMatching = () => {
    const availableGivers = unifiedGiversQueue.filter(g => g.availablePledge > 0);

    if (availableGivers.length === 0) {
      alert('कोई भी सक्रिय गिवर (Giver) उपलब्ध नहीं है। / No available givers in PH queue.');
      return;
    }

    const availableTakers = unifiedTakersQueue.filter(t => t.amountNeeded > 0);

    if (availableTakers.length === 0) {
      alert('कोई भी टेकर (Taker / Receiver) प्राप्तकर्ता कतार में नहीं है। / No takers needing help.');
      return;
    }

    let createdCount = 0;
    let totalMatchedAmount = 0;

    for (const giver of availableGivers) {
      let giverPledge = giver.availablePledge;
      if (giverPledge <= 0) continue;

      for (const taker of availableTakers) {
        if (giverPledge <= 0) break;
        if (taker.amountNeeded <= 0) continue;
        if (giver.userId === taker.userId) continue;

        const matchAmount = Math.min(giverPledge, taker.amountNeeded);
        if (matchAmount <= 0) continue;

        const takerUpi = taker.upiId || 'admin@upi';
        const takerPhone = taker.userPhone || 'N/A';

        const success = onManualMatch(
          giver.id,
          taker.id,
          matchAmount,
          '',
          '',
          ''
        );

        if (success) {
          giverPledge -= matchAmount;
          taker.amountNeeded -= matchAmount;
          createdCount++;
          totalMatchedAmount += matchAmount;
        }
      }
    }

    if (createdCount > 0) {
      alert(`⚡ ऑटो P2P मैचिंग सफल!

कुल ${createdCount} ऑटो मैच बनाए गए (कुल ₹${totalMatchedAmount})।

गिवर (Giver) को उसके डैशबोर्ड में लिंक बॉक्स मिल गया है। जब तक यूजर पेमेंट पे करके कन्फर्म नहीं करेगा, ID आगे नहीं बढ़ेगी!`);
    } else {
      alert('कोई नया मैच नहीं बन सका। कृपया गिवर्स और टेकर्स की राशि चेक करें।');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row font-sans">
      
      {/* Admin Left Sidebar */}
      <aside className="w-full md:w-64 bg-slate-900 text-slate-300 border-r border-slate-800 flex flex-col">
        <div className="p-4 border-b border-slate-800 bg-slate-950/50 flex items-center gap-3">
          <Logo size={42} showText={false} />
          <div>
            <span className="text-[8px] font-black tracking-widest text-emerald-400 block uppercase">Admin Console</span>
            <h2 className="text-sm font-black text-white leading-tight">HELP 100 System</h2>
            <p className="text-[9px] text-slate-500 font-medium mt-0.5">Control & Audit Panel</p>
          </div>
        </div>

        <nav className="flex-grow p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-140px)] scrollbar-thin scrollbar-thumb-slate-800">
          
          <button
            id="admin-nav-overview"
            onClick={() => setActiveAdminTab('overview')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'overview' ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">📊</span>
              <span>Overview Dashboard</span>
            </span>
          </button>

          <button
            id="admin-nav-option-two"
            onClick={() => setActiveAdminTab('option_two_ph_gh')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'option_two_ph_gh' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">🔄</span>
              <span>Option Two: PH & GH Lists</span>
            </span>
            <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-mono font-bold">DIRECTORY</span>
          </button>

          <button
            id="admin-nav-p2p-matching"
            onClick={() => setActiveAdminTab('p2p_matching')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'p2p_matching' ? 'bg-gradient-to-r from-indigo-500 to-indigo-600 text-white font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">⚡</span>
              <span>P2P Auto Matching</span>
            </span>
          </button>

          <button
            id="admin-nav-contributions"
            onClick={() => setActiveAdminTab('contributions')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'contributions' ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">🤝</span>
              <span>PH Contributions</span>
            </span>
            {pendingContributions > 0 && (
              <span className="text-[10px] bg-emerald-500 text-slate-950 px-2 py-0.5 rounded-full font-black animate-pulse">
                {pendingContributions}
              </span>
            )}
          </button>

          <button
            id="admin-nav-help-requests"
            onClick={() => setActiveAdminTab('help_requests')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'help_requests' ? 'bg-gradient-to-r from-purple-500 to-purple-600 text-white font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">💸</span>
              <span>GH Help Requests</span>
            </span>
            {pendingHelpRequests > 0 && (
              <span className="text-[10px] bg-purple-500 text-white px-2 py-0.5 rounded-full font-black animate-pulse">
                {pendingHelpRequests}
              </span>
            )}
          </button>

          <button
            id="admin-nav-pins"
            onClick={() => setActiveAdminTab('pins_admin')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'pins_admin' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">📌</span>
              <span>₹10 Registration PINs</span>
            </span>
          </button>

          <button
            id="admin-nav-members"
            onClick={() => setActiveAdminTab('members')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'members' ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">👥</span>
              <span>User Management</span>
            </span>
            <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full font-mono font-bold">
              {totalUserCount}
            </span>
          </button>

          <button
            id="admin-nav-kyc"
            onClick={() => setActiveAdminTab('kyc')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'kyc' ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">📄</span>
              <span>KYC Verifications</span>
            </span>
            {pendingKycCount > 0 && (
              <span className="text-[10px] bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full font-black animate-pulse">
                {pendingKycCount}
              </span>
            )}
          </button>

          <button
            id="admin-nav-support"
            onClick={() => setActiveAdminTab('email_logs')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'email_logs' ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">🎧</span>
              <span>Support & Tickets</span>
            </span>
          </button>

          <button
            id="admin-nav-reports"
            onClick={() => setActiveAdminTab('reports')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'reports' ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">📊</span>
              <span>Reports & Analytics</span>
            </span>
          </button>

          <button
            id="admin-nav-audit"
            onClick={() => setActiveAdminTab('audit_history')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'audit_history' ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">📜</span>
              <span>Audit History</span>
            </span>
          </button>

          <button
            id="admin-nav-security"
            onClick={() => setActiveAdminTab('security')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'security' ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">🔒</span>
              <span>Security Settings</span>
            </span>
          </button>

          <button
            id="admin-nav-backup"
            onClick={() => setActiveAdminTab('backup')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'backup' ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">💾</span>
              <span>Backup & Sync</span>
            </span>
          </button>

          <button
            id="admin-nav-settings"
            onClick={() => setActiveAdminTab('settings')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeAdminTab === 'settings' ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black shadow-md' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span className="text-sm">⚙️</span>
              <span>System Settings</span>
            </span>
          </button>

        </nav>

        {/* Device Share Card */}
        <div className="mx-4 my-2 p-2 rounded-xl bg-slate-950 border border-slate-800 text-center text-slate-400">
          <p className="text-[8px] font-black text-amber-400 uppercase tracking-widest mb-1 flex items-center justify-center gap-1">
            <Smartphone className="w-3 h-3 text-amber-400" /> Open on Mobile
          </p>
          <div className="bg-white p-1 rounded inline-block mb-1 shadow-md">
            <QRCodeSVG
              value={window.location.origin}
              size={64}
              level="M"
              includeMargin={false}
            />
          </div>
          <p className="text-[7.5px] leading-tight text-slate-500">Scan code to open on phone instantly!</p>
        </div>

        {/* Logout Bottom Container */}
        <div className="p-4 border-t border-slate-800">
          <button
            id="admin-nav-logout"
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-rose-400 hover:text-white hover:bg-rose-900/35 border border-rose-900/30 font-semibold transition-all text-xs cursor-pointer uppercase tracking-wider"
          >
            Sign Out Admin
          </button>
        </div>
      </aside>

      {/* Admin Content Canvas */}
      <main className="flex-grow p-6 sm:p-8 max-w-5xl overflow-y-auto">
        
        {/* SUBTAB 1: OVERVIEW */}
        {activeAdminTab === 'overview' && (
          <div>
            <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Console Headquarters</h1>
                <p className="text-slate-500 text-sm">Real-time status metrics of the peer crowdfund engine.</p>
              </div>

              {maintenance && (
                <div className="bg-rose-50 border border-rose-200 text-rose-700 text-xs px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4" /> MAINTENANCE MODE ACTIVE
                </div>
              )}
            </div>

            {/* 🛡️ 20,000 ID SCALE COMPLIANCE BLOCK */}
            <div className="mb-6 bg-gradient-to-r from-amber-50 to-indigo-50 border border-indigo-100 rounded-2xl p-5 sm:p-6 shadow-xs">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded-lg bg-indigo-100 text-indigo-700 font-bold text-[9px] uppercase tracking-wider">Scale Compliance</span>
                    {users.length >= 20000 ? (
                      <span className="px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-200">
                        🟢 MET: {users.length.toLocaleString()} IDs Active
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-amber-100 text-amber-800 border border-amber-200 animate-pulse">
                        ⚠️ WARNING: {users.length.toLocaleString()} / 20,000 IDs
                      </span>
                    )}
                  </div>
                  <h3 className="font-extrabold text-slate-900 text-sm sm:text-base font-sans mt-1.5">
                    Production ID Scaling & Stress Test Requirement
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed max-w-2xl">
                    To comply with production launch standards and performance benchmarks, a minimum of <strong>20,000 unique User/Member IDs</strong> should be required and appear in the admin. This guarantees the platform's high-speed pagination, searching, and peer routing engines are fully optimized for massive volume.
                  </p>
                </div>
                {users.length < 20000 ? (
                  <button
                    type="button"
                    id="seed-20k-ids-btn"
                    onClick={() => {
                      if (confirm(`Do you want to instantly generate and dispatch ${20000 - users.length} virtual members and PIN IDs to satisfy the 20,000 ID scaling compliance requirement?`)) {
                        const needed = 20000 - users.length;
                        const newUsersList: User[] = [];
                        const newPinsList: IssuedPin[] = [];
                        const startIdx = users.length;
                        
                        const firstNames = ['Amit', 'Rajesh', 'Pooja', 'Sunita', 'Vijay', 'Sanjay', 'Anil', 'Deepak', 'Suresh', 'Ramesh', 'Vikram', 'Arun', 'Karan', 'Pankaj', 'Neha', 'Ritu', 'Kiran', 'Jyoti', 'Rahul', 'Mohit', 'Sandeep', 'Aarav', 'Ishaan', 'Ananya', 'Diya', 'Rohan', 'Aditya'];
                        const lastNames = ['Sharma', 'Verma', 'Gupta', 'Singh', 'Kumar', 'Mehta', 'Joshi', 'Patel', 'Yadav', 'Mishra', 'Trivedi', 'Shah', 'Nair', 'Rao', 'Choudhary', 'Sen', 'Das', 'Gill', 'Kapoor', 'Malhotra', 'Bose'];
                        
                        for (let i = 0; i < needed; i++) {
                          const idx = startIdx + i + 1;
                          const fName = firstNames[idx % firstNames.length];
                          const lName = lastNames[idx % lastNames.length];
                          const fullName = `${fName} ${lName} ${idx}`;
                          const uid = `member-id-${1000000 + idx}`;
                          const email = `member${idx}@help100.com`;
                          const phone = `+91 ${7000000000 + idx}`;
                          const refCode = `REG${20000 + idx}`;
                          
                          newUsersList.push({
                            id: uid,
                            name: fullName,
                            email: email,
                            phone: phone,
                            password: `pass${idx}`,
                            status: 'active',
                            otp: '123456',
                            otpVerified: true,
                            kycStatus: 'approved',
                            walletBalance: 0,
                            totalContributed: 0,
                            totalReceived: 0,
                            referralCode: refCode,
                            registeredAt: new Date(Date.now() - (idx * 30000)).toISOString(),
                            role: 'user',
                            upiId: `member${idx}@okaxis`,
                            bankName: 'HDFC Bank',
                            accountNumber: `${501002000000 + idx}`,
                            ifscCode: 'HDFC0000120'
                          });

                          newPinsList.push({
                            id: `pin-scale-${idx}`,
                            pinCode: `PIN-SCL-${100000 + idx}`,
                            userId: uid,
                            userName: fullName,
                            amount: 10,
                            isUsed: true,
                            createdAt: new Date().toISOString(),
                            usedAt: new Date().toISOString()
                          });
                        }
                        
                        if (onBulkAddUsersAndPins) {
                          onBulkAddUsersAndPins(newUsersList, newPinsList);
                          alert(`Success! Successfully pre-loaded and registered ${needed.toLocaleString()} virtual member IDs and PIN codes. Total is now exactly 20,000 IDs!`);
                        } else {
                          alert('Error: Bulk generator callback is not connected.');
                        }
                      }
                    }}
                    className="shrink-0 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer shadow-sm transition-all flex items-center gap-1.5"
                  >
                    ⚡ Generate { (20000 - users.length).toLocaleString() } IDs Now
                  </button>
                ) : (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-xs text-emerald-800 font-semibold flex items-center gap-2">
                    ✅ Production Scaling Met ({users.length.toLocaleString()} IDs Active)
                  </div>
                )}
              </div>
            </div>

            {/* Quick Multi-Audits Alerts */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div 
                id="admin-alert-kyc"
                onClick={() => setActiveAdminTab('kyc')} 
                className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:border-amber-400 transition-all text-center"
              >
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Pending KYC</span>
                <p className={`text-2xl font-black mt-1 ${pendingKycCount > 0 ? 'text-amber-600' : 'text-slate-800'}`}>{pendingKycCount}</p>
                <span className="text-[9px] text-slate-400 mt-1 block hover:underline">Verify Docs →</span>
              </div>

              <div 
                id="admin-alert-pledge"
                onClick={() => setActiveAdminTab('contributions')} 
                className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:border-emerald-500 transition-all text-center"
              >
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Pending Pledges</span>
                <p className={`text-2xl font-black mt-1 ${pendingContributions > 0 ? 'text-emerald-600' : 'text-slate-800'}`}>{pendingContributions}</p>
                <span className="text-[9px] text-slate-400 mt-1 block hover:underline">Verify Receipts →</span>
              </div>

              <div 
                id="admin-alert-campaign"
                onClick={() => setActiveAdminTab('help_requests')} 
                className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:border-purple-500 transition-all text-center"
              >
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Campaign Audits</span>
                <p className={`text-2xl font-black mt-1 ${pendingHelpRequests > 0 ? 'text-purple-600' : 'text-slate-800'}`}>{pendingHelpRequests}</p>
                <span className="text-[9px] text-slate-400 mt-1 block hover:underline">Audit Claims →</span>
              </div>

              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm text-center">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Open Support Tickets</span>
                <p className="text-2xl font-black text-slate-800 mt-1">{openTicketsCount}</p>
                <span className="text-[9px] text-slate-400 mt-1 block">Help Ticket Queue</span>
              </div>
            </div>

            {/* ⚠️ EMERGENCY RESET & SYSTEM RESTART DESK */}
            <div className="mb-8 bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 rounded-2xl p-5 sm:p-6 shadow-sm">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="space-y-1">
                  <h3 className="font-extrabold text-red-950 text-sm sm:text-base uppercase tracking-wider flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-600 animate-bounce" />
                    ⚠️ SYSTEM RESET & RESTART DESK (Rs 100/- Help Plan)
                  </h3>
                  <p className="text-xs text-red-700 leading-relaxed font-medium">
                    This is an immediate, authoritative action. It will overwrite all user wallet funds (walletBalance, provideWallet, getWallet, directWallet, levelWallet, totalContributed, totalReceived) back to <strong className="font-bold">00000</strong>, reset and clear all active cycles to step 1 (buy_pin), and clean out all active contribution receipts, P2P matches, and pending transaction logs.
                  </p>
                </div>
                <button
                  type="button"
                  id="admin-emergency-reset-btn"
                  onClick={() => {
                    if (confirm("🚨 WARNING: This will set all community user balances to 00000 and restart everyone's help cycles from the beginning! This action is irreversible. Do you wish to proceed?")) {
                      if (onGlobalSystemReset) {
                        onGlobalSystemReset();
                        alert("🎉 Done! The entire Rs 100/- Help system has been wiped to 00000 and all users have been restarted from step 1.");
                      } else {
                        alert("Reset callback is not defined in App.");
                      }
                    }
                  }}
                  className="shrink-0 bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase px-5 py-3 rounded-xl border border-red-700/30 flex items-center gap-2 cursor-pointer transition-all active:scale-95 shadow-md"
                >
                  <Trash2 className="w-4 h-4 text-white" />
                  Wipe & Restart System
                </button>
              </div>
            </div>

            {/* Platform Financial Stats */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm grid md:grid-cols-4 gap-6 mb-8">
              <div>
                <span className="text-xs text-slate-400 font-semibold uppercase block">Total PH Contributions</span>
                <p className="text-3xl font-black text-slate-900 mt-1">₹{totalPHContributions.toLocaleString()}</p>
                <span className="text-[10px] text-emerald-600 font-semibold mt-1 inline-block">Manual audits validated successfully</span>
              </div>

              <div>
                <span className="text-xs text-slate-400 font-semibold uppercase block">Active Community Reserves Fund</span>
                <p className="text-3xl font-black text-indigo-600 mt-1">₹{communityReserves.toLocaleString()}</p>
                <span className="text-[10px] text-indigo-500 font-semibold mt-1 inline-block">Live Dynamic Reserves</span>
              </div>

              <div>
                <span className="text-xs text-slate-400 font-semibold uppercase block">Total GH Claims & Withdrawals</span>
                <p className="text-3xl font-black text-slate-900 mt-1">₹{totalGHClaimsAndWithdrawals.toLocaleString()}</p>
                <span className="text-[10px] text-slate-400 mt-1 inline-block">Sum of all platform GH requests & withdrawals</span>
              </div>

              <div>
                <span className="text-xs text-slate-400 font-semibold uppercase block">Active Registered Pledgers</span>
                <p className="text-3xl font-black text-slate-900 mt-1">{totalUserCount} Members</p>
                <span className="text-[10px] text-indigo-600 font-semibold mt-1 inline-block">100% verified KYC track record</span>
              </div>
            </div>

            {/* 👑 ADMIN PROFILE & PAYMENT GATEWAY QR CONFIGURATION */}
            <div className="bg-slate-900 border border-amber-400/30 text-white p-6 rounded-2xl shadow-xl mb-8 space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-white/10">
                <div className="space-y-1">
                  <h3 className="font-extrabold text-amber-400 text-base sm:text-lg uppercase tracking-wider flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-amber-400 animate-pulse" />
                    👑 Admin Payment Profile & QR Code Panel
                  </h3>
                  <p className="text-xs text-slate-300">
                    Configure official platform bank accounts, UPI IDs, and custom QR images shown to members during Provide Help steps.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const updated: SystemSettings = {
                      ...systemSettings,
                      systemWalletAddress: sysWallet,
                      systemQRUrl: systemQRUrl || `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(sysWallet)}`,
                      adminHolderName: adminHolderName,
                      adminBankName: adminBankName,
                      adminAccountNumber: adminAccountNumber,
                      adminIfscCode: adminIfscCode
                    };
                    onUpdateSettings(updated);
                    alert('👑 Admin Profile & QR Details updated successfully!');
                  }}
                  className="shrink-0 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs uppercase px-5 py-2.5 rounded-xl border border-amber-600 flex items-center gap-2 cursor-pointer transition-all active:scale-95 shadow-md"
                >
                  <Save className="w-4 h-4 text-slate-950" />
                  Save Admin Profile
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Form fields */}
                <div className="lg:col-span-2 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Admin Holder Name</label>
                      <input 
                        id="profile-input-holder"
                        type="text"
                        value={adminHolderName}
                        onChange={(e) => setAdminHolderName(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-lg text-xs text-white font-medium focus:border-amber-400 outline-none transition-colors"
                        placeholder="e.g. Platform Admin"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">System UPI ID / Wallet Address</label>
                      <input 
                        id="profile-input-upi"
                        type="text"
                        value={sysWallet}
                        onChange={(e) => setSysWallet(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-lg text-xs text-white font-mono focus:border-amber-400 outline-none transition-colors"
                        placeholder="e.g. admin@upi"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Admin Bank Name</label>
                      <input 
                        id="profile-input-bank"
                        type="text"
                        value={adminBankName}
                        onChange={(e) => setAdminBankName(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-lg text-xs text-white font-medium focus:border-amber-400 outline-none transition-colors"
                        placeholder="e.g. SBI"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Admin Account Number</label>
                      <input 
                        id="profile-input-acc"
                        type="text"
                        value={adminAccountNumber}
                        onChange={(e) => setAdminAccountNumber(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-lg text-xs text-white font-mono focus:border-amber-400 outline-none transition-colors"
                        placeholder="e.g. XXXXXXXX1234"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Admin IFSC Code</label>
                      <input 
                        id="profile-input-ifsc"
                        type="text"
                        value={adminIfscCode}
                        onChange={(e) => setAdminIfscCode(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-lg text-xs text-white font-mono focus:border-amber-400 outline-none transition-colors"
                        placeholder="e.g. SBIN0001234"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Custom QR Code Image URL (Optional)</label>
                    <div className="flex gap-2">
                      <input 
                        id="profile-input-qr"
                        type="text"
                        value={systemQRUrl}
                        onChange={(e) => setSystemQRUrl(e.target.value)}
                        className="flex-1 px-3 py-2 bg-slate-950 border border-white/15 rounded-lg text-xs text-white font-mono focus:border-amber-400 outline-none transition-colors"
                        placeholder="Leave empty to dynamically generate from UPI ID"
                      />
                      {systemQRUrl && (
                        <button 
                          type="button" 
                          onClick={() => setSystemQRUrl('')} 
                          className="px-3 py-2 bg-rose-950 text-rose-400 border border-rose-800 rounded-lg text-xs font-bold hover:bg-rose-900 transition-colors cursor-pointer shrink-0"
                        >
                          Clear Custom
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* QR Code Visual Card Column */}
                <div className="lg:col-span-1 bg-slate-950 p-4 rounded-xl border border-white/10 flex flex-col items-center justify-between text-center space-y-4">
                  <div>
                    <span className="text-[9px] uppercase font-bold text-amber-400 tracking-wider block">Live QR Preview</span>
                    <span className="text-[7px] text-slate-400 block mt-0.5">Scanned by givers during PH Step 2</span>
                  </div>

                  <div className="bg-white p-2.5 rounded-2xl shadow-inner border border-amber-400/25">
                    <img 
                      src={systemQRUrl || `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent('upi://pay?pa=' + sysWallet + '&pn=' + encodeURIComponent(adminHolderName) + '&am=20')}`} 
                      alt="Admin QR Preview" 
                      className="w-32 h-32"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <div className="text-[10px] space-y-1">
                    <p className="font-mono text-[9px] text-slate-300 truncate max-w-[150px]">{sysWallet || "No UPI Configured"}</p>
                    <span className="text-[8px] bg-amber-400/10 text-amber-400 px-2 py-0.5 rounded-full border border-amber-400/20 block font-bold uppercase tracking-wider">
                      {systemQRUrl ? 'Custom Image' : 'UPI Auto-Gen QR'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Broadcast Notification Form */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <h3 className="font-bold text-slate-900 mb-1">Broadcast Notification to Community</h3>
              <p className="text-slate-500 text-xs mb-4">Broadcast important announcements or system updates directly to member dashboards.</p>

              <form onSubmit={handleSendNotification} className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Target Audience</label>
                  <select 
                    id="notif-input-target"
                    value={notifTargetUser} 
                    onChange={(e) => setNotifTargetUser(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  >
                    <option value="all">All Members (Global)</option>
                    {users.filter(u => u.role === 'user').map(u => (
                      <option key={u.id} value={u.id}>{u.name}</option>
                    ))}
                  </select>
                </div>

                <div className="md:col-span-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Alert Title</label>
                  <input 
                    id="notif-input-title"
                    type="text"
                    required
                    placeholder="e.g. Server Upgrade Completed"
                    value={newNotifTitle}
                    onChange={(e) => setNewNotifTitle(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>

                <div className="md:col-span-2 flex gap-2 items-end">
                  <div className="flex-grow">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Message Body</label>
                    <input 
                      id="notif-input-message"
                      type="text"
                      required
                      placeholder="Type brief announcement details..."
                      value={newNotifMessage}
                      onChange={(e) => setNewNotifMessage(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                    />
                  </div>
                  <button 
                    id="notif-broadcast-submit"
                    type="submit"
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0"
                  >
                    Broadcast
                  </button>
                </div>
              </form>
            </div>

          </div>
        )}

        {/* SUBTAB 2: MEMBER PROFILES MANAGEMENT */}
        {activeAdminTab === 'members' && (
          <div>
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-slate-900">Member Profiles</h1>
              <p className="text-slate-500 text-sm">Review, audit, or adjust community wallet balances directly.</p>
            </div>

            {/* ⚡ Dynamic Double-User Funding Panel */}
            <div className="bg-slate-900 border border-slate-800 text-white p-5 rounded-2xl mb-6 shadow-md">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-lg">⚡</span>
                <h3 className="text-sm font-bold uppercase tracking-wider text-amber-400">Quick Double-User Funding Console</h3>
              </div>
              <p className="text-slate-400 text-xs mb-4">
                Instantly credit separate funds to two users at the same time. Select two distinct members, specify the credit amounts, and execute.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* User Slot 1 */}
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                  <span className="text-[10px] font-black uppercase text-amber-500 tracking-wider mb-2 block">👤 User Slot 1</span>
                  <div className="space-y-3">
                    <div>
                      <label className="text-[10px] text-slate-400 font-bold block mb-1 uppercase">Select User</label>
                      <select 
                        id="fund-user1-select"
                        value={fundUser1Id}
                        onChange={(e) => setFundUser1Id(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 text-white px-2.5 py-1.5 rounded-lg text-xs"
                      >
                        <option value="">-- Choose User --</option>
                        {users.filter(u => u.role !== 'admin').map(u => (
                          <option key={u.id} value={u.id}>{u.name} (ID: {u.id.substring(0,8).toUpperCase()}... - Balance: ₹{u.walletBalance})</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 font-bold block mb-1 uppercase">Amount to Credit (₹)</label>
                      <input 
                        id="fund-user1-amount"
                        type="number"
                        placeholder="e.g. 500"
                        value={fundUser1Amount}
                        onChange={(e) => setFundUser1Amount(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 text-white px-2.5 py-1.5 rounded-lg text-xs font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* User Slot 2 */}
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                  <span className="text-[10px] font-black uppercase text-amber-500 tracking-wider mb-2 block">👤 User Slot 2</span>
                  <div className="space-y-3">
                    <div>
                      <label className="text-[10px] text-slate-400 font-bold block mb-1 uppercase">Select User</label>
                      <select 
                        id="fund-user2-select"
                        value={fundUser2Id}
                        onChange={(e) => setFundUser2Id(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 text-white px-2.5 py-1.5 rounded-lg text-xs"
                      >
                        <option value="">-- Choose User --</option>
                        {users.filter(u => u.role !== 'admin').map(u => (
                          <option key={u.id} value={u.id}>{u.name} (ID: {u.id.substring(0,8).toUpperCase()}... - Balance: ₹{u.walletBalance})</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 font-bold block mb-1 uppercase">Amount to Credit (₹)</label>
                      <input 
                        id="fund-user2-amount"
                        type="number"
                        placeholder="e.g. 1000"
                        value={fundUser2Amount}
                        onChange={(e) => setFundUser2Amount(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 text-white px-2.5 py-1.5 rounded-lg text-xs font-mono"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-4 flex justify-end">
                <button
                  id="apply-double-credit-btn"
                  onClick={handleApplyDoubleCredit}
                  className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black rounded-lg text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md active:scale-95"
                >
                  ⚡ Execute Double-User Funding Credit
                </button>
              </div>
            </div>

            <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-sm">
              <div className="mb-4">
                <input 
                  id="member-search-input"
                  type="text"
                  placeholder="Search by legal name, email, or profile ID..."
                  value={memberSearch}
                  onChange={(e) => setMemberSearch(e.target.value)}
                  className="w-full max-w-sm px-3.5 py-2 rounded-lg border border-slate-200 text-xs focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="overflow-x-auto">
                <table id="admin-members-table" className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-100 text-slate-400 uppercase font-semibold">
                      <th className="pb-2">User ID</th>
                      <th className="pb-2">Full Legal Name</th>
                      <th className="pb-2">Contact Info</th>
                      <th className="pb-2">Password</th>
                      <th className="pb-2 text-right">Wallet Balance</th>
                      <th className="pb-2 text-center">Status</th>
                      <th className="pb-2 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {filteredMembers.slice(0, membersLimit).map(u => (
                      <tr id={`admin-member-row-${u.id}`} key={u.id} className="hover:bg-slate-50/50">
                        <td className="py-3 font-mono text-[10px] text-slate-500">{u.id}</td>
                        <td className="py-3">
                          <p className="font-bold text-slate-800">{u.name}</p>
                          <span className="text-[10px] text-amber-600 font-semibold uppercase">{u.role}</span>
                        </td>
                        <td className="py-3">
                          <p className="text-slate-700">{u.email}</p>
                          <span className="text-slate-400 font-mono text-[10px]">{u.phone}</span>
                        </td>
                        <td className="py-3">
                          <span className="px-2 py-1 rounded bg-amber-100 text-amber-950 text-[10px] font-bold font-mono border border-amber-200">
                            🔑 {u.password || '123456'}
                          </span>
                        </td>
                        <td className="py-3 text-right">
                          {editingUserId === u.id ? (
                            <div className="flex justify-end gap-1 items-center">
                              <input 
                                id={`edit-balance-input-${u.id}`}
                                type="number" 
                                value={editBalanceAmt} 
                                onChange={(e) => setEditBalanceAmt(e.target.value)}
                                className="w-20 px-1 py-0.5 border border-slate-300 rounded text-right font-bold"
                              />
                              <button 
                                id={`save-balance-btn-${u.id}`}
                                onClick={() => handleSaveBalanceEdit(u.id)} 
                                className="px-2 py-0.5 bg-emerald-600 text-white rounded text-[10px] font-bold cursor-pointer"
                              >
                                Save
                              </button>
                            </div>
                          ) : (
                            <div className="flex justify-end items-center gap-1.5">
                              <span className="font-black text-slate-900">₹{u.walletBalance.toLocaleString()}</span>
                              {u.role === 'user' && (
                                <button 
                                  id={`edit-balance-trigger-${u.id}`}
                                  onClick={() => { setEditingUserId(u.id); setEditBalanceAmt(u.walletBalance.toString()); }}
                                  className="text-[9px] text-amber-600 hover:underline font-semibold cursor-pointer"
                                >
                                  (Adjust)
                                </button>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="py-3 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase ${
                            (u.isBlocked || u.status === 'suspended') ? 'bg-rose-50 text-rose-700 border border-rose-200 font-extrabold' :
                            u.status === 'active' ? 'bg-emerald-50 text-emerald-700' :
                            'bg-amber-50 text-amber-700'
                          }`}>
                            {(u.isBlocked || u.status === 'suspended') ? '🚫 BLOCKED' : u.status}
                          </span>
                        </td>
                        <td className="py-3 text-right">
                          {u.id !== 'admin-id' && (
                            <div className="flex justify-end gap-1.5">
                              {!(u.isBlocked || u.status === 'suspended') ? (
                                <button 
                                  id={`suspend-user-btn-${u.id}`}
                                  onClick={() => {
                                    if (window.confirm(`Block user ID ${u.name} (${u.email})? They will be prevented from accessing the system.`)) {
                                      onUpdateUser({ ...u, isBlocked: true, status: 'suspended' });
                                    }
                                  }}
                                  className="px-2 py-1 text-[10px] font-bold text-rose-600 hover:bg-rose-50 border border-rose-200 rounded cursor-pointer transition-colors"
                                >
                                  Block ID
                                </button>
                              ) : (
                                <button 
                                  id={`activate-user-btn-${u.id}`}
                                  onClick={() => {
                                    if (window.confirm(`Unblock user ID ${u.name}?`)) {
                                      onUpdateUser({ ...u, isBlocked: false, status: 'active' });
                                    }
                                  }}
                                  className="px-2 py-1 text-[10px] font-bold text-emerald-600 hover:bg-emerald-50 border border-emerald-200 rounded cursor-pointer transition-colors"
                                >
                                  Unblock ID
                                </button>
                              )}
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-4 flex flex-col sm:flex-row justify-between items-center bg-slate-50 p-3 rounded-xl border border-slate-100 gap-2">
                <span className="text-slate-500 text-xs">
                  Showing first <b>{Math.min(membersLimit, filteredMembers.length)}</b> of <b>{filteredMembers.length}</b> registered members.
                </span>
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">Limit:</span>
                  <select
                    id="members-view-limit-select"
                    value={membersLimit}
                    onChange={(e) => setMembersLimit(parseInt(e.target.value))}
                    className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs font-bold focus:outline-none focus:border-amber-500"
                  >
                    <option value="10">10 IDs</option>
                    <option value="20">20 IDs</option>
                    <option value="30">30 IDs</option>
                    <option value="40">40 IDs</option>
                    <option value="50">50 IDs</option>
                    <option value="100">100 IDs</option>
                    <option value="500">500 IDs</option>
                    <option value="1000">1,000 IDs</option>
                    <option value="5000">5,000 IDs</option>
                    <option value="10000">10,000 IDs</option>
                    <option value="20000">20,000 IDs</option>
                    <option value="50000">Show All</option>
                  </select>
                  {filteredMembers.length > membersLimit && (
                    <button
                      id="load-more-members-btn"
                      onClick={() => setMembersLimit(prev => prev + 500)}
                      className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer shadow-xs"
                    >
                      Load More (+500)
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 3: KYC AUDITS */}
        {activeAdminTab === 'kyc' && (
          <div>
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-slate-900">KYC Verification</h1>
              <p className="text-slate-500 text-sm">Review scanned legal documents to approve help request permissions.</p>
            </div>

            {users.filter(u => u.kycStatus === 'pending').length === 0 ? (
              <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center text-slate-400 text-xs">
                All uploaded KYC verification packages are fully reviewed. No pending tasks!
              </div>
            ) : (
              <div className="space-y-6">
                {users.filter(u => u.kycStatus === 'pending').map(user => (
                  <div id={`kyc-audit-card-${user.id}`} key={user.id} className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-4">
                      <div>
                        <span className="text-[10px] font-mono font-bold text-slate-400">SUBMISSION BY:</span>
                        <h3 className="font-bold text-base text-slate-900">{user.name}</h3>
                        <p className="text-xs text-slate-500">Contact: {user.email} | Registered: {new Date(user.registeredAt).toLocaleDateString()}</p>
                      </div>

                      <div className="flex gap-2">
                        <button 
                          id={`kyc-approve-btn-${user.id}`}
                          onClick={() => {
                            const updated: User = {
                              ...user,
                              kycStatus: 'approved',
                              status: 'active'
                            };
                            onUpdateUser(updated);
                            alert(`Approved KYC for ${user.name}`);
                          }}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
                        >
                          Approve KYC Doc
                        </button>
                        <button 
                          id={`kyc-reject-btn-${user.id}`}
                          onClick={() => {
                            const updated: User = {
                              ...user,
                              kycStatus: 'rejected'
                            };
                            onUpdateUser(updated);
                            alert(`Rejected KYC for ${user.name}`);
                          }}
                          className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
                        >
                          Reject Request
                        </button>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Document Information</span>
                        <table className="w-full text-xs mt-2 space-y-1">
                          <tbody>
                            <tr>
                              <td className="text-slate-400 py-1 font-semibold pr-4">ID Type:</td>
                              <td className="text-slate-800 font-bold">{user.kycDetails?.documentType}</td>
                            </tr>
                            <tr>
                              <td className="text-slate-400 py-1 font-semibold pr-4">Doc Serial Number:</td>
                              <td className="text-slate-800 font-mono font-bold">{user.kycDetails?.documentNumber}</td>
                            </tr>
                            <tr>
                              <td className="text-slate-400 py-1 font-semibold pr-4">File Name Submitted:</td>
                              <td className="text-slate-600 font-mono text-[10px]">{user.kycDetails?.fileUrl}</td>
                            </tr>
                            <tr>
                              <td className="text-slate-400 py-1 font-semibold pr-4">Submit Time:</td>
                              <td className="text-slate-500">{new Date(user.kycDetails?.submittedAt || '').toLocaleString()}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>

                      {/* Attachment Proof Box mockup */}
                      <div className="border border-slate-200/80 rounded-xl p-4 bg-slate-50 flex items-center justify-center">
                        <div className="text-center">
                          <FileText className="w-8 h-8 text-slate-400 mx-auto mb-1.5" />
                          <p className="text-xs font-semibold text-slate-700">{user.kycDetails?.fileUrl}</p>
                          <span className="text-[9px] text-slate-400 font-mono block mt-0.5">Mock Scanner: Fully Legible Identity Proof</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* SUBTAB 4: PLEDGES AUDIT */}
        {activeAdminTab === 'contributions' && (
          <div className="space-y-8 animate-fade-in">
            {/* Header */}
            <div>
              <h1 className="text-2xl font-bold text-slate-900 font-sans tracking-tight">Provided Help (Givers) Portal</h1>
              <p className="text-slate-500 text-sm">Review, audit, and inspect all direct community provided help entries (pledges) in one ledger.</p>
            </div>

            {/* Part 1: Action Queue (Pending Verification) */}
            <div className="bg-amber-500/5 border border-amber-200/50 p-5 rounded-2xl space-y-4">
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse"></span>
                <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider">Action Required: Pending Verification Receipts</h3>
              </div>

              {contributions.filter(c => c.status === 'pending_verification').length === 0 ? (
                <p className="text-xs text-slate-500 font-medium">All submitted community contribution receipts have been approved. Zero pending audit tasks.</p>
              ) : (
                <div className="grid md:grid-cols-2 gap-4">
                  {contributions.filter(c => c.status === 'pending_verification').map(contrib => {
                    const isAdminLink = contrib.remarks?.includes('First Provide Help - Admin') || (contrib.amount === 20 && contrib.remarks?.includes('Admin'));
                    return (
                      <div 
                        id={`contrib-audit-card-${contrib.id}`} 
                        key={contrib.id} 
                        className={`bg-white p-4 rounded-xl border shadow-xs flex flex-col justify-between gap-3 transition-all ${
                          isAdminLink 
                            ? 'border-pink-300 ring-2 ring-pink-500/10 bg-gradient-to-b from-white to-pink-50/10' 
                            : 'border-slate-200'
                        }`}
                      >
                        <div>
                          <div className="flex justify-between items-start gap-2">
                            <span className="text-[9px] font-mono font-bold text-slate-400 uppercase">PLEDGE: {contrib.id.substring(0, 8)}...</span>
                            <div className="flex gap-1">
                              {isAdminLink && (
                                <span className="px-2 py-0.5 rounded text-[8px] font-black uppercase bg-pink-100 text-pink-700 animate-pulse border border-pink-200">
                                  👑 Admin Link (₹20)
                                </span>
                              )}
                              <span className="px-2 py-0.5 rounded text-[8px] font-black uppercase bg-amber-100 text-amber-700">Verification Pending</span>
                            </div>
                          </div>
                          <h4 className="font-bold text-slate-800 text-sm mt-1">Contributor: {contrib.userName}</h4>
                          <p className="text-[11px] text-slate-500 mt-0.5">Proof Submitted: <strong className="font-mono text-slate-700">{contrib.paymentProof || 'No proof file'}</strong></p>
                          {contrib.txLink && (
                            <p className="text-[11px] text-indigo-600 mt-1 truncate">
                              <strong>Tx Link: </strong>
                              <a href={contrib.txLink} target="_blank" rel="noopener noreferrer" className="underline hover:text-indigo-800 cursor-pointer">
                                {contrib.txLink}
                              </a>
                            </p>
                          )}

                          {contrib.remarks && (
                            <div className={`text-[10px] p-2 rounded-lg border mt-2 leading-relaxed ${
                              isAdminLink 
                                ? 'bg-pink-50/50 border-pink-100 text-pink-800' 
                                : 'bg-slate-50 border-slate-100 text-slate-700'
                            }`}>
                              <span className="font-bold block uppercase tracking-wider text-[8px] mb-0.5">Pledge Context / Remarks:</span>
                              {contrib.remarks}
                            </div>
                          )}

                          <p className={`text-lg font-black mt-2.5 ${isAdminLink ? 'text-pink-600' : 'text-emerald-600'}`}>₹{contrib.amount.toLocaleString()}</p>
                        </div>

                        <div className="flex gap-2 border-t border-slate-100 pt-2.5">
                          <button 
                            id={`contrib-approve-btn-${contrib.id}`}
                            onClick={() => {
                              onUpdateContribution(contrib.id, 'approved', 'Pledge validated and successfully credited.');
                              
                              // Add funds directly to the user's total pledges
                              const userObj = users.find(u => u.id === contrib.userId);
                              if (userObj) {
                                onUpdateUser({
                                  ...userObj,
                                  totalContributed: userObj.totalContributed + contrib.amount
                                });
                              }

                              // Trigger transaction completion status as well
                              const relevantTx = transactions.find(t => t.userId === contrib.userId && t.amount === contrib.amount && t.type === 'contribution' && t.status === 'pending');
                              if (relevantTx) {
                                onUpdateTransaction(relevantTx.id, 'completed');
                              }

                              alert('Contribution verified and credited successfully!');
                            }}
                            className={`flex-1 py-2 text-white rounded-lg text-[10px] font-black uppercase tracking-wider text-center cursor-pointer transition-colors ${
                              isAdminLink ? 'bg-pink-600 hover:bg-pink-700 shadow-sm' : 'bg-emerald-600 hover:bg-emerald-700'
                            }`}
                          >
                            Approve Payment
                          </button>
                          <button 
                            id={`contrib-reject-btn-${contrib.id}`}
                            onClick={() => {
                              onUpdateContribution(contrib.id, 'rejected', 'Verification failed. Incorrect transaction reference.');
                              alert('Contribution pledge rejected.');
                            }}
                            className="py-2 px-3 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[10px] font-black uppercase tracking-wider text-center cursor-pointer transition-colors"
                          >
                            Reject
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Part 2: Comprehensive Provided Help Ledger */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h3 className="font-bold text-slate-900 text-lg">Community Provided Help Ledger</h3>
                  <p className="text-xs text-slate-500 mt-0.5">Filter and review all submitted aid pledges and direct support transactions.</p>
                </div>

                {/* Filter Tabs */}
                <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200/50 self-stretch sm:self-auto">
                  {(['all', 'pending_verification', 'approved', 'rejected'] as const).map(f => (
                    <button
                      key={f}
                      onClick={() => setContribFilter(f === 'pending_verification' ? 'pending' : f)}
                      className={`flex-1 sm:flex-none px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer text-center ${
                        (contribFilter === 'pending' && f === 'pending_verification') || (contribFilter === f)
                          ? 'bg-white text-slate-900 shadow-sm'
                          : 'text-slate-500 hover:text-slate-900'
                      }`}
                    >
                      {f === 'pending_verification' ? 'Pending' : f}
                    </button>
                  ))}
                </div>
              </div>

              {/* Ledger Table */}
              <div className="overflow-x-auto border border-slate-100 rounded-xl bg-slate-50 p-1.5">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 uppercase tracking-wider text-[10px] font-bold">
                      <th className="p-3">Pledge ID</th>
                      <th className="p-3">Giver Name</th>
                      <th className="p-3">Amount</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Proof Details</th>
                      <th className="p-3">Pledged Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      const filteredContribs = contributions.filter(c => {
                        if (contribFilter === 'all') return true;
                        if (contribFilter === 'pending') return c.status === 'pending_verification';
                        return c.status === contribFilter;
                      });

                      if (filteredContribs.length === 0) {
                        return (
                          <tr>
                            <td colSpan={6} className="p-8 text-center text-slate-400 font-mono text-xs">
                              No contribution matching the filter criteria found.
                            </td>
                          </tr>
                        );
                      }

                      return filteredContribs.map(c => (
                        <tr key={c.id} className="border-b border-slate-100 bg-white hover:bg-slate-50/50 transition-colors">
                          <td className="p-3 font-mono font-bold text-slate-500">{c.id.substring(0, 10)}...</td>
                          <td className="p-3">
                            <div className="font-bold text-slate-800">{c.userName}</div>
                            <div className="flex flex-col gap-0.5">
                              <span className="text-[9px] text-slate-400 font-semibold uppercase">{users.find(u => u.id === c.userId)?.phone || 'No Phone'}</span>
                              {c.remarks && (
                                <span className="text-[10px] text-slate-500 italic max-w-[220px] truncate" title={c.remarks}>
                                  {c.remarks}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-3 font-black text-emerald-600">₹{c.amount.toLocaleString()}</td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                              c.status === 'approved' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' :
                              c.status === 'pending_verification' ? 'bg-amber-50 text-amber-700 border border-amber-100' :
                              c.status === 'rejected' ? 'bg-rose-50 text-rose-700 border border-rose-100' :
                              'bg-slate-50 text-slate-600'
                            }`}>
                              {c.status === 'pending_verification' ? 'Pending Audit' : c.status}
                            </span>
                          </td>
                          <td className="p-3 font-mono text-slate-500 text-[10px]">
                            {c.paymentProof && (
                              <div className="bg-slate-50 px-1.5 py-0.5 rounded border border-slate-200/50 font-medium inline-block mb-1">
                                Ref: {c.paymentProof}
                              </div>
                            )}
                            {c.txLink && (
                              <div className="block mt-0.5">
                                <a href={c.txLink} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline font-semibold block truncate max-w-[150px]">
                                  Tx Link ↗
                                </a>
                              </div>
                            )}
                            {!c.paymentProof && !c.txLink && (
                              <span className="text-slate-300">No proof/link</span>
                            )}
                          </td>
                          <td className="p-3 text-slate-400">{new Date(c.createdAt).toLocaleDateString()}</td>
                        </tr>
                      ));
                    })()}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* SUBTAB 5: HELP REQUESTS CAMPAIGNS */}
        {activeAdminTab === 'help_requests' && (
          <div className="space-y-8 animate-fade-in">
            {/* Header */}
            <div>
              <h1 className="text-2xl font-bold text-slate-900 font-sans tracking-tight">Takers (Aid Campaign) Portal</h1>
              <p className="text-slate-500 text-sm">Audit user aid applications, track funding progress, and manage the list of takers seeking direct community matching.</p>
            </div>

            {/* ADMINISTRATIVE GET HELP INITIATOR FORM */}
            <div className="bg-gradient-to-br from-indigo-50/50 via-white to-indigo-50/20 p-6 rounded-2xl border border-indigo-100 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-indigo-600" />
                <div>
                  <h3 className="font-extrabold text-slate-900 text-sm">🎁 Administrative Get-Help Initiator Desk</h3>
                  <p className="text-[11px] text-slate-500">Create a verified community aid campaign directly on behalf of any active member. The campaign will be pre-approved and instantly open for community routing.</p>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4 pt-2">
                {/* User Dropdown */}
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1">Beneficiary Member</label>
                  <select
                    value={adminInitTakerUserId}
                    onChange={(e) => {
                      const uId = e.target.value;
                      setAdminInitTakerUserId(uId);
                      const u = users.find(x => x.id === uId);
                      if (u) {
                        setAdminInitTakerName(u.name);
                      }
                    }}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-indigo-500"
                  >
                    <option value="">-- Select Member --</option>
                    {users.filter(u => u.role !== 'admin' && u.status === 'active').map(u => (
                      <option key={u.id} value={u.id}>{u.name} ({u.email})</option>
                    ))}
                  </select>
                </div>

                {/* Campaign Title */}
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1">Campaign Title / Need Reason</label>
                  <input
                    type="text"
                    placeholder="e.g. Urgent Medical / Household Bill"
                    value={adminInitTakerTitle}
                    onChange={(e) => setAdminInitTakerTitle(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                {/* Amount Requested */}
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1">Amount Requested (INR)</label>
                  <input
                    type="number"
                    placeholder="e.g. 5000"
                    value={adminInitTakerAmount}
                    onChange={(e) => setAdminInitTakerAmount(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                {/* Submit button */}
                <div className="flex items-end">
                  <button
                    onClick={() => {
                      if (!adminInitTakerUserId || !adminInitTakerTitle || !adminInitTakerAmount) {
                        alert('Please fill out all fields to initiate Get Help campaign.');
                        return;
                      }
                      const amt = parseFloat(adminInitTakerAmount);
                      if (isNaN(amt) || amt <= 0) {
                        alert('Please enter a valid positive amount.');
                        return;
                      }

                      const beneficiary = users.find(u => u.id === adminInitTakerUserId);
                      if (!beneficiary) {
                        alert('Beneficiary user not found.');
                        return;
                      }

                      // Create the campaign
                      const newCampaignId = 'help-' + Math.random().toString(36).substr(2, 9);
                      const newCampaign: HelpRequest = {
                        id: newCampaignId,
                        userId: beneficiary.id,
                        userName: beneficiary.name,
                        title: adminInitTakerTitle.trim(),
                        description: `Administratively initiated active community aid campaign for ${beneficiary.name}. Pre-vetted and approved for direct matching.`,
                        amountRequested: amt,
                        amountReceived: 0,
                        documentUrl: 'admin_vetted_claim.pdf',
                        status: 'approved', // Pre-approved so it's instantly matchable!
                        createdAt: new Date().toISOString(),
                        reviewedAt: new Date().toISOString(),
                        remarks: 'Created and verified directly by community administration desk.'
                      };

                      if (onAddHelpRequest) {
                        onAddHelpRequest(newCampaign);

                        // Trigger a notification for the beneficiary
                        const initNotif: Notification = {
                          id: 'notif-' + Math.random().toString(36).substr(2, 9),
                          userId: beneficiary.id,
                          title: '🎁 Admin Get-Help Campaign Created',
                          message: `The administration has initiated an active community Get-Help aid campaign of ₹${amt} on your behalf: "${adminInitTakerTitle.trim()}". You are now fully eligible to receive direct peer-to-peer aid matches or community reserve funds!`,
                          type: 'success',
                          read: false,
                          createdAt: new Date().toISOString()
                        };
                        onAddNotification(initNotif);

                        alert(`Successfully created and pre-approved Get-Help campaign for ${beneficiary.name}! Amount: ₹${amt}. Beneficiary notified.`);
                        
                        // Reset form
                        setAdminInitTakerUserId('');
                        setAdminInitTakerName('');
                        setAdminInitTakerTitle('');
                        setAdminInitTakerAmount('');
                      } else {
                        alert('Error: onAddHelpRequest callback is not available.');
                      }
                    }}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-2 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all text-center shadow-xs"
                  >
                    Send Get Help Request
                  </button>
                </div>
              </div>
            </div>

            {/* Filter and search header */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h3 className="font-bold text-slate-900 text-lg">Taker Campaigns Ledger</h3>
                  <p className="text-xs text-slate-500 mt-0.5">Filter takers seeking community aid and view their mutual aid progress.</p>
                </div>

                {/* Filter Tabs */}
                <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200/50 self-stretch sm:self-auto">
                  {(['all', 'pending_review', 'approved', 'completed'] as const).map(f => (
                    <button
                      key={f}
                      onClick={() => setTakerFilter(f)}
                      className={`flex-1 sm:flex-none px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer text-center ${
                        takerFilter === f
                          ? 'bg-white text-slate-900 shadow-sm'
                          : 'text-slate-500 hover:text-slate-900'
                      }`}
                    >
                      {f === 'pending_review' ? 'Pending Audit' : f}
                    </button>
                  ))}
                </div>
              </div>

              {/* Campaigns list */}
              {(() => {
                const filteredTakers = helpRequests.filter(h => {
                  if (takerFilter === 'all') return true;
                  return h.status === takerFilter;
                });

                if (filteredTakers.length === 0) {
                  return (
                    <div className="text-center py-8 text-slate-400 font-mono text-xs">
                      No taker campaigns match the selected filter.
                    </div>
                  );
                }

                return (
                  <div className="grid md:grid-cols-2 gap-6">
                    {filteredTakers.map(help => {
                      const fundingPercent = Math.min(100, Math.round((help.amountReceived / help.amountRequested) * 100));
                      const remainingNeed = help.amountRequested - help.amountReceived;
                      return (
                        <div id={`admin-help-card-${help.id}`} key={help.id} className="bg-slate-50 p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between gap-4">
                          <div className="space-y-2">
                            <div className="flex justify-between items-start">
                              <span className="text-[9px] font-mono font-bold text-slate-400 uppercase">TAKER ID: {help.id.substring(0,8)}...</span>
                              <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase border ${
                                help.status === 'completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                                help.status === 'approved' ? 'bg-indigo-50 text-indigo-700 border-indigo-100' :
                                'bg-amber-50 text-amber-700 border-amber-100'
                              }`}>
                                {help.status === 'pending_review' ? 'Pending Review' : help.status}
                              </span>
                            </div>
                            
                            <div>
                              <h4 className="font-bold text-slate-800 text-sm">{help.title}</h4>
                              <p className="text-[10px] text-slate-400">Raised By: <strong className="text-slate-600">{help.userName}</strong> | Raised: {new Date(help.createdAt).toLocaleDateString()}</p>
                            </div>

                            <p className="text-xs text-slate-600 line-clamp-3 bg-white p-3 rounded-lg border border-slate-200/50 leading-relaxed">
                              {help.description}
                            </p>

                            {/* Funding Progress Bar */}
                            <div className="space-y-1 pt-1">
                              <div className="flex justify-between text-[10px] font-bold text-slate-500">
                                <span>Funded: {fundingPercent}%</span>
                                <span>₹{help.amountReceived.toLocaleString()} / ₹{help.amountRequested.toLocaleString()}</span>
                              </div>
                              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                                <div 
                                  className="bg-indigo-600 h-2 rounded-full transition-all duration-500" 
                                  style={{ width: `${fundingPercent}%` }}
                                ></div>
                              </div>
                              {remainingNeed > 0 && (
                                <p className="text-[9px] text-amber-600 font-semibold uppercase tracking-wider">Remaining Aid Goal: ₹{remainingNeed.toLocaleString()}</p>
                              )}
                            </div>
                          </div>

                          <div className="flex flex-col gap-2 pt-2 border-t border-slate-200/50">
                            <div className="text-[10px] text-slate-400 font-medium">
                              Verification Proof: <strong className="text-slate-600 font-mono">{help.documentUrl || 'N/A'}</strong>
                            </div>

                            <div className="flex gap-2 mt-1">
                              {help.status === 'pending_review' && (
                                <button 
                                  id={`help-audit-approve-btn-${help.id}`}
                                  onClick={() => {
                                    onUpdateHelpRequest(help.id, 'approved', 0, 'Campaign claims audited and approved for matching.');
                                    alert(`Campaign '${help.title}' is now approved for matching.`);
                                  }}
                                  className="flex-1 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[10px] font-black uppercase tracking-wider text-center cursor-pointer transition-colors"
                                >
                                  Approve Aid Claim
                                </button>
                              )}

                              {help.status === 'approved' && remainingNeed > 0 && (
                                <button 
                                  id={`help-audit-match-btn-${help.id}`}
                                  onClick={() => {
                                    // Match 100% of the funds requested using system reserves
                                    onUpdateHelpRequest(help.id, 'completed', help.amountRequested, 'Matched successfully by collective pledge pool.');
                                    
                                    // Credit funds directly to target user balance
                                    const userObj = users.find(u => u.id === help.userId);
                                    if (userObj) {
                                      onUpdateUser({
                                        ...userObj,
                                        walletBalance: userObj.walletBalance + remainingNeed,
                                        totalReceived: userObj.totalReceived + remainingNeed
                                      });
                                    }

                                    // Record ledger payout transaction
                                    const newTx: Transaction = {
                                      id: 'tx-' + Math.random().toString(36).substr(2, 9),
                                      userId: help.userId,
                                      userName: help.userName,
                                      type: 'payout',
                                      amount: remainingNeed,
                                      status: 'completed',
                                      description: `Mutual Aid Payout Match for approved Help Request: ${help.title}`,
                                      createdAt: new Date().toISOString()
                                    };
                                    onAddTransaction(newTx);

                                    alert(`Successfully matched and disbursed remaining ₹${remainingNeed.toLocaleString()} from reserves to ${help.userName}'s wallet!`);
                                  }}
                                  className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-black uppercase tracking-wider text-center cursor-pointer transition-colors"
                                >
                                  Disburse Reserve Funds (₹{remainingNeed.toLocaleString()})
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>
          </div>
        )}

        {/* SUBTAB 6: WALLET AUDITS */}
        {activeAdminTab === 'wallet' && (
          <div>
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-slate-900">Wallet Audits</h1>
              <p className="text-slate-500 text-sm">Approve pending manual deposits, process manual payout transfers, or adjust user balances.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              
              {/* Form Side: Direct Adjustment Transaction */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm h-fit">
                <h3 className="font-bold text-slate-900 mb-1">Create Direct Adjusted Transaction</h3>
                <p className="text-slate-500 text-xs mb-4">Directly adjust user wallet balance with simulation records.</p>

                <form onSubmit={handleManualTxSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Target Member</label>
                    <select 
                      id="manual-tx-user"
                      required
                      value={selectedUserId} 
                      onChange={(e) => setSelectedUserId(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                    >
                      <option value="">-- Choose User --</option>
                      {users.filter(u => u.role === 'user').map(u => (
                        <option key={u.id} value={u.id}>{u.name} (Bal: ₹{u.walletBalance.toLocaleString()})</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Type</label>
                      <select 
                        id="manual-tx-type"
                        value={manualTxType} 
                        onChange={(e) => setManualTxType(e.target.value as any)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                      >
                        <option value="deposit">Manual Credit (Deposit)</option>
                        <option value="payout">Manual Debit (Withdrawal)</option>
                        <option value="referral_bonus">Referral Reward Credit</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Amount (₹)</label>
                      <input 
                        id="manual-tx-amount"
                        type="number"
                        required
                        placeholder="e.g. 150"
                        value={manualTxAmount}
                        onChange={(e) => setManualTxAmount(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Target Wallet</label>
                      <select 
                        id="manual-tx-target-wallet"
                        value={targetWallet}
                        onChange={(e) => setTargetWallet(e.target.value as any)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                      >
                        <option value="all">Main Wallet (All)</option>
                        <option value="provide">Provide Wallet</option>
                        <option value="get">Get Wallet</option>
                        <option value="direct">Direct Wallet</option>
                        <option value="level">Level Wallet</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Reason / Description</label>
                      <input 
                        id="manual-tx-desc"
                        type="text"
                        placeholder="e.g. Compensation Adjustments, manual validation"
                        value={manualTxDesc}
                        onChange={(e) => setManualTxDesc(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                      />
                    </div>
                  </div>

                  <button 
                    id="manual-tx-submit"
                    type="submit"
                    className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer"
                  >
                    Adjust Balance
                  </button>
                </form>
              </div>

              {/* List Side: Pending Transactions (Deposits / Withdrawals) */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <h3 className="font-bold text-slate-900 mb-1">Pending Deposit / Withdrawal Requests</h3>
                
                {transactions.filter(t => t.status === 'pending').length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-8">No pending transaction requests found.</p>
                ) : (
                  transactions.filter(t => t.status === 'pending').map(tx => (
                    <div id={`pending-tx-card-${tx.id}`} key={tx.id} className="p-4 rounded-xl bg-slate-50 border border-slate-100 flex flex-col justify-between gap-3">
                      <div>
                        <div className="flex justify-between items-start">
                          <span className="text-[9px] font-mono text-slate-400 font-bold uppercase">{tx.id} | {tx.type}</span>
                          {tx.txLink && (
                            <span className="text-[9px] text-indigo-600 font-semibold bg-indigo-50 px-1.5 py-0.5 rounded">
                              Link Attached
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-slate-800 text-xs mt-0.5">{tx.userName}</h4>
                        <p className="text-[11px] text-slate-600 mt-0.5">{tx.description}</p>
                        {tx.txLink && (
                          <p className="text-[10px] text-indigo-600 mt-1 truncate">
                            <strong>Tx Link: </strong>
                            <a href={tx.txLink} target="_blank" rel="noopener noreferrer" className="underline hover:text-indigo-800 cursor-pointer">
                              {tx.txLink}
                            </a>
                          </p>
                        )}
                        <p className="text-base font-black text-emerald-600 mt-1">₹{tx.amount.toLocaleString()}</p>
                      </div>

                      <div className="flex gap-1.5 self-end">
                        <button 
                          id={`tx-approve-btn-${tx.id}`}
                          onClick={() => {
                            onUpdateTransaction(tx.id, 'completed');
                            
                            // credit user balance if deposit
                            const targetUser = users.find(u => u.id === tx.userId);
                            if (targetUser && tx.type === 'deposit') {
                              onUpdateUser({
                                ...targetUser,
                                walletBalance: targetUser.walletBalance + tx.amount,
                                provideWallet: (targetUser.provideWallet ?? 0) + tx.amount
                              });
                            }

                            alert('Transaction validated successfully!');
                          }}
                          className="px-2 py-1 bg-emerald-600 text-white text-[10px] font-bold rounded cursor-pointer"
                        >
                          Approve Request
                        </button>
                        <button 
                          id={`tx-reject-btn-${tx.id}`}
                          onClick={() => {
                            onUpdateTransaction(tx.id, 'rejected');
                            
                            // refund user if withdrawal was rejected
                            const targetUser = users.find(u => u.id === tx.userId);
                            if (targetUser && tx.type === 'withdrawal') {
                              const walletField = tx.walletSource || 'get';
                              const prevWalletVal = targetUser[walletField] ?? 0;
                              onUpdateUser({
                                ...targetUser,
                                walletBalance: targetUser.walletBalance + tx.amount,
                                [walletField]: prevWalletVal + tx.amount
                              });
                              alert(`Withdrawal request rejected. ₹${tx.amount} has been refunded to their ${walletField.toUpperCase()} Wallet.`);
                            } else {
                              alert('Transaction rejected.');
                            }
                          }}
                          className="px-2 py-1 bg-rose-600 text-white text-[10px] font-bold rounded cursor-pointer"
                        >
                          Reject Request
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

            </div>

            {/* Complete System Transaction Ledger with Deletion Controls */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm mt-8 space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div>
                  <h3 className="font-bold text-slate-900 text-lg">System Transaction History & Ledger ({transactions.length})</h3>
                  <p className="text-xs text-slate-500 mt-0.5">Admin ledger management for all deposits, withdrawals, payouts, and commissions.</p>
                </div>
                {onClearAllTransactions && transactions.length > 0 && (
                  <button
                    onClick={() => {
                      if (window.confirm('⚠️ CRITICAL WARNING: Delete all system transaction history? This operation cannot be undone.')) {
                        onClearAllTransactions();
                        alert('All system transaction history has been cleared.');
                      }
                    }}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
                  >
                    🗑️ Delete All Transaction History
                  </button>
                )}
              </div>

              {transactions.length === 0 ? (
                <div className="text-center py-10 bg-slate-50 rounded-xl border border-slate-100">
                  <p className="text-xs text-slate-400 font-mono">No transaction history records found.</p>
                </div>
              ) : (
                <div className="overflow-x-auto border border-slate-100 rounded-xl">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-50 text-slate-500 text-[10px] font-bold uppercase tracking-wider border-b border-slate-200">
                        <th className="p-3">Tx ID / Date</th>
                        <th className="p-3">User</th>
                        <th className="p-3">Type</th>
                        <th className="p-3">Amount</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {transactions.slice(0, 100).map(tx => (
                        <tr key={tx.id} className="hover:bg-slate-50/60 transition-colors">
                          <td className="p-3">
                            <span className="font-mono font-bold text-slate-800">{tx.id}</span>
                            <span className="block text-[10px] text-slate-400 mt-0.5">{new Date(tx.createdAt).toLocaleString()}</span>
                          </td>
                          <td className="p-3 font-semibold text-slate-800">
                            {tx.userName}
                            <span className="block text-[10px] text-slate-400 font-mono">{tx.userId}</span>
                          </td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 bg-slate-100 text-slate-700 font-bold rounded text-[9px] uppercase font-mono">
                              {tx.type}
                            </span>
                          </td>
                          <td className="p-3 font-black text-slate-900">
                            ₹{tx.amount.toLocaleString()}
                          </td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${
                              tx.status === 'completed' ? 'bg-emerald-50 text-emerald-700' :
                              tx.status === 'pending' ? 'bg-amber-50 text-amber-700' :
                              'bg-rose-50 text-rose-700'
                            }`}>
                              {tx.status}
                            </span>
                          </td>
                          <td className="p-3 text-right">
                            {onDeleteTransaction && (
                              <button
                                onClick={() => {
                                  if (window.confirm(`Delete transaction record ${tx.id}?`)) {
                                    onDeleteTransaction(tx.id);
                                  }
                                }}
                                className="px-2 py-1 text-rose-600 hover:bg-rose-50 border border-rose-200 rounded text-[10px] font-bold cursor-pointer transition-colors"
                                title="Delete Transaction"
                              >
                                Delete Tx
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* SUBTAB 7: REPORTS & ANALYTICS */}
        {activeAdminTab === 'reports' && (
          <div>
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-slate-900">Reports & Analytics</h1>
              <p className="text-slate-500 text-sm">Visual presentation of system growth, matching indexes, and community activity.</p>
            </div>

            {/* Core Charts Mockup using Pure Tailwind divs for total safety */}
            <div className="grid md:grid-cols-2 gap-8">
              
              {/* Box A */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-slate-900 text-sm mb-4">Monthly Community Growth (Members)</h3>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                      <span>May 2026</span>
                      <span className="font-bold">1,200 Members</span>
                    </div>
                    <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden">
                      <div className="bg-emerald-500 h-4 rounded-full" style={{ width: '45%' }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                      <span>June 2026</span>
                      <span className="font-bold">1,850 Members</span>
                    </div>
                    <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden">
                      <div className="bg-emerald-500 h-4 rounded-full" style={{ width: '70%' }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                      <span>July 2026 (Active)</span>
                      <span className="font-bold">2,400 Members</span>
                    </div>
                    <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden">
                      <div className="bg-emerald-600 h-4 rounded-full" style={{ width: '92%' }} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Box B */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-slate-900 text-sm mb-4">Aid Campaign Match Ratios</h3>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                      <span>Cardiac Surgical Support</span>
                      <span className="font-bold">100% Fully Matched</span>
                    </div>
                    <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden">
                      <div className="bg-indigo-600 h-4 rounded-full" style={{ width: '100%' }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                      <span>Tuition Fee Support</span>
                      <span className="font-bold">80% Partially Matched</span>
                    </div>
                    <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden">
                      <div className="bg-indigo-500 h-4 rounded-full" style={{ width: '80%' }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                      <span>Bakery Fire Relief</span>
                      <span className="font-bold">0% Pending Verification</span>
                    </div>
                    <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden">
                      <div className="bg-slate-300 h-4 rounded-full" style={{ width: '0%' }} />
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* SUBTAB 8: WEBSITE SETTINGS */}
        {activeAdminTab === 'settings' && (
          <div>
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-slate-900">Website Settings</h1>
              <p className="text-slate-500 text-sm">Fine-tune system limits, toggle registration, or modify default deposit addresses.</p>
            </div>

            <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-sm max-w-xl">
              <form onSubmit={handleSaveSettings} className="space-y-4">
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Min Pledge Contribution (₹)</label>
                    <input 
                      id="setting-input-mincontrib"
                      type="number"
                      value={minContrib}
                      onChange={(e) => setMinContrib(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Max Pledge Contribution (₹)</label>
                    <input 
                      id="setting-input-maxcontrib"
                      type="number"
                      value={maxContrib}
                      onChange={(e) => setMaxContrib(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Min Withdrawal (₹)</label>
                    <input 
                      id="setting-input-minwith"
                      type="number"
                      value={minWith}
                      onChange={(e) => setMinWith(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Direct Commission Rate (%)</label>
                    <input 
                      id="setting-input-refcomm"
                      type="number"
                      value={refComm}
                      onChange={(e) => setRefComm(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                    />
                  </div>
                </div>

                {/* 10-Level Commission Structure Settings */}
                <div className="border-t border-slate-100 pt-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">10-Level Plan Commission Structure (₹)</h3>
                    <span className="text-[10px] text-amber-600 font-bold bg-amber-50 px-2 py-0.5 rounded">Admin Editable</span>
                  </div>
                  <p className="text-[11px] text-slate-500">Configure fixed rupee income distributed to 10 upline levels upon initial ₹100 activation:</p>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                    {levelAmounts.map((amt, idx) => (
                      <div key={idx} className="bg-slate-50 p-2 rounded-lg border border-slate-200">
                        <label className="block text-[9px] font-black text-slate-500 uppercase">L{idx + 1} Amount (₹)</label>
                        <input
                          type="number"
                          step="0.1"
                          value={amt}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            const next = [...levelAmounts];
                            next[idx] = val;
                            setLevelAmounts(next);
                          }}
                          className="w-full mt-1 px-2 py-1 bg-white border border-slate-200 rounded text-xs font-bold text-slate-800 focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Activation PIN Price (₹)</label>
                      <input 
                        type="number"
                        value={activationPinPrice}
                        onChange={(e) => setActivationPinPrice(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">First Giver PH Amount (₹)</label>
                      <input 
                        type="number"
                        value={giverPaymentAmount}
                        onChange={(e) => setGiverPaymentAmount(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">System UPI ID (e.g. help100@upi)</label>
                  <input 
                    id="setting-input-syswallet"
                    type="text"
                    value={sysWallet}
                    onChange={(e) => setSysWallet(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                  />
                </div>

                {/* Admin Profile Details */}
                <div className="border-t border-slate-100 pt-4 space-y-4">
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">Admin Profile / Link Payment Details</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Admin Account Holder Name</label>
                      <input 
                        id="setting-input-admin-holder"
                        type="text"
                        value={adminHolderName}
                        onChange={(e) => setAdminHolderName(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                        placeholder="e.g. Platform Admin"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Admin Bank Name</label>
                      <input 
                        id="setting-input-admin-bank"
                        type="text"
                        value={adminBankName}
                        onChange={(e) => setAdminBankName(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                        placeholder="e.g. SBI"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Admin Account Number</label>
                      <input 
                        id="setting-input-admin-acc"
                        type="text"
                        value={adminAccountNumber}
                        onChange={(e) => setAdminAccountNumber(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                        placeholder="e.g. 1234567890"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Admin IFSC Code</label>
                      <input 
                        id="setting-input-admin-ifsc"
                        type="text"
                        value={adminIfscCode}
                        onChange={(e) => setAdminIfscCode(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono uppercase"
                        placeholder="e.g. SBIN0001234"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Admin UPI QR Code (URL or Upload custom QR)</label>
                    <div className="flex gap-2">
                      <input 
                        id="setting-input-system-qr"
                        type="text"
                        placeholder="Leave empty to auto-generate from UPI ID"
                        value={systemQRUrl}
                        onChange={(e) => setSystemQRUrl(e.target.value)}
                        className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                      />
                      <label className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1">
                        <svg className="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                        Upload QR
                        <input 
                          type="file" 
                          accept="image/*" 
                          onChange={(e) => {
                            if (e.target.files && e.target.files[0]) {
                              const reader = new FileReader();
                              reader.onload = (event) => {
                                if (event.target?.result) {
                                  setSystemQRUrl(event.target.result as string);
                                }
                              };
                              reader.readAsDataURL(e.target.files[0]);
                            }
                          }}
                          className="hidden" 
                        />
                      </label>
                    </div>
                    
                    {/* Visual QR code preview */}
                    <div className="mt-2.5 p-3 bg-slate-50 border border-slate-200/60 rounded-xl flex items-center gap-4">
                      <div className="shrink-0 bg-white p-1 rounded-lg border border-slate-200">
                        <img 
                          src={systemQRUrl || `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent('upi://pay?pa=' + sysWallet + '&pn=' + encodeURIComponent(adminHolderName) + '&am=20')}`} 
                          alt="Admin QR Preview" 
                          className="w-16 h-16"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="text-slate-500 text-[10px]">
                        <p className="font-bold text-slate-700 uppercase">Live QR Preview</p>
                        <p className="mt-0.5">
                          {systemQRUrl ? 'Using custom uploaded QR image.' : 'Automatically generated from System UPI ID.'}
                        </p>
                        {systemQRUrl && (
                          <button 
                            type="button" 
                            onClick={() => setSystemQRUrl('')} 
                            className="text-rose-600 hover:underline mt-1 font-semibold block cursor-pointer"
                          >
                            Reset to Auto-generated
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Homepage Visual Branding */}
                <div className="border-t border-slate-100 pt-4 space-y-4">
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">Homepage Visual Branding</h3>
                  
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Homepage Logo Image (URL or Upload)</label>
                    <div className="flex gap-2">
                      <input 
                        id="setting-input-logo-url"
                        type="text"
                        placeholder="e.g. https://example.com/logo.png"
                        value={homeLogoUrl}
                        onChange={(e) => setHomeLogoUrl(e.target.value)}
                        className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                      />
                      <label className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1">
                        <svg className="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                        Upload
                        <input 
                          type="file" 
                          accept="image/*" 
                          onChange={(e) => {
                            if (e.target.files && e.target.files[0]) {
                              const reader = new FileReader();
                              reader.onload = (event) => {
                                if (event.target?.result) {
                                  setHomeLogoUrl(event.target.result as string);
                                }
                              };
                              reader.readAsDataURL(e.target.files[0]);
                            }
                          }}
                          className="hidden" 
                        />
                      </label>
                    </div>
                    {homeLogoUrl && (
                      <div className="mt-2 p-2 bg-slate-50 border border-slate-100 rounded-lg flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <img src={homeLogoUrl} alt="Logo Preview" className="h-8 max-w-[100px] object-contain rounded bg-white p-1 border border-slate-200" referrerPolicy="no-referrer" />
                          <span className="text-[10px] text-slate-500 truncate max-w-[150px]">Custom logo active</span>
                        </div>
                        <button 
                          type="button" 
                          onClick={() => setHomeLogoUrl('')} 
                          className="text-[10px] text-rose-600 hover:underline cursor-pointer"
                        >
                          Reset
                        </button>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Homepage Hero Background Image (URL or Upload)</label>
                    <div className="flex gap-2">
                      <input 
                        id="setting-input-bg-url"
                        type="text"
                        placeholder="e.g. https://example.com/banner.jpg"
                        value={homeBgImageUrl}
                        onChange={(e) => setHomeBgImageUrl(e.target.value)}
                        className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                      />
                      <label className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1">
                        <svg className="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                        Upload
                        <input 
                          type="file" 
                          accept="image/*" 
                          onChange={(e) => {
                            if (e.target.files && e.target.files[0]) {
                              const reader = new FileReader();
                              reader.onload = (event) => {
                                if (event.target?.result) {
                                  setHomeBgImageUrl(event.target.result as string);
                                }
                              };
                              reader.readAsDataURL(e.target.files[0]);
                            }
                          }}
                          className="hidden" 
                        />
                      </label>
                    </div>
                    {homeBgImageUrl && (
                      <div className="mt-2 p-2 bg-slate-50 border border-slate-100 rounded-lg flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <img src={homeBgImageUrl} alt="Background Preview" className="h-8 w-12 object-cover rounded border border-slate-200" referrerPolicy="no-referrer" />
                          <span className="text-[10px] text-slate-500 truncate max-w-[150px]">Custom background active</span>
                        </div>
                        <button 
                          type="button" 
                          onClick={() => setHomeBgImageUrl('https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&q=80&w=1200')} 
                          className="text-[10px] text-rose-600 hover:underline cursor-pointer"
                        >
                          Reset Default
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* WhatsApp Support & Auto Reply Configuration */}
                <div className="border-t border-slate-100 pt-4 space-y-4">
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">WhatsApp Support & Auto-Reply</h3>
                  
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">WhatsApp Support Number</label>
                    <input 
                      id="setting-input-whatsapp-number"
                      type="text"
                      value={whatsappSupportNumber}
                      onChange={(e) => setWhatsappSupportNumber(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                      placeholder="e.g. +919876543210"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <div>
                      <h4 className="font-bold text-slate-800 text-xs">WhatsApp Auto-Reply System</h4>
                      <p className="text-[11px] text-slate-400">Trigger simulated WhatsApp reply on new support tickets.</p>
                    </div>
                    <input 
                      id="setting-toggle-whatsapp-reply"
                      type="checkbox"
                      checked={whatsappAutoReplyEnabled}
                      onChange={(e) => setWhatsappAutoReplyEnabled(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 border-slate-300 focus:ring-emerald-500 rounded"
                    />
                  </div>

                  {whatsappAutoReplyEnabled && (
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">WhatsApp Auto-Reply Message Template</label>
                      <textarea 
                        id="setting-input-whatsapp-msg"
                        value={whatsappAutoReplyMessage}
                        onChange={(e) => setWhatsappAutoReplyMessage(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs h-20 resize-none font-medium text-slate-700 leading-normal"
                        placeholder="Customize auto-reply template here..."
                      />
                      <p className="text-[9px] text-slate-400 mt-1">
                        Use placeholders: <strong className="font-mono text-slate-600">{`{name}`}</strong>, <strong className="font-mono text-slate-600">{`{subject}`}</strong>, <strong className="font-mono text-slate-600">{`{ticket_id}`}</strong>.
                      </p>
                    </div>
                  )}
                </div>

                {/* Website Button Configuration */}
                <div className="border-t border-slate-100 pt-4 space-y-4">
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">Landing Page Website Link</h3>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-slate-800 text-xs">Enable Home Page Website Button</h4>
                      <p className="text-[11px] text-slate-400">Display a quick button on the navigation bar and hero page.</p>
                    </div>
                    <input 
                      id="setting-toggle-website-btn"
                      type="checkbox"
                      checked={websiteButtonEnabled}
                      onChange={(e) => setWebsiteButtonEnabled(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 border-slate-300 focus:ring-emerald-500 rounded"
                    />
                  </div>

                  {websiteButtonEnabled && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Button Text</label>
                        <input 
                          id="setting-input-website-text"
                          type="text"
                          value={websiteButtonText}
                          onChange={(e) => setWebsiteButtonText(e.target.value)}
                          className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                          placeholder="e.g. Visit Official Website"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Button Website URL</label>
                        <input 
                          id="setting-input-website-url"
                          type="text"
                          value={websiteButtonUrl}
                          onChange={(e) => setWebsiteButtonUrl(e.target.value)}
                          className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                          placeholder="e.g. https://help100.org"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Promotional Offers & Banners Management */}
                <div className="border-t border-slate-100 pt-4 space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Promotions & Special Offers</h3>
                      <p className="text-[11px] text-slate-400">Configure special offer banners that appear on Member Dashboards and Home page.</p>
                    </div>
                    <span className="text-[10px] bg-amber-50 text-amber-700 font-extrabold px-2 py-0.5 rounded border border-amber-200">
                      {offers.filter(o => o.isActive).length} Active Offers
                    </span>
                  </div>

                  {/* Offers List */}
                  <div className="space-y-2">
                    {offers.length === 0 ? (
                      <p className="text-xs text-slate-400 italic py-2">No promotional offers created yet.</p>
                    ) : (
                      offers.map((off, oIdx) => (
                        <div key={off.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="px-2 py-0.5 bg-amber-500 text-slate-950 text-[9px] font-black uppercase rounded">
                                {off.badge || 'PROMO'}
                              </span>
                              <h4 className="font-bold text-xs text-slate-900">{off.title}</h4>
                            </div>
                            <p className="text-[11px] text-slate-600">{off.description}</p>
                          </div>
                          <div className="flex items-center gap-2 self-end sm:self-center">
                            <button
                              type="button"
                              onClick={() => {
                                const next = [...offers];
                                next[oIdx].isActive = !next[oIdx].isActive;
                                setOffers(next);
                              }}
                              className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase transition-colors cursor-pointer ${
                                off.isActive ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-slate-200 text-slate-600'
                              }`}
                            >
                              {off.isActive ? 'Active' : 'Disabled'}
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (window.confirm('Delete this special offer?')) {
                                  setOffers(offers.filter(o => o.id !== off.id));
                                }
                              }}
                              className="text-rose-600 hover:text-rose-800 p-1 cursor-pointer"
                              title="Delete Offer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Add Offer Form */}
                  <div className="p-3 bg-indigo-50/60 border border-indigo-100 rounded-xl space-y-3">
                    <h4 className="font-bold text-xs text-indigo-950 uppercase tracking-wider">+ Add New Promotional Offer</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[10px] font-bold text-indigo-800 uppercase">Offer Title</label>
                        <input
                          type="text"
                          placeholder="e.g. 🎉 Double Commission Week!"
                          value={newOfferTitle}
                          onChange={(e) => setNewOfferTitle(e.target.value)}
                          className="w-full mt-1 px-2.5 py-1.5 bg-white border border-indigo-200 rounded text-xs focus:outline-none focus:border-indigo-500 font-semibold text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-indigo-800 uppercase">Badge Text</label>
                        <input
                          type="text"
                          placeholder="e.g. BUMPER OFFER"
                          value={newOfferBadge}
                          onChange={(e) => setNewOfferBadge(e.target.value)}
                          className="w-full mt-1 px-2.5 py-1.5 bg-white border border-indigo-200 rounded text-xs focus:outline-none focus:border-indigo-500 font-semibold text-slate-800"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-indigo-800 uppercase">Description</label>
                      <input
                        type="text"
                        placeholder="e.g. Get instant 100% priority matching and bonus ₹10 on every direct activation!"
                        value={newOfferDesc}
                        onChange={(e) => setNewOfferDesc(e.target.value)}
                        className="w-full mt-1 px-2.5 py-1.5 bg-white border border-indigo-200 rounded text-xs focus:outline-none focus:border-indigo-500 font-medium text-slate-800"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        if (!newOfferTitle.trim()) {
                          alert('Please enter an offer title.');
                          return;
                        }
                        const newOff: SpecialOffer = {
                          id: 'offer-' + Math.random().toString(36).substring(2, 9),
                          title: newOfferTitle.trim(),
                          badge: newOfferBadge.trim() || 'SPECIAL OFFER',
                          description: newOfferDesc.trim() || 'Special promotional offer active on platform!',
                          isActive: true,
                          createdAt: new Date().toISOString()
                        };
                        setOffers(prev => [newOff, ...prev]);
                        setNewOfferTitle('');
                        setNewOfferDesc('');
                        setNewOfferBadge('SPECIAL OFFER');
                        alert('New offer added! Click "Save Settings" below to publish.');
                      }}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg uppercase tracking-wider transition-colors cursor-pointer"
                    >
                      Publish Offer
                    </button>
                  </div>
                </div>

                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-slate-800 text-xs">Allow New Registrations</h4>
                      <p className="text-[11px] text-slate-400">Toggle whether new visitor sign-ups are allowed.</p>
                    </div>
                    <input 
                      id="setting-toggle-reg"
                      type="checkbox"
                      checked={isRegOpen}
                      onChange={(e) => setIsRegOpen(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 border-slate-300 focus:ring-emerald-500 rounded"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div>
                      <h4 className="font-bold text-slate-800 text-xs">Maintenance Mode</h4>
                      <p className="text-[11px] text-slate-400">Put the entire visitor side under maintenance display.</p>
                    </div>
                    <input 
                      id="setting-toggle-maint"
                      type="checkbox"
                      checked={maintenance}
                      onChange={(e) => setMaintenance(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 border-slate-300 focus:ring-emerald-500 rounded"
                    />
                  </div>
                </div>

                <button 
                  id="setting-save-btn"
                  type="submit"
                  className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Save settings
                </button>
              </form>
            </div>
          </div>
        )}

        {/* SUBTAB 9: SECURITY & AUDIT LOGS */}
        {activeAdminTab === 'security' && (
          <div>
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-slate-900">Security Control</h1>
              <p className="text-slate-500 text-sm">Review real-time simulation audit logs and security parameters.</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm max-w-2xl">
              <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider mb-3">Live Security Intrusion Prevention logs</h3>
              
              <div className="bg-slate-900 text-emerald-400 p-4 rounded-xl font-mono text-[11px] space-y-1.5 h-64 overflow-y-auto">
                <p>[2026-07-07 18:56:00] [SYSTEM] SSL handshake verified securely on endpoint.</p>
                <p>[2026-07-07 19:12:05] [AUDIT] Approved transaction 'tx-1' for John Doe.</p>
                <p>[2026-07-07 20:01:40] [SECURITY] Cross-Origin request validation parsed correctly.</p>
                <p>[2026-07-07 21:30:11] [SYSTEM] Backup routine completed cleanly with 0 exceptions.</p>
                <p className="text-amber-400">[2026-07-08 10:12:00] [AUDIT] Manual balance overwrite request completed on 'user-sarah'.</p>
                <p>[2026-07-08 10:15:30] [SYSTEM] Real-time websocket channels active. Ping: 24ms.</p>
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 10: BACKUP */}
        {activeAdminTab === 'backup' && (
          <div>
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-slate-900">Platform Data Backup</h1>
              <p className="text-slate-500 text-sm">Download or export the complete application state in a single JSON block.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              
              {/* Simulator Action */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-slate-900 mb-3">Generate System Backup</h3>
                <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                  Click the button below to simulate compiling all user databases, transaction ledgers, support tickets, and system settings into a cryptographically sealed package.
                </p>

                <button 
                  id="backup-trigger-btn"
                  onClick={handleTriggerBackup} 
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Trigger Live System Backup
                </button>

                {backupLog.length > 0 && (
                  <div className="mt-4 p-3 bg-slate-950 text-emerald-400 font-mono text-[10px] rounded-lg space-y-1">
                    {backupLog.map((log, i) => (
                      <p key={i}>{log}</p>
                    ))}
                  </div>
                )}
              </div>

              {/* Data Export Box */}
              {exportDataText && (
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                  <h3 className="font-bold text-slate-900 text-xs uppercase mb-2">Export Data Bundle</h3>
                  <textarea 
                    id="backup-export-textarea"
                    readOnly 
                    rows={10} 
                    value={exportDataText} 
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono text-[10px] text-slate-600 focus:outline-none"
                  />
                </div>
              )}

            </div>

            {/* Firebase Cloud Firestore Synchronization Panel */}
            <div className="mt-8 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-slate-100">
                <div>
                  <h3 className="font-bold text-slate-900 flex items-center gap-2">
                    <span className="text-lg">🔥</span> Firebase Cloud Firestore Integration
                  </h3>
                  <p className="text-slate-500 text-xs mt-1">
                    Manage real-time cloud data synchronization, remote schema hosting, and system backups.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {isCloudConnectionFailed ? (
                    <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 text-rose-700 text-xs font-black uppercase tracking-wider border border-rose-100 animate-pulse">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                      ⚠️ OFFLINE / CONNECTION ISSUES
                    </span>
                  ) : firebaseEnabled ? (
                    <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-black uppercase tracking-wider border border-emerald-100">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                      🟢 CONNECTED TO CLOUD FIRESTORE
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-600 text-xs font-black uppercase tracking-wider border border-slate-200">
                      <span className="w-2.5 h-2.5 rounded-full bg-slate-400" />
                      🔴 OFFLINE / LOCAL STORAGE FALLBACK
                    </span>
                  )}
                </div>
              </div>

              {isFirebaseConfigured ? (
                <div className="space-y-4">
                  {isCloudConnectionFailed && (
                    <div className="bg-amber-50 border border-amber-200 text-amber-900 rounded-xl p-4 text-xs leading-relaxed flex items-start gap-3">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5 animate-pulse" />
                      <div>
                        <p className="font-black uppercase tracking-wider">Cloud Sync Suspended (Offline / Connection Failed)</p>
                        <p className="mt-1 text-amber-800">
                          Automatic background cloud synchronization has been temporarily suspended to avoid application lag and console warnings because the Firestore client is currently offline or unreachable. 
                          The app is safely running on <strong>LocalStorage fallback</strong>. You can click <strong>Push</strong> or <strong>Pull</strong> below to test and attempt to re-establish the connection manually.
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="grid sm:grid-cols-3 gap-4">
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-3">
                      <div className="flex items-center gap-2 text-indigo-700">
                        <HardDrive className="w-4 h-4" />
                        <h4 className="text-xs font-black uppercase tracking-wider">Push Local to Cloud Database</h4>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        Uploads all members, transactions, active matching queues, and settings currently stored in this browser's LocalStorage directly to your Firebase Firestore collections.
                      </p>
                      <button
                        id="firebase-push-btn"
                        onClick={onForceSyncPush}
                        className="w-full px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-sm flex items-center justify-center gap-2"
                      >
                        🚀 Push Local State to Firestore
                      </button>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-3">
                      <div className="flex items-center gap-2 text-emerald-700">
                        <Activity className="w-4 h-4 animate-pulse" />
                        <h4 className="text-xs font-black uppercase tracking-wider">Pull Cloud Database to Local</h4>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        Fetches all documents from Firebase Cloud Firestore collections and overwrites your current LocalStorage state. Perfect for synchronizing across multiple sessions or devices.
                      </p>
                      <button
                        id="firebase-pull-btn"
                        onClick={onForceSyncPull}
                        className="w-full px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-sm flex items-center justify-center gap-2"
                      >
                        📥 Pull Cloud State to Browser
                      </button>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-3">
                      <div className="flex items-center gap-2 text-amber-700">
                        <ShieldCheck className="w-4 h-4" />
                        <h4 className="text-xs font-black uppercase tracking-wider">Reset & Fix Connection</h4>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        Clears offline connection flags and resets Firestore real-time cloud sync status to re-establish connection immediately.
                      </p>
                      <button
                        id="firebase-reset-btn"
                        onClick={() => {
                          resetCloudConnection();
                          alert('✅ Firebase Cloud Connection status reset! Re-attempting sync...');
                          if (onForceSyncPull) {
                            onForceSyncPull();
                          }
                        }}
                        className="w-full px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-sm flex items-center justify-center gap-2"
                      >
                        🔄 Fix / Reset Firebase Connection
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-100 flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div className="space-y-1.5">
                    <p className="text-xs font-black text-amber-900 uppercase">Custom Firebase Setup Required</p>
                    <p className="text-xs text-amber-800 leading-relaxed">
                      The application is currently operating in offline-first mode using the browser's LocalStorage. To connect your real-time Cloud Firestore database, provide your Firebase project credentials inside the <strong>Secrets panel</strong> or edit your <strong>.env</strong> file with the following variables:
                    </p>
                    <div className="bg-slate-900 p-3 rounded-lg font-mono text-[10px] text-indigo-300 border border-slate-800 space-y-1 overflow-x-auto select-all">
                      <p>VITE_FIREBASE_API_KEY=your_api_key</p>
                      <p>VITE_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com</p>
                      <p>VITE_FIREBASE_PROJECT_ID=your_project_id</p>
                      <p>VITE_FIREBASE_STORAGE_BUCKET=your_project.appspot.com</p>
                      <p>VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id</p>
                      <p>VITE_FIREBASE_APP_ID=your_app_id</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Redundant Emergency System Reset and Cycle Restart console */}
            <div className="mt-8 bg-rose-50 border border-rose-200 rounded-2xl p-5 sm:p-6 space-y-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5 animate-pulse" />
                <div>
                  <h3 className="font-black text-rose-950 text-sm uppercase tracking-wider">
                    Administrative Reset & Cycle Re-activation Engine
                  </h3>
                  <p className="text-xs text-rose-700 leading-relaxed font-medium mt-1">
                    Warning: Clicking below instantly wipes all community wallet balances (walletBalance, provideWallet, getWallet, directWallet, levelWallet, totalContributed, totalReceived) back to <strong className="font-bold">00000</strong> for all active accounts, clears active queues, and restarts everyone's help cycle state back to Step 1 (buy_pin) from scratch.
                  </p>
                </div>
              </div>
              <div className="flex justify-end border-t border-rose-100 pt-4">
                <button
                  type="button"
                  id="backup-emergency-reset-btn"
                  onClick={() => {
                    if (confirm("🚨 WARNING: This will set all community user balances to 00000 and restart everyone's help cycles from the beginning! This action is irreversible. Do you wish to proceed?")) {
                      if (onGlobalSystemReset) {
                        onGlobalSystemReset();
                        alert("🎉 Done! All member funds have been set to 00000 and all cycles started from the beginning.");
                      } else {
                        alert("Reset callback is not defined in App.");
                      }
                    }
                  }}
                  className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer shadow-sm transition-all"
                >
                  Confirm Full System Wiping
                </button>
              </div>
            </div>

          </div>
        )}



        {/* SUBTAB EMAIL LOGS */}
        {activeAdminTab === 'email_logs' && (
          <div className="space-y-6">
            <div className="bg-slate-900 text-slate-100 p-8 rounded-3xl relative overflow-hidden shadow-xl border border-slate-800">
              <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
              <div className="relative flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-500/20 text-emerald-300 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-500/30">
                    <Mail className="w-3.5 h-3.5" /> Platform Outbox Audit Ledger
                  </div>
                  <h2 className="text-2xl md:text-3xl font-extrabold font-sans tracking-tight text-white">
                    Simulated SMTP Mail Dispatch History
                  </h2>
                  <p className="text-xs text-slate-400 max-w-2xl font-medium leading-relaxed">
                    Review and audit secure credentials emails dispatched during user registration or forgot-passcode recovery requests. Ensure transparency and verify system communications.
                  </p>
                </div>
              </div>
            </div>

            {/* Stats grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Total Mail Logs</span>
                <span className="text-2xl font-extrabold text-slate-800">{emailLogs.length}</span>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Welcome Emails</span>
                <span className="text-2xl font-extrabold text-slate-800">
                  {emailLogs.filter(e => e.type === 'welcome').length}
                </span>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Passcode Recovery</span>
                <span className="text-2xl font-extrabold text-slate-800">
                  {emailLogs.filter(e => e.type === 'forgot_password').length}
                </span>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">SMTP Delivery Status</span>
                <span className="text-xs font-black text-emerald-600 bg-emerald-50 self-start px-2 py-1 rounded-lg">100.00% DELIVERED</span>
              </div>
            </div>

            {/* DataTable */}
            <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xl shadow-slate-100 overflow-hidden">
              <div className="p-5 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
                <h3 className="font-extrabold text-slate-800 text-sm">SMTP Dispatch Queue Ledger</h3>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">REAL-TIME DATA SECURED</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-100/75 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                      <th className="p-4">Log ID</th>
                      <th className="p-4">Recipient</th>
                      <th className="p-4">Email Address</th>
                      <th className="p-4">Subject Line</th>
                      <th className="p-4">Type</th>
                      <th className="p-4">Timestamp</th>
                      <th className="p-4">Status</th>
                      <th className="p-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                    {emailLogs.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-slate-400 font-bold">
                          No simulated emails have been dispatched yet. Register users or use the "Forgot Password" link on the home screen to generate logs.
                        </td>
                      </tr>
                    ) : (
                      emailLogs.map((log) => (
                        <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                          <td className="p-4 font-mono text-[10px] text-slate-500">{log.id}</td>
                          <td className="p-4 font-bold text-slate-900">{log.recipientName}</td>
                          <td className="p-4 text-slate-600 font-semibold">{log.recipientEmail}</td>
                          <td className="p-4 text-slate-800 font-semibold">{log.subject}</td>
                          <td className="p-4">
                            <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                              log.type === 'welcome' 
                                ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' 
                                : 'bg-amber-50 text-amber-700 border border-amber-200'
                            }`}>
                              {log.type === 'welcome' ? 'WELCOME' : 'RECOVERY'}
                            </span>
                          </td>
                          <td className="p-4 text-slate-500">{new Date(log.sentAt).toLocaleString()}</td>
                          <td className="p-4">
                            <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200 inline-flex items-center gap-1">
                              ● DELIVERED
                            </span>
                          </td>
                          <td className="p-4">
                            <button
                              onClick={() => {
                                alert(`📧 SIMULATED MAIL PREVIEW:\n\nSubject: ${log.subject}\nTo: ${log.recipientName} <${log.recipientEmail}>\n\n---\n\n${log.body}`);
                              }}
                              className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-[10px] font-black uppercase tracking-wider cursor-pointer"
                            >
                              View Content
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}



        {/* SUBTAB 11: PIN KEYS ADMINISTRATION */}
        {activeAdminTab === 'pins_admin' && (
          <div className="space-y-8 animate-fade-in">
            {/* Header */}
            <div>
              <h1 className="text-2xl font-bold text-slate-900 font-sans tracking-tight">PIN Keys Administration</h1>
              <p className="text-slate-500 text-sm">Generate help authorization PIN keys of any custom face value and manage owner transfers.</p>
            </div>

            {/* ADVANCED PIN KEY GENERATOR & DISPATCH CENTER */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
              <div className="border-b border-slate-100 pb-4">
                <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                  <Key className="w-5 h-5 text-amber-500" />
                  PIN Administration & Key Generation Console
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Generate Help Authorization PINs of any custom value (₹10 / ₹100 or more) and batch quantity. Send them directly to specific users, keep them in unassigned stock, or transfer existing unassigned PINs to members.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                {/* Advanced PIN Generator */}
                <div className="space-y-4">
                  <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-100/80">
                    <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider text-amber-800 mb-2">Option A: Advanced PIN Generator</h4>
                    
                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">PIN Face Value Amount (₹ INR)</label>
                        <select
                          value={pinGenAmount}
                          onChange={(e) => setPinGenAmount(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none"
                        >
                          <option value="10">₹10 PIN (Standard Help100 Activation)</option>
                          <option value="100">₹100 PIN (Direct/Level Authorization)</option>
                          <option value="500">₹500 PIN (Premium Authorization)</option>
                          <option value="1000">₹1,000 PIN (VIP Club Authorization)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Target Recipient / Owner</label>
                        <select
                          value={pinGenUser}
                          onChange={(e) => setPinGenUser(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none"
                        >
                          <option value="system">-- Keep in Unassigned System Stock --</option>
                          {users.filter(u => u.role !== 'admin').map(user => (
                            <option key={user.id} value={user.id}>
                              {user.name} (Phone: {user.phone || 'N/A'})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Quantity to Generate</label>
                        <input
                          type="number"
                          min="1"
                          max="50"
                          value={pinGenQty}
                          onChange={(e) => setPinGenQty(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none"
                        />
                      </div>

                      <button
                        onClick={() => {
                          const amt = parseFloat(pinGenAmount);
                          const qty = parseInt(pinGenQty);
                          if (isNaN(amt) || amt <= 0) {
                            alert('Please select a valid amount.');
                            return;
                          }
                          if (isNaN(qty) || qty <= 0) {
                            alert('Please enter a valid quantity.');
                            return;
                          }

                          // Generate loop
                          for (let i = 0; i < qty; i++) {
                            onSendPin(pinGenUser, amt);
                          }

                          const targetLabel = pinGenUser === 'system' ? 'Unassigned System Stock' : (users.find(u => u.id === pinGenUser)?.name || 'User');
                          alert(`Successfully generated and dispatched ${qty} PIN keys (Value: ₹${amt} each) to: ${targetLabel}`);
                          setPinGenQty('1');
                        }}
                        className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black uppercase rounded-lg text-[10px] tracking-wider transition-colors cursor-pointer text-center"
                      >
                        Generate & Dispatch Keys
                      </button>
                    </div>
                  </div>
                </div>

                {/* PIN Transfer Option */}
                <div className="space-y-4">
                  <div className="bg-indigo-50/50 p-4 rounded-xl border border-indigo-100/80">
                    <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider text-indigo-800 mb-2">Option B: Send / Transfer Unassigned PINs</h4>
                    
                    {issuedPins.filter(p => (p.userId === 'system' || p.userId === 'unassigned') && !p.isUsed).length === 0 ? (
                      <div className="py-8 text-center">
                        <p className="text-xs text-slate-400">No active unassigned PINs currently in stock.</p>
                        <p className="text-[10px] text-slate-400 mt-1">Generate unassigned keys using the left-side panel first.</p>
                      </div>
                    ) : (
                      <div className="space-y-3 text-xs">
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">Select Unassigned PIN from Stock</label>
                          <select
                            value={pinTransferPinId}
                            onChange={(e) => setPinTransferPinId(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none"
                          >
                            <option value="">-- Select an active PIN key --</option>
                            {issuedPins
                              .filter(p => (p.userId === 'system' || p.userId === 'unassigned') && !p.isUsed)
                              .map(pin => (
                                <option key={pin.id} value={pin.id}>
                                  {pin.pinCode} (Value: ₹{pin.amount})
                                </option>
                              ))}
                          </select>
                        </div>

                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">Select Target Recipient</label>
                          <select
                            value={pinTransferUserId}
                            onChange={(e) => setPinTransferUserId(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none"
                          >
                            <option value="">-- Select User --</option>
                            {users.filter(u => u.role !== 'admin').map(user => (
                              <option key={user.id} value={user.id}>
                                {user.name} (Phone: {user.phone || 'N/A'})
                              </option>
                            ))}
                          </select>
                        </div>

                        <button
                          onClick={() => {
                            if (!pinTransferPinId) {
                              alert('Please select a PIN to transfer.');
                              return;
                            }
                            if (!pinTransferUserId) {
                              alert('Please select a target user.');
                              return;
                            }

                            if (onAssignPin) {
                              onAssignPin(pinTransferPinId, pinTransferUserId);
                              const targetUser = users.find(u => u.id === pinTransferUserId);
                              const selectedPinCode = issuedPins.find(p => p.id === pinTransferPinId)?.pinCode;
                              alert(`Successfully transferred PIN ${selectedPinCode} to ${targetUser?.name || 'user'}!`);
                              setPinTransferPinId('');
                              setPinTransferUserId('');
                            } else {
                              alert('Assignment action not configured in application core.');
                            }
                          }}
                          className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-black uppercase rounded-lg text-[10px] tracking-wider transition-colors cursor-pointer text-center"
                        >
                          Transfer Key Owner
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Layout Split: Users & PINs */}
            <div className="grid lg:grid-cols-12 gap-8">
              
              {/* Left Side: Users PIN Dispatch Panel */}
              <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <div>
                  <h3 className="font-bold text-slate-900 text-lg">Send ₹10 Help PIN Keys</h3>
                  <p className="text-xs text-slate-500 mt-0.5">Generate and send authorization keys of ₹10 directly to specific users.</p>
                </div>

                <div className="space-y-2 max-h-[350px] overflow-y-auto border border-slate-100 rounded-xl p-2 bg-slate-50">
                  {users.filter(u => u.role !== 'admin').map(user => {
                    const userPins = issuedPins.filter(p => p.userId === user.id);
                    const unusedCount = userPins.filter(p => !p.isUsed).length;
                    return (
                      <div key={user.id} className="flex justify-between items-center bg-white p-3 rounded-xl border border-slate-100 shadow-xs hover:border-slate-200 transition-colors">
                        <div>
                          <h4 className="font-bold text-slate-800 text-xs">{user.name}</h4>
                          <p className="text-[10px] text-slate-400">{user.email} | Phone: {user.phone}</p>
                          <div className="flex gap-2 mt-1">
                            <span className="text-[9px] px-1.5 py-0.2 bg-slate-100 text-slate-600 rounded font-bold font-mono">
                              Wallet: ₹{user.walletBalance}
                            </span>
                            <span className="text-[9px] px-1.5 py-0.2 bg-indigo-50 text-indigo-600 rounded font-bold font-mono">
                              Unused PINs: {unusedCount}
                            </span>
                          </div>
                        </div>

                        <button
                          onClick={() => {
                            onSendPin(user.id);
                            alert(`₹10 Help PIN generated and sent to ${user.name}!`);
                          }}
                          className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-lg text-[10px] uppercase tracking-wider cursor-pointer"
                        >
                          Send ₹10 PIN
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Right Side: Issued PINs Audit Log */}
              <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-slate-900 text-lg">Issued PIN Keys History</h3>
                    <p className="text-xs text-slate-500 mt-0.5">Audit log of all system-dispatched and consumed ₹10 PINs.</p>
                  </div>
                  {onDeleteUsedPins && issuedPins.some(p => p.isUsed) && (
                    <button
                      onClick={() => {
                        if (window.confirm('Are you sure you want to remove all consumed/used PINs from the admin list?')) {
                          onDeleteUsedPins();
                        }
                      }}
                      className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 text-[10px] font-bold rounded-lg border border-rose-200 transition-colors cursor-pointer"
                    >
                      Clear Used PINs
                    </button>
                  )}
                </div>

                <div className="space-y-2 max-h-[350px] overflow-y-auto border border-slate-100 rounded-xl p-2 bg-slate-50">
                  {issuedPins.length === 0 ? (
                    <p className="text-xs text-slate-400 text-center py-10 font-mono">No PINs generated yet.</p>
                  ) : (
                    issuedPins.map(pin => (
                      <div key={pin.id} className="bg-white p-2.5 rounded-xl border border-slate-100 flex justify-between items-center text-xs">
                        <div>
                          <span className="font-bold font-mono text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded text-[10px]">
                            {pin.pinCode}
                          </span>
                          <p className="text-[10px] text-slate-500 mt-1">Sent to: <strong className="text-slate-700">{pin.userName}</strong></p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                            pin.isUsed ? 'bg-rose-50 text-rose-600 border border-rose-100' : 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                          }`}>
                            {pin.isUsed ? 'Consumed' : 'Active'}
                          </span>
                          {onDeletePin && (
                            <button
                              title="Delete PIN Record"
                              onClick={() => {
                                if (window.confirm(`Delete PIN record ${pin.pinCode}?`)) {
                                  onDeletePin(pin.id);
                                }
                              }}
                              className="text-slate-400 hover:text-rose-600 p-1 transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* SUBTAB 12: PEER TO PEER MATCHING */}
        {activeAdminTab === 'p2p_matching' && (
          <div className="space-y-6 animate-fade-in text-xs">
            {/* Header banner */}
            <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 animate-fade-in">
              <div>
                <h2 className="text-base font-extrabold flex items-center gap-2">
                  <ArrowRightLeft className="w-4 h-4 text-amber-400" />
                  P2P Router & Dispatch Desk (ऑटोमेटिक P2P मैचिंग)
                </h2>
                <p className="text-slate-400 text-[10px]">Establish direct peer matches or trigger automatic system routing between active Givers and Takers.</p>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={handleRunAutoP2PMatching}
                  className="bg-gradient-to-r from-emerald-500 via-indigo-600 to-purple-600 hover:from-emerald-600 hover:to-purple-700 text-white font-extrabold px-4 py-2.5 rounded-xl shadow-lg flex items-center gap-2 cursor-pointer text-xs border border-white/20 transition-all active:scale-95"
                >
                  <span className="text-sm">⚡</span>
                  <span>Start Auto P2P Router (ऑटो P2P मैचिंग शुरू करें)</span>
                </button>
                <div className="flex gap-3 bg-black/40 px-3.5 py-2 rounded-xl border border-white/10 text-[10px]">
                  <div>Givers: <strong className="text-emerald-400">{unifiedGiversQueue.length}</strong></div>
                  <div>Takers: <strong className="text-amber-400">{helpRequests.filter(h => h.status === 'approved' && h.amountReceived < h.amountRequested).length + transactions.filter(t => t.type === 'withdrawal' && t.status === 'pending' && (t.amount - p2pMatches.filter(m => m.takerId === t.id && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0)) > 0).length}</strong></div>
                  <div>Matches: <strong className="text-indigo-400">{p2pMatches.length}</strong></div>
                </div>
              </div>
            </div>

            {/* 📢 LINK DISPATCH & PLATFORM HISTORY MASTER CONTROL PANEL */}
            <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 rounded-2xl border border-indigo-500/30 shadow-xl space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/10 pb-4">
                <div>
                  <h3 className="font-extrabold text-base text-amber-400 flex items-center gap-2">
                    <span>📢 Link Dispatch Control & History Management</span>
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Toggle visibility of payment link boxes across all user devices or clear platform history.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  {/* Link Dispatch Switch Button */}
                  <button
                    type="button"
                    onClick={() => {
                      const newStatus = !(systemSettings.dispatchLinksEnabled !== false);
                      onUpdateSettings({
                        ...systemSettings,
                        dispatchLinksEnabled: newStatus
                      });
                      alert(
                        newStatus
                          ? '⚡ लिंक डिस्पैच ON कर दिया गया है! अब सभी यूजर्स (Giver और Taker) के डिवाइस में पेमेंट लिंक बॉक्स दिखाई देंगे।'
                          : '⏸️ लिंक डिस्पैच OFF कर दिया गया है! (प्रमोशन मोड चालू)। यूजर्स को प्रमोशन मैसेज दिखेगा और लिंक बॉक्स होल्ड पर रहेंगे।'
                      );
                    }}
                    className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider shadow-md transition-all flex items-center gap-2 cursor-pointer active:scale-95 border ${
                      systemSettings.dispatchLinksEnabled !== false
                        ? 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 border-emerald-400'
                        : 'bg-amber-500 hover:bg-amber-600 text-slate-950 border-amber-400'
                    }`}
                  >
                    <span>{systemSettings.dispatchLinksEnabled !== false ? '🟢' : '⏸️'}</span>
                    <span>
                      {systemSettings.dispatchLinksEnabled !== false
                        ? 'Link Dispatch: ON (डिस्पैच चालू)'
                        : 'Link Dispatch: OFF (प्रमोशन मोड - OFF)'}
                    </span>
                  </button>

                  {/* Delete All History Button */}
                  {onGlobalSystemReset && (
                    <button
                      type="button"
                      onClick={() => {
                        if (
                          window.confirm(
                            '🚨 WARNING: क्या आप वाकई सारी प्लेटफॉर्म हिस्ट्री (गिवर्स, टेकर्स, ट्रांजैक्शन, P2P मैच, नोटिफिकेशन्स) डिलीट करना चाहते हैं?\n\nयह एक्शन वापस नहीं लिया जा सकता!'
                          )
                        ) {
                          onGlobalSystemReset();
                          alert('🎉 सभी प्लेटफॉर्म हिस्ट्री और ट्रांजैक्शन डेटा सफलतापूर्वक डिलीट कर दिए गए हैं!');
                        }
                      }}
                      className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md border border-rose-500 transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>Delete All History (हिस्ट्री डिलीट करें)</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-300">
                <div className="bg-slate-950/60 p-3.5 rounded-xl border border-white/10 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider block">⚡ Link Dispatch Status Info</span>
                  <p className="leading-relaxed">
                    {systemSettings.dispatchLinksEnabled !== false ? (
                      <span className="text-emerald-400 font-bold">
                        ● Link Dispatch is ON: All Givers and Takers can see active payment link boxes on their devices and complete transactions.
                      </span>
                    ) : (
                      <span className="text-amber-300 font-bold">
                        ● Link Dispatch is OFF (Promotion Mode): Links are paused. User dashboards display a "Promotional Phase - Links will be dispatched shortly" notice.
                      </span>
                    )}
                  </p>
                </div>

                <div className="bg-slate-950/60 p-3.5 rounded-xl border border-white/10 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-rose-400 tracking-wider block">🗑️ Clear Platform Records</span>
                  <p className="leading-relaxed">
                    Use "Delete All History" to wipe all test PH/GH matches, transactions, and notifications prior to live launching. User profile accounts will remain intact.
                  </p>
                </div>
              </div>
            </div>

            {/* SIDE-BY-SIDE GIVERS & TAKERS CORES */}
            <div className="grid lg:grid-cols-2 gap-4">
              {/* GIVERS COLUMN */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3 shadow-xs">
                <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                  <span className="font-extrabold text-slate-800 flex items-center gap-1">
                    <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    1. Givers (PH) Queue ({unifiedGiversQueue.length})
                  </span>
                  <input
                    type="text"
                    placeholder="Filter Givers..."
                    value={matchGiverSearch}
                    onChange={(e) => setMatchGiverSearch(e.target.value)}
                    className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-[10px] w-40 focus:outline-none"
                  />
                </div>

                <div className="max-h-[300px] overflow-y-auto space-y-2 bg-slate-50 p-2 rounded-lg">
                  {(() => {
                    const filtered = unifiedGiversQueue.filter(g => 
                      g.userName.toLowerCase().includes(matchGiverSearch.toLowerCase()) || 
                      g.id.toLowerCase().includes(matchGiverSearch.toLowerCase()) ||
                      g.userId.toLowerCase().includes(matchGiverSearch.toLowerCase())
                    );
                    if (filtered.length === 0) return <div className="text-center py-6 text-slate-400 italic">No active givers.</div>;
                    
                    return filtered.map(giver => {
                      const userObj = users.find(u => u.id === giver.userId);
                      const isSelected = manualGiverId === giver.id || manualGiverId === giver.userId;
                      return (
                        <div key={giver.id} className={`p-2.5 rounded-lg border bg-white transition-colors space-y-1.5 ${isSelected ? 'border-emerald-500 bg-emerald-50/20' : 'border-slate-200'}`}>
                          <div className="flex justify-between items-start">
                            <div>
                              <span className="font-extrabold text-slate-800 flex items-center gap-1.5">
                                {giver.userName}
                                {giver.status === 'pin_active' && (
                                  <span className="bg-emerald-100 text-emerald-800 text-[8px] font-black px-1.5 py-0.5 rounded">
                                    PIN Active
                                  </span>
                                )}
                              </span>
                              <span className="text-[9px] text-slate-400 font-mono block">ID: {giver.id.substring(0,12)} | User: {giver.userId.substring(0,8)}</span>
                            </div>
                            <span className="font-black text-emerald-600">₹{giver.availablePledge}</span>
                          </div>

                          <div className="text-[10px] text-slate-500 border-t border-dashed border-slate-100 pt-1 space-y-0.5">
                            <div>📞 {giver.userPhone || userObj?.phone || 'N/A'} | UPI: <strong className="font-mono text-slate-700 select-all">{userObj?.upiId || 'N/A'}</strong></div>
                            <div>🏦 Bank: <strong className="text-slate-700 select-all">{userObj?.bankName || 'N/A'} ({userObj?.accountNumber || 'N/A'} / {userObj?.ifscCode || 'N/A'})</strong></div>
                            {giver.remarks && <div className="text-[9px] text-emerald-700 font-medium">Stage: {giver.remarks}</div>}
                          </div>

                          <div className="flex justify-end gap-1.5 pt-1">
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(giver.id);
                                alert('Pledge/User ID copied!');
                              }}
                              className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded hover:bg-slate-200 text-[9px] font-bold"
                            >
                              Copy ID
                            </button>
                            <button
                              onClick={() => {
                                setManualGiverId(giver.id);
                                setManualMatchAmount(giver.availablePledge.toString());
                              }}
                              className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded hover:bg-indigo-100 text-[9px] font-black"
                            >
                              {isSelected ? 'Loaded ✓' : 'Load Giver'}
                            </button>
                          </div>
                        </div>
                      );
                    });
                  })()}
                </div>
              </div>

              {/* TAKERS COLUMN */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3 shadow-xs">
                <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                  <span className="font-extrabold text-slate-800 flex items-center gap-1">
                    <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse"></span>
                    2. Takers (GH / Withdrawals) Queue
                  </span>
                  <input
                    type="text"
                    placeholder="Filter Takers..."
                    value={matchReceiverSearch}
                    onChange={(e) => setMatchReceiverSearch(e.target.value)}
                    className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-[10px] w-40 focus:outline-none"
                  />
                </div>

                <div className="max-h-[300px] overflow-y-auto space-y-2 bg-slate-50 p-2 rounded-lg">
                  {(() => {
                    const openGh = helpRequests.filter(h => {
                      if (h.status === 'rejected' || h.status === 'completed') return false;
                      const matchSum = p2pMatches.filter(m => (m.takerId === h.id || m.takerUserId === h.userId) && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0);
                      const remaining = h.amountRequested - (h.amountReceived + matchSum);
                      return remaining > 0;
                    });
                    const openWithdraw = transactions.filter(t => {
                      if (t.type !== 'withdrawal' || t.status === 'rejected' || t.status === 'completed') return false;
                      const matchSum = p2pMatches.filter(m => (m.takerId === t.id || m.takerUserId === t.userId) && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0);
                      return (t.amount - matchSum) > 0;
                    });
                    const adminUserObj = users.find(u => u.role === 'admin');
                    const adminTakerEntry = adminUserObj ? {
                      id: 'admin-taker-help-id',
                      userId: adminUserObj.id,
                      name: adminUserObj.name + ' (Admin Escrow)',
                      type: 'get_help' as const,
                      title: 'Platform Maintenance & Central Escrow',
                      amountNeeded: 100
                    } : null;

                    const takers = [
                      ...(adminTakerEntry ? [adminTakerEntry] : []),
                      ...openGh.map(h => {
                        const matchSum = p2pMatches.filter(m => (m.takerId === h.id || m.takerUserId === h.userId) && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0);
                        const amountNeeded = Math.max(0, h.amountRequested - (h.amountReceived + matchSum));
                        return { id: h.id, userId: h.userId, name: h.userName, type: 'get_help' as const, title: h.title, amountNeeded };
                      }),
                      ...openWithdraw.map(w => {
                        const matchSum = p2pMatches.filter(m => (m.takerId === w.id || m.takerUserId === w.userId) && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0);
                        return { id: w.id, userId: w.userId, name: w.userName, type: 'withdrawal' as const, title: 'Pending Wallet Withdrawal', amountNeeded: Math.max(0, w.amount - matchSum) };
                      })
                    ];
                    const filtered = takers.filter(r => r.name.toLowerCase().includes(matchReceiverSearch.toLowerCase()) || r.id.toLowerCase().includes(matchReceiverSearch.toLowerCase()));
                    if (filtered.length === 0) return <div className="text-center py-6 text-slate-400 italic">No active takers.</div>;

                    return filtered.map(taker => {
                      const userObj = users.find(u => u.id === taker.userId);
                      const isSelected = manualTakerId === taker.id;
                      return (
                        <div key={taker.id} className={`p-2.5 rounded-lg border bg-white transition-colors space-y-1.5 ${isSelected ? 'border-amber-500 bg-amber-50/20' : 'border-slate-200'}`}>
                          <div className="flex justify-between items-start">
                            <div>
                              <span className="font-extrabold text-slate-800 block">
                                {taker.name}
                                <span className={`ml-1 px-1 rounded text-[8px] font-black ${taker.type === 'withdrawal' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'}`}>
                                  {taker.type === 'withdrawal' ? 'Withdraw' : 'GH'}
                                </span>
                              </span>
                              <span className="text-[9px] text-slate-400 font-mono block">Request: {taker.id.substring(0,8)} | User: {taker.userId.substring(0,8)}</span>
                            </div>
                            <span className="font-black text-amber-600">₹{taker.amountNeeded}</span>
                          </div>

                          <div className="text-[10px] text-slate-500 border-t border-dashed border-slate-100 pt-1 space-y-0.5">
                            <div>📞 {userObj?.phone || 'N/A'} | UPI: <strong className="font-mono text-slate-700 select-all">{userObj?.upiId || 'N/A'}</strong></div>
                            <div>🏦 Bank: <strong className="text-slate-700 select-all">{userObj?.bankName || 'N/A'} ({userObj?.accountNumber || 'N/A'} / {userObj?.ifscCode || 'N/A'})</strong></div>
                          </div>

                          <div className="flex justify-end gap-1.5 pt-1">
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(taker.id);
                                alert('Taker/Request ID copied!');
                              }}
                              className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded hover:bg-slate-200 text-[9px] font-bold"
                            >
                              Copy ID
                            </button>
                            <button
                              onClick={() => {
                                setManualTakerId(taker.id);
                                const giverObj = contributions.find(c => c.id === manualGiverId);
                                if (giverObj) {
                                  setManualMatchAmount(Math.min(giverObj.amount, taker.amountNeeded).toString());
                                } else {
                                  setManualMatchAmount(taker.amountNeeded.toString());
                                }
                              }}
                              className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded hover:bg-indigo-100 text-[9px] font-black"
                            >
                              {isSelected ? 'Loaded ✓' : 'Load Taker'}
                            </button>
                          </div>
                        </div>
                      );
                    });
                  })()}
                </div>
              </div>
            </div>

            {/* ROUTING CONTROL & MANUAL LINK DISPATCH PANELS */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-black text-slate-700">P2P Route Alignment Console</span>
                {selectedGiverObj && selectedTakerObj ? (
                  <span className="bg-emerald-100 text-emerald-800 font-black px-2 py-0.5 rounded text-[8px] uppercase tracking-wider animate-pulse">
                    ● Pair Loaded Side-by-Side
                  </span>
                ) : (
                  <span className="bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded text-[8px]">
                    ⚠️ Load Giver & Taker to Begin
                  </span>
                )}
              </div>

              <div className="grid sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1">Paste / Verify Giver ID</label>
                  <input
                    type="text"
                    placeholder="Enter Pledge/PH ID"
                    value={manualGiverId}
                    onChange={(e) => {
                      setManualGiverId(e.target.value);
                      const found = contributions.find(c => c.id === e.target.value);
                      if (found) setManualMatchAmount(found.amount.toString());
                    }}
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 font-bold focus:outline-none"
                  />
                  {selectedGiverObj && (
                    <div className="mt-1 text-[10px] text-slate-500">
                      Loaded: <strong className="text-emerald-600">{selectedGiverObj.userName}</strong> (Pledge ₹{selectedGiverObj.amount})
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1">Paste / Verify Taker ID</label>
                  <input
                    type="text"
                    placeholder="Enter Request/GH ID"
                    value={manualTakerId}
                    onChange={(e) => setManualTakerId(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 font-bold focus:outline-none"
                  />
                  {selectedTakerObj && (
                    <div className="mt-1 text-[10px] text-slate-500">
                      Loaded: <strong className="text-amber-600">{selectedTakerObj.name}</strong> (Need ₹{selectedTakerObj.amountNeeded})
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1">Match Routing Value (INR)</label>
                  <input
                    type="number"
                    value={manualMatchAmount}
                    onChange={(e) => setManualMatchAmount(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 font-bold focus:outline-none"
                  />
                </div>
              </div>

              {/* ROUTING PRESET */}
              <div className="bg-white p-3 rounded-lg border border-slate-200/60 space-y-2">
                <span className="block font-bold text-slate-500 text-[10px]">Payment Routing Destination Mode</span>
                <div className="grid sm:grid-cols-2 gap-2 text-[10px]">
                  <label className="flex items-center gap-2 p-2 border border-slate-200 rounded-lg cursor-pointer">
                    <input
                      type="radio"
                      name="presetRadio"
                      checked={manualAdminLink === ''}
                      onChange={() => setManualAdminLink('')}
                    />
                    <div>
                      <strong className="block text-slate-700">Direct User-to-User P2P</strong>
                      <span className="text-[9px] text-slate-400">Giver pays the taker's direct UPI/Bank details</span>
                    </div>
                  </label>

                  <label className="flex items-center gap-2 p-2 border border-slate-200 rounded-lg cursor-pointer">
                    <input
                      type="radio"
                      name="presetRadio"
                      checked={manualAdminLink !== ''}
                      onChange={() => setManualAdminLink('System Escrow Gate Active')}
                    />
                    <div>
                      <strong className="block text-indigo-700">🛡️ First Link on Admin ID (Escrow Route)</strong>
                      <span className="text-[9px] text-slate-400">Giver pays the Platform Admin's UPI/Bank details</span>
                    </div>
                  </label>
                </div>
              </div>

              {/* MANUAL LINK DISPATCH FIELDS */}
              <div className="grid sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-0.5">Giver PH Payment Link (Optional)</label>
                  <input
                    type="text"
                    placeholder="https://pay.example.com/..."
                    value={manualGiverLink}
                    onChange={(e) => setManualGiverLink(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg p-1.5 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-0.5">Taker GH Claim Link (Optional)</label>
                  <input
                    type="text"
                    placeholder="https://claim.example.com/..."
                    value={manualTakerLink}
                    onChange={(e) => setManualTakerLink(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg p-1.5 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-0.5">Admin Tracking / System Reference Link</label>
                  <input
                    type="text"
                    placeholder="System link"
                    value={manualAdminLink}
                    onChange={(e) => setManualAdminLink(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg p-1.5 focus:outline-none"
                  />
                </div>
              </div>

              {/* ACTION BUTTON */}
              <div className="flex justify-end gap-3 pt-2">
                <button
                  onClick={() => {
                    setManualGiverId('');
                    setManualTakerId('');
                    setManualMatchAmount('');
                    setManualGiverLink('');
                    setManualTakerLink('');
                    setManualAdminLink('');
                  }}
                  className="px-4 py-2 bg-slate-200 text-slate-700 hover:bg-slate-300 font-extrabold uppercase rounded-lg text-[10px]"
                >
                  Clear Form
                </button>
                <button
                  onClick={() => {
                    if (!manualGiverId || !manualTakerId || !manualMatchAmount) {
                      alert('Please select both Giver and Taker first, then verify the match value!');
                      return;
                    }

                    const amt = parseFloat(manualMatchAmount);
                    if (isNaN(amt) || amt <= 0) {
                      alert('Enter a valid positive match amount.');
                      return;
                    }

                    const giver = contributions.find(c => c.id === manualGiverId);
                    const takerHelp = helpRequests.find(h => h.id === manualTakerId);
                    const takerTx = transactions.find(t => t.id === manualTakerId);

                    if (!giver) {
                      alert('Pledge ID not found in contributions database.');
                      return;
                    }
                    if (!takerHelp && !takerTx) {
                      alert('Taker request ID not found.');
                      return;
                    }

                    const takerMatchSum = p2pMatches.filter(m => m.takerId === manualTakerId && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0);
                    const remainingNeed = takerHelp 
                      ? Math.max(0, takerHelp.amountRequested - Math.max(takerHelp.amountReceived, takerMatchSum)) 
                      : (takerTx ? Math.max(0, takerTx.amount - takerMatchSum) : 0);
                    if (amt > giver.amount) {
                      alert(`Match amount (₹${amt}) exceeds Giver's available pledge limit (₹${giver.amount}).`);
                      return;
                    }
                    if (amt > remainingNeed) {
                      alert(`Match amount (₹${amt}) exceeds Taker's remaining need (₹${remainingNeed}).`);
                      return;
                    }

                    const success = onManualMatch(
                      manualGiverId,
                      manualTakerId,
                      amt,
                      manualGiverLink.trim(),
                      manualTakerLink.trim(),
                      manualAdminLink.trim()
                    );

                    if (success) {
                      const recName = takerHelp ? takerHelp.userName : (takerTx ? takerTx.userName : 'Taker');
                      alert(`🎉 Established Direct Route of ₹${amt} from Giver ${giver.userName} to Taker ${recName}! Manual dispatches notified.`);
                      setManualGiverId('');
                      setManualTakerId('');
                      setManualMatchAmount('');
                      setManualGiverLink('');
                      setManualTakerLink('');
                      setManualAdminLink('');
                    } else {
                      alert('Match failed. Check inputs.');
                    }
                  }}
                  className="px-5 py-2 bg-indigo-600 text-white hover:bg-indigo-700 font-black uppercase rounded-lg text-[10px] shadow-sm"
                >
                  Establish P2P Connection & Dispatch Links
                </button>
              </div>
            </div>

            {/* ACTIVE P2P MATCHES LEDGER */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3 shadow-xs">
              <span className="font-extrabold text-slate-800 text-sm block">Active Peer-to-Peer Matches Ledger</span>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-[10px]">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 uppercase font-black text-[8px] tracking-wider">
                      <th className="p-2">Match ID</th>
                      <th className="p-2">Giver (PH)</th>
                      <th className="p-2">Taker (GH)</th>
                      <th className="p-2">Value</th>
                      <th className="p-2">Route Target</th>
                      <th className="p-2">Status</th>
                      <th className="p-2 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {p2pMatches.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center py-6 text-slate-400 italic font-mono">No matches established. Use the desk above to create one.</td>
                      </tr>
                    ) : (
                      p2pMatches.map(match => (
                        <React.Fragment key={match.id}>
                          <tr className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="p-2 font-mono font-bold text-slate-500">{match.id.substring(0,8).toUpperCase()}</td>
                            <td className="p-2">
                              <div><strong>{match.giverName}</strong></div>
                              {match.phLink ? <span className="text-[8px] font-black uppercase tracking-wider text-indigo-700 bg-indigo-50 border border-indigo-100 px-1 rounded">PH Sent</span> : <span className="text-[8px] text-slate-400">No Link</span>}
                            </td>
                            <td className="p-2">
                              <div><strong>{match.takerName}</strong></div>
                              {match.ghLink ? <span className="text-[8px] font-black uppercase tracking-wider text-amber-700 bg-amber-50 border border-amber-100 px-1 rounded">GH Sent</span> : <span className="text-[8px] text-slate-400">No Link</span>}
                            </td>
                            <td className="p-2 font-extrabold text-emerald-600">₹{match.amount}</td>
                            <td className="p-2">
                              {match.adminLink || match.paymentDetails === 'admin_upi' ? (
                                <span className="text-[8px] font-black bg-indigo-100 text-indigo-800 px-1.5 py-0.5 rounded uppercase border border-indigo-200">🛡️ Admin ID</span>
                              ) : (
                                <span className="text-[8px] font-bold bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded uppercase">⚡ Direct P2P</span>
                              )}
                            </td>
                            <td className="p-2">
                              {match.status === 'pending' && <span className="bg-amber-100 text-amber-800 px-1 rounded text-[8px] font-bold uppercase">Pending Pay</span>}
                              {match.status === 'pending_verification' && <span className="bg-indigo-100 text-indigo-800 px-1 rounded text-[8px] font-black uppercase animate-pulse">Checking...</span>}
                              {match.status === 'completed' && <span className="bg-emerald-100 text-emerald-800 px-1 rounded text-[8px] font-bold uppercase">Verified ✓</span>}
                              {match.status === 'rejected' && <span className="bg-red-100 text-red-800 px-1 rounded text-[8px] font-bold uppercase">Rejected ✗</span>}
                            </td>
                            <td className="p-2 text-right space-y-1">
                              {match.screenshotUrl && (
                                <div className="text-[9px] text-slate-500">
                                  Proof: <span className="text-indigo-600 underline cursor-pointer" onClick={() => alert(`Showing receipt proof: ${match.screenshotUrl}`)}>{match.screenshotUrl}</span>
                                </div>
                              )}
                              
                              {match.status === 'pending_verification' && (
                                <div className="flex justify-end gap-1">
                                  <button
                                    onClick={() => {
                                      if (onApproveP2PMatch) onApproveP2PMatch(match.id);
                                      alert('Match payment approved and verified!');
                                    }}
                                    className="px-1.5 py-0.5 bg-emerald-600 text-white rounded font-extrabold text-[8px]"
                                  >
                                    Approve
                                  </button>
                                  <button
                                    onClick={() => {
                                      if (onRejectP2PMatch) onRejectP2PMatch(match.id);
                                      alert('Match payment proof rejected.');
                                    }}
                                    className="px-1.5 py-0.5 bg-red-600 text-white rounded font-extrabold text-[8px]"
                                  >
                                    Reject
                                  </button>
                                </div>
                              )}

                              {/* Admin Link Accept/Reject Control Option (Always available for Admin Links to ensure flexibility) */}
                              {(match.adminLink || match.paymentDetails === 'admin_upi' || match.takerUserId === 'admin' || match.giverUserId === 'admin' || match.takerName.toLowerCase().includes('admin') || match.giverName.toLowerCase().includes('admin')) && match.status !== 'completed' && match.status !== 'rejected' && (
                                <div className="mt-1.5 flex flex-wrap justify-end items-center gap-1 bg-indigo-50 p-1 rounded border border-indigo-100 max-w-[180px] ml-auto">
                                  <span className="text-[7px] font-black text-indigo-700 uppercase tracking-tight shrink-0">Admin Link:</span>
                                  <button
                                    onClick={() => {
                                      if (confirm("Confirm receipt of Admin Link payment? This will approve the match and credit the users.")) {
                                        if (onApproveP2PMatch) {
                                          onApproveP2PMatch(match.id);
                                          alert('Admin Link payment accepted & approved successfully!');
                                        }
                                      }
                                    }}
                                    className="px-1.5 py-0.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-[7px] font-black uppercase tracking-wider cursor-pointer transition-all active:scale-95"
                                  >
                                    Accept
                                  </button>
                                  <button
                                    onClick={() => {
                                      const reason = prompt('Please enter rejection reason:');
                                      if (reason === null) return;
                                      if (onRejectP2PMatch) {
                                        onRejectP2PMatch(match.id);
                                        alert('Admin Link payment rejected.');
                                      }
                                    }}
                                    className="px-1.5 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[7px] font-black uppercase tracking-wider cursor-pointer transition-all active:scale-95"
                                  >
                                    Reject
                                  </button>
                                </div>
                              )}

                              <div className="flex justify-end gap-1">
                                <button
                                  onClick={() => {
                                    if (editingMatchLinksId === match.id) {
                                      setEditingMatchLinksId(null);
                                    } else {
                                      setEditingMatchLinksId(match.id);
                                      setTempPhLink(match.phLink || '');
                                      setTempGhLink(match.ghLink || '');
                                    }
                                  }}
                                  className="text-[9px] font-black text-indigo-700 hover:underline"
                                >
                                  Edit Links
                                </button>
                              </div>
                            </td>
                          </tr>

                          {editingMatchLinksId === match.id && (
                            <tr className="bg-indigo-50/20">
                              <td colSpan={7} className="p-3 border-b border-indigo-100">
                                <div className="bg-white p-3 rounded-lg border border-indigo-100 space-y-2 text-[10px]">
                                  <div className="flex justify-between items-center font-bold">
                                    <span>🔗 Manual Link Dispatch Overwrite</span>
                                    <button onClick={() => setEditingMatchLinksId(null)} className="text-slate-400 hover:text-slate-600">✕ Close</button>
                                  </div>
                                  <div className="grid sm:grid-cols-2 gap-2">
                                    <div>
                                      <label className="block text-[9px] font-bold text-slate-500 mb-0.5">PH Link (Giver: {match.giverName})</label>
                                      <input
                                        type="text"
                                        value={tempPhLink}
                                        onChange={(e) => setTempPhLink(e.target.value)}
                                        className="w-full bg-slate-50 border border-slate-200 rounded p-1"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[9px] font-bold text-slate-500 mb-0.5">GH Link (Taker: {match.takerName})</label>
                                      <input
                                        type="text"
                                        value={tempGhLink}
                                        onChange={(e) => setTempGhLink(e.target.value)}
                                        className="w-full bg-slate-50 border border-slate-200 rounded p-1"
                                      />
                                    </div>
                                  </div>
                                  <div className="flex justify-end gap-2 pt-1">
                                    <button onClick={() => {
                                      if (onUpdateP2PMatch) {
                                        onUpdateP2PMatch(match.id, { 
                                          phLink: tempPhLink.trim(), 
                                          ghLink: tempGhLink.trim(),
                                          isPhLinkSent: !!tempPhLink.trim(),
                                          isGhLinkSent: !!tempGhLink.trim()
                                        });

                                        // Send notification to Giver (PH Link)
                                        if (tempPhLink.trim()) {
                                          const notifGiver: Notification = {
                                            id: Math.random().toString(36).substr(2, 9),
                                            userId: match.giverUserId,
                                            title: '🔗 Admin Sent PH Payment Link',
                                            message: `The administrator has attached a payment link for your ₹${match.amount} contribution to ${match.takerName}. Click to open link: ${tempPhLink.trim()}`,
                                            type: 'info',
                                            read: false,
                                            createdAt: new Date().toISOString()
                                          };
                                          onAddNotification(notifGiver);

                                          // Copy to Admin ALSO
                                          const notifAdminPh: Notification = {
                                            id: Math.random().toString(36).substr(2, 9),
                                            userId: 'admin-id',
                                            title: '🔗 PH Link Logged (Admin Copy)',
                                            message: `Dispatched PH link for Giver ${match.giverName} (Amount: ₹${match.amount}). Link: ${tempPhLink.trim()}`,
                                            type: 'success',
                                            read: false,
                                            createdAt: new Date().toISOString()
                                          };
                                          onAddNotification(notifAdminPh);
                                        }

                                        // Send notification to Taker (GH Link)
                                        if (tempGhLink.trim()) {
                                          const notifTaker: Notification = {
                                            id: Math.random().toString(36).substr(2, 9),
                                            userId: match.takerUserId,
                                            title: '🔗 Admin Sent GH Claim Link',
                                            message: `The administrator has attached a payout link for your ₹${match.amount} aid from ${match.giverName}. Click to open link: ${tempGhLink.trim()}`,
                                            type: 'info',
                                            read: false,
                                            createdAt: new Date().toISOString()
                                          };
                                          onAddNotification(notifTaker);

                                          // Copy to Admin ALSO
                                          const notifAdminGh: Notification = {
                                            id: Math.random().toString(36).substr(2, 9),
                                            userId: 'admin-id',
                                            title: '🔗 GH Link Logged (Admin Copy)',
                                            message: `Dispatched GH link for Taker ${match.takerName} (Amount: ₹${match.amount}). Link: ${tempGhLink.trim()}`,
                                            type: 'success',
                                            read: false,
                                            createdAt: new Date().toISOString()
                                          };
                                          onAddNotification(notifAdminGh);
                                        }

                                        alert('PH/GH Links successfully dispatched and logged!');
                                        setEditingMatchLinksId(null);
                                      }
                                    }} className="px-3 py-1 bg-indigo-600 text-white rounded font-black uppercase text-[9px]">
                                      Save & Dispatch
                                    </button>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

              {/* LIVE QUEUE COUNTERS */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="bg-emerald-50 border border-emerald-200/60 p-4 rounded-xl flex items-center justify-between">
                  <div className="space-y-1">
                    <span className="text-[10px] font-black uppercase text-emerald-800 tracking-wider block">Going to Give (PH Phase)</span>
                    <span className="text-3xl font-black text-emerald-950 block">{unifiedGiversQueue.length} Users</span>
                    <span className="text-[10px] text-emerald-700 font-medium block">Total Expected: ₹{unifiedGiversQueue.reduce((sum, item) => sum + item.availablePledge, 0).toLocaleString()}</span>
                  </div>
                  <div className="bg-emerald-100 p-2.5 rounded-lg text-emerald-800 text-xl font-bold">
                    📥 PH
                  </div>
                </div>

                <div className="bg-amber-50 border border-amber-200/60 p-4 rounded-xl flex items-center justify-between">
                  <div className="space-y-1">
                    <span className="text-[10px] font-black uppercase text-amber-800 tracking-wider block">Going to Take (GH Phase)</span>
                    <span className="text-3xl font-black text-amber-950 block">{unifiedTakersQueue.length} Users</span>
                    <span className="text-[10px] text-amber-700 font-medium block">Total Expected: ₹{unifiedTakersQueue.reduce((sum, item) => sum + item.amountNeeded, 0).toLocaleString()}</span>
                  </div>
                  <div className="bg-amber-100 p-2.5 rounded-lg text-amber-800 text-xl font-bold">
                    📤 GH
                  </div>
                </div>
              </div>

              {/* DETAILED GIVER AND TAKER QUEUES DIRECTORY */}
              <div className="grid md:grid-cols-2 gap-6 pt-2">
                {/* GIVERS DIRECTORY */}
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                  <h4 className="text-xs font-black uppercase text-slate-600 tracking-wider flex items-center gap-1.5 mb-3 pb-2 border-b border-slate-200">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                    List of Givers Going to Give ({unifiedGiversQueue.length})
                  </h4>
                  <div className="space-y-2.5 max-h-[250px] overflow-y-auto pr-1">
                    {unifiedGiversQueue.length === 0 ? (
                      <div className="text-center py-8 text-slate-400 text-[11px] italic font-mono bg-white rounded-lg border border-dashed border-slate-200">
                        No active givers currently waiting to give.
                      </div>
                    ) : (
                      unifiedGiversQueue.map((item, idx) => {
                        return (
                          <div key={item.id + '-' + idx} className="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex justify-between items-center">
                            <div>
                              <p className="text-xs font-bold text-slate-800">{item.userName}</p>
                              <div className="flex items-center gap-1.5 mt-0.5">
                                <span className="text-[9px] bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded uppercase font-black tracking-wider">
                                  {item.remarks || `PH Pledge ₹${item.availablePledge}`}
                                </span>
                                <span className="text-[8px] text-slate-400 font-mono">Cycle #{item.cycleCount || 1}</span>
                              </div>
                            </div>
                            <div className="text-right flex items-center gap-2">
                              <span className="text-xs font-black text-emerald-600">₹{item.availablePledge}</span>
                              <button
                                type="button"
                                onClick={() => {
                                  // Pick best taker or platform reserve
                                  const targetTaker = unifiedTakersQueue.find(t => t.userId !== item.userId) || {
                                    id: `admin-system-taker-${adminUser?.id || 'admin-id'}`,
                                    userId: adminUser?.id || 'admin-id',
                                    userName: 'Platform Admin Escrow',
                                    upiId: systemSettings.systemWalletAddress || 'help100admin@sbin'
                                  };

                                  const customPhLink = `upi://pay?pa=${targetTaker.upiId || 'help100admin@sbin'}&pn=${encodeURIComponent(targetTaker.userName)}&am=${item.availablePledge}&cu=INR&tn=PH_MATCH_${item.userId.slice(-4)}`;

                                  const success = onManualMatch(
                                    item.id,
                                    targetTaker.id,
                                    item.availablePledge,
                                    customPhLink,
                                    '',
                                    ''
                                  );

                                  if (success) {
                                    onAddNotification({
                                      id: Math.random().toString(36).substr(2, 9),
                                      userId: item.userId,
                                      title: '⚡ PH Payment Link Dispatched!',
                                      message: `Admin has dispatched your payment link box for ₹${item.availablePledge}. Recipient: ${targetTaker.userName} (${targetTaker.upiId}). Open dashboard to pay & submit proof!`,
                                      type: 'info',
                                      read: false,
                                      createdAt: new Date().toISOString()
                                    });

                                    alert(`🎉 Direct Payment Link Dispatched for ${item.userName}!
• Amount: ₹${item.availablePledge}
• Recipient Taker: ${targetTaker.userName} (${targetTaker.upiId})

✓ गिवर लिस्ट (Giver List) और टेकर लिस्ट (Taker List) दोनों से ₹${item.availablePledge} की राशि कट (deduct हो) गई है।
✓ यूजर के डैशबोर्ड में Active Payment Link Box चालू हो गया है!`);
                                  } else {
                                    alert('Link dispatch failed. Please check Giver/Taker queue status.');
                                  }
                                }}
                                className="px-2.5 py-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer shadow-xs active:scale-95 flex items-center gap-1"
                              >
                                🔗 Dispatch Link
                              </button>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

                {/* TAKERS DIRECTORY */}
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                  <h4 className="text-xs font-black uppercase text-slate-600 tracking-wider flex items-center gap-1.5 mb-3 pb-2 border-b border-slate-200">
                    <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
                    List of Takers Going to Take ({unifiedTakersQueue.length})
                  </h4>
                  <div className="space-y-2.5 max-h-[250px] overflow-y-auto pr-1">
                    {unifiedTakersQueue.length === 0 ? (
                      <div className="text-center py-8 text-slate-400 text-[11px] italic font-mono bg-white rounded-lg border border-dashed border-slate-200">
                        No active takers currently waiting to take.
                      </div>
                    ) : (
                      unifiedTakersQueue.map((item, idx) => {
                        return (
                          <div key={item.id + '-' + idx} className="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex justify-between items-center">
                            <div>
                              <p className="text-xs font-bold text-slate-800">{item.userName} {item.type === 'admin' && <span className="text-[8px] bg-indigo-100 text-indigo-700 px-1 rounded">PLATFORM</span>}</p>
                              <div className="flex items-center gap-1.5 mt-0.5">
                                <span className="text-[9px] bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded uppercase font-black tracking-wider">
                                  {item.stepName}
                                </span>
                                <span className="text-[8px] text-slate-400 font-mono">Cycle #{item.cycleCount || 1}</span>
                              </div>
                            </div>
                            <div className="text-right flex items-center gap-2">
                              <span className="text-xs font-black text-amber-600">₹{item.amountNeeded}</span>
                              <button
                                type="button"
                                onClick={() => {
                                  const targetGiver = unifiedGiversQueue.find(g => g.userId !== item.userId);
                                  if (!targetGiver) {
                                    alert('No active Giver available in the queue to match with this Taker right now.');
                                    return;
                                  }

                                  const matchAmt = Math.min(targetGiver.availablePledge, item.amountNeeded);
                                  const customPhLink = `upi://pay?pa=${item.upiId || 'help100admin@sbin'}&pn=${encodeURIComponent(item.userName)}&am=${matchAmt}&cu=INR&tn=GH_PAYOUT_${item.userId.slice(-4)}`;

                                  const success = onManualMatch(
                                    targetGiver.id,
                                    item.id,
                                    matchAmt,
                                    customPhLink,
                                    '',
                                    ''
                                  );

                                  if (success) {
                                    onAddNotification({
                                      id: Math.random().toString(36).substr(2, 9),
                                      userId: item.userId,
                                      title: '💰 Payout Link Dispatched & Matched!',
                                      message: `Your payout request of ₹${matchAmt} has been matched with Giver ${targetGiver.userName}. They have received the payment link!`,
                                      type: 'success',
                                      read: false,
                                      createdAt: new Date().toISOString()
                                    });

                                    alert(`🎉 Taker Request Matched & Dispatched!
• Amount: ₹${matchAmt}
• Giver: ${targetGiver.userName}
• Taker: ${item.userName} (${item.upiId})

✓ गिवर लिस्ट और टेकर लिस्ट दोनों से ₹${matchAmt} कट (deduct हो) गई है!`);
                                  } else {
                                    alert('Match & dispatch failed.');
                                  }
                                }}
                                className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer shadow-xs active:scale-95 flex items-center gap-1"
                              >
                                ⚡ Match & Dispatch
                              </button>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>

            {/* Auto-Pin dispenser */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="space-y-1">
                <h4 className="text-sm font-black text-amber-400 flex items-center gap-1.5 uppercase tracking-wider">
                  <Key className="w-4 h-4 text-amber-400" />
                  🔑 Registration PIN Distributor
                </h4>
                <p className="text-[11px] text-slate-400">
                  Manually distribute a free ₹10 PIN to all users to bypass registration costs instantly.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  let distributedCount = 0;
                  users.forEach(u => {
                    onSendPin(u.id);
                    distributedCount++;
                    
                    onAddNotification({
                      id: Math.random().toString(36).substr(2, 9),
                      userId: u.id,
                      title: '🔑 Registration PIN Received',
                      message: `Admin auto-dispatched a new ₹10 Registration PIN key to activate your next Help Cycle! Check your Active PINs area.`,
                      type: 'info',
                      read: false,
                      createdAt: new Date().toISOString()
                    });
                  });
                  alert(`🎁 Done! Distributed a new ₹10 Help Pin to all ${distributedCount} users to seamlessly unlock their next cycles.`);
                }}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs px-5 py-2.5 rounded-xl border border-amber-400/30 flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95 shrink-0"
              >
                <span>Give PINs to Everyone</span>
              </button>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
                {/* COLUMN 1: PROVIDE HELP (PH) QUEUE */}
                <div className="bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200/60 space-y-4">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                    <span className="text-xs font-black uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-ping"></span>
                      1. PH (Provide Help / Contributions) Queue
                    </span>
                    <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded font-black">
                      {contributions.filter(c => c.status === 'pending_dispatch' || c.status === 'pending_proof' || c.status === 'pending_verification').length} ACTIVE
                    </span>
                  </div>

                  <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                    {contributions.filter(c => c.status === 'pending_dispatch' || c.status === 'pending_proof' || c.status === 'pending_verification').length === 0 ? (
                      <div className="text-center py-10 text-slate-400 text-xs italic font-mono bg-white rounded-xl border border-dashed border-slate-200">
                        No active PH contributions waiting for links/receipts.
                      </div>
                    ) : (
                      contributions.filter(c => c.status === 'pending_dispatch' || c.status === 'pending_proof' || c.status === 'pending_verification').map(c => {
                        const hasLink = !!c.txLink;
                        return (
                          <div key={c.id} className="bg-white p-3.5 rounded-xl border border-slate-200/80 hover:border-indigo-200 hover:shadow-xs transition-all space-y-3">
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="text-xs font-black text-slate-800">{c.userName}</h4>
                                <p className="text-[10px] text-slate-400 font-mono mt-0.5">ID: {c.id.substring(0,8).toUpperCase()} | PH Pledge ({c.remarks || 'PH Request'})</p>
                              </div>
                              <div className="text-right">
                                <span className="text-sm font-black text-indigo-600">₹{c.amount.toLocaleString()}</span>
                                <span className={`block text-[8px] font-extrabold uppercase px-1.5 py-0.5 rounded mt-1 text-center ${
                                  c.status === 'pending_verification' 
                                    ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                                  c.status === 'pending_proof'
                                    ? 'bg-indigo-50 text-indigo-700 border border-indigo-100'
                                    : 'bg-rose-50 text-rose-700 border border-rose-100'
                                }`}>
                                  {c.status === 'pending_verification' ? 'Proof Uploaded' : c.status === 'pending_proof' ? 'Link Sent (Awaiting Pay)' : 'Needs Manual Link'}
                                </span>
                              </div>
                            </div>

                            {/* Input form to send payment gateway / UPI link */}
                            <div className="bg-slate-50/50 p-2.5 rounded-lg border border-slate-100 space-y-2">
                              <label className="block text-[8px] font-black uppercase tracking-wider text-slate-500">
                                Dispatch Payment URL / UPI Gateway Link
                              </label>
                              <div className="flex gap-2">
                                <input
                                  type="text"
                                  placeholder={hasLink ? c.txLink : "e.g. upi://pay?pa=... or payment url"}
                                  value={inlinePhLinks[c.id] || ''}
                                  onChange={(e) => setInlinePhLinks(prev => ({ ...prev, [c.id]: e.target.value }))}
                                  className="flex-grow bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-[11px] font-medium focus:outline-none focus:border-indigo-500 text-slate-800"
                                />
                                <button
                                  onClick={() => {
                                    const linkVal = inlinePhLinks[c.id]?.trim();
                                    if (!linkVal) {
                                      alert('Please enter a valid URL or UPI string.');
                                      return;
                                    }
                                    onUpdateContribution(c.id, 'pending_proof', 'Link dispatched via Quick Action Center', linkVal);
                                    c.txLink = linkVal;
                                    
                                    // Add notification
                                    const notif: Notification = {
                                      id: Math.random().toString(36).substr(2, 9),
                                      userId: c.userId,
                                      title: '🔗 PH Gateway Link Received',
                                      message: `Admin sent a payment gateway link for your ₹${c.amount} contribution (${c.remarks || 'PH'}). Pay here: ${linkVal}`,
                                      type: 'info',
                                      read: false,
                                      createdAt: new Date().toISOString()
                                    };
                                    onAddNotification(notif);
                                    alert(`Successfully dispatched gateway link to ${c.userName}!`);
                                    setInlinePhLinks(prev => ({ ...prev, [c.id]: '' }));
                                  }}
                                  className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer"
                                >
                                  Send Link
                                </button>
                              </div>
                              {hasLink && (
                                <p className="text-[9px] text-slate-400 font-medium truncate">
                                  Current Active Link: <span className="text-indigo-600 font-mono">{c.txLink}</span>
                                </p>
                              )}
                            </div>

                            <div className="flex gap-2 justify-between items-center pt-1">
                              {c.paymentProof && c.paymentProof !== 'None (Pending Upload)' && c.paymentProof !== 'Pending Upload' ? (
                                <span className="text-[9px] text-slate-500 italic flex items-center gap-1">
                                  📁 Proof: <strong className="text-indigo-600 underline cursor-pointer" onClick={() => alert(`Showing receipt: ${c.paymentProof}`)}>{c.paymentProof}</strong>
                                </span>
                              ) : (
                                <span className="text-[9px] text-slate-400 font-medium">Awaiting payment & proof</span>
                              )}
                              <button
                                onClick={() => {
                                  if (confirm(`Directly approve ₹${c.amount} contribution for ${c.userName}?`)) {
                                    onUpdateContribution(c.id, 'approved', 'Directly verified & approved by Admin');
                                    alert(`₹${c.amount} contribution approved for ${c.userName}!`);
                                  }
                                }}
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer shrink-0"
                              >
                                ✓ Approve Payment
                              </button>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

                {/* COLUMN 2: GET HELP (GH) QUEUE */}
                <div className="bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200/60 space-y-4">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                    <span className="text-xs font-black uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping"></span>
                      2. GH (Get Help / Withdrawals / Payouts) Queue
                    </span>
                    <span className="text-[10px] bg-amber-50 text-amber-700 px-2 py-0.5 rounded font-black">
                      {(() => {
                        const hrCount = helpRequests.filter(h => h.status === 'approved' && h.amountReceived < h.amountRequested).length;
                        const withCount = transactions.filter(t => {
                          if (t.type !== 'withdrawal' || t.status === 'rejected' || t.status === 'completed') return false;
                          const matchSum = p2pMatches.filter(m => m.takerId === t.id && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0);
                          return (t.amount - matchSum) > 0;
                        }).length;
                        return hrCount + withCount;
                      })()} ACTIVE
                    </span>
                  </div>

                  <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                    {(() => {
                      const activeHrs = helpRequests.filter(h => h.status === 'approved' && h.amountReceived < h.amountRequested).map(h => ({
                        id: h.id,
                        userId: h.userId,
                        userName: h.userName,
                        amount: h.amountRequested - h.amountReceived,
                        type: 'campaign' as const,
                        original: h
                      }));
                      const activeWiths = transactions.filter(t => {
                        if (t.type !== 'withdrawal' || t.status === 'rejected' || t.status === 'completed') return false;
                        const matchSum = p2pMatches.filter(m => m.takerId === t.id && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0);
                        return (t.amount - matchSum) > 0;
                      }).map(t => {
                        const matchSum = p2pMatches.filter(m => m.takerId === t.id && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0);
                        const remaining = Math.max(0, t.amount - matchSum);
                        return {
                          id: t.id,
                          userId: t.userId,
                          userName: t.userName,
                          amount: remaining,
                          type: 'withdrawal' as const,
                          original: t
                        };
                      });
                      const ghQueue = [...activeHrs, ...activeWiths];

                      if (ghQueue.length === 0) {
                        return (
                          <div className="text-center py-10 text-slate-400 text-xs italic font-mono bg-white rounded-xl border border-dashed border-slate-200">
                            No active GH campaigns or pending withdrawals in queue.
                          </div>
                        );
                      }

                      return ghQueue.map(item => {
                        const hasLink = !!(item.original.txLink);
                        return (
                          <div key={item.id} className="bg-white p-3.5 rounded-xl border border-slate-200/80 hover:border-amber-200 hover:shadow-xs transition-all space-y-3">
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="text-xs font-black text-slate-800">{item.userName}</h4>
                                <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                                  Ref: {item.id.substring(0,8).toUpperCase()} | {item.type === 'campaign' ? 'Get Help Campaign' : 'Direct Withdrawal'}
                                </p>
                              </div>
                              <div className="text-right">
                                <span className="text-sm font-black text-amber-600">₹{item.amount.toLocaleString()}</span>
                                <span className={`block text-[8px] font-extrabold uppercase px-1.5 py-0.5 rounded mt-1 text-center ${
                                  item.type === 'campaign' 
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' 
                                    : 'bg-rose-50 text-rose-700 border border-rose-100'
                                }`}>
                                  {item.type === 'campaign' ? 'Campaign payout' : 'UPI Withdrawal'}
                                </span>
                              </div>
                            </div>

                            {/* Input form to send payout / claim gateway link */}
                            <div className="bg-slate-50/50 p-2.5 rounded-lg border border-slate-100 space-y-2">
                              <label className="block text-[8px] font-black uppercase tracking-wider text-slate-500">
                                Dispatch Payout / Receipt Link & Amount
                              </label>
                              <div className="flex gap-2">
                                <div className="w-24 shrink-0">
                                  <input
                                    type="number"
                                    placeholder={`₹${item.amount}`}
                                    value={inlineGhAmounts[item.id] || ''}
                                    onChange={(e) => setInlineGhAmounts(prev => ({ ...prev, [item.id]: e.target.value }))}
                                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-[11px] font-bold focus:outline-none focus:border-indigo-500 text-slate-800"
                                  />
                                </div>
                                <input
                                  type="text"
                                  placeholder={hasLink ? item.original.txLink : "e.g. receipt link or transfer tracker"}
                                  value={inlineGhLinks[item.id] || ''}
                                  onChange={(e) => setInlineGhLinks(prev => ({ ...prev, [item.id]: e.target.value }))}
                                  className="flex-grow bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-[11px] font-medium focus:outline-none focus:border-indigo-500 text-slate-800"
                                />
                                <button
                                  onClick={() => {
                                    const linkVal = inlineGhLinks[item.id]?.trim();
                                    if (!linkVal) {
                                      alert('Please enter a valid URL link.');
                                      return;
                                    }
                                    const dispatchAmt = Number(inlineGhAmounts[item.id]) > 0 
                                      ? Number(inlineGhAmounts[item.id]) 
                                      : item.amount;

                                    if (dispatchAmt > item.amount) {
                                      alert(`Warning: Dispatched link amount (₹${dispatchAmt}) exceeds remaining Get Help need (₹${item.amount}).`);
                                      return;
                                    }

                                    if (item.type === 'campaign') {
                                      const newReceived = item.original.amountReceived + dispatchAmt;
                                      const isCompleted = newReceived >= item.original.amountRequested;
                                      const newStatus = isCompleted ? 'completed' : 'approved';

                                      item.original.amountReceived = newReceived;
                                      item.original.status = newStatus;
                                      item.original.txLink = linkVal;

                                      if (onUpdateHelpRequest) {
                                        onUpdateHelpRequest(item.id, newStatus, newReceived, `Link of ₹${dispatchAmt} dispatched via Action Center`, linkVal);
                                      }

                                      // Update target user's wallet balance
                                      const targetUserObj = users.find(u => u.id === item.userId);
                                      if (targetUserObj) {
                                        onUpdateUser({
                                          ...targetUserObj,
                                          walletBalance: (targetUserObj.walletBalance || 0) + dispatchAmt,
                                          totalReceived: (targetUserObj.totalReceived || 0) + dispatchAmt
                                        });
                                      }

                                      const remainingAmt = Math.max(0, item.original.amountRequested - newReceived);

                                      // Send notification
                                      const notif: Notification = {
                                        id: Math.random().toString(36).substr(2, 9),
                                        userId: item.userId,
                                        title: `🔗 Payment Link Received (₹${dispatchAmt})`,
                                        message: `The administrator sent you a direct payment link of ₹${dispatchAmt}. Link: ${linkVal}. ${remainingAmt > 0 ? `Remaining Get Help balance: ₹${remainingAmt}` : 'Your Get Help is now 100% completed!'}`,
                                        type: 'info',
                                        read: false,
                                        createdAt: new Date().toISOString()
                                      };
                                      onAddNotification(notif);

                                      alert(`Successfully dispatched ₹${dispatchAmt} link to ${item.userName}! ${remainingAmt > 0 ? `Remaining balance in GH queue: ₹${remainingAmt}` : 'Get Help 100% completed!'}`);
                                    } else {
                                      item.original.txLink = linkVal;
                                      const originalTxAmt = item.amount;

                                      if (dispatchAmt < originalTxAmt) {
                                        // 1. Mark dispatched portion as completed with link
                                        onUpdateTransaction(item.id, 'completed', linkVal, dispatchAmt);

                                        // 2. Create remaining pending withdrawal transaction so remaining balance stays in Taker list!
                                        const remainingAmount = originalTxAmt - dispatchAmt;
                                        const remainingTx: Transaction = {
                                          id: 'tx-with-rem-' + Math.random().toString(36).substring(2, 9),
                                          userId: item.userId,
                                          userName: item.userName,
                                          type: 'withdrawal',
                                          amount: remainingAmount,
                                          status: 'pending',
                                          createdAt: new Date().toISOString(),
                                          description: `Remaining withdrawal balance after ₹${dispatchAmt} link dispatch`,
                                          walletSource: item.original.walletSource || 'get'
                                        };
                                        if (onAddTransaction) {
                                          onAddTransaction(remainingTx);
                                        }

                                        // Send notification to user
                                        const notif: Notification = {
                                          id: Math.random().toString(36).substr(2, 9),
                                          userId: item.userId,
                                          title: `🔗 Withdrawal Link Received (₹${dispatchAmt})`,
                                          message: `Admin sent you a withdrawal payout link of ₹${dispatchAmt}. Link: ${linkVal}. Remaining pending withdrawal balance: ₹${remainingAmount}.`,
                                          type: 'info',
                                          read: false,
                                          createdAt: new Date().toISOString()
                                        };
                                        onAddNotification(notif);

                                        alert(`Successfully dispatched ₹${dispatchAmt} link to ${item.userName}! Remaining pending withdrawal in Taker list: ₹${remainingAmount}`);
                                      } else {
                                        onUpdateTransaction(item.id, 'completed', linkVal, dispatchAmt);

                                        const notif: Notification = {
                                          id: Math.random().toString(36).substr(2, 9),
                                          userId: item.userId,
                                          title: `🔗 Withdrawal Link Received (₹${dispatchAmt})`,
                                          message: `Admin sent you a withdrawal payout link of ₹${dispatchAmt}. Link: ${linkVal}. Your withdrawal is 100% completed!`,
                                          type: 'info',
                                          read: false,
                                          createdAt: new Date().toISOString()
                                        };
                                        onAddNotification(notif);

                                        alert(`Successfully dispatched ₹${dispatchAmt} withdrawal link to ${item.userName}!`);
                                      }
                                    }

                                    setInlineGhLinks(prev => ({ ...prev, [item.id]: '' }));
                                    setInlineGhAmounts(prev => ({ ...prev, [item.id]: '' }));
                                  }}
                                  className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer shrink-0"
                                >
                                  Send Link
                                </button>
                              </div>
                              {hasLink && (
                                <p className="text-[9px] text-slate-400 font-medium truncate">
                                  Current Active Link: <span className="text-amber-600 font-mono">{item.original.txLink}</span>
                                </p>
                              )}
                            </div>

                            {/* Rapid Force Complete button (Removed to enforce standard plan workflow) */}
                          </div>
                        );
                      });
                    })()}
                  </div>
                </div>
              </div>

            {/* MANUAL P2P DIRECT MATCHMAKER CONSOLE */}
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
              <div>
                <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                  <HeartHandshake className="w-5 h-5 text-indigo-600" />
                  Separated Direct Peer Matching Work Desk
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  The Giving Users (Givers) and Receiving Users (Takers) are separated below. Click the select button on any active user to auto-load them into the Match Routing Console, then establish the direct peer-to-peer connection.
                </p>
              </div>

              {/* ACTIVE MATCH ROUTING CONSOLE */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-6">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">Active Match Routing Console</h4>
                  {isFaceToFaceAligned ? (
                    <span className="bg-emerald-500/10 text-emerald-600 px-2.5 py-0.5 rounded text-[9px] font-black uppercase tracking-wider flex items-center gap-1 border border-emerald-500/20 animate-pulse">
                      ● FACE-TO-FACE ACTIVE
                    </span>
                  ) : (
                    <span className="bg-amber-500/10 text-amber-600 px-2.5 py-0.5 rounded text-[9px] font-black uppercase tracking-wider flex items-center gap-1 border border-amber-500/20">
                      ⚠️ ALIGNMENT REQUIRED
                    </span>
                  )}
                </div>
                
                {selectedGiverObj && selectedTakerObj ? (
                  <div className="space-y-6">
                    {/* Visual Face-to-Face Alignment Workspace */}
                    <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800 relative overflow-hidden">
                      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.08)_0%,transparent_100%)] pointer-events-none"></div>
                      
                      <div className="relative grid md:grid-cols-7 gap-4 items-center">
                        {/* GIVER CARD - FACING RIGHT */}
                        <div className={`col-span-2 p-4 rounded-xl border transition-all duration-500 text-center space-y-2 bg-slate-950/40 ${
                          isFaceToFaceAligned 
                            ? 'border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.15)] ring-2 ring-emerald-500/20' 
                            : 'border-slate-800'
                        }`}>
                          <div className="mx-auto w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 text-lg font-black transition-transform duration-500 relative">
                            👤
                            <div className={`absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-slate-950 flex items-center justify-center text-[7px] font-bold text-white transition-transform duration-500 ${isFaceToFaceAligned ? 'rotate-90 scale-110' : ''}`}>
                              ➔
                            </div>
                          </div>
                          <div>
                            <span className="text-[8px] font-black uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">Giver (Source Help)</span>
                            <h5 className="font-extrabold text-white text-sm mt-1.5 truncate">{selectedGiverObj.userName}</h5>
                            <p className="text-[9px] text-slate-400 font-mono mt-0.5">Pledge: ₹{selectedGiverObj.amount.toLocaleString()}</p>
                          </div>
                        </div>

                        {/* PEER-TO-PEER INTERACTIVE ALIGNMENT BRIDGE */}
                        <div className="col-span-3 text-center space-y-3 px-2">
                          {!isFaceToFaceAligned ? (
                            <div className="space-y-3">
                              <p className="text-[10px] text-slate-300 font-semibold leading-relaxed">
                                Under P2P protocols, you must position both members face-to-face to authorize direct aid transfers.
                              </p>
                              <button
                                type="button"
                                onClick={() => {
                                  setIsFaceToFaceAligned(true);
                                }}
                                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 cursor-pointer border border-indigo-500"
                              >
                                🔄 Place Members Face-to-Face
                              </button>
                            </div>
                          ) : (
                            <div className="space-y-2 py-2">
                              <div className="flex items-center justify-center gap-1 text-emerald-400">
                                <CheckCircle className="w-4 h-4 animate-bounce" />
                                <span className="text-[10px] font-black uppercase tracking-widest">P2P Peer Connection Established</span>
                              </div>
                              
                              {/* Direct flow arrow animation */}
                              <div className="flex justify-center items-center gap-2 py-1">
                                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                                <div className="h-0.5 bg-gradient-to-r from-emerald-500 to-amber-500 flex-1 max-w-[120px] relative">
                                  <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1.5 h-1.5 border-t-2 border-r-2 border-amber-500 rotate-45"></div>
                                </div>
                                <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-ping"></span>
                              </div>

                              <p className="text-[10px] text-emerald-300 font-semibold">
                                Both members are now face-to-face. Ready to complete direct aid.
                              </p>
                            </div>
                          )}
                        </div>

                        {/* TAKER CARD - FACING LEFT */}
                        <div className={`col-span-2 p-4 rounded-xl border transition-all duration-500 text-center space-y-2 bg-slate-950/40 ${
                          isFaceToFaceAligned 
                            ? 'border-amber-500/50 shadow-[0_0_15px_rgba(245,158,11_0.15)] ring-2 ring-amber-500/20' 
                            : 'border-slate-800'
                        }`}>
                          <div className="mx-auto w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30 text-lg font-black transition-transform duration-500 relative">
                            👤
                            <div className={`absolute bottom-0 left-0 w-3.5 h-3.5 bg-amber-500 rounded-full border-2 border-slate-950 flex items-center justify-center text-[7px] font-bold text-white transition-transform duration-500 ${isFaceToFaceAligned ? '-rotate-90 scale-110' : ''}`}>
                              ➔
                            </div>
                          </div>
                          <div>
                            <span className="text-[8px] font-black uppercase tracking-wider text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded">Taker (Receiver)</span>
                            <h5 className="font-extrabold text-white text-sm mt-1.5 truncate">{selectedTakerObj.name}</h5>
                            <p className="text-[9px] text-slate-400 font-mono mt-0.5">Need: ₹{selectedTakerObj.amountNeeded.toLocaleString()}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* MATCH SETTINGS FORM */}
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/60 space-y-4">
                      <div className="grid sm:grid-cols-4 gap-4 items-end">
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5">Specify P2P Transfer Amount (INR)</label>
                          <input
                            type="number"
                            placeholder="Enter Match Value (e.g. 40, 50)"
                            value={manualMatchAmount}
                            onChange={(e) => setManualMatchAmount(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold focus:outline-none focus:border-indigo-500 text-slate-800"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5">Admin's Gateway Link (Required for Giver & Taker to see)</label>
                          <input
                            type="text"
                            placeholder="e.g. https://help100.com/secure-gateway/admin-payment-link"
                            value={manualAdminLink}
                            onChange={(e) => setManualAdminLink(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold focus:outline-none focus:border-indigo-500 text-slate-800"
                          />
                        </div>
                      </div>

                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5">Giver's PH Payment Link (To send to Giver/PH)</label>
                          <input
                            type="text"
                            placeholder="e.g. https://help100.com/secure-gateway/ph/giver-contrib-xyz"
                            value={manualGiverLink}
                            onChange={(e) => setManualGiverLink(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold focus:outline-none focus:border-indigo-500 text-slate-800"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5">Taker's GH Payout Link (To send to Taker/GH)</label>
                          <input
                            type="text"
                            placeholder="e.g. https://help100.com/secure-gateway/gh/taker-payout-abc"
                            value={manualTakerLink}
                            onChange={(e) => setManualTakerLink(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold focus:outline-none focus:border-indigo-500 text-slate-800"
                          />
                        </div>
                      </div>

                      <div className="pt-2">
                        <button
                          type="button"
                          disabled={!isFaceToFaceAligned}
                          onClick={() => {
                            if (!isFaceToFaceAligned) {
                              alert('Warning: You must place the members face-to-face first using the workspace above.');
                              return;
                            }

                            if (!manualGiverId || !manualTakerId || !manualMatchAmount) {
                              alert('Please select a Giver, a Taker, and specify the Match Amount.');
                              return;
                            }

                            const amt = parseFloat(manualMatchAmount);
                            if (isNaN(amt) || amt <= 0) {
                              alert('Please enter a valid positive number for match amount.');
                              return;
                            }

                            const giver = contributions.find(c => c.id === manualGiverId);
                            const takerHelp = helpRequests.find(h => h.id === manualTakerId);
                            const takerTx = transactions.find(t => t.id === manualTakerId);

                            if (!giver || (!takerHelp && !takerTx)) {
                              alert('Selected Giver or Taker not found.');
                              return;
                            }

                            const takerMatchSum = p2pMatches.filter(m => m.takerId === manualTakerId && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0);
                            const remainingNeed = takerHelp 
                              ? Math.max(0, takerHelp.amountRequested - Math.max(takerHelp.amountReceived, takerMatchSum))
                              : (takerTx ? Math.max(0, takerTx.amount - takerMatchSum) : 0);

                            if (amt > giver.amount) {
                              alert(`Warning: Match amount (₹${amt}) exceeds Giver's available pledge limit (₹${giver.amount}).`);
                              return;
                            }
                            if (amt > remainingNeed) {
                              alert(`Warning: Match amount (₹${amt}) exceeds Taker's remaining need or withdrawal request (₹${remainingNeed}).`);
                              return;
                            }

                            const success = onManualMatch(
                              manualGiverId,
                              manualTakerId,
                              amt,
                              manualGiverLink.trim(),
                              manualTakerLink.trim(),
                              manualAdminLink.trim()
                            );
                            if (success) {
                              const targetName = takerHelp ? takerHelp.userName : (takerTx ? takerTx.userName : 'Taker');
                              alert(`P2P Route established face-to-face! ₹${amt} is matched from Giver ${giver.userName} directly to Taker ${targetName}. Custom dispatch links have been assigned and notified.`);
                              setManualGiverId('');
                              setManualTakerId('');
                              setManualMatchAmount('');
                              setManualGiverLink('');
                              setManualTakerLink('');
                              setManualAdminLink('');
                              setIsFaceToFaceAligned(false);
                            } else {
                              alert('Failed to establish manual match. Please check fields.');
                            }
                          }}
                          className={`w-full py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-colors duration-200 cursor-pointer text-center ${
                            isFaceToFaceAligned 
                              ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/10' 
                              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                          }`}
                        >
                          Establish P2P Route with Custom Links
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="border border-dashed border-slate-200 bg-slate-50/50 rounded-2xl p-8 text-center text-slate-400 space-y-2">
                    <p className="text-xs italic font-medium">No active pair loaded into the routing workspace.</p>
                    <p className="text-[10px] text-slate-400 max-w-sm mx-auto font-medium leading-relaxed">
                      Please select a <strong className="text-indigo-600">Giver</strong> and a <strong className="text-amber-600">Receiver</strong> from the lists below to position them face-to-face and authorize peer-to-peer routing.
                    </p>
                  </div>
                )}
              </div>

              {/* SEPARATED WORKSPACE COLUMNS: GIVERS & RECEIVERS */}
              <div className="grid lg:grid-cols-2 gap-8">
                {/* COLUMN 1: GIVING MEMBERS (GIVERS) */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-4 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
                          <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                          Givers: Giving Help List
                        </h4>
                        <p className="text-[11px] text-slate-400">Members with approved unmatched pledges ready to give.</p>
                      </div>
                      <span className="text-[10px] font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full">
                        {unifiedGiversQueue.length} Available
                      </span>
                    </div>

                    {/* Search filter for Givers */}
                    <div>
                      <input
                        type="text"
                        placeholder="Search Giving Members..."
                        value={matchGiverSearch}
                        onChange={(e) => setMatchGiverSearch(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-medium focus:outline-none focus:border-indigo-500"
                      />
                    </div>

                    {/* List container */}
                    <div className="max-h-[300px] overflow-y-auto border border-slate-100 rounded-xl divide-y divide-slate-100 bg-slate-50/50">
                      {(() => {
                        const filteredUnmatchedGivers = unifiedGiversQueue.filter(g => 
                          g.userName.toLowerCase().includes(matchGiverSearch.toLowerCase()) || 
                          g.id.toLowerCase().includes(matchGiverSearch.toLowerCase()) ||
                          g.userId.toLowerCase().includes(matchGiverSearch.toLowerCase())
                        );

                        if (filteredUnmatchedGivers.length === 0) {
                          return (
                            <div className="text-center py-8 text-slate-400 font-mono text-[11px] italic">
                              No active giving help users found.
                            </div>
                          );
                        }

                        return filteredUnmatchedGivers.map(giver => {
                          const isSelected = manualGiverId === giver.id || manualGiverId === giver.userId;
                          return (
                            <div 
                              key={giver.id} 
                              className={`p-3 flex justify-between items-center transition-colors ${
                                isSelected ? 'bg-indigo-50/60 border-l-2 border-indigo-600' : 'hover:bg-slate-50'
                              }`}
                            >
                              <div className="space-y-0.5">
                                <p className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                                  {giver.userName}
                                  {giver.status === 'pin_active' && (
                                    <span className="bg-emerald-100 text-emerald-800 text-[8px] font-black px-1.5 py-0.5 rounded">
                                      PIN Active
                                    </span>
                                  )}
                                </p>
                                <p className="text-[10px] text-slate-400 font-medium">ID: <span className="font-mono">{giver.id.substring(0,12)}</span> | Cycle #{giver.cycleCount || 1}</p>
                              </div>
                              <div className="flex items-center gap-3">
                                <span className="font-black text-emerald-600 text-xs">₹{giver.availablePledge.toLocaleString()}</span>
                                <button
                                  onClick={() => {
                                    setManualGiverId(giver.id);
                                    setManualMatchAmount(giver.availablePledge.toString());
                                    setIsFaceToFaceAligned(false);
                                  }}
                                  className={`px-2.5 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider cursor-pointer transition-colors ${
                                    isSelected 
                                      ? 'bg-indigo-600 text-white' 
                                      : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700'
                                  }`}
                                >
                                  {isSelected ? 'Selected' : '👉 Select Giver'}
                                </button>
                              </div>
                            </div>
                          );
                        });
                      })()}
                    </div>
                  </div>
                </div>

                {/* COLUMN 2: RECEIVING MEMBERS (TAKERS) */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-4 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
                          <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse"></span>
                          Receivers: Taking Help List
                        </h4>
                        <p className="text-[11px] text-slate-400">Members needing help (Get Help Campaigns & Withdrawals).</p>
                      </div>
                      <span className="text-[10px] font-bold bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full">
                        {(() => {
                          const openGetHelpCount = helpRequests.filter(h => {
                            if (h.status === 'completed') return false;
                            const mSum = p2pMatches.filter(m => m.takerId === h.id && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0);
                            return Math.max(h.amountReceived, mSum) < h.amountRequested;
                          }).length;
                          const activeWithdrawalsCount = transactions.filter(t => {
                            if (t.type !== 'withdrawal' || t.status === 'rejected') return false;
                            const mSum = p2pMatches.filter(m => m.takerId === t.id && m.status !== 'rejected').reduce((s, m) => s + m.amount, 0);
                            return mSum < t.amount;
                          }).length;
                          return openGetHelpCount + activeWithdrawalsCount;
                        })()} Active
                      </span>
                    </div>

                    {/* Search filter for Receivers */}
                    <div>
                      <input
                        type="text"
                        placeholder="Search Receiving Members..."
                        value={matchReceiverSearch}
                        onChange={(e) => setMatchReceiverSearch(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-medium focus:outline-none focus:border-indigo-500"
                      />
                    </div>

                    {/* List container */}
                    <div className="max-h-[300px] overflow-y-auto border border-slate-100 rounded-xl divide-y divide-slate-100 bg-slate-50/50">
                      {(() => {
                        const openGetHelp = helpRequests.filter(h => {
                          if (h.status === 'completed') return false;
                          const matchSum = p2pMatches.filter(m => m.takerId === h.id && m.status !== 'rejected').reduce((sum, m) => sum + m.amount, 0);
                          const rec = Math.max(h.amountReceived, matchSum);
                          return rec < h.amountRequested;
                        });
                        const activeWithdrawals = transactions.filter(t => {
                          if (t.type !== 'withdrawal' || t.status === 'rejected') return false;
                          const matchSum = p2pMatches.filter(m => m.takerId === t.id && m.status !== 'rejected').reduce((sum, m) => sum + m.amount, 0);
                          return matchSum < t.amount;
                        });

                        const combinedReceivers = [
                          ...openGetHelp.map(h => {
                            const matchSum = p2pMatches.filter(m => m.takerId === h.id && m.status !== 'rejected').reduce((sum, m) => sum + m.amount, 0);
                            const rec = Math.max(h.amountReceived, matchSum);
                            return {
                              id: h.id,
                              name: h.userName,
                              type: 'get_help' as const,
                              title: h.title,
                              amountNeeded: Math.max(0, h.amountRequested - rec),
                              totalAmount: h.amountRequested,
                              info: `Campaign: ${h.title}`
                            };
                          }),
                          ...activeWithdrawals.map(w => {
                            const matchSum = p2pMatches.filter(m => m.takerId === w.id && m.status !== 'rejected').reduce((sum, m) => sum + w.amount, 0);
                            return {
                              id: w.id,
                              name: w.userName,
                              type: 'withdrawal' as const,
                              title: `Withdrawal request via ${w.walletSource?.toUpperCase() || 'Wallet'}`,
                              amountNeeded: Math.max(0, w.amount - matchSum),
                              totalAmount: w.amount,
                              info: `Withdrawal request`
                            };
                          })
                        ];

                        const filteredReceivers = combinedReceivers.filter(r => 
                          r.name.toLowerCase().includes(matchReceiverSearch.toLowerCase()) || 
                          r.title.toLowerCase().includes(matchReceiverSearch.toLowerCase()) ||
                          r.id.toLowerCase().includes(matchReceiverSearch.toLowerCase())
                        );

                        if (filteredReceivers.length === 0) {
                          return (
                            <div className="text-center py-8 text-slate-400 font-mono text-[11px] italic">
                              No active receiving help users found.
                            </div>
                          );
                        }

                        return filteredReceivers.map(receiver => {
                          const isSelected = manualTakerId === receiver.id;
                          return (
                            <div 
                              key={receiver.id} 
                              className={`p-3 flex justify-between items-center transition-colors ${
                                isSelected ? 'bg-indigo-50/60 border-l-2 border-indigo-600' : 'hover:bg-slate-50'
                              }`}
                            >
                              <div className="space-y-0.5">
                                <div className="flex items-center gap-1.5">
                                  <p className="font-bold text-slate-800 text-xs">{receiver.name}</p>
                                  {receiver.type === 'withdrawal' ? (
                                    <span className="text-[8px] font-black uppercase tracking-wider px-1 bg-amber-100 text-amber-800 rounded">Withdrawal</span>
                                  ) : (
                                    <span className="text-[8px] font-black uppercase tracking-wider px-1 bg-emerald-100 text-emerald-800 rounded">Get Help</span>
                                  )}
                                </div>
                                <p className="text-[10px] text-slate-400 font-medium line-clamp-1">{receiver.title}</p>
                                <p className="text-[9px] text-slate-400 font-mono">Taker ID: {receiver.id.substring(0,8)}</p>
                              </div>
                              <div className="flex items-center gap-3">
                                <span className="font-black text-amber-600 text-xs">₹{receiver.amountNeeded.toLocaleString()}</span>
                                <button
                                  onClick={() => {
                                    setManualTakerId(receiver.id);
                                    // Pre-populate with either the Giver's amount or remaining need (whichever is lower)
                                    const giverObj = contributions.find(c => c.id === manualGiverId);
                                    if (giverObj) {
                                      setManualMatchAmount(Math.min(giverObj.amount, receiver.amountNeeded).toString());
                                    } else {
                                      setManualMatchAmount(receiver.amountNeeded.toString());
                                    }
                                    setIsFaceToFaceAligned(false);
                                  }}
                                  className={`px-2.5 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider cursor-pointer transition-colors ${
                                    isSelected 
                                      ? 'bg-indigo-600 text-white' 
                                      : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700'
                                  }`}
                                >
                                  {isSelected ? 'Selected' : '👈 Select Receiver'}
                                </button>
                              </div>
                            </div>
                          );
                        });
                      })()}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* P2P Pairs Direct Routing Ledger */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div>
                <h3 className="font-bold text-slate-900 text-lg font-sans tracking-tight">P2P Giving & Taking Live Matches Ledger</h3>
                <p className="text-xs text-slate-500 mt-0.5">Live routing sheet displaying direct member-to-member matched aid contributions.</p>
              </div>

              <div className="overflow-x-auto border border-slate-100 rounded-xl bg-slate-50 p-2">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 uppercase tracking-wider text-[10px] font-bold">
                      <th className="p-3">Match ID</th>
                      <th className="p-3">Giver (Giving Help)</th>
                      <th className="p-3">Taker (Taking Help)</th>
                      <th className="p-3">Matched Value</th>
                      <th className="p-3">Consensus Date</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Actions / Verification Proof</th>
                    </tr>
                  </thead>
                  <tbody>
                    {p2pMatches.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="text-center py-8 text-slate-400 font-mono text-xs">
                          No active Peer-to-Peer matches in memory. Try running the Matching engine or toggle Auto-Matching!
                        </td>
                      </tr>
                    ) : (
                      p2pMatches.map(match => (
                        <React.Fragment key={match.id}>
                          <tr className="border-b border-slate-100 bg-white hover:bg-slate-50 transition-colors">
                            <td className="p-3 font-mono font-bold text-slate-500">
                              {match.id.substring(0, 8).toUpperCase()}
                            </td>
                            <td className="p-3 font-bold text-slate-700">
                              <div className="flex flex-col gap-1">
                                <span>{match.giverName}</span>
                                {match.phLink ? (
                                  <span className="inline-flex items-center gap-1 w-fit px-1.5 py-0.5 rounded text-[8px] font-black uppercase bg-indigo-50 text-indigo-700 border border-indigo-200">
                                    🔗 PH Link Active
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 w-fit px-1.5 py-0.5 rounded text-[8px] font-medium bg-slate-50 text-slate-400 border border-slate-200">
                                    No PH Link yet
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="p-3 font-bold text-slate-700">
                              <div className="flex flex-col gap-1">
                                <span>{match.takerName}</span>
                                {match.takerType === 'withdrawal' || transactions.some(t => t.id === match.takerId && t.type === 'withdrawal') ? (
                                  <span className="inline-flex items-center gap-1 w-fit px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-amber-50 text-amber-700 border border-amber-200">
                                    💸 Withdrawal Request
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 w-fit px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-emerald-50 text-emerald-700 border border-emerald-200">
                                    💖 Get Help Campaign
                                  </span>
                                )}
                                {match.ghLink ? (
                                  <span className="inline-flex items-center gap-1 w-fit px-1.5 py-0.5 rounded text-[8px] font-black uppercase bg-amber-50 text-amber-700 border border-amber-200">
                                    🔗 GH Link Active
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 w-fit px-1.5 py-0.5 rounded text-[8px] font-medium bg-slate-50 text-slate-400 border border-slate-200">
                                    No GH Link yet
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="p-3 font-black text-emerald-600">₹{match.amount}</td>
                            <td className="p-3 text-slate-400">{new Date(match.createdAt).toLocaleDateString()}</td>
                            <td className="p-3">
                              {match.status === 'pending' && (
                                <span className="px-2 py-0.5 rounded text-[9px] font-black bg-amber-50 text-amber-700 border border-amber-200">
                                  PENDING PAYMENT
                                </span>
                              )}
                              {match.status === 'pending_verification' && (
                                <span className="px-2 py-0.5 rounded text-[9px] font-black bg-indigo-50 text-indigo-700 border border-indigo-200 animate-pulse">
                                  PENDING VERIFICATION
                                </span>
                              )}
                              {match.status === 'completed' && (
                                <span className="px-2 py-0.5 rounded text-[9px] font-black bg-emerald-50 text-emerald-700 border border-emerald-200">
                                  COMPLETED & VERIFIED
                                </span>
                              )}
                              {match.status === 'rejected' && (
                                <span className="px-2 py-0.5 rounded text-[9px] font-black bg-red-50 text-red-700 border border-red-200">
                                  REJECTED / RE-UPLOAD
                                </span>
                              )}
                            </td>
                            <td className="p-3">
                              <div className="flex flex-col gap-1">
                                {match.screenshotUrl ? (
                                  <div className="text-[10px] text-slate-600 font-mono font-medium flex items-center gap-1">
                                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                                    File: <strong className="text-indigo-600 underline cursor-pointer" onClick={() => alert(`Showing receipt proof: ${match.screenshotUrl}`)} title="Click to view file name">{match.screenshotUrl}</strong>
                                  </div>
                                ) : (
                                  <span className="text-[10px] text-slate-400 italic">No receipt uploaded yet</span>
                                )}

                                {match.status === 'pending_verification' && (
                                  <div className="flex gap-1.5 mt-1">
                                    <button
                                      onClick={() => {
                                        if (onApproveP2PMatch) {
                                          onApproveP2PMatch(match.id);
                                          alert(`P2P Match ${match.id} successfully verified and completed!`);
                                        }
                                      }}
                                      className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[9px] font-black uppercase transition-all cursor-pointer"
                                    >
                                      Verify & Approve
                                    </button>
                                    <button
                                      onClick={() => {
                                        if (onRejectP2PMatch) {
                                          onRejectP2PMatch(match.id);
                                          alert(`P2P Match ${match.id} payment proof has been rejected.`);
                                        }
                                      }}
                                      className="px-2 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-[9px] font-black uppercase transition-all cursor-pointer"
                                    >
                                      Reject
                                    </button>
                                  </div>
                                )}
                                
                                {match.status === 'completed' && (
                                  <span className="text-[9px] font-bold text-emerald-600">✓ Fully verified by Admin</span>
                                )}
                                {match.status === 'rejected' && (
                                  <span className="text-[9px] font-bold text-red-500">✗ Proof rejected</span>
                                )}

                                <button
                                  type="button"
                                  onClick={() => {
                                    if (editingMatchLinksId === match.id) {
                                      setEditingMatchLinksId(null);
                                    } else {
                                      setEditingMatchLinksId(match.id);
                                      setTempPhLink(match.phLink || '');
                                      setTempGhLink(match.ghLink || '');
                                    }
                                  }}
                                  className="mt-1.5 px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded text-[9px] font-black uppercase flex items-center justify-center gap-1 cursor-pointer"
                                >
                                  🔗 Send PH & GH Link
                                </button>
                              </div>
                            </td>
                          </tr>

                          {editingMatchLinksId === match.id && (
                            <tr className="bg-indigo-50/40 border-b border-slate-100">
                              <td colSpan={7} className="p-4">
                                <div className="bg-white border border-indigo-100 p-4 rounded-xl space-y-3 shadow-xs">
                                  <div className="flex justify-between items-center">
                                    <h5 className="text-[10px] font-black uppercase tracking-wider text-indigo-950 flex items-center gap-1.5">
                                      <span>🔗 Direct Link Dispatches for Match {match.id.substring(0,8).toUpperCase()}</span>
                                    </h5>
                                    <button 
                                      onClick={() => setEditingMatchLinksId(null)}
                                      className="text-slate-400 hover:text-slate-600 text-xs font-bold"
                                    >
                                      ✕ Close
                                    </button>
                                  </div>
                                  <p className="text-[11px] text-slate-500 leading-relaxed">
                                    Enter specific URLs/Links below. The Giver will see the PH Link on their dashboard; the Taker will see the GH Link on theirs.
                                  </p>
                                  <div className="grid sm:grid-cols-2 gap-4">
                                    <div className="space-y-1">
                                      <label className="block text-[9px] font-black uppercase tracking-wider text-slate-500">PH Link (For Giver: {match.giverName})</label>
                                      <input 
                                        type="text"
                                        placeholder="e.g. https://upi.example.com/pay/..."
                                        value={tempPhLink}
                                        onChange={(e) => setTempPhLink(e.target.value)}
                                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-medium focus:outline-none focus:border-indigo-500"
                                      />
                                    </div>
                                    <div className="space-y-1">
                                      <label className="block text-[9px] font-black uppercase tracking-wider text-slate-500">GH Link (For Taker: {match.takerName})</label>
                                      <input 
                                        type="text"
                                        placeholder="e.g. https://gateway.example.com/claim/..."
                                        value={tempGhLink}
                                        onChange={(e) => setTempGhLink(e.target.value)}
                                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-medium focus:outline-none focus:border-indigo-500"
                                      />
                                    </div>
                                  </div>
                                  <div className="flex justify-end gap-2 pt-1">
                                    <button
                                      type="button"
                                      onClick={() => setEditingMatchLinksId(null)}
                                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-bold uppercase cursor-pointer"
                                    >
                                      Cancel
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        if (onUpdateP2PMatch) {
                                          onUpdateP2PMatch(match.id, {
                                            phLink: tempPhLink.trim(),
                                            ghLink: tempGhLink.trim(),
                                            isPhLinkSent: !!tempPhLink.trim(),
                                            isGhLinkSent: !!tempGhLink.trim()
                                          });
                                          
                                          // Add notification to Giver
                                          if (tempPhLink.trim()) {
                                            const notifGiver: Notification = {
                                              id: Math.random().toString(36).substr(2, 9),
                                              userId: match.giverUserId,
                                              title: '🔗 Admin Sent PH Payment Link',
                                              message: `The administrator has attached a payment link for your ₹${match.amount} contribution to ${match.takerName}. Click to open link: ${tempPhLink.trim()}`,
                                              type: 'info',
                                              read: false,
                                              createdAt: new Date().toISOString()
                                            };
                                            onAddNotification(notifGiver);

                                            // Copy to Admin ALSO
                                            const notifAdminPh: Notification = {
                                              id: Math.random().toString(36).substr(2, 9),
                                              userId: 'admin-id',
                                              title: '🔗 PH Link Logged (Admin Copy)',
                                              message: `Dispatched PH link for Giver ${match.giverName} (Amount: ₹${match.amount}). Link: ${tempPhLink.trim()}`,
                                              type: 'success',
                                              read: false,
                                              createdAt: new Date().toISOString()
                                            };
                                            onAddNotification(notifAdminPh);
                                          }

                                          // Add notification to Taker
                                          if (tempGhLink.trim()) {
                                            const notifTaker: Notification = {
                                              id: Math.random().toString(36).substr(2, 9),
                                              userId: match.takerUserId,
                                              title: '🔗 Admin Sent GH Claim Link',
                                              message: `The administrator has attached a payout link for your ₹${match.amount} aid from ${match.giverName}. Click to open link: ${tempGhLink.trim()}`,
                                              type: 'info',
                                              read: false,
                                              createdAt: new Date().toISOString()
                                            };
                                            onAddNotification(notifTaker);

                                            // Copy to Admin ALSO
                                            const notifAdminGh: Notification = {
                                              id: Math.random().toString(36).substr(2, 9),
                                              userId: 'admin-id',
                                              title: '🔗 GH Link Logged (Admin Copy)',
                                              message: `Dispatched GH link for Taker ${match.takerName} (Amount: ₹${match.amount}). Link: ${tempGhLink.trim()}`,
                                              type: 'success',
                                              read: false,
                                              createdAt: new Date().toISOString()
                                            };
                                            onAddNotification(notifAdminGh);
                                          }

                                          alert('PH and GH links updated successfully and notifications dispatched!');
                                          setEditingMatchLinksId(null);
                                        } else {
                                          alert('onUpdateP2PMatch is not defined.');
                                        }
                                      }}
                                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[10px] font-black uppercase cursor-pointer"
                                    >
                                      Dispatch & Send Links
                                    </button>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeAdminTab === 'audit_history' && (
          <div className="space-y-6">
            {/* AUDIT HISTORY TITLE PANEL */}
            <div className="bg-slate-900 text-slate-100 p-8 rounded-3xl relative overflow-hidden shadow-xl border border-slate-800">
              <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
              <div className="absolute left-1/3 bottom-0 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

              <div className="relative flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/20 text-indigo-300 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-500/30">
                    <History className="w-3.5 h-3.5" /> Security Logging & Routing Ledger
                  </div>
                  <h2 className="text-2xl md:text-3xl font-extrabold font-sans tracking-tight text-white">
                    P2P Direct Match Audit History
                  </h2>
                  <p className="text-xs text-slate-400 max-w-2xl font-medium leading-relaxed">
                    Complete cryptographic-style logs of all direct peer-to-peer matched contributions. Easily search, filter, and audit manual routings, automated batch pairings, and completion status.
                  </p>
                </div>
                
                {/* Reset Filters and Download Logs buttons */}
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setAuditSearchQuery('');
                      setAuditMethodFilter('all');
                      setAuditStatusFilter('all');
                      setAuditTypeFilter('all');
                      setExpandedAuditMatchId(null);
                    }}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-4 py-2 rounded-xl text-xs font-bold transition-all border border-slate-700 hover:border-slate-600 flex items-center gap-2 cursor-pointer"
                  >
                    Clear Filters
                  </button>
                  <button
                    onClick={() => {
                      // Simple download CSV action
                      const headers = ['Match ID', 'Giver Name', 'Giver Email', 'Taker Name', 'Taker Email', 'Type', 'Amount (INR)', 'Method', 'Status', 'Timestamp'];
                      const matchesList = p2pMatches || [];
                      const rows = matchesList.map(m => {
                        const mId = m?.id || '';
                        const giverName = m?.giverName || 'N/A';
                        const giverEmail = m?.giverEmail || 'N/A';
                        const takerName = m?.takerName || 'N/A';
                        const takerEmail = m?.takerEmail || 'N/A';
                        const matchType = m?.takerType || (((transactions || []).some(t => t?.id && m?.takerId && t.id === m.takerId && t.type === 'withdrawal')) ? 'withdrawal' : 'get_help');
                        const amount = m?.amount || 0;
                        const matchMethod = m?.matchMethod || (m?.paymentDetails?.toLowerCase().includes('manual') ? 'manual' : 'auto');
                        const status = m?.status || 'pending';
                        const createdAt = m?.createdAt || '';
                        return [
                          mId,
                          giverName,
                          giverEmail,
                          takerName,
                          takerEmail,
                          matchType,
                          amount,
                          matchMethod,
                          status,
                          createdAt
                        ];
                      });
                      
                      const csvContent = "data:text/csv;charset=utf-8," 
                        + [headers.join(','), ...rows.map(e => e.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))].join('\n');
                      
                      const encodedUri = encodeURI(csvContent);
                      const link = document.createElement("a");
                      link.setAttribute("href", encodedUri);
                      link.setAttribute("download", `p2p_audit_matches_log_${new Date().toISOString().split('T')[0]}.csv`);
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);
                    }}
                    className="bg-amber-50 hover:bg-amber-400 text-slate-950 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer"
                  >
                    📥 Export Ledger (CSV)
                  </button>
                </div>
              </div>
            </div>

            {/* AUDIT METRIC BENTO CARDS */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Total Card */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
                <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Matches Routed</span>
                <div className="mt-2">
                  <h3 className="text-2xl font-black text-slate-900">₹{(p2pMatches || []).reduce((sum, m) => sum + (m?.amount || 0), 0).toLocaleString()}</h3>
                  <p className="text-xs text-slate-500 font-bold mt-1">Total {(p2pMatches || []).length} pairings routed</p>
                </div>
              </div>

              {/* Auto matches card */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
                <span className="text-[10px] font-black uppercase text-indigo-600 tracking-wider flex items-center gap-1">
                  <span className="h-2 w-2 rounded-full bg-indigo-500"></span>
                  🤖 Automated Pairings
                </span>
                <div className="mt-2">
                  <h3 className="text-2xl font-black text-slate-900">
                    ₹{(p2pMatches || []).filter(m => (m?.matchMethod || (m?.paymentDetails?.toLowerCase().includes('manual') ? 'manual' : 'auto')) === 'auto').reduce((sum, m) => sum + (m?.amount || 0), 0).toLocaleString()}
                  </h3>
                  <p className="text-xs text-indigo-600 font-extrabold mt-1">
                    {(p2pMatches || []).filter(m => (m?.matchMethod || (m?.paymentDetails?.toLowerCase().includes('manual') ? 'manual' : 'auto')) === 'auto').length} batch operations executed
                  </p>
                </div>
              </div>

              {/* Manual matches card */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
                <span className="text-[10px] font-black uppercase text-emerald-600 tracking-wider flex items-center gap-1">
                  <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
                  ✍️ Administrative Routings
                </span>
                <div className="mt-2">
                  <h3 className="text-2xl font-black text-slate-900">
                    ₹{(p2pMatches || []).filter(m => (m?.matchMethod || (m?.paymentDetails?.toLowerCase().includes('manual') ? 'manual' : 'auto')) === 'manual').reduce((sum, m) => sum + (m?.amount || 0), 0).toLocaleString()}
                  </h3>
                  <p className="text-xs text-emerald-600 font-extrabold mt-1">
                    {(p2pMatches || []).filter(m => (m?.matchMethod || (m?.paymentDetails?.toLowerCase().includes('manual') ? 'manual' : 'auto')) === 'manual').length} bespoke matches established
                  </p>
                </div>
              </div>

              {/* Average Pairing size card */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
                <span className="text-[10px] font-black uppercase text-amber-600 tracking-wider">Average Ticket Volume</span>
                <div className="mt-2">
                  <h3 className="text-2xl font-black text-slate-900">
                    ₹{(p2pMatches || []).length > 0 ? Math.round((p2pMatches || []).reduce((sum, m) => sum + (m?.amount || 0), 0) / (p2pMatches || []).length).toLocaleString() : '0'}
                  </h3>
                  <p className="text-xs text-amber-600 font-extrabold mt-1">
                    Average size of community match
                  </p>
                </div>
              </div>
            </div>

            {/* AUDIT SEARCH & FILTER BAR */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex flex-col lg:flex-row gap-4 justify-between items-stretch">
                {/* Search input */}
                <div className="flex-1 relative">
                  <input
                    type="text"
                    placeholder="Search by Match ID, Giver or Taker Name, Phone, Email..."
                    value={auditSearchQuery}
                    onChange={(e) => setAuditSearchQuery(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-4 pr-10 py-3 text-xs font-semibold placeholder:text-slate-400 text-slate-800 focus:outline-none focus:border-indigo-500"
                  />
                  <span className="absolute right-3 top-3.5 text-slate-400">🔍</span>
                </div>

                {/* Dropdown Filters */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Method Filter */}
                  <div>
                    <select
                      value={auditMethodFilter}
                      onChange={(e) => setAuditMethodFilter(e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-3 text-xs font-semibold text-slate-700 focus:outline-none focus:border-indigo-500"
                    >
                      <option value="all">🔄 All Match Methods</option>
                      <option value="auto">🤖 Automatic Engine</option>
                      <option value="manual">✍️ Manual Routing</option>
                    </select>
                  </div>

                  {/* Type Filter */}
                  <div>
                    <select
                      value={auditTypeFilter}
                      onChange={(e) => setAuditTypeFilter(e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-3 text-xs font-semibold text-slate-700 focus:outline-none focus:border-indigo-500"
                    >
                      <option value="all">💖 All Recipient Types</option>
                      <option value="get_help">💖 Get Help Campaigns</option>
                      <option value="withdrawal">💸 Withdrawal Requests</option>
                    </select>
                  </div>

                  {/* Status Filter */}
                  <div>
                    <select
                      value={auditStatusFilter}
                      onChange={(e) => setAuditStatusFilter(e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-3 text-xs font-semibold text-slate-700 focus:outline-none focus:border-indigo-500"
                    >
                      <option value="all">🟢 All Statuses</option>
                      <option value="completed">✅ Completed</option>
                      <option value="pending">⏳ Pending</option>
                      <option value="rejected">❌ Rejected</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* AUDIT LOG TABLE */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                <h3 className="font-bold text-slate-800 text-sm">Matches Audit Ledger ({
                  (p2pMatches || []).filter(match => {
                    if (!match) return false;
                    const query = (auditSearchQuery || '').toLowerCase();
                    const matchesSearch = !query || 
                      (match.id || '').toLowerCase().includes(query) ||
                      (match.giverName || '').toLowerCase().includes(query) ||
                      (match.giverEmail || '').toLowerCase().includes(query) ||
                      (match.takerName || '').toLowerCase().includes(query) ||
                      (match.takerEmail || '').toLowerCase().includes(query) ||
                      (match.giverPhone || '').includes(query) ||
                      (match.takerPhone || '').includes(query);

                    const method = match.matchMethod || (match.paymentDetails?.toLowerCase().includes('manual') ? 'manual' : 'auto');
                    const matchesMethod = auditMethodFilter === 'all' || method === auditMethodFilter;
                    const matchesStatus = auditStatusFilter === 'all' || match.status === auditStatusFilter;

                    const type = match.takerType || (((transactions || []).some(t => t?.id && match?.takerId && t.id === match.takerId && t.type === 'withdrawal')) ? 'withdrawal' : 'get_help');
                    const matchesType = auditTypeFilter === 'all' || type === auditTypeFilter;

                    return matchesSearch && matchesMethod && matchesStatus && matchesType;
                  }).length
                } records found)</h3>
                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest font-mono">
                  Showing matches log
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 uppercase tracking-wider text-[10px] font-bold bg-slate-50">
                      <th className="p-4">Match Details</th>
                      <th className="p-4">Route Method</th>
                      <th className="p-4">Source Giver (Provider)</th>
                      <th className="p-4">Destination Taker (Receiver)</th>
                      <th className="p-4">Volume</th>
                      <th className="p-4">Timestamp</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {(() => {
                      const list = (p2pMatches || []).filter(match => {
                        if (!match) return false;
                        const query = (auditSearchQuery || '').toLowerCase();
                        const matchesSearch = !query || 
                          (match.id || '').toLowerCase().includes(query) ||
                          (match.giverName || '').toLowerCase().includes(query) ||
                          (match.giverEmail || '').toLowerCase().includes(query) ||
                          (match.takerName || '').toLowerCase().includes(query) ||
                          (match.takerEmail || '').toLowerCase().includes(query) ||
                          (match.giverPhone || '').includes(query) ||
                          (match.takerPhone || '').includes(query);

                        const method = match.matchMethod || (match.paymentDetails?.toLowerCase().includes('manual') ? 'manual' : 'auto');
                        const matchesMethod = auditMethodFilter === 'all' || method === auditMethodFilter;
                        const matchesStatus = auditStatusFilter === 'all' || match.status === auditStatusFilter;

                        const type = match.takerType || (((transactions || []).some(t => t?.id && match?.takerId && t.id === match.takerId && t.type === 'withdrawal')) ? 'withdrawal' : 'get_help');
                        const matchesType = auditTypeFilter === 'all' || type === auditTypeFilter;

                        return matchesSearch && matchesMethod && matchesStatus && matchesType;
                      });

                      if (list.length === 0) {
                        return (
                          <tr>
                            <td colSpan={8} className="text-center py-12 text-slate-400 font-medium italic">
                              No audit records found matching the current filters. Clear the filters or search query to try again.
                            </td>
                          </tr>
                        );
                      }

                      return list.map(match => {
                        const isExpanded = expandedAuditMatchId === match.id;
                        const matchType = match.takerType || (((transactions || []).some(t => t?.id && match?.takerId && t.id === match.takerId && t.type === 'withdrawal')) ? 'withdrawal' : 'get_help');
                        const matchMethod = match.matchMethod || (match.paymentDetails?.toLowerCase().includes('manual') ? 'manual' : 'auto');

                        return (
                          <React.Fragment key={match.id}>
                            <tr className={`hover:bg-slate-50 transition-colors ${isExpanded ? 'bg-indigo-50/20' : ''}`}>
                              {/* Match Details ID */}
                              <td className="p-4">
                                <div className="space-y-1">
                                  <span className="font-mono font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded text-[11px] border border-slate-200">
                                    {match.id}
                                  </span>
                                </div>
                              </td>

                              {/* Route Method */}
                              <td className="p-4">
                                {matchMethod === 'auto' ? (
                                  <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-lg text-[10px] font-bold uppercase bg-indigo-50 text-indigo-700 border border-indigo-100">
                                    🤖 Auto Match
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-lg text-[10px] font-bold uppercase bg-emerald-50 text-emerald-700 border border-emerald-100">
                                    ✍️ Manual Route
                                  </span>
                                )}
                              </td>

                              {/* Giver Details */}
                              <td className="p-4">
                                <div className="space-y-0.5">
                                  <p className="font-extrabold text-slate-800">{match.giverName}</p>
                                  <p className="text-[10px] text-slate-400 font-medium">{match.giverEmail}</p>
                                  <p className="text-[9px] text-slate-400 font-mono font-bold">ID: {match.giverUserId.substring(0,8)}</p>
                                </div>
                              </td>

                              {/* Taker Details */}
                              <td className="p-4">
                                <div className="space-y-0.5">
                                  <p className="font-extrabold text-slate-800">{match.takerName}</p>
                                  <div className="flex items-center gap-1.5 mt-0.5">
                                    {matchType === 'withdrawal' ? (
                                      <span className="px-1.5 py-0.5 rounded text-[8px] font-black uppercase bg-amber-50 text-amber-700 border border-amber-200">
                                        Withdrawal
                                      </span>
                                    ) : (
                                      <span className="px-1.5 py-0.5 rounded text-[8px] font-black uppercase bg-emerald-50 text-emerald-700 border border-emerald-200">
                                        Aid Campaign
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-[9px] text-slate-400 font-mono font-bold">ID: {match.takerUserId.substring(0,8)}</p>
                                </div>
                              </td>

                              {/* Matched Volume (INR) */}
                              <td className="p-4">
                                <span className="font-black text-emerald-600 text-sm">
                                  ₹{match.amount.toLocaleString()}
                                </span>
                              </td>

                              {/* Timestamp */}
                              <td className="p-4">
                                <div className="space-y-0.5">
                                  <p className="font-semibold text-slate-600">{new Date(match.createdAt).toLocaleDateString()}</p>
                                  <p className="text-[10px] text-slate-400 font-mono">{new Date(match.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                                </div>
                              </td>

                              {/* Completion Status */}
                              <td className="p-4">
                                <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                                  match.status === 'completed' 
                                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                    : match.status === 'pending'
                                    ? 'bg-amber-100 text-amber-800 border border-amber-200'
                                    : 'bg-rose-100 text-rose-800 border border-rose-200'
                                }`}>
                                  {match.status}
                                </span>
                              </td>

                              {/* Action trigger to expand details */}
                              <td className="p-4 text-center">
                                <button
                                  onClick={() => setExpandedAuditMatchId(isExpanded ? null : match.id)}
                                  className="px-3 py-1.5 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 font-bold rounded-lg transition-all cursor-pointer text-[10px] uppercase tracking-wider"
                                >
                                  {isExpanded ? 'Hide Details' : 'View Details'}
                                </button>
                              </td>
                            </tr>

                            {/* Expanded Row Detail Details Panel */}
                            {isExpanded && (
                              <tr className="bg-slate-50/50">
                                <td colSpan={8} className="p-6 border-l-2 border-indigo-500">
                                  <div className="grid md:grid-cols-2 gap-6 text-xs">
                                    <div className="space-y-3">
                                      <h4 className="font-extrabold text-slate-700 uppercase tracking-wider text-[10px]">📋 Pair Correspondence & Route Ledger Info</h4>
                                      <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-2">
                                        <div className="flex justify-between">
                                          <span className="text-slate-400 font-medium">Unique Match UUID:</span>
                                          <span className="font-mono text-slate-800 font-bold">{match.id}</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-slate-400 font-medium">Route Matching Protocol:</span>
                                          <span className="font-bold text-slate-800">{matchMethod === 'auto' ? 'Automated Algorithmic Match' : 'Manual Route Protocol'}</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-slate-400 font-medium">Agreement Date & Time:</span>
                                          <span className="font-bold text-slate-700">{new Date(match.createdAt).toLocaleString()}</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-slate-400 font-medium">Target Category:</span>
                                          <span className="font-bold text-slate-800 uppercase">{matchType}</span>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="space-y-3">
                                      <h4 className="font-extrabold text-slate-700 uppercase tracking-wider text-[10px]">💬 Auto-Generated Communication Payload</h4>
                                      <div className="bg-indigo-50/50 p-4 rounded-xl border border-indigo-100 space-y-2.5">
                                        <div>
                                          <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">GIVER INSTRUCTIONS & DETAILS</p>
                                          <p className="text-slate-600 font-medium leading-relaxed mt-1">
                                            {match.giverName} was sent instructions to transfer ₹{match.amount} directly to {match.takerName}.
                                          </p>
                                          <p className="text-[10px] text-slate-400 mt-1 font-semibold">
                                            📞 Contact Phone: {match.giverPhone || 'N/A'} | ✉️ Contact Email: {match.giverEmail || 'N/A'}
                                          </p>
                                        </div>
                                        <hr className="border-indigo-100" />
                                        <div>
                                          <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">TRANSACTION / DISPATCH DETAILS</p>
                                          <p className="text-indigo-950 font-semibold font-mono text-[11px] mt-1 bg-white p-2 rounded border border-indigo-100/50">
                                            {match.paymentDetails || 'Direct member-to-member ledger sync.'}
                                          </p>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            )}
                          </React.Fragment>
                        );
                      });
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 14: OPTION TWO: PH & GH USER LISTS */}
        {activeAdminTab === 'option_two_ph_gh' && (
          <div className="space-y-8 animate-fade-in">
            {/* Header */}
            <div>
              <h1 className="text-2xl font-bold text-slate-900 font-sans tracking-tight">Option Two: Active PH & GH User Lists</h1>
              <p className="text-slate-500 text-sm">Full administrative directory tracking users in Provide Help (PH) and Get Help (GH) cycles.</p>
            </div>

            {/* Dashboard Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gradient-to-r from-indigo-900 to-indigo-950 p-5 rounded-2xl border border-indigo-800 text-white shadow-md">
                <div className="flex justify-between items-center">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-300">Total PH Contributions</span>
                    <h3 className="text-3xl font-black mt-1">₹{contributions.reduce((sum, c) => sum + c.amount, 0).toLocaleString()}</h3>
                    <p className="text-[11px] text-indigo-200/80 mt-1.5">{contributions.length} total registrations filed</p>
                  </div>
                  <div className="bg-indigo-500/20 p-3 rounded-xl border border-indigo-500/30">
                    <HeartHandshake className="w-6 h-6 text-indigo-400" />
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-amber-900 to-amber-950 p-5 rounded-2xl border border-amber-800 text-white shadow-md">
                <div className="flex justify-between items-center">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300">Total GH Claims & Withdrawals</span>
                    <h3 className="text-3xl font-black mt-1">
                      ₹{(
                        helpRequests.reduce((sum, h) => sum + h.amountRequested, 0) +
                        transactions.filter(t => t.type === 'withdrawal').reduce((sum, t) => sum + t.amount, 0)
                      ).toLocaleString()}
                    </h3>
                    <p className="text-[11px] text-amber-200/80 mt-1.5">
                      {helpRequests.length + transactions.filter(t => t.type === 'withdrawal').length} total claims filed
                    </p>
                  </div>
                  <div className="bg-amber-500/20 p-3 rounded-xl border border-amber-500/30">
                    <Users className="w-6 h-6 text-amber-400" />
                  </div>
                </div>
              </div>
            </div>

            {/* Main Content Area */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
              {/* Inner Tabs & Filters */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-100 pb-4">
                <div className="flex flex-wrap bg-slate-100 p-1 rounded-xl border border-slate-200/60 gap-1">
                  <button
                    onClick={() => setOptionTwoSubTab('ph')}
                    className={`px-3 py-1.5 rounded-lg text-[11px] font-black uppercase tracking-wider cursor-pointer transition-all ${
                      optionTwoSubTab === 'ph' 
                        ? 'bg-white text-indigo-700 shadow-xs' 
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    💖 PH User List ({contributions.length})
                  </button>
                  <button
                    onClick={() => setOptionTwoSubTab('pin_active')}
                    className={`px-3 py-1.5 rounded-lg text-[11px] font-black uppercase tracking-wider cursor-pointer transition-all ${
                      optionTwoSubTab === 'pin_active' 
                        ? 'bg-white text-pink-700 shadow-xs' 
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    📌 Pin Active User List ({pinActiveMembers.length})
                  </button>
                  <button
                    onClick={() => setOptionTwoSubTab('gh')}
                    className={`px-3 py-1.5 rounded-lg text-[11px] font-black uppercase tracking-wider cursor-pointer transition-all ${
                      optionTwoSubTab === 'gh' 
                        ? 'bg-white text-amber-700 shadow-xs' 
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    💸 GH User List ({helpRequests.length + transactions.filter(t => t.type === 'withdrawal').length})
                  </button>
                  <button
                    onClick={() => setOptionTwoSubTab('new_joiners')}
                    className={`px-3 py-1.5 rounded-lg text-[11px] font-black uppercase tracking-wider cursor-pointer transition-all ${
                      optionTwoSubTab === 'new_joiners' 
                        ? 'bg-white text-emerald-700 shadow-xs' 
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    🆕 New Joiners & Members ({users.filter(u => u.role !== 'admin').length})
                  </button>
                </div>

                <div className="flex flex-wrap gap-2 w-full sm:w-auto">
                  <input
                    type="text"
                    placeholder="Search name, phone, email, reference ID..."
                    value={optionTwoSearch}
                    onChange={(e) => setOptionTwoSearch(e.target.value)}
                    className="flex-grow sm:flex-grow-0 px-3 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-800 focus:outline-none focus:border-indigo-500"
                  />
                  <select
                    value={optionTwoStatusFilter}
                    onChange={(e) => setOptionTwoStatusFilter(e.target.value as any)}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs bg-white text-slate-700 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="all">🟢 All Statuses</option>
                    <option value="pending">⏳ Pending/Review</option>
                    <option value="approved">✅ Verified/Approved</option>
                    <option value="completed">🎉 Completed</option>
                  </select>
                </div>
              </div>

              {/* PH List View */}
              {optionTwoSubTab === 'ph' && (
                <div className="overflow-x-auto">
                  <table id="option-two-ph-table" className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-100 text-slate-400 uppercase font-black tracking-wider bg-slate-50/50">
                        <th className="p-3">Reference ID</th>
                        <th className="p-3">User Legal Name</th>
                        <th className="p-3">Pledge Amount</th>
                        <th className="p-3">Contact Details</th>
                        <th className="p-3">Submission Date</th>
                        <th className="p-3">Proof Status</th>
                        <th className="p-3">Transaction Gateway</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {(() => {
                        const filteredPh = contributions.filter(c => {
                          const matchesSearch = 
                            c.id.toLowerCase().includes(optionTwoSearch.toLowerCase()) ||
                            c.userName.toLowerCase().includes(optionTwoSearch.toLowerCase()) ||
                            (users.find(u => u.id === c.userId)?.email || '').toLowerCase().includes(optionTwoSearch.toLowerCase()) ||
                            (users.find(u => u.id === c.userId)?.phone || '').includes(optionTwoSearch);
                          
                          let matchesStatus = true;
                          if (optionTwoStatusFilter === 'pending') {
                            matchesStatus = c.status === 'pending_proof' || c.status === 'pending_verification';
                          } else if (optionTwoStatusFilter === 'approved') {
                            matchesStatus = c.status === 'approved';
                          } else if (optionTwoStatusFilter === 'completed') {
                            matchesStatus = c.status === 'approved'; // Approved means completed/progressed in simplex plan
                          }

                          return matchesSearch && matchesStatus;
                        });

                        if (filteredPh.length === 0) {
                          return (
                            <tr>
                              <td colSpan={8} className="text-center py-12 text-slate-400 font-medium italic">
                                No PH (Provide Help) records found matching the current search query or filter.
                              </td>
                            </tr>
                          );
                        }

                        return filteredPh.map(c => {
                          const userProfile = users.find(u => u.id === c.userId);
                          return (
                            <tr id={`option-two-ph-row-${c.id}`} key={c.id} className="hover:bg-slate-50/50 transition-colors">
                              <td className="p-3">
                                <span className="font-mono font-bold bg-slate-100 border border-slate-200 px-2 py-0.5 rounded text-slate-600">
                                  {c.id.substring(0, 8).toUpperCase()}
                                </span>
                              </td>
                              <td className="p-3 font-bold text-slate-800">
                                {c.userName}
                                <span className="block text-[9px] font-semibold text-slate-400 font-mono">UID: {c.userId.substring(0, 8)}</span>
                              </td>
                              <td className="p-3">
                                <span className="font-black text-indigo-600 text-sm">₹{c.amount.toLocaleString()}</span>
                              </td>
                              <td className="p-3 text-slate-600 space-y-0.5">
                                <p className="font-medium">{userProfile?.email || 'N/A'}</p>
                                <p className="font-mono text-[10px] text-slate-400">{userProfile?.phone || 'No Phone'}</p>
                              </td>
                              <td className="p-3 text-slate-500 font-mono">
                                {new Date(c.createdAt).toLocaleDateString()} {new Date(c.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </td>
                              <td className="p-3">
                                <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                                  c.status === 'approved' 
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                                    : c.status === 'pending_verification'
                                    ? 'bg-amber-50 text-amber-700 border border-amber-200'
                                    : 'bg-indigo-50 text-indigo-700 border border-indigo-100'
                                }`}>
                                  {c.status === 'approved' ? 'Verified' : c.status === 'pending_verification' ? 'Uploaded' : 'Waiting'}
                                </span>
                              </td>
                              <td className="p-3">
                                <div className="flex gap-1.5 items-center">
                                  <input
                                    type="text"
                                    placeholder="Enter PH payment Link..."
                                    value={inlinePhLinks[c.id] !== undefined ? inlinePhLinks[c.id] : (c.txLink || '')}
                                    onChange={(e) => setInlinePhLinks(prev => ({ ...prev, [c.id]: e.target.value }))}
                                    className="bg-slate-50 border border-slate-200 rounded-md px-1.5 py-0.5 text-[10px] font-medium focus:outline-none focus:border-indigo-500 text-slate-800 w-24 sm:w-28"
                                  />
                                  <button
                                    onClick={() => {
                                      const linkVal = inlinePhLinks[c.id] !== undefined ? inlinePhLinks[c.id].trim() : (c.txLink || '').trim();
                                      if (!linkVal) {
                                        alert('Please enter a valid PH link.');
                                        return;
                                      }
                                      onUpdateContribution(c.id, c.status, 'PH Link manually updated by Admin', linkVal);
                                      // Send notification
                                      const notif: Notification = {
                                        id: 'notif-' + Math.random().toString(36).substr(2, 9),
                                        userId: c.userId,
                                        title: '🔗 PH Payment Link Manually Sent',
                                        message: `The administrator has manually sent/updated the PH payment link for your ₹${c.amount} contribution. Link: ${linkVal}`,
                                        type: 'info',
                                        read: false,
                                        createdAt: new Date().toISOString()
                                      };
                                      onAddNotification(notif);
                                      alert('PH Link successfully sent to user!');
                                    }}
                                    className="px-2 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-[10px] font-bold uppercase tracking-wider cursor-pointer transition-all"
                                  >
                                    Send
                                  </button>
                                </div>
                                {c.txLink && (
                                  <p className="text-[9px] text-slate-400 font-medium truncate max-w-[200px] mt-1">
                                    Current: <a href={c.txLink} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">{c.txLink}</a>
                                  </p>
                                )}
                              </td>
                              <td className="p-3 text-right">
                                {c.status !== 'approved' ? (
                                  <button
                                    onClick={() => {
                                      if (confirm(`Approve ₹${c.amount} contribution from ${c.userName}?`)) {
                                        onUpdateContribution(c.id, 'approved', 'Approved via Option Two admin directory');
                                        alert('Pledge verified successfully!');
                                      }
                                    }}
                                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-black uppercase tracking-wider cursor-pointer transition-all"
                                  >
                                    Verify Pledge
                                  </button>
                                ) : (
                                  <span className="text-emerald-500 font-bold text-[10px] uppercase">✅ Finalized</span>
                                )}
                              </td>
                            </tr>
                          );
                        });
                      })()}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Pin Active List View */}
              {optionTwoSubTab === 'pin_active' && (
                <div className="overflow-x-auto">
                  <table id="option-two-pin-active-table" className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-100 text-slate-400 uppercase font-black tracking-wider bg-slate-50/50">
                        <th className="p-3">User Legal Name</th>
                        <th className="p-3">Contact Info</th>
                        <th className="p-3">Activation PIN</th>
                        <th className="p-3">Current Step</th>
                        <th className="p-3">Required PH Amt</th>
                        <th className="p-3">Contribution Status</th>
                        <th className="p-3 text-right">Cycle Simulation (Super-User)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {(() => {
                        const filteredPinActive = pinActiveMembers.filter(u => {
                          const matchesSearch = 
                            u.name.toLowerCase().includes(optionTwoSearch.toLowerCase()) ||
                            u.phone.includes(optionTwoSearch) ||
                            u.email.toLowerCase().includes(optionTwoSearch.toLowerCase());
                          return matchesSearch;
                        });

                        if (filteredPinActive.length === 0) {
                          return (
                            <tr>
                              <td colSpan={7} className="text-center py-12 text-slate-400 font-medium italic">
                                No PIN-Active users found matching search query.
                              </td>
                            </tr>
                          );
                        }

                        return filteredPinActive.map(u => {
                          let cycleCount = 1;
                          let currentStepName = "first_ph";
                          try {
                            const saved = localStorage.getItem(`help100_cycle_state_${u.id}`);
                            if (saved) {
                              const parsed = JSON.parse(saved);
                              cycleCount = parsed?.cycleCount || 1;
                              currentStepName = parsed?.currentStep || "first_ph";
                            }
                          } catch (e) {}

                          // Is this user in a PH step? (first_ph or second_ph)
                          const isPhStep = currentStepName === 'first_ph' || currentStepName === 'second_ph';
                          const phAmount = currentStepName === 'first_ph' ? 50 : currentStepName === 'second_ph' ? 50 : 0;

                          // Check if they already have an active/pending contribution in the list
                          const existingContrib = contributions.find(c => 
                            c.userId === u.id && 
                            c.amount === phAmount && 
                            c.remarks?.includes(`Cycle #${cycleCount}`)
                          );

                          // Find PIN used or assigned to this user
                          const matchedPin = issuedPins.find(p => p.userId === u.id && p.isUsed) || 
                                             issuedPins.find(p => p.userId === u.id) ||
                                             issuedPins.find(p => p.isUsed && p.userName === u.name);
                          const pinCodeDisplay = matchedPin ? matchedPin.pinCode : 'N/A';

                          return (
                            <tr id={`option-two-pin-active-row-${u.id}`} key={u.id} className="hover:bg-slate-50/50 transition-colors">
                              <td className="p-3 font-bold text-slate-800">
                                {u.name}
                                <span className="block text-[9px] font-semibold text-slate-400 font-mono">UID: {u.id.substring(0, 8)}</span>
                              </td>
                              <td className="p-3 text-slate-600 space-y-0.5">
                                <p className="font-medium">{u.email}</p>
                                <p className="font-mono text-[10px] text-slate-400">{u.phone}</p>
                              </td>
                              <td className="p-3">
                                <span className="px-2 py-1 rounded bg-rose-50 text-rose-700 text-[10px] font-extrabold font-mono uppercase tracking-wider border border-rose-100">
                                  🔑 {pinCodeDisplay}
                                </span>
                              </td>
                              <td className="p-3">
                                <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 text-[10px] font-bold uppercase tracking-wider">
                                  {currentStepName.replace('_', ' ')} (Cycle #{cycleCount})
                                </span>
                              </td>
                              <td className="p-3">
                                {isPhStep ? (
                                  <span className="font-black text-rose-600 text-sm">₹{phAmount}</span>
                                ) : (
                                  <span className="text-slate-400 italic">No PH Required</span>
                                )}
                              </td>
                              <td className="p-3">
                                {existingContrib ? (
                                  <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider ${
                                    existingContrib.status === 'approved'
                                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                                      : 'bg-amber-50 text-amber-700 border border-amber-100'
                                  }`}>
                                    ✓ Active Contribution ({existingContrib.status === 'approved' ? 'Verified' : existingContrib.status === 'pending_verification' ? 'Uploaded Proof' : 'Awaiting Payment'})
                                  </span>
                                ) : isPhStep ? (
                                  <span className="px-2 py-0.5 rounded-full text-[9px] font-bold uppercase bg-amber-50/50 text-amber-600 animate-pulse border border-amber-100/30">
                                    ⏳ Generating Links
                                  </span>
                                ) : (
                                  <span className="text-slate-400 font-medium italic">N/A</span>
                                )}
                              </td>
                              <td className="p-3 text-right">
                                <div className="flex gap-1.5 justify-end">
                                  {currentStepName !== 'completed' ? (
                                    <span className="text-[10px] text-indigo-600 font-bold bg-indigo-50 px-2.5 py-1 rounded border border-indigo-100">
                                      🔄 Active Cycle Plan
                                    </span>
                                  ) : (
                                    <span className="px-2 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-extrabold rounded uppercase tracking-wider">
                                      🏆 Fully Finished
                                    </span>
                                  )}
                                </div>
                              </td>
                            </tr>
                          );
                        });
                      })()}
                    </tbody>
                  </table>
                </div>
              )}

              {/* GH List View */}
              {optionTwoSubTab === 'gh' && (
                <div className="overflow-x-auto">
                  <table id="option-two-gh-table" className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-100 text-slate-400 uppercase font-black tracking-wider bg-slate-50/50">
                        <th className="p-3">Reference ID</th>
                        <th className="p-3">User Legal Name</th>
                        <th className="p-3">Type</th>
                        <th className="p-3">Amount Requested</th>
                        <th className="p-3">Amount Received</th>
                        <th className="p-3">Contact Details</th>
                        <th className="p-3">Submission Date</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {(() => {
                        const activeHrs = helpRequests.map(h => ({
                          id: h.id,
                          userId: h.userId,
                          userName: h.userName,
                          amountRequested: h.amountRequested,
                          amountReceived: h.amountReceived,
                          type: 'campaign' as const,
                          createdAt: h.createdAt,
                          status: h.status,
                          original: h
                        }));

                        const activeWiths = transactions.filter(t => t.type === 'withdrawal').map(t => ({
                          id: t.id,
                          userId: t.userId,
                          userName: t.userName,
                          amountRequested: t.amount,
                          amountReceived: t.status === 'completed' ? t.amount : 0,
                          type: 'withdrawal' as const,
                          createdAt: t.createdAt,
                          status: t.status,
                          original: t
                        }));

                        const combinedGh = [...activeHrs, ...activeWiths];

                        const filteredGh = combinedGh.filter(item => {
                          const matchesSearch = 
                            item.id.toLowerCase().includes(optionTwoSearch.toLowerCase()) ||
                            item.userName.toLowerCase().includes(optionTwoSearch.toLowerCase()) ||
                            (users.find(u => u.id === item.userId)?.email || '').toLowerCase().includes(optionTwoSearch.toLowerCase()) ||
                            (users.find(u => u.id === item.userId)?.phone || '').includes(optionTwoSearch);
                          
                          let matchesStatus = true;
                          if (optionTwoStatusFilter === 'pending') {
                            matchesStatus = (item.status as string) === 'pending' || (item.status as string) === 'pending_review' || (item.status as string) === 'approved';
                          } else if (optionTwoStatusFilter === 'approved') {
                            matchesStatus = (item.status as string) === 'completed';
                          }

                          return matchesSearch && matchesStatus;
                        });

                        if (filteredGh.length === 0) {
                          return (
                            <tr>
                              <td colSpan={8} className="text-center py-12 text-slate-400 font-medium italic">
                                No GH (Get Help) records found matching the current search query or filter.
                              </td>
                            </tr>
                          );
                        }

                        return filteredGh.map(item => {
                          const userProfile = users.find(u => u.id === item.userId);

                          return (
                            <tr id={`option-two-gh-row-${item.id}`} key={item.id} className="hover:bg-slate-50/50 transition-colors">
                              <td className="p-3">
                                <span className="font-mono font-bold bg-slate-100 border border-slate-200 px-2 py-0.5 rounded text-slate-600">
                                  {item.id.substring(0, 8).toUpperCase()}
                                </span>
                              </td>
                              <td className="p-3 font-bold text-slate-800">
                                {item.userName}
                                <span className="block text-[9px] font-semibold text-slate-400 font-mono">UID: {item.userId.substring(0, 8)}</span>
                              </td>
                              <td className="p-3">
                                <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase ${
                                  item.type === 'campaign' 
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' 
                                    : 'bg-rose-50 text-rose-700 border border-rose-100'
                                }}`}>
                                  {item.type === 'campaign' ? 'Campaign' : 'Withdrawal'}
                                </span>
                              </td>
                              <td className="p-3">
                                <span className="font-black text-amber-600 text-sm">₹{item.amountRequested.toLocaleString()}</span>
                              </td>
                              <td className="p-3 text-slate-700 font-bold">
                                ₹{item.amountReceived.toLocaleString()}
                              </td>
                              <td className="p-3 text-slate-600 space-y-0.5">
                                <p className="font-medium">{userProfile?.email || 'N/A'}</p>
                                <p className="font-mono text-[10px] text-slate-400">{userProfile?.phone || 'No Phone'}</p>
                              </td>
                              <td className="p-3 text-slate-500 font-mono">
                                {new Date(item.createdAt).toLocaleDateString()} {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </td>
                              <td className="p-3">
                                <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                                  item.status === 'completed'
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                                    : item.status === 'pending_review' || item.status === 'pending'
                                    ? 'bg-rose-50 text-rose-700 border border-rose-100'
                                    : 'bg-amber-50 text-amber-700 border border-amber-200'
                                }}`}>
                                  {item.status}
                                </span>
                              </td>

                              <td className="p-3 text-right">
                                {item.status !== 'completed' ? (
                                  <button
                                    onClick={() => {
                                      if (confirm(`Force Mark GH/Payout of ₹${item.amountRequested} for ${item.userName} as Completed?`)) {
                                        if (item.type === 'campaign') {
                                          if (onUpdateHelpRequest) {
                                            onUpdateHelpRequest(item.id, 'completed', item.amountRequested, 'Paid via Option Two admin directory');
                                          }
                                        } else {
                                          onUpdateTransaction(item.id, 'completed');
                                        }
                                        alert('GH campaign payout marked as completed!');
                                      }
                                    }}
                                    className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-lg text-[10px] font-black uppercase tracking-wider cursor-pointer transition-all"
                                  >
                                    Fulfill Payout
                                  </button>
                                ) : (
                                  <span className="text-emerald-500 font-bold text-[10px] uppercase">✅ Paid</span>
                                )}
                              </td>
                            </tr>
                          );
                        });
                      })()}
                    </tbody>
                  </table>
                </div>
              )}

              {/* New Joiners & Members List View */}
              {optionTwoSubTab === 'new_joiners' && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center bg-emerald-50/50 p-4 rounded-xl border border-emerald-100">
                    <div>
                      <p className="text-xs font-black text-emerald-800 uppercase">🆕 Non-Admin User Registry</p>
                      <p className="text-[11px] text-emerald-600 font-medium">Real-time directory of all registered platform members, including pending or new registrations.</p>
                    </div>
                    <span className="bg-emerald-600 text-white font-mono text-[10px] px-2.5 py-1 rounded-full font-black">
                      {users.filter(u => u.role !== 'admin').length} REGISTERED
                    </span>
                  </div>

                  <div className="overflow-x-auto">
                    <table id="option-two-new-joiners-table" className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-slate-100 text-slate-400 uppercase font-black tracking-wider bg-slate-50/50">
                          <th className="p-3">User Legal Name</th>
                          <th className="p-3">Contact Details</th>
                          <th className="p-3">Passcode</th>
                          <th className="p-3">Sponsor / Referred By</th>
                          <th className="p-3">Activation PIN</th>
                          <th className="p-3">KYC Status</th>
                          <th className="p-3 text-right">User Status & Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {(() => {
                          const nonAdminUsers = users.filter(u => u.role !== 'admin');
                          const filteredUsers = nonAdminUsers.filter(u => {
                            const matchesSearch = 
                              u.name.toLowerCase().includes(optionTwoSearch.toLowerCase()) ||
                              u.phone.includes(optionTwoSearch) ||
                              u.email.toLowerCase().includes(optionTwoSearch.toLowerCase()) ||
                              (u.referredBy || '').toLowerCase().includes(optionTwoSearch.toLowerCase());
                            return matchesSearch;
                          });

                          if (filteredUsers.length === 0) {
                            return (
                              <tr>
                                <td colSpan={7} className="text-center py-12 text-slate-400 font-medium italic">
                                  No members found matching the current search query.
                                </td>
                              </tr>
                            );
                          }

                          return filteredUsers.slice(0, newJoinersLimit).map(u => {
                            // Find sponsor name with normalized matching
                            const sponsor = findSponsorInList(u.referredBy, users);
                            const sponsorDisplay = u.referredBy 
                              ? (sponsor ? `${sponsor.name} (${sponsor.referralCode || sponsor.id})` : `Ref Code: ${u.referredBy}`) 
                              : 'None (Direct Join)';

                            // Get Direct Recruits & Total Downline count for this user
                            const getDirects = (targetUser: User): User[] => {
                              return getDirectChildren(targetUser, users);
                            };
                            const directRecruitsList = getDirects(u);
                            
                            const getDownlineCount = (targetUser: User): number => {
                              const visited = new Set<string>([targetUser.id]);
                              let count = 0;
                              const traverse = (usr: User, level: number) => {
                                if (level > 5 || !usr) return;
                                const children = getDirects(usr);
                                const unvisitedChildren = children.filter(c => !visited.has(c.id));
                                unvisitedChildren.forEach(c => visited.add(c.id));
                                count += unvisitedChildren.length;
                                unvisitedChildren.forEach(c => traverse(c, level + 1));
                              };
                              traverse(targetUser, 1);
                              return count;
                            };
                            const downlineCount = getDownlineCount(u);

                            return (
                              <tr id={`option-two-joiner-row-${u.id}`} key={u.id} className="hover:bg-slate-50/50 transition-colors">
                                <td className="p-3">
                                  <p className="font-bold text-slate-800">{u.name}</p>
                                  <p className="text-[10px] text-slate-500 font-mono">UID: {u.id} | <span className="font-black text-emerald-700 bg-emerald-50 px-1 py-0.5 rounded border border-emerald-200">Direct ID: {u.directId || u.referralCode}</span></p>
                                  <p className="text-[9px] text-indigo-500 font-semibold mt-0.5">Joined: {u.registeredAt ? new Date(u.registeredAt).toLocaleString() : 'N/A'}</p>
                                </td>
                                <td className="p-3 space-y-0.5">
                                  <p className="font-medium text-slate-700">{u.email}</p>
                                  <p className="font-mono text-[10px] text-slate-400">{u.phone}</p>
                                </td>
                                <td className="p-3">
                                  <span className="px-2 py-1 rounded bg-amber-100 text-amber-950 font-mono text-[10px] font-black border border-amber-200">
                                    🔑 {u.password || '123456'}
                                  </span>
                                </td>
                                <td className="p-3">
                                  <p className="font-bold text-slate-800 text-[11px]">{sponsorDisplay}</p>
                                  <div className="flex items-center gap-1 mt-1 flex-wrap">
                                    <span className="px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 text-[9px] font-extrabold border border-emerald-100">
                                      👥 Directs: {directRecruitsList.length}
                                    </span>
                                    <span className="px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 text-[9px] font-extrabold border border-indigo-100">
                                      🌐 Downline: {downlineCount}
                                    </span>
                                  </div>
                                </td>
                                <td className="p-3">
                                  {u.registrationPin ? (
                                    <span className="px-2 py-1 rounded bg-rose-50 text-rose-700 text-[10px] font-extrabold font-mono uppercase tracking-wider border border-rose-100">
                                      🎟️ {u.registrationPin}
                                    </span>
                                  ) : (
                                    <span className="text-slate-400 italic">No Pin Consumed</span>
                                  )}
                                </td>
                                <td className="p-3">
                                  <div className="flex items-center gap-1.5">
                                    <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                                      u.kycStatus === 'approved' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' :
                                      u.kycStatus === 'pending' ? 'bg-amber-50 text-amber-700 border border-amber-200 animate-pulse' :
                                      'bg-slate-50 text-slate-500 border border-slate-100'
                                    }`}>
                                      {u.kycStatus}
                                    </span>
                                    {u.kycStatus === 'pending' && (
                                      <button
                                        onClick={() => {
                                          if (confirm(`Directly approve KYC for ${u.name}?`)) {
                                            onUpdateUser({
                                              ...u,
                                              kycStatus: 'approved',
                                              status: 'active'
                                            });
                                            alert(`KYC approved for ${u.name}!`);
                                          }
                                        }}
                                        className="px-1.5 py-0.5 bg-emerald-600 text-white rounded text-[8px] font-bold uppercase hover:bg-emerald-700 transition-all cursor-pointer"
                                      >
                                        Approve
                                      </button>
                                    )}
                                  </div>
                                </td>
                                <td className="p-3 text-right space-y-1.5">
                                  <div className="flex justify-end gap-1 items-center">
                                    <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                                      u.status === 'active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' :
                                      u.status === 'suspended' ? 'bg-rose-50 text-rose-700 border border-rose-100' :
                                      'bg-amber-50 text-amber-700 border border-amber-100'
                                    }`}>
                                      {u.status}
                                    </span>
                                    {u.status !== 'active' ? (
                                      <button
                                        onClick={() => {
                                          onUpdateUser({ ...u, status: 'active', kycStatus: 'approved' });
                                          alert(`${u.name} activated successfully!`);
                                        }}
                                        className="px-2 py-0.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[9px] font-bold uppercase transition-all cursor-pointer"
                                      >
                                        Activate
                                      </button>
                                    ) : (
                                      <button
                                        onClick={() => {
                                          if (confirm(`Are you sure you want to suspend ${u.name}?`)) {
                                            onUpdateUser({ ...u, status: 'suspended' });
                                            alert(`${u.name} suspended!`);
                                          }
                                        }}
                                        className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[9px] font-bold uppercase transition-all cursor-pointer"
                                      >
                                        Suspend
                                      </button>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            );
                          });
                        })()}
                      </tbody>
                    </table>
                  </div>

                  {(() => {
                    const nonAdminUsersCount = users.filter(u => u.role !== 'admin').length;
                    return (
                      <div className="mt-4 flex flex-col sm:flex-row justify-between items-center bg-slate-50 p-3 rounded-xl border border-slate-100 gap-2">
                        <span className="text-slate-500 text-xs">
                          Showing first <b>{Math.min(newJoinersLimit, nonAdminUsersCount)}</b> of <b>{nonAdminUsersCount}</b> total registered members.
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">Limit:</span>
                          <select
                            id="joiners-view-limit-select"
                            value={newJoinersLimit}
                            onChange={(e) => setNewJoinersLimit(parseInt(e.target.value))}
                            className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs font-bold focus:outline-none focus:border-emerald-500"
                          >
                            <option value="10">10 IDs</option>
                            <option value="20">20 IDs</option>
                            <option value="30">30 IDs</option>
                            <option value="40">40 IDs</option>
                            <option value="50">50 IDs</option>
                            <option value="100">100 IDs</option>
                            <option value="500">500 IDs</option>
                            <option value="1000">1,000 IDs</option>
                            <option value="5000">5,000 IDs</option>
                            <option value="10000">10,000 IDs</option>
                            <option value="20000">20,000 IDs</option>
                            <option value="50000">Show All</option>
                          </select>
                          {nonAdminUsersCount > newJoinersLimit && (
                            <button
                              id="load-more-joiners-btn"
                              onClick={() => setNewJoinersLimit(prev => prev + 500)}
                              className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer shadow-xs"
                            >
                              Load More (+500)
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
          </div>
        )}

      </main>

    </div>
  );
}
