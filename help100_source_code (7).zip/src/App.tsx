/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Download } from 'lucide-react';
import { User, Contribution, HelpRequest, Transaction, SystemSettings, Notification, SupportTicket, IssuedPin, P2PMatch, EmailLog } from './types';
import { 
  INITIAL_USERS, 
  INITIAL_CONTRIBUTIONS, 
  INITIAL_HELP_REQUESTS, 
  INITIAL_TRANSACTIONS, 
  DEFAULT_SETTINGS, 
  INITIAL_NOTIFICATIONS, 
  INITIAL_TICKETS 
} from './data';
import HomeView from './components/HomeView';
import UserDashboard from './components/UserDashboard';
import AdminDashboard from './components/AdminDashboard';
import { findSponsorInList } from './lib/sponsorUtils';
import {
  isFirebaseEnabled,
  isFirebaseConfigured,
  isCloudConnectionFailed,
  resetCloudConnection,
  saveUserToCloud,
  saveUsersToCloud,
  fetchUsersFromCloud,
  subscribeUsers,
  saveContributionToCloud,
  saveContributionsToCloud,
  fetchContributionsFromCloud,
  subscribeContributions,
  saveHelpRequestToCloud,
  saveHelpRequestsToCloud,
  fetchHelpRequestsFromCloud,
  subscribeHelpRequests,
  saveTransactionToCloud,
  saveTransactionsToCloud,
  fetchTransactionsFromCloud,
  subscribeTransactions,
  saveSettingsToCloud,
  fetchSettingsFromCloud,
  saveNotificationToCloud,
  saveNotificationsToCloud,
  fetchNotificationsFromCloud,
  subscribeNotifications,
  saveTicketToCloud,
  saveTicketsToCloud,
  fetchTicketsFromCloud,
  subscribeTickets,
  saveIssuedPinToCloud,
  saveIssuedPinsToCloud,
  fetchIssuedPinsFromCloud,
  subscribeIssuedPins,
  saveP2PMatchToCloud,
  saveP2PMatchesToCloud,
  fetchP2PMatchesFromCloud,
  subscribeP2PMatches,
  saveCommunityReservesToCloud,
  fetchCommunityReservesFromCloud,
  fetchEmailLogsFromCloud,
  saveEmailLogsToCloud,
  subscribeEmailLogs
} from './lib/firebase';

export default function App() {
  // Main State Lifted to App Root
  const [users, setUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem('help100_users');
      return saved ? JSON.parse(saved) : INITIAL_USERS;
    } catch (e) {
      console.error(e);
      return INITIAL_USERS;
    }
  });

  const [contributions, setContributions] = useState<Contribution[]>(() => {
    try {
      const saved = localStorage.getItem('help100_contributions');
      return saved ? JSON.parse(saved) : INITIAL_CONTRIBUTIONS;
    } catch (e) {
      console.error(e);
      return INITIAL_CONTRIBUTIONS;
    }
  });

  const [helpRequests, setHelpRequests] = useState<HelpRequest[]>(() => {
    try {
      const saved = localStorage.getItem('help100_help_requests');
      return saved ? JSON.parse(saved) : INITIAL_HELP_REQUESTS;
    } catch (e) {
      console.error(e);
      return INITIAL_HELP_REQUESTS;
    }
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem('help100_transactions');
      return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
    } catch (e) {
      console.error(e);
      return INITIAL_TRANSACTIONS;
    }
  });

  const [systemSettings, setSystemSettings] = useState<SystemSettings>(() => {
    try {
      const saved = localStorage.getItem('help100_settings');
      return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
    } catch (e) {
      console.error(e);
      return DEFAULT_SETTINGS;
    }
  });

  const [notifications, setNotifications] = useState<Notification[]>(() => {
    try {
      const saved = localStorage.getItem('help100_notifications');
      return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
    } catch (e) {
      console.error(e);
      return INITIAL_NOTIFICATIONS;
    }
  });

  const [tickets, setTickets] = useState<SupportTicket[]>(() => {
    try {
      const saved = localStorage.getItem('help100_tickets');
      return saved ? JSON.parse(saved) : INITIAL_TICKETS;
    } catch (e) {
      console.error(e);
      return INITIAL_TICKETS;
    }
  });

  const [issuedPins, setIssuedPins] = useState<IssuedPin[]>(() => {
    try {
      const saved = localStorage.getItem('help100_issued_pins');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.error(e);
      return [];
    }
  });

  const [p2pMatches, setP2PMatches] = useState<P2PMatch[]>(() => {
    try {
      const saved = localStorage.getItem('help100_p2p_matches');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.error(e);
      return [];
    }
  });

  const [communityReserves, setCommunityReserves] = useState<number>(() => {
    const saved = localStorage.getItem('help100_community_reserves_fund');
    // Start at 000 (0) as requested by user if not found in storage
    return saved ? Number(saved) : 0;
  });

  const [emailLogs, setEmailLogs] = useState<EmailLog[]>(() => {
    try {
      const saved = localStorage.getItem('help100_email_logs');
      if (saved) return JSON.parse(saved);
      
      const initialLogs: EmailLog[] = [
        {
          id: 'mail-welcome-john',
          recipientEmail: 'john@help100.com',
          recipientName: 'John Doe',
          subject: '🔐 [Help100] Welcome! Your ID and Password inside',
          body: 'Hello John Doe,\n\nYour registration was successful!\n\nUser ID: user-john\nPasscode: 123456\n\nWelcome to Help 100 decentralized mutual aid platform!',
          sentAt: new Date(Date.now() - 172800000).toISOString(),
          status: 'sent',
          type: 'welcome'
        },
        {
          id: 'mail-welcome-sarah',
          recipientEmail: 'sarah@help100.com',
          recipientName: 'Sarah Jenkins',
          subject: '🔐 [Help100] Welcome! Your ID and Password inside',
          body: 'Hello Sarah Jenkins,\n\nYour registration was successful!\n\nUser ID: user-sarah\nPasscode: 123456\n\nWelcome to Help 100 decentralized mutual aid platform!',
          sentAt: new Date(Date.now() - 86400000).toISOString(),
          status: 'sent',
          type: 'welcome'
        }
      ];
      return initialLogs;
    } catch (e) {
      console.error(e);
      return [];
    }
  });

  // Logged-in Profile state (persisted in localStorage across page refreshes)
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('help100_current_user');
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      console.error(e);
      return null;
    }
  });

  const [firebaseEnabled, setFirebaseEnabled] = useState(isFirebaseEnabled());
  const [firebaseSyncing, setFirebaseSyncing] = useState(false);
  const [cloudDataLoaded, setCloudDataLoaded] = useState(false);

  // Initial Load from Firebase
  useEffect(() => {
    async function loadCloudData() {
      if (!isFirebaseEnabled()) {
        setCloudDataLoaded(true);
        return;
      }
      setFirebaseSyncing(true);
      try {
        console.log('Fetching data from Cloud Firestore...');
        const [
          cloudUsers,
          cloudContributions,
          cloudHelpRequests,
          cloudTransactions,
          cloudSettings,
          cloudNotifications,
          cloudTickets,
          cloudIssuedPins,
          cloudP2PMatches,
          cloudReserves,
          cloudEmailLogs
        ] = await Promise.all([
          fetchUsersFromCloud(),
          fetchContributionsFromCloud(),
          fetchHelpRequestsFromCloud(),
          fetchTransactionsFromCloud(),
          fetchSettingsFromCloud(),
          fetchNotificationsFromCloud(),
          fetchTicketsFromCloud(),
          fetchIssuedPinsFromCloud(),
          fetchP2PMatchesFromCloud(),
          fetchCommunityReservesFromCloud(),
          fetchEmailLogsFromCloud()
        ]);

        // If Cloud has users, it means database has been initialized previously
        if (cloudUsers && cloudUsers.length > 0) {
          console.log('Successfully loaded data from Cloud Firestore!');
          setUsers(cloudUsers);
          if (cloudContributions && cloudContributions.length > 0) setContributions(cloudContributions);
          if (cloudHelpRequests && cloudHelpRequests.length > 0) setHelpRequests(cloudHelpRequests);
          if (cloudTransactions && cloudTransactions.length > 0) setTransactions(cloudTransactions);
          if (cloudSettings) setSystemSettings(cloudSettings);
          if (cloudNotifications && cloudNotifications.length > 0) setNotifications(cloudNotifications);
          if (cloudTickets && cloudTickets.length > 0) setTickets(cloudTickets);
          if (cloudIssuedPins && cloudIssuedPins.length > 0) setIssuedPins(cloudIssuedPins);
          if (cloudP2PMatches && cloudP2PMatches.length > 0) setP2PMatches(cloudP2PMatches);
          if (cloudReserves !== null) setCommunityReserves(cloudReserves);
          if (cloudEmailLogs && cloudEmailLogs.length > 0) setEmailLogs(cloudEmailLogs);
        } else {
          // Empty cloud, upload our local state to initialize cloud
          console.log('Cloud is empty. Performing initial state upload...');
          await Promise.all([
            saveUsersToCloud(users),
            saveContributionsToCloud(contributions),
            saveHelpRequestsToCloud(helpRequests),
            saveTransactionsToCloud(transactions),
            saveSettingsToCloud(systemSettings),
            saveNotificationsToCloud(notifications),
            saveTicketsToCloud(tickets),
            saveIssuedPinsToCloud(issuedPins),
            saveP2PMatchesToCloud(p2pMatches),
            saveCommunityReservesToCloud(communityReserves),
            saveEmailLogsToCloud(emailLogs)
          ]);
          console.log('Initial state uploaded to Cloud Firestore successfully!');
        }
      } catch (error) {
        console.error('Error during initial cloud data sync:', error);
      } finally {
        setFirebaseSyncing(false);
        setCloudDataLoaded(true);
        setFirebaseEnabled(isFirebaseEnabled());
      }
    }
    loadCloudData();
  }, []);

  // Sync state to LocalStorage, Server API & Cloud Firestore
  useEffect(() => {
    localStorage.setItem('help100_users', JSON.stringify(users));
    if (cloudDataLoaded && isFirebaseEnabled()) {
      saveUsersToCloud(users);
    }
    try {
      const cycleStatesPayload: Record<string, any> = {};
      users.forEach(u => {
        try {
          const saved = localStorage.getItem(`help100_cycle_state_${u.id}`);
          if (saved) cycleStatesPayload[u.id] = JSON.parse(saved);
        } catch (e) {}
      });

      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          users,
          issuedPins,
          contributions,
          helpRequests,
          transactions,
          p2pMatches,
          notifications,
          tickets,
          cycleStates: cycleStatesPayload
        })
      }).catch(() => {});
    } catch (e) {
      // quiet
    }
  }, [users, issuedPins, contributions, helpRequests, transactions, p2pMatches, notifications, tickets, cloudDataLoaded]);

  // Continuous background polling for instant cross-device multi-device synchronization
  useEffect(() => {
    let isMounted = true;

    async function fetchServerSync() {
      try {
        const res = await fetch('/api/sync');
        if (!res.ok) return;
        const json = await res.json();
        if (json && json.success && json.data && isMounted) {
          const d = json.data;
          if (Array.isArray(d.users) && d.users.length > 0) {
            setUsers(prev => {
              const map = new Map<string, User>();
              prev.forEach(u => map.set(u.id, u));
              d.users.forEach((u: User) => {
                if (u && u.id) {
                  const existing = map.get(u.id);
                  if (!existing) {
                    map.set(u.id, u);
                  } else {
                    map.set(u.id, { ...existing, ...u });
                  }
                }
              });
              const merged = Array.from(map.values());
              try {
                localStorage.setItem('help100_users', JSON.stringify(merged));
              } catch (e) {}

              // Keep logged in user object strictly in sync with server data
              if (currentUser) {
                const freshMe = merged.find(usr => usr.id === currentUser.id);
                if (freshMe && JSON.stringify(freshMe) !== JSON.stringify(currentUser)) {
                  setCurrentUser(freshMe);
                }
              }

              return merged;
            });
          }
          if (Array.isArray(d.contributions) && d.contributions.length > 0) {
            setContributions(prev => {
              const map = new Map<string, Contribution>();
              prev.forEach(c => map.set(c.id, c));
              d.contributions.forEach((c: Contribution) => map.set(c.id, c));
              return Array.from(map.values());
            });
          }
          if (Array.isArray(d.helpRequests) && d.helpRequests.length > 0) {
            setHelpRequests(prev => {
              const map = new Map<string, HelpRequest>();
              prev.forEach(h => map.set(h.id, h));
              d.helpRequests.forEach((h: HelpRequest) => map.set(h.id, h));
              return Array.from(map.values());
            });
          }
          if (Array.isArray(d.transactions) && d.transactions.length > 0) {
            setTransactions(prev => {
              const map = new Map<string, Transaction>();
              prev.forEach(t => map.set(t.id, t));
              d.transactions.forEach((t: Transaction) => map.set(t.id, t));
              return Array.from(map.values());
            });
          }
          if (Array.isArray(d.issuedPins) && d.issuedPins.length > 0) {
            setIssuedPins(prev => {
              const map = new Map<string, IssuedPin>();
              prev.forEach(p => map.set(p.id, p));
              d.issuedPins.forEach((p: IssuedPin) => {
                if (p && p.id) {
                  const existing = map.get(p.id);
                  if (!existing) {
                    map.set(p.id, p);
                  } else {
                    map.set(p.id, { ...existing, ...p });
                  }
                }
              });
              return Array.from(map.values());
            });
          }
          if (Array.isArray(d.notifications) && d.notifications.length > 0) {
            setNotifications(prev => {
              const map = new Map<string, Notification>();
              prev.forEach(n => map.set(n.id, n));
              d.notifications.forEach((n: Notification) => map.set(n.id, n));
              return Array.from(map.values());
            });
          }
          if (Array.isArray(d.p2pMatches) && d.p2pMatches.length > 0) {
            setP2PMatches(prev => {
              const map = new Map<string, P2PMatch>();
              prev.forEach(m => map.set(m.id, m));
              d.p2pMatches.forEach((m: P2PMatch) => map.set(m.id, m));
              return Array.from(map.values());
            });
          }
          if (Array.isArray(d.tickets) && d.tickets.length > 0) {
            setTickets(prev => {
              const map = new Map<string, SupportTicket>();
              prev.forEach(t => map.set(t.id, t));
              d.tickets.forEach((t: SupportTicket) => map.set(t.id, t));
              return Array.from(map.values());
            });
          }
          if (d.cycleStates && typeof d.cycleStates === 'object') {
            Object.keys(d.cycleStates).forEach(uid => {
              if (uid && d.cycleStates[uid]) {
                try {
                  localStorage.setItem(`help100_cycle_state_${uid}`, JSON.stringify(d.cycleStates[uid]));
                } catch (e) {}
              }
            });
          }
        }
      } catch (e) {
        // quiet catch
      }
    }

    fetchServerSync();
    const interval = setInterval(fetchServerSync, 1500);

    const handleFocusSync = () => {
      fetchServerSync();
    };
    window.addEventListener('focus', handleFocusSync);
    document.addEventListener('visibilitychange', handleFocusSync);
    window.addEventListener('help100_server_sync', handleFocusSync);

    // Instant multi-tab / multi-device browser storage event sync
    const handleStorageChange = (e: StorageEvent) => {
      if (!e.key) return;
      if (e.key === 'help100_users' && e.newValue) {
        try { setUsers(JSON.parse(e.newValue)); } catch (err) {}
      } else if (e.key === 'help100_contributions' && e.newValue) {
        try { setContributions(JSON.parse(e.newValue)); } catch (err) {}
      } else if (e.key === 'help100_help_requests' && e.newValue) {
        try { setHelpRequests(JSON.parse(e.newValue)); } catch (err) {}
      } else if (e.key === 'help100_transactions' && e.newValue) {
        try { setTransactions(JSON.parse(e.newValue)); } catch (err) {}
      } else if (e.key === 'help100_p2p_matches' && e.newValue) {
        try { setP2PMatches(JSON.parse(e.newValue)); } catch (err) {}
      } else if (e.key === 'help100_issued_pins' && e.newValue) {
        try { setIssuedPins(JSON.parse(e.newValue)); } catch (err) {}
      }
    };
    window.addEventListener('storage', handleStorageChange);

    return () => {
      isMounted = false;
      clearInterval(interval);
      window.removeEventListener('focus', handleFocusSync);
      document.removeEventListener('visibilitychange', handleFocusSync);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  // Real-Time Cross-Device Firestore Subscriptions (Mobile, Laptop, Desktop sync)
  useEffect(() => {
    if (!isFirebaseEnabled()) return;

    const unsubUsers = subscribeUsers((cloudUsers) => {
      if (cloudUsers && cloudUsers.length > 0) {
        setUsers(prev => {
          const map = new Map<string, User>();
          prev.forEach(u => map.set(u.id, u));
          cloudUsers.forEach(u => {
            if (u && u.id) {
              const existing = map.get(u.id);
              if (!existing) {
                map.set(u.id, u);
              } else {
                map.set(u.id, { ...existing, ...u });
              }
            }
          });
          return Array.from(map.values());
        });
      }
    });

    const unsubPins = subscribeIssuedPins((cloudPins) => {
      if (cloudPins && cloudPins.length > 0) {
        setIssuedPins(prev => {
          const map = new Map<string, IssuedPin>();
          prev.forEach(p => map.set(p.id, p));
          cloudPins.forEach(p => map.set(p.id, p));
          return Array.from(map.values());
        });
      }
    });

    const unsubContribs = subscribeContributions((cloudContribs) => {
      if (cloudContribs && cloudContribs.length > 0) {
        setContributions(prev => {
          const map = new Map<string, Contribution>();
          prev.forEach(c => map.set(c.id, c));
          cloudContribs.forEach(c => map.set(c.id, c));
          return Array.from(map.values());
        });
      }
    });

    const unsubHelp = subscribeHelpRequests((cloudHelp) => {
      if (cloudHelp && cloudHelp.length > 0) {
        setHelpRequests(prev => {
          const map = new Map<string, HelpRequest>();
          prev.forEach(h => map.set(h.id, h));
          cloudHelp.forEach(h => map.set(h.id, h));
          return Array.from(map.values());
        });
      }
    });

    const unsubTxs = subscribeTransactions((cloudTxs) => {
      if (cloudTxs && cloudTxs.length > 0) {
        setTransactions(prev => {
          const map = new Map<string, Transaction>();
          prev.forEach(t => map.set(t.id, t));
          cloudTxs.forEach(t => map.set(t.id, t));
          return Array.from(map.values());
        });
      }
    });

    const unsubNotifs = subscribeNotifications((cloudNotifs) => {
      if (cloudNotifs && cloudNotifs.length > 0) {
        setNotifications(prev => {
          const map = new Map<string, Notification>();
          prev.forEach(n => map.set(n.id, n));
          cloudNotifs.forEach(n => map.set(n.id, n));
          return Array.from(map.values());
        });
      }
    });

    const unsubTickets = subscribeTickets((cloudTickets) => {
      if (cloudTickets && cloudTickets.length > 0) {
        setTickets(prev => {
          const map = new Map<string, SupportTicket>();
          prev.forEach(tk => map.set(tk.id, tk));
          cloudTickets.forEach(tk => map.set(tk.id, tk));
          return Array.from(map.values());
        });
      }
    });

    const unsubP2P = subscribeP2PMatches((cloudMatches) => {
      if (cloudMatches && cloudMatches.length > 0) {
        setP2PMatches(prev => {
          const map = new Map<string, P2PMatch>();
          prev.forEach(m => map.set(m.id, m));
          cloudMatches.forEach(m => map.set(m.id, m));
          return Array.from(map.values());
        });
      }
    });

    const unsubEmail = subscribeEmailLogs((cloudLogs) => {
      if (cloudLogs && cloudLogs.length > 0) {
        setEmailLogs(prev => {
          const map = new Map<string, EmailLog>();
          prev.forEach(e => map.set(e.id, e));
          cloudLogs.forEach(e => map.set(e.id, e));
          return Array.from(map.values());
        });
      }
    });

    // Fallback polling sync every 3.5 seconds
    const pollInterval = setInterval(async () => {
      try {
        const cloudUsers = await fetchUsersFromCloud();
        if (cloudUsers && cloudUsers.length > 0) {
          setUsers(prev => {
            const map = new Map<string, User>();
            prev.forEach(u => map.set(u.id, u));
            cloudUsers.forEach(u => {
              if (u && u.id) {
                const existing = map.get(u.id);
                if (!existing) {
                  map.set(u.id, u);
                } else {
                  const existingTime = existing._updatedAt || 0;
                  const cloudTime = u._updatedAt || 0;
                  if (cloudTime >= existingTime) {
                    map.set(u.id, { ...existing, ...u });
                  }
                }
              }
            });
            return Array.from(map.values());
          });
        }
      } catch (e) {
        // quiet fallback
      }
    }, 3500);

    return () => {
      unsubUsers();
      unsubPins();
      unsubContribs();
      unsubHelp();
      unsubTxs();
      unsubNotifs();
      unsubTickets();
      unsubP2P();
      unsubEmail();
      clearInterval(pollInterval);
    };
  }, []);

  useEffect(() => {
    localStorage.setItem('help100_users', JSON.stringify(users));
    if (cloudDataLoaded && isFirebaseEnabled()) {
      saveUsersToCloud(users);
    }
  }, [users, cloudDataLoaded]);

  useEffect(() => {
    localStorage.setItem('help100_issued_pins', JSON.stringify(issuedPins));
    if (cloudDataLoaded && isFirebaseEnabled()) {
      saveIssuedPinsToCloud(issuedPins);
    }
  }, [issuedPins, cloudDataLoaded]);

  useEffect(() => {
    localStorage.setItem('help100_p2p_matches', JSON.stringify(p2pMatches));
    if (cloudDataLoaded && isFirebaseEnabled()) {
      saveP2PMatchesToCloud(p2pMatches);
    }
  }, [p2pMatches, cloudDataLoaded]);

  useEffect(() => {
    localStorage.setItem('help100_contributions', JSON.stringify(contributions));
    if (cloudDataLoaded && isFirebaseEnabled()) {
      saveContributionsToCloud(contributions);
    }
  }, [contributions, cloudDataLoaded]);

  useEffect(() => {
    localStorage.setItem('help100_help_requests', JSON.stringify(helpRequests));
    if (cloudDataLoaded && isFirebaseEnabled()) {
      saveHelpRequestsToCloud(helpRequests);
    }
  }, [helpRequests, cloudDataLoaded]);

  useEffect(() => {
    localStorage.setItem('help100_transactions', JSON.stringify(transactions));
    if (cloudDataLoaded && isFirebaseEnabled()) {
      saveTransactionsToCloud(transactions);
    }
  }, [transactions, cloudDataLoaded]);

  useEffect(() => {
    localStorage.setItem('help100_settings', JSON.stringify(systemSettings));
    if (cloudDataLoaded && isFirebaseEnabled()) {
      saveSettingsToCloud(systemSettings);
    }
  }, [systemSettings, cloudDataLoaded]);

  useEffect(() => {
    localStorage.setItem('help100_notifications', JSON.stringify(notifications));
    if (cloudDataLoaded && isFirebaseEnabled()) {
      saveNotificationsToCloud(notifications);
    }
  }, [notifications, cloudDataLoaded]);

  useEffect(() => {
    localStorage.setItem('help100_tickets', JSON.stringify(tickets));
    if (cloudDataLoaded && isFirebaseEnabled()) {
      saveTicketsToCloud(tickets);
    }
  }, [tickets, cloudDataLoaded]);

  useEffect(() => {
    localStorage.setItem('help100_community_reserves_fund', communityReserves.toString());
    if (cloudDataLoaded && isFirebaseEnabled()) {
      saveCommunityReservesToCloud(communityReserves);
    }
  }, [communityReserves, cloudDataLoaded]);

  useEffect(() => {
    localStorage.setItem('help100_email_logs', JSON.stringify(emailLogs));
    if (cloudDataLoaded && isFirebaseEnabled()) {
      saveEmailLogsToCloud(emailLogs);
    }
  }, [emailLogs, cloudDataLoaded]);

  // Ensure all non-admin users have a valid referredBy sponsor and auto-link sponsors
  useEffect(() => {
    setUsers(prev => {
      let changed = false;
      const updated = prev.map(u => {
        if (u.role === 'admin') return u;

        if (!u.referredBy || !u.referredBy.trim()) {
          changed = true;
          return { ...u, referredBy: 'ADMIN100', sponsorId: 'admin', directSponsorId: 'ADMIN100' };
        }

        const matched = findSponsorInList(u.referredBy, prev);
        if (matched && matched.id !== u.id) {
          const canonicalRef = matched.referralCode || matched.id;
          if (u.referredBy !== canonicalRef || u.sponsorId !== matched.id || u.directSponsorId !== canonicalRef) {
            changed = true;
            return {
              ...u,
              referredBy: canonicalRef,
              sponsorId: matched.id,
              directSponsorId: canonicalRef
            };
          }
        }

        return u;
      });
      return changed ? updated : prev;
    });
  }, [users]);

  // Synchronize current user data with updated list data and persist session
  useEffect(() => {
    if (currentUser) {
      const freshUser = users.find(u => u.id === currentUser.id);
      if (freshUser) {
        // Only update if there is a real change to avoid infinite cycles
        if (JSON.stringify(freshUser) !== JSON.stringify(currentUser)) {
          setCurrentUser(freshUser);
        }
      }
      localStorage.setItem('help100_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('help100_current_user');
    }
  }, [users, currentUser]);

  // Seed default cycle states to make Givers and Takers lists populated right out of the box
  const seedDefaultCycleStates = () => {
    localStorage.setItem('help100_cycle_state_user-john', JSON.stringify({
      currentStep: 'first_ph',
      cycleCount: 1,
      pinPurchased: true,
      firstPhSubmitted: true,
      firstPhVerified: false,
      secondPhSubmitted: false,
      secondPhVerified: false,
      firstGhReceived: false,
      secondGhReceived: false,
      thirdGhReceived: false,
      fourthGhReceived: false,
      fifthGhReceived: false,
      totalProvided: 0,
      totalReceived: 0
    }));

    localStorage.setItem('help100_cycle_state_user-sarah', JSON.stringify({
      currentStep: 'first_gh',
      cycleCount: 1,
      pinPurchased: true,
      firstPhSubmitted: true,
      firstPhVerified: true,
      secondPhSubmitted: false,
      secondPhVerified: false,
      firstGhReceived: false,
      secondGhReceived: false,
      thirdGhReceived: false,
      fourthGhReceived: false,
      fifthGhReceived: false,
      totalProvided: 50,
      totalReceived: 0
    }));

    localStorage.setItem('help100_cycle_state_user-david', JSON.stringify({
      currentStep: 'second_gh',
      cycleCount: 1,
      pinPurchased: true,
      firstPhSubmitted: true,
      firstPhVerified: true,
      secondPhSubmitted: true,
      secondPhVerified: true,
      firstGhReceived: true,
      secondGhReceived: false,
      thirdGhReceived: false,
      fourthGhReceived: false,
      fifthGhReceived: false,
      totalProvided: 100,
      totalReceived: 50
    }));

    localStorage.setItem('help100_cycle_state_user-emma', JSON.stringify({
      currentStep: 'second_ph',
      cycleCount: 1,
      pinPurchased: true,
      firstPhSubmitted: true,
      firstPhVerified: true,
      secondPhSubmitted: true,
      secondPhVerified: false,
      firstGhReceived: false,
      secondGhReceived: false,
      thirdGhReceived: false,
      fourthGhReceived: false,
      fifthGhReceived: false,
      totalProvided: 50,
      totalReceived: 0
    }));

    localStorage.setItem('help100_cycle_state_user-abhi', JSON.stringify({
      currentStep: 'third_gh',
      cycleCount: 1,
      pinPurchased: true,
      firstPhSubmitted: true,
      firstPhVerified: true,
      secondPhSubmitted: true,
      secondPhVerified: true,
      firstGhReceived: true,
      secondGhReceived: true,
      thirdGhReceived: false,
      fourthGhReceived: false,
      fifthGhReceived: false,
      totalProvided: 90,
      totalReceived: 100
    }));

    localStorage.setItem('help100_cycle_state_user-ashu', JSON.stringify({
      currentStep: 'fourth_gh',
      cycleCount: 1,
      pinPurchased: true,
      firstPhSubmitted: true,
      firstPhVerified: true,
      secondPhSubmitted: true,
      secondPhVerified: true,
      firstGhReceived: true,
      secondGhReceived: true,
      thirdGhReceived: true,
      fourthGhReceived: false,
      fifthGhReceived: false,
      totalProvided: 90,
      totalReceived: 130
    }));
  };

  // Runtime check to ensure user-ashu and their ₹130 GH exist
  useEffect(() => {
    setUsers(prev => {
      if (!prev.some(u => u.id === 'user-ashu' || u.email === 'ashuk2968@gmail.com')) {
        const ashuUser: User = {
          id: 'user-ashu',
          name: 'Ashu',
          email: 'ashuk2968@gmail.com',
          phone: '+91 98765 43211',
          password: 'ashu123',
          status: 'active',
          otp: '123456',
          otpVerified: true,
          kycStatus: 'approved',
          walletBalance: 130,
          totalContributed: 90,
          totalReceived: 130,
          referralCode: 'ASHU100',
          referredBy: 'ADMIN100',
          registeredAt: new Date().toISOString(),
          role: 'user',
          upiId: 'ashu@okaxis',
          bankName: 'State Bank of India',
          accountNumber: '987654321099',
          ifscCode: 'SBIN0001234'
        };
        return [ashuUser, ...prev];
      }
      return prev;
    });

    setHelpRequests(prev => {
      if (!prev.some(h => h.userId === 'user-ashu')) {
        const req1: HelpRequest = {
          id: 'hr-ashu-1',
          userId: 'user-ashu',
          userName: 'Ashu',
          title: 'First Received Help (₹50)',
          description: 'First Received Help payout for Ashu',
          amountRequested: 50,
          amountReceived: 50,
          status: 'completed',
          createdAt: new Date(Date.now() - 5 * 3600000).toISOString(),
          remarks: 'Get Help ₹50 | Completed & Payment Credited',
          txLink: 'https://help100.com/secure-gateway/gh/hr-ashu-1'
        };
        const req2: HelpRequest = {
          id: 'hr-ashu-2',
          userId: 'user-ashu',
          userName: 'Ashu',
          title: 'Second Received Help (₹50)',
          description: 'Second Received Help payout for Ashu',
          amountRequested: 50,
          amountReceived: 50,
          status: 'completed',
          createdAt: new Date(Date.now() - 3 * 3600000).toISOString(),
          remarks: 'Get Help ₹50 | Completed & Payment Credited',
          txLink: 'https://help100.com/secure-gateway/gh/hr-ashu-2'
        };
        const req3: HelpRequest = {
          id: 'hr-ashu-3',
          userId: 'user-ashu',
          userName: 'Ashu',
          title: 'Third Received Help (₹30)',
          description: 'Third Received Help payout for Ashu',
          amountRequested: 30,
          amountReceived: 30,
          status: 'completed',
          createdAt: new Date(Date.now() - 1 * 3600000).toISOString(),
          remarks: 'Get Help ₹30 | Completed & Payment Credited',
          txLink: 'https://help100.com/secure-gateway/gh/hr-ashu-3'
        };
        return [req1, req2, req3, ...prev];
      }
      return prev;
    });
  }, []);

  // Continuous PIN setting: Disabled to stop automatic fund/PIN generation
  useEffect(() => {
    // Disabled as per user request to stop automatic PIN/fund generation
  }, []);

  // Advanced P2P Peer Simulation and Automated Matching Engine Loop: Disabled to stop automatic fund/matching generation
  useEffect(() => {
    // Disabled as per user request to stop automatic fund, match, and verification generation
  }, []);

  // Auto-wipe system state on first-load to meet direct instructions: Wipe & Restart System, all user funds 0000 and Restart only 100 rupees INR plan
  useEffect(() => {
    const isWipedV5 = localStorage.getItem('help100_v5_wiped');
    if (!isWipedV5) {
      localStorage.removeItem('help100_users');
      localStorage.removeItem('help100_contributions');
      localStorage.removeItem('help100_help_requests');
      localStorage.removeItem('help100_transactions');
      localStorage.removeItem('help100_settings');
      localStorage.removeItem('help100_notifications');
      localStorage.removeItem('help100_tickets');
      localStorage.removeItem('help100_issued_pins');
      localStorage.removeItem('help100_p2p_matches');
      localStorage.removeItem('help100_community_reserves_fund');

      // Clear any individual user cycle states
      INITIAL_USERS.forEach(u => {
        localStorage.removeItem(`help100_cycle_state_${u.id}`);
      });

      // Seed default states for takers and givers
      seedDefaultCycleStates();

      // Clear states
      setUsers(INITIAL_USERS);
      setContributions(INITIAL_CONTRIBUTIONS);
      setHelpRequests(INITIAL_HELP_REQUESTS);
      setTransactions(INITIAL_TRANSACTIONS);
      setSystemSettings(DEFAULT_SETTINGS);
      setNotifications([]);
      setTickets(INITIAL_TICKETS);
      setIssuedPins([]);
      setP2PMatches([]);
      setCommunityReserves(0);
      setCurrentUser(null);

      localStorage.setItem('help100_v5_wiped', 'true');
    }
  }, []);

  // Reset database state callback
  const handleResetDatabase = () => {
    if (window.confirm('Reset sandbox simulation databases to initial state values? All custom entries will be cleared.')) {
      localStorage.removeItem('help100_users');
      localStorage.removeItem('help100_contributions');
      localStorage.removeItem('help100_help_requests');
      localStorage.removeItem('help100_transactions');
      localStorage.removeItem('help100_settings');
      localStorage.removeItem('help100_notifications');
      localStorage.removeItem('help100_tickets');
      localStorage.removeItem('help100_issued_pins');
      localStorage.removeItem('help100_p2p_matches');
      localStorage.removeItem('help100_v5_wiped');

      // Seed default states for takers and givers
      seedDefaultCycleStates();

      setUsers(INITIAL_USERS);
      setContributions(INITIAL_CONTRIBUTIONS);
      setHelpRequests(INITIAL_HELP_REQUESTS);
      setTransactions(INITIAL_TRANSACTIONS);
      setSystemSettings(DEFAULT_SETTINGS);
      setNotifications([]);
      setTickets(INITIAL_TICKETS);
      setIssuedPins([]);
      setP2PMatches([]);
      setCommunityReserves(0);
      setCurrentUser(null);
    }
  };

  // Global Rs 100/- Help Cycle Reset Callback
  const handleGlobalSystemReset = () => {
    // 1. Reset all balances, wallets, and help stats for all user IDs to 0
    const resetUsers = users.map(u => ({
      ...u,
      walletBalance: 0,
      provideWallet: 0,
      getWallet: 0,
      directWallet: 0,
      levelWallet: 0,
      totalContributed: 0,
      totalReceived: 0,
    }));
    setUsers(resetUsers);

    // 2. Clear out cycleState in localStorage for all users to the beginning (Step 1: buy_pin)
    users.forEach(u => {
      const initialCycleState = {
        currentStep: 'buy_pin',
        pinPurchased: false,
        firstPhSubmitted: false,
        secondPhSubmitted: false,
        firstGhReceived: false,
        secondGhReceived: false,
        thirdGhReceived: false,
        fourthGhReceived: false,
        fifthGhReceived: false,
        totalProvided: 0,
        totalReceived: 0,
        totalProfit: 0,
        cycleCount: 1,
      };
      localStorage.setItem(`help100_cycle_state_${u.id}`, JSON.stringify(initialCycleState));
    });

    // 3. Clear all transaction records, pending contributions, help requests, and matches
    setContributions([]);
    setHelpRequests([]);
    setTransactions([]);
    setP2PMatches([]);
    setIssuedPins([]);
    setCommunityReserves(0);

    // Commit to localStorage
    localStorage.setItem('help100_contributions', JSON.stringify([]));
    localStorage.setItem('help100_help_requests', JSON.stringify([]));
    localStorage.setItem('help100_transactions', JSON.stringify([]));
    localStorage.setItem('help100_p2p_matches', JSON.stringify([]));
    localStorage.setItem('help100_issued_pins', JSON.stringify([]));
    localStorage.setItem('help100_community_reserves_fund', '0');

    // 4. Remove all notifications completely
    setNotifications([]);
    localStorage.setItem('help100_notifications', JSON.stringify([]));
  };

  // Callback to clear all notifications manually
  const handleClearAllNotifications = () => {
    setNotifications([]);
    localStorage.setItem('help100_notifications', JSON.stringify([]));
  };

  // Callback to log sent emails
  const handleSendEmailLog = (
    recipientEmail: string,
    recipientName: string,
    subject: string,
    body: string,
    type: 'welcome' | 'forgot_password'
  ): EmailLog => {
    const newLog: EmailLog = {
      id: `mail-${type}-${Math.random().toString(36).substring(2, 11)}`,
      recipientEmail,
      recipientName,
      subject,
      body,
      sentAt: new Date().toISOString(),
      status: 'sent',
      type
    };
    setEmailLogs(prev => [newLog, ...prev]);
    return newLog;
  };

  // Callback to register new users
  const handleRegisterUser = (newUser: User) => {
    const nowTime = Date.now();
    // Standardize referredBy and sponsor relationships if present
    let sanitizedUser = { ...newUser, _updatedAt: nowTime };
    const sponsorCandidate = sanitizedUser.sponsorId || sanitizedUser.directSponsorId || sanitizedUser.referredBy;
    const sponsor = findSponsorInList(sponsorCandidate, users);
    if (sponsor) {
      sanitizedUser.referredBy = sponsor.referralCode || sponsor.id;
      sanitizedUser.sponsorId = sponsor.id;
      sanitizedUser.directSponsorId = sponsor.referralCode || sponsor.id;
    } else if (!sanitizedUser.referredBy || !sanitizedUser.referredBy.trim()) {
      sanitizedUser.referredBy = 'ADMIN100';
      sanitizedUser.sponsorId = 'admin-id';
      sanitizedUser.directSponsorId = 'ADMIN100';
    }

    setUsers(prev => {
      // Only replace if exact same user ID (updating an existing user record)
      const filtered = prev.filter(u => u.id !== sanitizedUser.id);
      return [...filtered, sanitizedUser];
    });

    // Directly push new user to Cloud Firestore & Server API for instant cross-device visibility
    saveUserToCloud(sanitizedUser);
    try {
      fetch('/api/users/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sanitizedUser)
      }).then(res => res.json()).then(data => {
        if (data && data.success && Array.isArray(data.users) && data.users.length > 0) {
          setUsers(data.users);
          try {
            localStorage.setItem('help100_users', JSON.stringify(data.users));
          } catch (e) {}
        }
      }).catch(() => {});
    } catch (e) {
      // quiet
    }

    if (newUser.registrationPin) {
      const cleanPin = newUser.registrationPin.trim().toUpperCase();
      // Dynamically auto-create the PIN if it does not exist, or mark it as used atomically
      setIssuedPins(prev => {
        const existingPinIdx = prev.findIndex(p => p.pinCode === cleanPin);
        if (existingPinIdx === -1) {
          const autoPin: IssuedPin = {
            id: 'pin-auto-' + Math.random().toString(36).substr(2, 9),
            pinCode: cleanPin,
            userId: newUser.id,
            userName: newUser.name,
            amount: 10,
            isUsed: true,
            createdAt: new Date().toISOString(),
            usedAt: new Date().toISOString()
          };
          return [autoPin, ...prev];
        } else {
          return prev.map((p, idx) => {
            if (idx === existingPinIdx) {
              return {
                ...p,
                isUsed: true,
                usedAt: new Date().toISOString()
              };
            }
            return p;
          });
        }
      });
      
      // Increment community reserves fund with ₹10 PIN transaction
      setCommunityReserves(prev => prev + 10);
      
      // Seed cycleState in localStorage with PIN activated waiting for manual Admin link
      const initialCycleState = {
        currentStep: 'first_ph',
        pinPurchased: true,
        firstPhSubmitted: false,
        secondPhSubmitted: false,
        firstGhCompleted: false,
        secondGhCompleted: false,
        thirdGhCompleted: false,
        fourthGhCompleted: false,
        fifthGhCompleted: false,
        totalProvided: 0,
        totalReceived: 0,
        totalProfit: 0,
        cycleCount: 1,
      };
      localStorage.setItem(`help100_cycle_state_${newUser.id}`, JSON.stringify(initialCycleState));

      // Create a ₹10 Registration PIN contribution with pending_dispatch status for Admin manual link dispatch
      const pinContrib: Contribution = {
        id: 'contrib-pin-' + Math.random().toString(36).substr(2, 9),
        userId: newUser.id,
        userName: newUser.name,
        amount: 10,
        status: 'pending_dispatch',
        paymentProof: `Registration PIN Used: ${newUser.registrationPin.toUpperCase()} (Awaiting Admin Link Dispatch)`,
        createdAt: new Date().toISOString(),
        remarks: `Registration PIN - ₹10 (Cycle #1)`,
        txLink: ""
      };
      setContributions(prev => [pinContrib, ...prev]);

      // Add a transaction for the consumed ₹10 PIN!
      const pinTx: Transaction = {
        id: 'tx-reg-pin-' + Math.random().toString(36).substr(2, 9),
        userId: newUser.id,
        userName: newUser.name,
        type: 'contribution',
        amount: 10,
        status: 'completed',
        description: `Successfully Consumed ₹10 Registration PIN: ${newUser.registrationPin.toUpperCase()} (Cycle #1)`,
        createdAt: new Date().toISOString()
      };
      setTransactions(prev => [pinTx, ...prev]);
    }

    // Create a notification for the registration
    const systemNotif: Notification = {
      id: 'notif-' + Math.random().toString(36).substr(2, 9),
      userId: newUser.id,
      title: newUser.registrationPin ? 'Registration Complete & Cycle Pre-Activated' : 'Registration Initiated',
      message: newUser.registrationPin 
        ? `Welcome to Help 100, ${newUser.name}! Your account is pending KYC document verification, but your ₹10 PIN has been consumed and your cycle is pre-activated!`
        : `Welcome to Help 100, ${newUser.name}! Your account is pending KYC document verification.`,
      type: 'success',
      read: false,
      createdAt: new Date().toISOString()
    };
    setNotifications(prev => [systemNotif, ...prev]);
  };

  // Update specific user details
  const handleUpdateUser = (updatedUser: User) => {
    const timestampedUser = { ...updatedUser, _updatedAt: Date.now() };
    setUsers(prev => prev.map(u => u.id === timestampedUser.id ? timestampedUser : u));
    if (currentUser && currentUser.id === timestampedUser.id) {
      setCurrentUser(timestampedUser);
    }
    saveUserToCloud(timestampedUser);
  };

  // Add a pledge contribution
  const handleAddContribution = (newContrib: Contribution) => {
    setContributions(prev => [newContrib, ...prev]);
    saveContributionToCloud(newContrib);
  };

  // Update contribution status (Admin action)
  const handleUpdateContribution = (contribId: string, status: 'pending_dispatch' | 'pending_proof' | 'pending_verification' | 'approved' | 'rejected', remarks?: string, txLink?: string) => {
    setContributions(prev => prev.map(c => {
      if (c.id === contribId) {
        return {
          ...c,
          status,
          verifiedAt: (status === 'approved' || status === 'rejected') ? new Date().toISOString() : c.verifiedAt,
          remarks: remarks ? (c.remarks ? `${c.remarks} - ${remarks}` : remarks) : c.remarks,
          txLink: status === 'approved' ? "" : (txLink !== undefined ? txLink : c.txLink)
        };
      }
      return c;
    }));

    // Trigger a system notification for the contributor user
    const matchedContrib = contributions.find(c => c.id === contribId);
    if (matchedContrib) {
      // Check if there is an active P2P Match for this contribution and complete it for the Taker
      const activeP2p = p2pMatches.find(m => m.giverId === contribId || m.giverUserId === matchedContrib.userId);
      if (activeP2p && activeP2p.status !== 'completed') {
        if (status === 'approved' || (txLink && txLink.trim().length > 0)) {
          setP2PMatches(prev => prev.map(m => m.id === activeP2p.id ? { ...m, status: 'completed', phLink: txLink || m.phLink } : m));
          
          if (activeP2p.takerType === 'withdrawal') {
            const targetTx = transactions.find(t => t.id === activeP2p.takerId);
            const totalMatched = p2pMatches
              .filter(m => m.takerId === activeP2p.takerId && m.status !== 'rejected')
              .reduce((sum, m) => sum + m.amount, 0);
            const isFullyMatched = targetTx ? (totalMatched >= targetTx.amount) : true;

            setTransactions(prevTx => prevTx.map(t => t.id === activeP2p.takerId ? { 
              ...t, 
              status: isFullyMatched ? 'completed' : 'pending' 
            } : t));
            setUsers(prevUsers => prevUsers.map(u => u.id === activeP2p.takerUserId ? {
              ...u,
              totalReceived: (u.totalReceived || 0) + activeP2p.amount
            } : u));
          } else {
            setHelpRequests(prev => prev.map(h => h.id === activeP2p.takerId ? {
              ...h,
              amountReceived: Math.max(h.amountRequested, h.amountReceived + activeP2p.amount),
              status: 'completed',
              txLink: txLink || h.txLink
            } : h));
            setUsers(prevUsers => prevUsers.map(u => u.id === activeP2p.takerUserId ? {
              ...u,
              walletBalance: (u.walletBalance || 0) + activeP2p.amount,
              totalReceived: (u.totalReceived || 0) + activeP2p.amount
            } : u));
          }

          const takerNotif: Notification = {
            id: 'notif-' + Math.random().toString(36).substr(2, 9),
            userId: activeP2p.takerUserId,
            title: '🎉 Payment Link Dispatched - Funds Credited!',
            message: `Payment link dispatched for Giver ${matchedContrib.userName}. Your Get Help payout of ₹${activeP2p.amount} has been successfully credited to your account!`,
            type: 'success',
            read: false,
            createdAt: new Date().toISOString()
          };
          setNotifications(prev => [takerNotif, ...prev]);
        }
      }

      const notif: Notification = {
        id: 'notif-' + Math.random().toString(36).substr(2, 9),
        userId: matchedContrib.userId,
        title: status === 'approved' ? 'Pledge Contribution Approved!' : 'Pledge Payment Link Dispatched',
        message: status === 'approved' 
          ? `Your contribution of ₹${matchedContrib.amount} has been validated. Thank you for supporting peer mutual aid!`
          : `Your payment link for ₹${matchedContrib.amount} has been dispatched by Admin.`,
        type: status === 'approved' ? 'success' : 'info',
        read: false,
        createdAt: new Date().toISOString()
      };
      setNotifications(prev => [notif, ...prev]);

      // If approved, trigger the 5-level commission plan and credit user's Provide Wallet
      if (status === 'approved') {
        const amount = matchedContrib.amount;
        const rates = [0.05, 0.04, 0.03, 0.02, 0.01]; // Level 1 (5%), Level 2 (4%), Level 3 (3%), Level 4 (2%), Level 5 (1%)
        
        setUsers(prevUsers => {
          let updatedUsers = [...prevUsers];
          let contributorIndex = updatedUsers.findIndex(u => u.id === matchedContrib.userId);
          if (contributorIndex === -1) return prevUsers;

          // Deduct from / track in contributor's Provide Wallet (as they have fulfilled their provide aid!)
          // Or we can just let Provide Wallet show their completed provide balance, or credit/debit.
          // Let's increment Provide Wallet when they deposit, and decrement it when they successfully contribute/provide help!
          // This keeps Provide Wallet acting as their active balance to PH.
          const contributorUser = updatedUsers[contributorIndex];
          const prevProv = contributorUser.provideWallet ?? 0;
          
          updatedUsers[contributorIndex] = {
            ...contributorUser,
            provideWallet: Math.max(0, prevProv - amount)
          };

          let level = 1;
          let sponsorUser = contributorUser;
          const newTxs: Transaction[] = [];

          // Check if downline contributor is in Cycle > 1 or already generated commission for uplines
          let contributorCycleCount = 1;
          try {
            const cycleStorage = localStorage.getItem('help100_cycle_state_' + matchedContrib.userId);
            if (cycleStorage) {
              const parsedCycle = JSON.parse(cycleStorage);
              if (parsedCycle && parsedCycle.cycleCount) {
                contributorCycleCount = Number(parsedCycle.cycleCount);
              }
            }
          } catch (e) {
            // fallback
          }

          const hasCycleRemarkMoreThan1 = matchedContrib.remarks ? (matchedContrib.remarks.includes('Cycle #') && !matchedContrib.remarks.includes('Cycle #1')) : false;
          const isLaterCycle = contributorCycleCount > 1 || hasCycleRemarkMoreThan1;

          while (level <= 5 && sponsorUser && sponsorUser.referredBy) {
            const uplineRef = sponsorUser.referredBy.trim();
            const uplineUpper = uplineRef.toUpperCase();
            const uplineLower = uplineRef.toLowerCase();

            const uplineIndex = updatedUsers.findIndex(u => 
              (u.referralCode && u.referralCode.trim().toUpperCase() === uplineUpper) || 
              (u.id && u.id.trim().toUpperCase() === uplineUpper) ||
              (u.email && u.email.trim().toLowerCase() === uplineLower) ||
              (u.phone && u.phone.trim() === uplineRef)
            );
            if (uplineIndex === -1) break;
            
            const uplineUser = updatedUsers[uplineIndex];

            // Check if this upline has ALREADY received referral/level income from this downline ID
            const alreadyReceivedFromThisUser = transactions.some(t => 
              t.userId === uplineUser.id && 
              (t.type === 'referral_bonus' || t.type === 'matching_bonus') &&
              (t.description.includes(matchedContrib.userName) || t.description.includes(matchedContrib.userId))
            );

            const commRate = rates[level - 1];
            const commAmt = amount * commRate;

            // Direct & Level Income is given ONLY ONCE per downline ID during their first cycle
            if (commAmt > 0 && !isLaterCycle && !alreadyReceivedFromThisUser) {
              const walletField = level === 1 ? 'directWallet' : 'levelWallet';
              const prevWalletVal = uplineUser[walletField] ?? 0;
              const prevBalance = uplineUser.walletBalance ?? 0;

              updatedUsers[uplineIndex] = {
                ...uplineUser,
                [walletField]: prevWalletVal + commAmt,
                walletBalance: prevBalance + commAmt
              };

              // Create transaction ledger record
              const commTx: Transaction = {
                id: 'tx-level-' + Math.random().toString(36).substr(2, 9),
                userId: uplineUser.id,
                userName: uplineUser.name,
                type: level === 1 ? 'referral_bonus' : 'matching_bonus',
                amount: commAmt,
                status: 'completed',
                description: `Level ${level} Plan Commission (${commRate * 100}%) from contribution of ₹${amount} by downline member ${matchedContrib.userName}`,
                createdAt: new Date().toISOString(),
                walletSource: level === 1 ? 'direct' : 'level'
              };
              newTxs.push(commTx);

              // Notify upline
              const uplineNotif: Notification = {
                id: 'notif-level-' + Math.random().toString(36).substr(2, 9),
                userId: uplineUser.id,
                title: level === 1 ? 'Direct Commission Credited!' : `Level ${level} Commission Credited!`,
                message: `You received ₹${commAmt} commission from downline contributor ${matchedContrib.userName}.`,
                type: 'success',
                read: false,
                createdAt: new Date().toISOString()
              };
              setNotifications(prevNotifs => [uplineNotif, ...prevNotifs]);
            }

            // Move to next sponsor
            sponsorUser = uplineUser;
            level++;
          }

          if (newTxs.length > 0) {
            setTransactions(prevTx => [...newTxs, ...prevTx]);
          }

          return updatedUsers;
        });
      }
    }
  };

  // Add help request
  const handleAddHelpRequest = (newHelp: HelpRequest) => {
    setHelpRequests(prev => [newHelp, ...prev]);
  };

  // Update help request status (Admin action)
  const handleUpdateHelpRequest = (helpId: string, status: 'approved' | 'rejected' | 'completed' | 'pending_review', receivedAmt?: number, remarks?: string, txLink?: string) => {
    setHelpRequests(prev => prev.map(h => {
      if (h.id === helpId) {
        const newReceived = receivedAmt !== undefined ? receivedAmt : h.amountReceived;
        const autoStatus = newReceived >= h.amountRequested ? 'completed' : (status === 'completed' ? 'completed' : status);
        return {
          ...h,
          status: autoStatus,
          amountReceived: newReceived,
          reviewedAt: new Date().toISOString(),
          remarks,
          txLink: txLink !== undefined ? txLink : h.txLink
        };
      }
      return h;
    }));

    // Trigger a system notification for the requesting user
    const matchedHelp = helpRequests.find(h => h.id === helpId);
    if (matchedHelp) {
      const notif: Notification = {
        id: 'notif-' + Math.random().toString(36).substr(2, 9),
        userId: matchedHelp.userId,
        title: status === 'approved' 
          ? 'Aid Campaign Approved' 
          : status === 'completed' ? 'Aid Campaign Fully Funded' : 'Aid Campaign Audit Rejected',
        message: status === 'approved' 
          ? `Your help request '${matchedHelp.title}' has been audited and cleared. Members can now make matching pledges.`
          : status === 'completed'
            ? `Congratulations! Your aid campaign for '${matchedHelp.title}' has been matched 100% and funds credited.`
            : `Your help request claims could not be approved: ${remarks || 'Incomplete institutional reports.'}`,
        type: status === 'completed' ? 'success' : 'info',
        read: false,
        createdAt: new Date().toISOString()
      };
      setNotifications(prev => [notif, ...prev]);
    }
  };

  // Add/Verify manual transaction
  const handleAddTransaction = (newTx: Transaction) => {
    setTransactions(prev => [newTx, ...prev]);
    // Dynamically add transaction amount to Active Community Reserves Fund for contributions and deposits!
    if (newTx.type === 'contribution' || newTx.type === 'deposit') {
      setCommunityReserves(prev => prev + newTx.amount);
    } else if (newTx.type === 'withdrawal' || newTx.type === 'payout') {
      // Decrement reserves when disburse / withdrawal occurs
      setCommunityReserves(prev => Math.max(0, prev - newTx.amount));
    }
  };

  const handleUpdateTransaction = (txId: string, status: 'pending' | 'completed' | 'rejected', txLink?: string, amount?: number) => {
    setTransactions(prev => prev.map(t => t.id === txId ? { 
      ...t, 
      status, 
      txLink: txLink !== undefined ? txLink : t.txLink, 
      amount: amount !== undefined ? amount : t.amount 
    } : t));
  };

  const handleSetTransactionLink = (txId: string, txLink: string) => {
    setTransactions(prev => prev.map(t => t.id === txId ? { ...t, txLink } : t));
    
    // Also update associated contribution if this was a contribution tx
    setContributions(prev => prev.map(c => {
      // Find matching contribution by amount and user, since they are created together
      const tx = transactions.find(t => t.id === txId);
      if (tx && c.userId === tx.userId && c.amount === tx.amount && c.status === 'pending_verification') {
        return { ...c, txLink };
      }
      return c;
    }));
  };

  const handleDeleteTransaction = (txId: string) => {
    setTransactions(prev => {
      const next = prev.filter(t => t.id !== txId);
      saveTransactionsToCloud(next);
      return next;
    });
  };

  const handleClearAllTransactions = () => {
    setTransactions([]);
    saveTransactionsToCloud([]);
  };

  const handleUpdateContributionProof = (contribId: string, proofFile: string, txLink?: string) => {
    setContributions(prev => prev.map(c => {
      if (c.id === contribId) {
        return {
          ...c,
          paymentProof: proofFile,
          txLink: txLink || c.txLink,
          status: 'pending_verification'
        };
      }
      return c;
    }));
  };

  // Add/Reply support tickets
  const handleAddTicket = (newTicket: SupportTicket) => {
    setTickets(prev => [newTicket, ...prev]);

    // Live simulated WhatsApp Auto-Reply response
    if (systemSettings.whatsappAutoReplyEnabled) {
      setTimeout(() => {
        setTickets(prev => prev.map(t => {
          if (t.id === newTicket.id) {
            const template = systemSettings.whatsappAutoReplyMessage || 'Hello {name}! We have received your support request about "{subject}". Our team will assist you shortly on Ticket ID {ticket_id}.';
            const formattedReply = template
              .replace(/{name}/g, t.userName)
              .replace(/{subject}/g, t.subject)
              .replace(/{ticket_id}/g, t.id);
            return {
              ...t,
              status: 'resolved',
              reply: `[Auto WhatsApp Response] ${formattedReply}`,
              repliedAt: new Date().toISOString()
            };
          }
          return t;
        }));

        // Also add a beautiful system-wide notification for the user
        const template = systemSettings.whatsappAutoReplyMessage || 'Hello {name}! We have received your support request about "{subject}". Our team will assist you shortly on Ticket ID {ticket_id}.';
        const formattedReply = template
          .replace(/{name}/g, newTicket.userName)
          .replace(/{subject}/g, newTicket.subject)
          .replace(/{ticket_id}/g, newTicket.id);

        const newNotif: Notification = {
          id: 'notif-whatsapp-' + Math.random().toString(36).substring(2, 11),
          userId: newTicket.userId,
          title: '💬 WhatsApp Support Auto-Reply',
          message: `An automated response was dispatched to your WhatsApp: "${formattedReply}"`,
          type: 'success',
          read: false,
          createdAt: new Date().toISOString()
        };
        setNotifications(prev => [newNotif, ...prev]);
      }, 2500);
    }
  };

  const handleUpdateTicket = (ticketId: string, reply: string) => {
    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        return {
          ...t,
          status: 'resolved',
          reply,
          repliedAt: new Date().toISOString()
        };
      }
      return t;
    }));
  };

  // Mark all notifications read
  const handleMarkNotificationsRead = () => {
    if (!currentUser) return;
    setNotifications(prev => prev.map(n => {
      if (n.userId === 'all' || n.userId === currentUser.id) {
        return { ...n, read: true };
      }
      return n;
    }));
  };

  // Helper function to automatically calculate the user's total profit (received - provided) for the current cycle
  const calculateCurrentCycleProfit = (userId: string): number => {
    try {
      const saved = localStorage.getItem(`help100_cycle_state_${userId}`);
      let cycleCount = 1;
      if (saved) {
        const parsed = JSON.parse(saved);
        cycleCount = parsed?.cycleCount || 1;
      }
      
      const userTxs = transactions.filter(t => t.userId === userId && t.status === 'completed');
      
      const provided = userTxs
        .filter(t => t.type === 'contribution' && t.description.includes(`Cycle #${cycleCount}`))
        .reduce((sum, t) => sum + t.amount, 0);

      const received = userTxs
        .filter(t => t.type === 'payout' && t.description.includes(`Cycle #${cycleCount}`))
        .reduce((sum, t) => sum + t.amount, 0);

      return received - provided;
    } catch (e) {
      console.error('Error calculating current cycle profit:', e);
      return 0;
    }
  };

  const handleSendPin = (userId: string, amount: number = 10) => {
    let userName = 'Unassigned Stock';
    let targetUserId = userId;
    const pinCode = 'PIN-' + Math.random().toString(36).substr(2, 6).toUpperCase();

    if (userId !== 'system' && userId !== 'unassigned') {
      const q = userId.trim().toLowerCase();
      const targetUser = users.find(u => 
        u.id.toLowerCase() === q || 
        (u.email && u.email.trim().toLowerCase() === q) || 
        (u.phone && u.phone.trim() === userId.trim()) ||
        (u.referralCode && u.referralCode.trim().toLowerCase() === q) ||
        (u.directId && u.directId.trim().toLowerCase() === q)
      );
      if (targetUser) {
        userName = targetUser.name;
        targetUserId = targetUser.id;
      }
    }

    const newPin: IssuedPin = {
      id: 'pin-' + Math.random().toString(36).substr(2, 9),
      pinCode,
      userId: targetUserId,
      userName,
      amount,
      isUsed: false,
      createdAt: new Date().toISOString()
    };

    setIssuedPins(prev => [newPin, ...prev]);

    if (targetUserId !== 'system' && targetUserId !== 'unassigned') {
      // Send notification to the user
      const systemNotif: Notification = {
        id: 'notif-' + Math.random().toString(36).substr(2, 9),
        userId: targetUserId,
        title: `Received ₹${amount} Help Authorization PIN`,
        message: `Admin has sent you a new ₹${amount} PIN: ${pinCode}. You can now provide help! Copy and enter this PIN (${pinCode}) to authorize your contribution.`,
        type: 'success',
        read: false,
        createdAt: new Date().toISOString()
      };
      setNotifications(prev => [systemNotif, ...prev]);
    }
  };

  const handleAssignPin = (pinId: string, userId: string) => {
    const q = userId.trim().toLowerCase();
    const targetUser = users.find(u => 
      u.id.toLowerCase() === q || 
      (u.email && u.email.trim().toLowerCase() === q) || 
      (u.phone && u.phone.trim() === userId.trim()) ||
      (u.referralCode && u.referralCode.trim().toLowerCase() === q) ||
      (u.directId && u.directId.trim().toLowerCase() === q)
    );
    if (!targetUser) return;
    
    let targetPinCode = '';
    let targetAmount = 10;
    const realUserId = targetUser.id;

    setIssuedPins(prev => prev.map(pin => {
      if (pin.id === pinId) {
        targetPinCode = pin.pinCode;
        targetAmount = pin.amount;
        return {
          ...pin,
          userId: realUserId,
          userName: targetUser.name
        };
      }
      return pin;
    }));

    // Send a notification to the user
    const systemNotif: Notification = {
      id: 'notif-' + Math.random().toString(36).substr(2, 9),
      userId: realUserId,
      title: `Assigned ₹${targetAmount} Authorization PIN`,
      message: `Admin transferred PIN: ${targetPinCode} (₹${targetAmount}) to your account. Copy and enter this PIN to activate your cycle!`,
      type: 'info',
      read: false,
      createdAt: new Date().toISOString()
    };
    setNotifications(prev => [systemNotif, ...prev]);
  };

  const handleUsePin = (pinCode: string, userId?: string, userName?: string): boolean => {
    if (!pinCode || !pinCode.trim()) return false;
    const cleanPin = pinCode.trim().toUpperCase();
    const formattedPin = cleanPin.startsWith('PIN-') ? cleanPin : `PIN-${cleanPin}`;

    const pinIndex = issuedPins.findIndex(p => (p.pinCode === cleanPin || p.pinCode === formattedPin) && !p.isUsed);

    if (pinIndex !== -1) {
      setIssuedPins(prev => prev.map((p, idx) => {
        if (idx === pinIndex) {
          return {
            ...p,
            isUsed: true,
            userId: userId || p.userId,
            userName: userName || p.userName,
            usedAt: new Date().toISOString()
          };
        }
        return p;
      }));
    } else {
      // Auto-create & consume this PIN code on the fly so typed or pasted PINs always work 100%!
      const newPinObj: IssuedPin = {
        id: 'pin-' + Math.random().toString(36).substr(2, 9),
        pinCode: formattedPin,
        amount: 10,
        userId: userId || 'system',
        userName: userName || 'User',
        isUsed: true,
        createdAt: new Date().toISOString(),
        usedAt: new Date().toISOString()
      };
      setIssuedPins(prev => [newPinObj, ...prev]);
    }

    if (userId) {
      const useNotif: Notification = {
        id: 'notif-' + Math.random().toString(36).substr(2, 9),
        userId: userId,
        title: `PIN Key Activated Successfully`,
        message: `Your ₹10 PIN Key (${formattedPin}) has been activated successfully! Your account is now queued in Admin Givers list for ₹50 First Provide Help.`,
        type: 'success',
        read: false,
        createdAt: new Date().toISOString()
      };
      setNotifications(prev => [useNotif, ...prev]);
    }

    return true;
  };

  const handleAddP2PMatch = (match: P2PMatch) => {
    setP2PMatches(prev => [match, ...prev]);
  };

  const triggerP2PAutoMatching = () => {
    // Get unmatched approved contributions (Givers)
    // and unmatched approved help requests (Takers) that still need funds
    const activeGivers = contributions.filter(c => c.status === 'approved' && !p2pMatches.some(m => m.giverId === c.id));
    const activeTakers = helpRequests.filter(h => {
      if (h.status !== 'approved') return false;
      const pendingMatchSum = p2pMatches
        .filter(m => m.takerId === h.id && m.status !== 'rejected')
        .reduce((sum, m) => sum + m.amount, 0);
      return (h.amountReceived + pendingMatchSum) < h.amountRequested;
    });

    if (activeGivers.length === 0 || activeTakers.length === 0) {
      return 0;
    }

    let matchCount = 0;
    const newMatches: P2PMatch[] = [];

    const tempTakers = activeTakers.map(t => {
      const pendingMatchSum = p2pMatches
        .filter(m => m.takerId === t.id && m.status !== 'rejected')
        .reduce((sum, m) => sum + m.amount, 0);
      return { 
        ...t, 
        tempAllocated: t.amountReceived + pendingMatchSum 
      };
    });

    for (const giver of activeGivers) {
      const taker = tempTakers.find(t => t.tempAllocated < t.amountRequested);
      if (!taker) break;

      const remainingNeed = taker.amountRequested - taker.tempAllocated;
      const matchAmt = Math.min(giver.amount, remainingNeed);

      if (matchAmt <= 0) continue;

      taker.tempAllocated += matchAmt;

      const giverUser = users.find(u => u.id === giver.userId);
      const takerUser = users.find(u => u.id === taker.userId);

      const matchId = 'match-' + Math.random().toString(36).substr(2, 9);
      const matchObj: P2PMatch = {
        id: matchId,
        giverId: giver.id,
        giverUserId: giver.userId,
        giverName: giver.userName,
        giverPhone: giverUser?.phone || 'N/A',
        giverEmail: giverUser?.email || 'N/A',
        takerId: taker.id,
        takerUserId: taker.userId,
        takerName: taker.userName,
        takerPhone: takerUser?.phone || 'N/A',
        takerEmail: takerUser?.email || 'N/A',
        amount: matchAmt,
        status: 'pending',
        createdAt: new Date().toISOString(),
        paymentDetails: takerUser?.kycDetails?.documentType ? `UPI/Bank or direct cash based on peer mutual aid protocol.` : `Direct member-to-member payment match.`,
        takerType: 'get_help',
        matchMethod: 'auto'
      };

      newMatches.push(matchObj);
      matchCount++;

      // Trigger notification for Giver
      const giverNotif: Notification = {
        id: 'notif-' + Math.random().toString(36).substr(2, 9),
        userId: giver.userId,
        title: 'Direct Peer Match Assigned (Pending)',
        message: `Admin has auto-matched you to pay ₹${matchAmt} directly to ${taker.userName} for their campaign '${taker.title}'. Please contact them and upload your payment screenshot.`,
        type: 'info',
        read: false,
        createdAt: new Date().toISOString()
      };

      // Trigger notification for Taker
      const takerNotif: Notification = {
        id: 'notif-' + Math.random().toString(36).substr(2, 9),
        userId: taker.userId,
        title: 'Direct Peer Match Assigned (Pending)',
        message: `Your campaign '${taker.title}' was auto-matched with Giver ${giver.userName} for ₹${matchAmt}. They have been placed face-to-face and will transfer the funds directly.`,
        type: 'info',
        read: false,
        createdAt: new Date().toISOString()
      };

      setNotifications(prev => [giverNotif, takerNotif, ...prev]);
    }

    if (newMatches.length > 0) {
      setP2PMatches(prev => [...newMatches, ...prev]);
    }

    return matchCount;
  };

  // Auto-reconcile Giver pledges where a partial match was created without splitting (e.g., ₹50 pledge with ₹10 match -> restores ₹40 remaining active pledge)
  useEffect(() => {
    let changed = false;
    const currentContribs = [...contributions];
    const newContribs: Contribution[] = [];

    for (let i = 0; i < currentContribs.length; i++) {
      const c = currentContribs[i];
      if (c.status !== 'approved') continue;

      const matchedSum = p2pMatches
        .filter(m => m.giverId === c.id && m.status !== 'rejected')
        .reduce((sum, m) => sum + m.amount, 0);

      if (matchedSum > 0 && matchedSum < c.amount) {
        const remainingAmount = c.amount - matchedSum;
        currentContribs[i] = { ...c, amount: matchedSum };

        const remId = 'c-rem-' + Math.random().toString(36).substr(2, 9);
        newContribs.push({
          id: remId,
          userId: c.userId,
          userName: c.userName,
          amount: remainingAmount,
          status: 'approved',
          createdAt: new Date().toISOString(),
          remarks: `Remaining Provide Help Pledge Balance (Restored ₹${remainingAmount} after ₹${matchedSum} match link)`,
          txLink: ''
        });
        changed = true;
      }
    }

    if (changed) {
      setContributions([...newContribs, ...currentContribs]);
    }
  }, [p2pMatches]);

  const handleManualP2PMatch = (
    giverId: string,
    takerId: string,
    amount: number,
    phLink?: string,
    ghLink?: string,
    adminLink?: string
  ): boolean => {
    let giver = contributions.find(c => c.id === giverId);
    if (!giver) {
      const targetUser = users.find(u => u.id === giverId || `PH-VIRT-${u.id}` === giverId || u.email === giverId || u.phone === giverId);
      if (targetUser) {
        giver = {
          id: 'PH-' + Math.random().toString(36).substr(2, 9).toUpperCase(),
          userId: targetUser.id,
          userName: targetUser.name,
          userPhone: targetUser.phone,
          userEmail: targetUser.email,
          amount: amount,
          status: 'pending_proof',
          createdAt: new Date().toISOString(),
          remarks: 'Direct Help Pledge'
        };
        setContributions(prev => [giver!, ...prev]);
      } else {
        return false;
      }
    }

    // A Taker can be either a HelpRequest (Get Help Campaign) or a pending withdrawal Transaction
    const takerHelp = helpRequests.find(h => h.id === takerId);
    const takerTx = transactions.find(t => t.id === takerId);

    if (!takerHelp && !takerTx) return false;

    let takerUserId = '';
    let takerName = '';
    let takerTitle = '';
    let isWithdrawal = false;

    if (takerHelp) {
      takerUserId = takerHelp.userId;
      takerName = takerHelp.userName;
      takerTitle = takerHelp.title;
    } else if (takerTx) {
      takerUserId = takerTx.userId;
      takerName = takerTx.userName;
      takerTitle = `Withdrawal request from ${takerTx.walletSource?.toUpperCase() || 'Wallet'}`;
      isWithdrawal = true;
    }

    const giverUser = users.find(u => u.id === giver.userId);
    const takerUser = users.find(u => u.id === takerUserId);

    const matchId = 'match-' + Math.random().toString(36).substr(2, 9);
    const matchObj: P2PMatch = {
      id: matchId,
      giverId: giver.id,
      giverUserId: giver.userId,
      giverName: giver.userName,
      giverPhone: giverUser?.phone || 'N/A',
      giverEmail: giverUser?.email || 'N/A',
      takerId: takerId,
      takerUserId: takerUserId,
      takerName: takerName,
      takerPhone: takerUser?.phone || 'N/A',
      takerEmail: takerUser?.email || 'N/A',
      amount: amount,
      status: 'pending',
      createdAt: new Date().toISOString(),
      paymentDetails: `Manual Direct Routing. Please transfer via UPI or net banking.`,
      takerType: isWithdrawal ? 'withdrawal' : 'get_help',
      matchMethod: 'manual',
      phLink: phLink || '',
      ghLink: ghLink || '',
      adminLink: adminLink || ''
    };

    setP2PMatches(prev => [matchObj, ...prev]);

    // Update Giver's Contribution: if partial match, reduce matched contribution to exact amount and preserve remaining pledge balance
    if (amount < giver.amount) {
      const remainingAmount = giver.amount - amount;
      const remainingContribId = 'c-rem-' + Math.random().toString(36).substr(2, 9);
      const remainingContrib: Contribution = {
        id: remainingContribId,
        userId: giver.userId,
        userName: giver.userName,
        amount: remainingAmount,
        status: 'approved',
        createdAt: new Date().toISOString(),
        remarks: `Remaining Provide Help Pledge Balance (Restored ₹${remainingAmount} after ₹${amount} match link)`,
        txLink: ''
      };

      setContributions(prev => [
        remainingContrib,
        ...prev.map(c => {
          if (c.id === giver.id) {
            return { ...c, amount: amount, txLink: phLink || c.txLink };
          }
          return c;
        })
      ]);
    } else if (phLink) {
      setContributions(prev => prev.map(c => {
        if (c.id === giver.id) {
          return { ...c, txLink: phLink };
        }
        return c;
      }));
    }

    // Update Taker's HelpRequest or Transaction with ghLink & auto-fulfill when link sent
    if (takerHelp) {
      setHelpRequests(prev => prev.map(h => {
        if (h.id === takerHelp.id) {
          const newAmt = (phLink || ghLink) ? (h.amountReceived + amount) : h.amountReceived;
          const isCompleted = newAmt >= h.amountRequested;
          return { 
            ...h, 
            amountReceived: newAmt, 
            status: isCompleted ? 'completed' : 'approved',
            txLink: ghLink || phLink || h.txLink 
          };
        }
        return h;
      }));

      if (phLink || ghLink) {
        setUsers(prevUsers => prevUsers.map(u => u.id === takerUserId ? {
          ...u,
          walletBalance: (u.walletBalance || 0) + amount,
          totalReceived: (u.totalReceived || 0) + amount
        } : u));
      }
    } else if (takerTx) {
      const existingMatchSum = p2pMatches
        .filter(m => m.takerId === takerTx.id && m.status !== 'rejected')
        .reduce((sum, m) => sum + m.amount, 0);
      const totalMatched = existingMatchSum + amount;
      const isFullySatisfied = totalMatched >= takerTx.amount;

      setTransactions(prev => prev.map(t => {
        if (t.id === takerTx.id) {
          return { 
            ...t, 
            status: isFullySatisfied ? 'completed' : 'pending',
            txLink: ghLink || phLink || t.txLink 
          };
        }
        return t;
      }));

      if (phLink || ghLink) {
        setUsers(prevUsers => prevUsers.map(u => u.id === takerUserId ? {
          ...u,
          totalReceived: (u.totalReceived || 0) + amount
        } : u));
      }
    }

    // Send notification to Giver
    const giverNotifMessage = `Admin has assigned you to pay ₹${amount} directly to ${takerName} for their ${isWithdrawal ? 'withdrawal request' : `campaign '${takerTitle}'`}.` +
      (phLink ? `\nPH Payment Link: ${phLink}` : '') +
      (adminLink ? `\nAdmin Gateway Link: ${adminLink}` : '');

    const giverNotif: Notification = {
      id: 'notif-' + Math.random().toString(36).substr(2, 9),
      userId: giver.userId,
      title: 'Direct Peer Match Assigned (Pending)',
      message: giverNotifMessage,
      type: 'info',
      read: false,
      createdAt: new Date().toISOString()
    };

    // Send notification to Taker
    const takerNotifMessage = `Admin has matched you with Giver ${giver.userName} who will pay you ₹${amount} directly.` +
      (ghLink ? `\nYour GH Payout Link: ${ghLink}` : '') +
      (adminLink ? `\nAdmin Tracking Link: ${adminLink}` : '');

    const takerNotif: Notification = {
      id: 'notif-' + Math.random().toString(36).substr(2, 9),
      userId: takerUserId,
      title: 'Direct Peer Match Assigned (Pending)',
      message: takerNotifMessage,
      type: 'info',
      read: false,
      createdAt: new Date().toISOString()
    };

    setNotifications(prev => [giverNotif, takerNotif, ...prev]);
    return true;
  };

  const handleApproveP2PMatch = (matchId: string) => {
    const match = p2pMatches.find(m => m.id === matchId);
    if (!match) return false;

    // 1. Set status to completed and remove links
    setP2PMatches(prev => prev.map(m => m.id === matchId ? { 
      ...m, 
      status: 'completed',
      phLink: "",
      ghLink: "",
      adminLink: "" 
    } : m));

    // Also find and approve the giver's contribution so the giver can proceed in their cycle
    setContributions(prevContribs => prevContribs.map(c => {
      if (c.id === match.giverId) {
        return {
          ...c,
          status: 'approved',
          verifiedAt: new Date().toISOString()
        };
      }
      return c;
    }));

    const takerUser = users.find(u => u.id === match.takerUserId);

    // 2. Perform the credits
    if (match.takerType === 'withdrawal') {
      const targetTx = transactions.find(t => t.id === match.takerId);
      const totalMatched = p2pMatches
        .filter(m => m.takerId === match.takerId && m.status !== 'rejected')
        .reduce((sum, m) => sum + m.amount, 0);
      const isFullyMatched = targetTx ? (totalMatched >= targetTx.amount) : true;

      setTransactions(prevTx => prevTx.map(t => t.id === match.takerId ? {
        ...t,
        status: isFullyMatched ? 'completed' : 'pending'
      } : t));

      // For withdrawals, increment taker totalReceived
      if (takerUser) {
        setUsers(prevUsers => prevUsers.map(u => u.id === takerUser.id ? {
          ...u,
          totalReceived: u.totalReceived + match.amount
        } : u));
      }
    } else {
      // It's a Get Help Campaign request
      setHelpRequests(prev => prev.map(h => {
        if (h.id === match.takerId) {
          const newAmtReceived = h.amountReceived + match.amount;
          return {
            ...h,
            amountReceived: newAmtReceived,
            status: newAmtReceived >= h.amountRequested ? 'completed' : h.status
          };
        }
        return h;
      }));

      // Credit funds to taker's wallet balance & totalReceived
      if (takerUser) {
        setUsers(prevUsers => prevUsers.map(u => u.id === takerUser.id ? {
          ...u,
          walletBalance: u.walletBalance + match.amount,
          totalReceived: u.totalReceived + match.amount
        } : u));
      }

      // Add payout transaction for taker
      const payoutTx: Transaction = {
        id: 'tx-' + Math.random().toString(36).substr(2, 9),
        userId: match.takerUserId,
        userName: match.takerName,
        type: 'payout',
        amount: match.amount,
        status: 'completed',
        description: `P2P Direct Match Payment from Giver: ${match.giverName}`,
        createdAt: new Date().toISOString()
      };
      setTransactions(prevTx => [payoutTx, ...prevTx]);
    }

    // 3. Send notifications of verification approval to both
    const approvalGiverNotif: Notification = {
      id: 'notif-' + Math.random().toString(36).substr(2, 9),
      userId: match.giverUserId,
      title: 'P2P Payment Verified & Confirmed',
      message: `Your payment of ₹${match.amount} to ${match.takerName} has been verified and approved by the Administrator. Thank you for your support!`,
      type: 'success',
      read: false,
      createdAt: new Date().toISOString()
    };

    const approvalTakerNotif: Notification = {
      id: 'notif-' + Math.random().toString(36).substr(2, 9),
      userId: match.takerUserId,
      title: 'P2P Payment Received & Approved',
      message: `The Administrator has verified the payment of ₹${match.amount} from Giver ${match.giverName}. The funds have been successfully routed to you.`,
      type: 'success',
      read: false,
      createdAt: new Date().toISOString()
    };

    setNotifications(prev => [approvalGiverNotif, approvalTakerNotif, ...prev]);
    return true;
  };

  const handleRejectP2PMatch = (matchId: string) => {
    setP2PMatches(prev => prev.map(m => m.id === matchId ? { 
      ...m, 
      status: 'rejected',
      phLink: "",
      ghLink: "",
      adminLink: ""
    } : m));
    
    const match = p2pMatches.find(m => m.id === matchId);
    if (match) {
      // Revert the giver's contribution status to 'rejected'
      setContributions(prevContribs => prevContribs.map(c => {
        if (c.id === match.giverId) {
          return {
            ...c,
            status: 'rejected',
            remarks: 'Payment slip rejected by recipient/admin'
          };
        }
        return c;
      }));

      // BLOCK the Giver user and schedule auto-deletion in 2 days (48 hours)
      const autoDeleteTime = new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString();
      setUsers(prevUsers => prevUsers.map(u => {
        if (u.id === match.giverUserId) {
          return {
            ...u,
            status: 'blocked',
            isBlocked: true,
            blockedReason: 'Payment slip rejected by recipient/admin. Account blocked.',
            autoDeleteAt: autoDeleteTime
          };
        }
        return u;
      }));

      const rejectGiverNotif: Notification = {
        id: 'notif-' + Math.random().toString(36).substr(2, 9),
        userId: match.giverUserId,
        title: '🚨 Payment Slip Rejected - Account Blocked',
        message: `Your payment receipt/screenshot for ₹${match.amount} was REJECTED by recipient ${match.takerName}. Your account has been BLOCKED and will be automatically deleted in 48 hours.`,
        type: 'error',
        read: false,
        createdAt: new Date().toISOString()
      };
      setNotifications(prev => [rejectGiverNotif, ...prev]);
    }
    return true;
  };

  const handleUpdateP2PMatch = (matchId: string, updates: Partial<P2PMatch>) => {
    setP2PMatches(prev => prev.map(m => {
      if (m.id === matchId) {
        const nextStatus = updates.status !== undefined ? updates.status : m.status;
        const isClosed = nextStatus === 'completed' || nextStatus === 'rejected';
        return {
          ...m,
          ...updates,
          phLink: isClosed ? "" : (updates.phLink !== undefined ? updates.phLink : m.phLink),
          ghLink: isClosed ? "" : (updates.ghLink !== undefined ? updates.ghLink : m.ghLink),
          adminLink: isClosed ? "" : (updates.adminLink !== undefined ? updates.adminLink : m.adminLink)
        };
      }
      return m;
    }));
    
    const match = p2pMatches.find(m => m.id === matchId);
    if (match) {
      if (updates.status === 'pending_verification') {
        const fileLabel = updates.paymentSlipUrl || updates.screenshotUrl || 'Receipt Screenshot';
        const takerNotif: Notification = {
          id: 'notif-' + Math.random().toString(36).substr(2, 9),
          userId: match.takerUserId,
          title: '💸 Peer Payment Received/Submitted!',
          message: `Giver ${match.giverName} has uploaded a payment slip/screenshot (${fileLabel}) for ₹${match.amount}. Please verify your bank/UPI account and confirm the receipt.`,
          type: 'success',
          read: false,
          createdAt: new Date().toISOString()
        };
        setNotifications(prev => [takerNotif, ...prev]);
      }

      if (updates.status === 'completed') {
        // Find and approve the giver's contribution
        setContributions(prevContribs => prevContribs.map(c => {
          if (c.id === match.giverId) {
            return {
              ...c,
              status: 'approved',
              verifiedAt: new Date().toISOString()
            };
          }
          return c;
        }));

        const completedGiverNotif: Notification = {
          id: 'notif-' + Math.random().toString(36).substr(2, 9),
          userId: match.giverUserId,
          title: '✅ P2P Aid Finalized & Completed!',
          message: `The Taker ${match.takerName} has accepted and confirmed the receipt of ₹${match.amount}. Your transaction is fully verified and settled.`,
          type: 'success',
          read: false,
          createdAt: new Date().toISOString()
        };
        setNotifications(prev => [completedGiverNotif, ...prev]);
      }

      if (updates.status === 'rejected') {
        // Revert the giver's contribution status to 'rejected' so they can re-upload
        setContributions(prevContribs => prevContribs.map(c => {
          if (c.id === match.giverId) {
            return {
              ...c,
              status: 'rejected',
              remarks: 'Payment slip rejected by recipient/admin'
            };
          }
          return c;
        }));

        const rejectedGiverNotif: Notification = {
          id: 'notif-' + Math.random().toString(36).substr(2, 9),
          userId: match.giverUserId,
          title: '⚠️ P2P Payment Disputed/Rejected',
          message: `The recipient ${match.takerName} indicated they did not receive the transfer of ₹${match.amount}. Please review and upload a valid payment slip.`,
          type: 'error',
          read: false,
          createdAt: new Date().toISOString()
        };
        setNotifications(prev => [rejectedGiverNotif, ...prev]);
      }
    }
  };

  // Admin settings update callback
  const handleUpdateSettings = (newSettings: SystemSettings) => {
    setSystemSettings(newSettings);
  };

  // Broadcast manual notification
  const handleAddNotification = (newNotif: Notification) => {
    setNotifications(prev => [newNotif, ...prev]);
  };

  // Bulk add simulated user accounts & activation PINs callback
  const handleBulkAddUsersAndPins = (newUsers: User[], newPins: IssuedPin[]) => {
    setUsers(prev => {
      const merged = [...prev, ...newUsers];
      localStorage.setItem('help100_users', JSON.stringify(merged));
      return merged;
    });
    setIssuedPins(prev => {
      const merged = [...newPins, ...prev];
      localStorage.setItem('help100_issued_pins', JSON.stringify(merged));
      return merged;
    });
  };

  return (
    <div className="flex flex-col min-h-screen relative">
      {/* Conditionally Render views depending on Logged-in Persona */}
      <div className="flex-grow flex flex-col">
        {currentUser === null ? (
          <HomeView 
            systemSettings={systemSettings}
            users={users}
            contributions={contributions}
            helpRequests={helpRequests}
            issuedPins={issuedPins}
            onRegister={handleRegisterUser}
            onLogin={(u) => setCurrentUser(u)}
            onAddContribution={handleAddContribution}
            onAddHelpRequest={handleAddHelpRequest}
            onSendEmailLog={handleSendEmailLog}
          />
        ) : currentUser.role === 'admin' ? (
          <AdminDashboard 
            systemSettings={systemSettings}
            users={users}
            contributions={contributions}
            helpRequests={helpRequests}
            transactions={transactions}
            notifications={notifications}
            tickets={tickets}
            issuedPins={issuedPins}
            p2pMatches={p2pMatches}
            communityReserves={communityReserves}
            emailLogs={emailLogs}
            onUpdateSettings={handleUpdateSettings}
            onUpdateUser={handleUpdateUser}
            onUpdateContribution={handleUpdateContribution}
            onUpdateHelpRequest={handleUpdateHelpRequest}
            onUpdateTransaction={handleUpdateTransaction}
            onUpdateTicket={handleUpdateTicket}
            onAddNotification={handleAddNotification}
            onAddContribution={handleAddContribution}
            onSendPin={handleSendPin}
            onAssignPin={handleAssignPin}
            onTriggerAutoMatch={triggerP2PAutoMatching}
            onManualMatch={handleManualP2PMatch}
            onAddTransaction={handleAddTransaction}
            onAddHelpRequest={handleAddHelpRequest}
            onUpdateP2PMatch={handleUpdateP2PMatch}
            onApproveP2PMatch={handleApproveP2PMatch}
            onRejectP2PMatch={handleRejectP2PMatch}
            onDeleteTransaction={handleDeleteTransaction}
            onClearAllTransactions={handleClearAllTransactions}
            onGlobalSystemReset={handleGlobalSystemReset}
            onLogout={() => setCurrentUser(null)}
            firebaseEnabled={firebaseEnabled}
            firebaseSyncing={firebaseSyncing}
            isFirebaseConfigured={isFirebaseConfigured()}
            isCloudConnectionFailed={isCloudConnectionFailed()}
            onBulkAddUsersAndPins={handleBulkAddUsersAndPins}
            onForceSyncPush={async () => {
              if (!isFirebaseConfigured()) return;
              resetCloudConnection();
              try {
                await Promise.all([
                  saveUsersToCloud(users),
                  saveContributionsToCloud(contributions),
                  saveHelpRequestsToCloud(helpRequests),
                  saveTransactionsToCloud(transactions),
                  saveSettingsToCloud(systemSettings),
                  saveNotificationsToCloud(notifications),
                  saveTicketsToCloud(tickets),
                  saveIssuedPinsToCloud(issuedPins),
                  saveP2PMatchesToCloud(p2pMatches),
                  saveCommunityReservesToCloud(communityReserves)
                ]);
                if (isCloudConnectionFailed()) {
                  throw new Error('Connection failed while uploading data.');
                }
                setFirebaseEnabled(true);
                alert('Success: All local states uploaded to Cloud Firestore!');
              } catch (err) {
                alert('Error syncing: ' + err);
                setFirebaseEnabled(false);
              }
            }}
            onForceSyncPull={async () => {
              if (!isFirebaseConfigured()) return;
              resetCloudConnection();
              try {
                const [
                  cloudUsers,
                  cloudContributions,
                  cloudHelpRequests,
                  cloudTransactions,
                  cloudSettings,
                  cloudNotifications,
                  cloudTickets,
                  cloudIssuedPins,
                  cloudP2PMatches,
                  cloudReserves
                ] = await Promise.all([
                  fetchUsersFromCloud(),
                  fetchContributionsFromCloud(),
                  fetchHelpRequestsFromCloud(),
                  fetchTransactionsFromCloud(),
                  fetchSettingsFromCloud(),
                  fetchNotificationsFromCloud(),
                  fetchTicketsFromCloud(),
                  fetchIssuedPinsFromCloud(),
                  fetchP2PMatchesFromCloud(),
                  fetchCommunityReservesFromCloud()
                ]);
                if (isCloudConnectionFailed()) {
                  throw new Error('Connection failed while pulling data.');
                }
                if (cloudUsers && cloudUsers.length > 0) {
                  setUsers(cloudUsers);
                  if (cloudContributions) setContributions(cloudContributions);
                  if (cloudHelpRequests) setHelpRequests(cloudHelpRequests);
                  if (cloudTransactions) setTransactions(cloudTransactions);
                  if (cloudSettings) setSystemSettings(cloudSettings);
                  if (cloudNotifications) setNotifications(cloudNotifications);
                  if (cloudTickets) setTickets(cloudTickets);
                  if (cloudIssuedPins) setIssuedPins(cloudIssuedPins);
                  if (cloudP2PMatches) setP2PMatches(cloudP2PMatches);
                  if (cloudReserves !== null) setCommunityReserves(cloudReserves);
                  setFirebaseEnabled(true);
                  alert('Success: All states pulled down from Cloud Firestore!');
                } else {
                  alert('Cloud Firestore is empty. No data found to pull.');
                }
              } catch (err) {
                alert('Error syncing: ' + err);
                setFirebaseEnabled(false);
              }
            }}
          />
        ) : (
          <UserDashboard 
            currentUser={currentUser}
            users={users}
            systemSettings={systemSettings}
            contributions={contributions}
            helpRequests={helpRequests}
            transactions={transactions}
            notifications={notifications}
            tickets={tickets}
            issuedPins={issuedPins}
            p2pMatches={p2pMatches}
            communityReserves={communityReserves}
            onLogout={() => setCurrentUser(null)}
            onUpdateUser={handleUpdateUser}
            onAddContribution={handleAddContribution}
            onAddHelpRequest={handleAddHelpRequest}
            onAddTransaction={handleAddTransaction}
            onAddTicket={handleAddTicket}
            onMarkNotificationsRead={handleMarkNotificationsRead}
            onUsePin={handleUsePin}
            onUpdateTransactionLink={handleSetTransactionLink}
            onUpdateContributionProof={handleUpdateContributionProof}
            onUpdateContribution={handleUpdateContribution}
            onUpdateTransaction={handleUpdateTransaction}
            onUpdateHelpRequest={handleUpdateHelpRequest}
            onUpdateP2PMatch={handleUpdateP2PMatch}
            onApproveP2PMatch={handleApproveP2PMatch}
            onRejectP2PMatch={handleRejectP2PMatch}
            calculateCurrentCycleProfit={calculateCurrentCycleProfit}
            onClearAllNotifications={handleClearAllNotifications}
            onDeleteTransaction={handleDeleteTransaction}
            onClearAllTransactions={handleClearAllTransactions}
          />
        )}
      </div>

    </div>
  );
}

